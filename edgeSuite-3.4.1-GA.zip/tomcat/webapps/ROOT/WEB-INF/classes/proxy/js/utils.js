/*
 * Copyright 2016 Edge Technologies
 */

var edgeWeb = (function () {

    var cachedTop = null;

    return {

        getFrameName: function(frame) {

            var frameElement = frame.frameElement;
            if (frameElement) {
                var name = frameElement.getAttribute("name");
                if (name) {
                    return name;
                }
            }
            return "";
        },

        getTop: function() {

            if ( cachedTop == null ) {
                var retFrame = null;
                if (window != top && this.getFrameName(window).indexOf('edgeWebTop') != -1) {
                    retFrame = window;
                } else {
                    retFrame = parent;
                    var i = 0;
                    while (retFrame != top && i < 10) {
                        if (this.getFrameName(retFrame).indexOf('edgeWebTop') != -1) {
                            break;
                        } else {
                            i++;
                            retFrame = retFrame.parent;
                        }
                    }
                    if (retFrame == top) {
                        retFrame = ((top.opener != null) ? top.opener : top);
                    }
                    if (i == 10) {
                        retFrame = window;
                        alert('Unable to find edgeWebTop. Current Frame Name: ' + this.getFrameName(window));
                    }
                }
                cachedTop = retFrame;
            }
            return cachedTop;
        }
    };

})();
