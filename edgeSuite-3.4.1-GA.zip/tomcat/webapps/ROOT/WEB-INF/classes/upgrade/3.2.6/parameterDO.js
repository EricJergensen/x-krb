logger.info("*******************************************");
logger.info("*       updating ParameterDO              *");
logger.info("*******************************************");

var String = Java.type("java.lang.String");
var Long = Java.type("java.lang.Long");
var Double = Java.type("java.lang.Double");
var Math = Java.type("java.lang.Math");
upgradeUtil.updateAllObjects("ParameterDO", function(parameterDO) {
    if (parameterDO.parameterConstraintId === "DEFAULT_NUMBER_CONSTRAINT") {
        var existing = JSON.stringify(parameterDO);
        if (typeof parameterDO.defaultValue === 'string' || parameterDO.defaultValue instanceof String) {
            try {
        			var defaultVal = Double.valueOf(parameterDO.defaultValue);
        			if ( Math.floor(defaultVal) == defaultVal ) {
            			parameterDO.defaultValue = defaultVal.longValue();
        			} else {
            			parameterDO.defaultValue = defaultVal;
        			}
            } catch ( e ) {
            }
        }
    }
    return parameterDO;
});

