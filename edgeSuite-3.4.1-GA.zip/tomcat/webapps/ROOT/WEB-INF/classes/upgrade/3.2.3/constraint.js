logger.info("***********************************************");
logger.info("*          updating Constraints               *");
logger.info("***********************************************");

// look for the ParameterConstraintDO definitions themselves (PageDOs erroneously contain redundant definitions,
// which we need to ignore).
var constraintFile = null;
var jsonFileNames = upgradeUtil.listAllJsonFiles();

for (var key in jsonFileNames) {
    if (jsonFileNames[key].indexOf("ParameterConstraintDO.json") >= 0) {
        constraintFile = jsonFileNames[key];
    }
}

if (constraintFile) {
    var constraintTypes = ["StringParameterConstraintDO", "NumberParameterConstraintDO", "RealtimeParameterConstraintDO"];

    for (var i in constraintTypes) {

        logger.debug("checking {}", constraintTypes[i]);

        upgradeUtil.updateAllObjectsInFile(constraintFile, constraintTypes[i], function (constraint) {

            if (constraint.id.startsWith('DEFAULT_')) {

                var parameterService = upgradeUtil.getBean('parameterService');

                var existingConstraint = parameterService.getParameterConstraint(constraint.id);

                if (existingConstraint) {
                    // drop from archive - we know that default constraints haven't been modified
                    logger.debug("dropped redundant constraint definition {}", existingConstraint.getName());
                    return null;
                }
            }

            return constraint;

        }, false);
    }
}
