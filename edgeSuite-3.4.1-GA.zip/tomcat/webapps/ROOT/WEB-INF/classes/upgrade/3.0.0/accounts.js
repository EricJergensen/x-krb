logger.info("***********************************************");
logger.info("*       updating Accounts                     *");
logger.info("***********************************************");

var userPath = "AccountAdapterManager/AccountAdapterRestoreBundleDO.json";

var accountUserMeta = {
    "doClass" : "AccountUserMetaDO",
    "id" : "1",
    "creationTime" : 0,
    "currentLogin" : 0,
    "failures" : 0,
    "lastChange" : 0,
    "changedByAdmin" : false,
    "lastFailure" : 0,
    "lastLogin" : 0,
    "temporaryLock" : false,
    "permanentLock" : false,
    "lockTime" : 0,
    "lockReason" : "",
    "acceptedFormNames" : [ ]
}

function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + s4();
}

function process(key,value) {
    // do nothing; debug only
    // logObjectWithLabel(key, value);
}

function traverse(o,func) {
	if (o["backupClass"] === "edge.server.account.adapter.embedded.AccountUser" ) {
		for (var i=0; i<o["objects"].length; i++) {
			if (o["objects"][i].accountUserMeta == null) {
				o["objects"][i].accountUserMeta = JSON.parse(JSON.stringify(accountUserMeta));
				o["objects"][i].accountUserMeta.id = guid() + i;
			}
		}
	}
    for (var i in o) {
        func.apply(this,[i,o[i]]);  
        if (o[i] !== null && typeof(o[i])=="object") {
            //going on step down in the object tree!!
            traverse(o[i],func);
        }
    }
}

if (upgradeUtil.fileExists(userPath)) {
    var json = upgradeUtil.readFileByPath(userPath);
    var users = JSON.parse(json);

    traverse(users, process)
    upgradeUtil.writeFile(userPath, JSON.stringify(users));
}
