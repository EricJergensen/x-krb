logger.info("***********************************************");
logger.info("*       updating Filter Transforms            *");
logger.info("***********************************************");

var path = "DataProducerService/AbstractTabularProducerDO.json";

var DataAttributeTypeDO = Java.type("edge.server.pipeline.data.document.DataAttributeTypeDO");

var updateExpressionJSON = function(expressionTokenDO) {
	if (expressionTokenDO.doClass == "ExpressionDO") {
		if (expressionTokenDO.tokens != null) {
			for (var t = 0; t < expressionTokenDO.tokens.length; t++) {
				var token = expressionTokenDO.tokens[t];
				token = updateExpressionJSON(token);
			}
		}
	} else if (expressionTokenDO.doClass == "ExpressionRuleDO") {
		if ( logger.isTraceEnabled() ) {
	        logger.trace("converting DataAttributeTypeDO value: {} => {}", expressionTokenDO.type, DataAttributeTypeDO.byTypeName(expressionTokenDO.type).getOrdinal());
		}
        expressionTokenDO.type = DataAttributeTypeDO.byTypeName(expressionTokenDO.type).getOrdinal();
	}
	
	return expressionTokenDO;
	
};

if (upgradeUtil.fileExists(path)) {
	upgradeUtil.updateAllObjectsInFile(path, "TabularTransformDO", function(transformDO) {
		if (transformDO.typeName == "GUISelect") {
			for (var i = 0; i < transformDO.properties.propertyValues.length; i++) {
				var property = transformDO.properties.propertyValues[i];
				if (property.propertyDefName == "sort") {
					logger.info("Found GUISelect needing sort upgrade...Fixing.")
					property.propertyDefName = "sorts";
				} else if (property.propertyDefName == "expression") {
					logger.info("Found GUISelect needing expression upgrade...Fixing.")
					var valueJSON = JSON.parse(property.value);
					valueJSON = updateExpressionJSON(valueJSON);
					property.value = JSON.stringify(valueJSON);
				}
			}
		}
       return transformDO; 
    }, true);    
}