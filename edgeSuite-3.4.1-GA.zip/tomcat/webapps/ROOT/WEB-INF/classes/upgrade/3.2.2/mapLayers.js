logger.info("***********************************************");
logger.info("*          updating Map Layers                *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("MapLayerDO", function(layer) {
	switch (layer.name) {
	case "openstreetmap":
		layer.id = "_system_openstreetmap";
		break;
	case "opencyclemap":
		layer.id = "_system_opencyclemap";
		break;
	case "nasa":
		layer.id = "_system_nasa";
		break;
	case "watercolor":
		layer.id = "_system_watercolor";
		break;
	case "toner":
		layer.id = "_system_toner";
		break;
	case "cartolight":
		layer.id = "_system_cartolight";
		break;
	case "cartodark":
		layer.id = "_system_cartodark";
		break;
	case "blanklight":
		layer.id = "_system_blanklight";
		break;
	case "blankdark":
		layer.id = "_system_blankdark";
		break;
	case "owm-precip":
		layer.id = "_system_owm-precip";
		break;
	case "owm-clouds":
		layer.id = "_system_owm-clouds";
		break;
	case "owm-pressure":
		layer.id = "_system_owm-pressure";
		break;
	case "owm-temp":
		layer.id = "_system_owm-temp";
		break;
	case "nexrad":
		layer.id = "_system_nexrad";
		break;
	case "visible":
		layer.id = "_system_visible";
		break;
	case "infrared-4km":
		layer.id = "_system_infrared-4km";
		break;
	}
	
	return layer;
	
}, false);





