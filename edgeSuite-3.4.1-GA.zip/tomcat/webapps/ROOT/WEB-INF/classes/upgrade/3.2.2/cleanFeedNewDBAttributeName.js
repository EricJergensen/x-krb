logger.info("*************************************************************");
logger.info("* makeSafeIdentifier Json/Xml/Xslt feed new attribute names *");
logger.info("*************************************************************");

function makeSafeIdentifier(originalId) {
    var cleanChars = originalId.replace(/[^a-zA-Z0-9_]/g, "_");
    var noAdjacent = cleanChars.replace(/__+/g, "_");
    var safeId = noAdjacent.replace(/(^_|_$)/g, "");
    return safeId;
}

upgradeUtil.updateAllObjects("DataFeedDO", function (obj) {
    if (obj.typeName.indexOf("JSON") > -1) {
        var propertyValues = obj.properties.propertyValues;
        for (var i=0; i < propertyValues.length; i++) {
            if (propertyValues[i].propertyTypeName === "JsonAttributes") {
                var jsonAttributes = JSON.parse(propertyValues[i].value);
                var allList = jsonAttributes.jsonAttributeList;
                for (var j=0; j < allList.length; j++) {
                    allList[j].newAttributeName = makeSafeIdentifier(allList[j].newAttributeName);
                }
                propertyValues[i].value = JSON.stringify(jsonAttributes);
                break;
            }
        }
    } else if (obj.typeName.search(/XML/) > -1) {
        var propertyValues = obj.properties.propertyValues;
        for (var i=0; i < propertyValues.length; i++) {
            if (propertyValues[i].propertyTypeName === "XmlAttributes") {
                var xmlAttributes = JSON.parse(propertyValues[i].value);
                var allList = xmlAttributes.xmlAttributeList;
                for (var j=0; j < allList.length; j++) {
                    allList[j].newAttributeName = makeSafeIdentifier(allList[j].newAttributeName);
                }
                propertyValues[i].value = JSON.stringify(xmlAttributes);
                break;
            }
        }
    }

    return obj;
}, false);

