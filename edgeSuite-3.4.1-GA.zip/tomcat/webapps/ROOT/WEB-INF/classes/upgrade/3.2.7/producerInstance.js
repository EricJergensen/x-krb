logger.info("**************************************************");
logger.info("* upgrade Producer Instance config               *");
logger.info("**************************************************");


var producerInstances = {};

upgradeUtil.updateAllObjects("ProducerInstanceDO", function (producerInstance) {
    producerInstances[producerInstance["id"]] = producerInstance;
    return null;
});

upgradeUtil.updateAllObjects("PageDO", function (page) {

    var producerInstanceIds = page["producerInstanceIds"];

    page["producerInstances"] = [];
    for (var i = 0; i < producerInstanceIds.length; i++) {
    	    if ( logger.isDebugEnabled() ) {
    	        logger.debug("producerInstance {} = {}", producerInstanceIds[i], JSON.stringify(producerInstances[producerInstanceIds[i]]));
    	    }
        page["producerInstances"].push(producerInstances[producerInstanceIds[i]]);
    }

    return page;
});
