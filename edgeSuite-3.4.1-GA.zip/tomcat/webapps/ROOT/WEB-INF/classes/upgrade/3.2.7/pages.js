logger.info("***********************************************");
logger.info("* Updating Pages                              *");
logger.info("***********************************************");

// actions reference pages by hashed path, while kiosk mode uses the raw/fully expanded path
var pageIdsByPath = [];
var pageIdsByRawPath = [];

function traverseContentMenu(node, path) {

    node.id = upgradeUtil.getUID();

    if (node.hasOwnProperty("doClass") && node.doClass === "PageDO") {
        var hash = upgradeUtil.menuHash(path);
        pageIdsByPath[hash + "/" + node.name] = node.id;
        pageIdsByRawPath[path + "/" + node.name] = node.id;
    }

    if (path.length > 1) {
        path += "/";
    }
    path += node.name;
    logger.info("Created ID for page: " + path + " = " + node.id);

    if (!node.hasOwnProperty("children") || node.children === null) {
        return;
    }

    for (var i = 0; i < node.children.length; i++) {
        traverseContentMenu(node.children[i], path);
    }
}

if (fullBackup) {

    // full backup has the entire menu structure.. pages are all under the 'content menu' folder
    upgradeUtil.updateAllObjects("ContentFolderDO", function (folder) {

            if (folder.name === "Content Menu") {
                traverseContentMenu(folder, "Root");
            }
            return folder;
        },
        false
    );

} else {
    // partials have a list of pages, even if folder(s) selected..

    upgradeUtil.updateAllObjects("PageDO", function (page) {

            traverseContentMenu(page, "Root" + page.parentPath);
            return page;
        },
        false
    );
}

upgradeUtil.updateAllObjects("VisualizationInstanceDO", function (visInstance) {

        if (visInstance.actionsConfig) {
            var actionsConfig = JSON.parse(visInstance.actionsConfig);
            var actions = actionsConfig.actions;
            if (actions) {
                for (var k = 0; k < actions.length; k++) {
                    if (actions[k].selectedPage) {

                        if (pageIdsByPath[actions[k].selectedPage]) {

                            logger.info("Updating selectedPage field value '" + actions[k].selectedPage + "' for "
                                + actions[k].actionName + " action");

                            actions[k].selectedPage = pageIdsByPath[actions[k].selectedPage];
                            visInstance.actionsConfig = JSON.stringify(actionsConfig);

                        } else {
                            logger.info("Not updating selectedPage field value '" + actions[k].selectedPage + "' for "
                                + actions[k].actionName + " action - target page not in archive");
                        }
                    }
                }
            }
        }
        return visInstance;
    },
    false
);


// KioskModeDO has a pagesConfig field which is a JSON-mapped array of KioskPage
upgradeUtil.updateAllObjects("KioskModeDO", function (kioskMode) {

        if (kioskMode.pagesConfig) {
            var didReplacement = false;
            var kioskPages = JSON.parse(kioskMode.pagesConfig);
            for (var i = 0; i < kioskPages.length; i++) {
                var kioskPage = kioskPages[i];

                if (pageIdsByRawPath[kioskPage.path]) {

                    logger.info("Updating Kiosk page path field value '" + kioskPage.path + "'");

                    kioskPage.id = pageIdsByRawPath[kioskPage.path];
                    delete kioskPage.path;
                    didReplacement = true;

                } else {
                    logger.info("Not updating Kiosk page path field value '" + kioskPage.path
                        + "' - target page not in archive");
                }
            }

            if (didReplacement) {
                kioskMode.pagesConfig = JSON.stringify(kioskPages);
            }
        }

        return kioskMode;
    },
    false
);
