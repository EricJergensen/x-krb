logger.info("**************************************************");
logger.info("* Upgrading system menu                          *");
logger.info("**************************************************");

upgradeUtil.updateAllObjects("ContentItemDO", function (contentItem) {

    if (contentItem.name === "Pages" && contentItem.data === "showManageContent" && contentItem.itemType === "ACTION") {
        contentItem.itemType = "ROUTE";
        contentItem.data = "{\"state\":\"admin.manage.content\", \"param\":{}}";
    }

    return contentItem;
});

