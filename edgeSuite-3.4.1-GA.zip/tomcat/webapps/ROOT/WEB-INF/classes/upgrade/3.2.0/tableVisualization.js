logger.info("***********************************************");
logger.info("*       updating Table Visualization          *");
logger.info("***********************************************");

function getNewUseRowColorRulePV() {
    return {
        "doClass": "PropertyValueDO",
        "id": null,
        "propertyDefName": "useRowColorRule",
        "propertyTypeName": "Boolean",
        "boundToParameter": false,
        "value": true,
        "metaJson": null
    };
}

function getRowColorRulePV() {
    return {
        "doClass" : "PropertyValueDO",
        "id": null,
        "propertyDefName" : "rowColorRule",
        "propertyTypeName" : "JSON",
        "boundToParameter" : false,
        "value" : null,
        "metaJson" : null
    };
}



function getNewColorRule() {
    return {
        className: "edge.ui.complex.megaformatters.types.Color",
        isDerived: true,
        ruleset: {ruleSetID: null, ruleSetAttribute: null},
        dataType: "color",
        color: "default-13"
    };
}

upgradeUtil.updateAllObjects("DataVisualizationDO", function (dataVisualizationDO) {
    if (dataVisualizationDO.typeName == "Table") {
        var colorRuleSet = getNewColorRule();
        var hasRowColorRule = false;
        var propertyValues = dataVisualizationDO.properties.propertyValues;
        for (var i = 0; i < propertyValues.length; i++) {
            var pv = propertyValues[i];
            if (pv.propertyDefName == "derivedColorMethod" && pv.metaJson != null ) {
                var propertyValueMeta = JSON.parse(pv.metaJson);
                if ( propertyValueMeta && (propertyValueMeta.ruleset_id != undefined) && (propertyValueMeta.ruleset_attribute != undefined)  ) {
	                colorRuleSet.ruleset.ruleSetID = propertyValueMeta.ruleset_id;
	                colorRuleSet.ruleset.ruleSetAttribute = propertyValueMeta.ruleset_attribute;
	                hasRowColorRule = true;
	                break;
	            }
            }
        }
        if (hasRowColorRule) {
            propertyValues.push(getNewUseRowColorRulePV());
            var colorRulePV = getRowColorRulePV();
            colorRulePV.value = JSON.stringify(colorRuleSet);
            propertyValues.push(colorRulePV);
        }
        var propertiesToDelete = ["selectionMode", "derivedColorMethod", "colorMethod"];
        dataVisualizationDO.properties.propertyValues = propertyValues.filter(function (pv) {
            var keep = true;
            for (var j = 0; j < propertiesToDelete.length; j++) {
                if (propertiesToDelete[j] == pv.propertyDefName) {
                    keep = false;
                }
            }
            return keep;
        });
    }
    return dataVisualizationDO;
}, false);

upgradeUtil.updateAllObjects("VisualizationInstanceDO", function (visInstanceDO) {
    if (visInstanceDO.hasOwnProperty('actionsConfig') && visInstanceDO.actionsConfig) {
        var actionsConfig = JSON.parse(visInstanceDO.actionsConfig);
        for (var i = 0; i < actionsConfig.actions.length; i++) {
            var action = actionsConfig.actions[i];
            if (action.widgetEventTypeID == "tableAttrClicked") {
                action.widgetEventTypeID = "tableRowClicked";
                action.targetId = "Row";
            }
            if (action.hasOwnProperty('conditions')) {
                var conditions = action.conditions;
                for (var j = 0; j < conditions.tokens.length; j++) {
                    var token = conditions.tokens[j];
                    if (token.type == "ANY") {
                        token.type = 6;
                    }
                    if (token.type == 6) {
                        token.field = "selectedAttribute";
                    }
                }
            }
        }
        visInstanceDO.actionsConfig = JSON.stringify(actionsConfig);
    }
    return visInstanceDO;
}, false);
