logger.info("***************************************************");
logger.info("* updating webdata feeds                          *");
logger.info("***************************************************");

//
// Previous versions of the product included the Content-Type header by default, if it wasn't specified, regardless
// of the request-type, but as of 3.3.0, only does this for request types that typically have a body.
//
// We assume that previous archives are in a working state.  Therefore we add explicit configuration for what was
// previously implied.
//

upgradeUtil.updateAllObjects("DataFeedDO", function (obj) {

    if (obj.typeName.startsWith('Web Data Feed')) {
        var headersProperty = null;
        var propertyValues = obj.properties.propertyValues;
        for (var i=0; i < propertyValues.length; i++) {
            if (propertyValues[i].propertyDefName === "headers") {
                headersProperty = propertyValues[i];
                break;
            }
        }

        if (headersProperty) {
            var hasContentTypeHeader = false;
            var headers = JSON.parse(headersProperty.value);
            for (var j = 0; j < headers.pairs.length; j++) {
                if (headers.pairs[j].key.toUpperCase() === 'CONTENT-TYPE') {
                    hasContentTypeHeader = true;
                    break;
                }
            }

            if (!hasContentTypeHeader) {
                headers.pairs.push({
                    "doClass": "KeyValuePairDO",
                    "key": "Content-Type",
                    "value": "application/x-www-form-urlencoded"
                });
                headersProperty.value = JSON.stringify(headers);
            }

        } else {
            propertyValues.push({
                "doClass" : "PropertyValueDO",
                "id" : upgradeUtil.getUID(),
                "propertyDefName" : "headers",
                "propertyTypeName" : "KeyValuePair",
                "boundToParameter" : false,
                "value" : "{\"doClass\":\"KeyValuePairsDO\",\"pairs\":[{\"doClass\":\"KeyValuePairDO\",\"key\":\"Content-Type\",\"value\":\"application/x-www-form-urlencoded\"}]}",
                "metaJson" : null
            });
        }
    }

    return obj;

}, false);

