logger.info("**************************************************");
logger.info("* convert RuleSetDO to ExpRuleSetDO's  (v10)     *");
logger.info("*                                                *");
logger.info("* ...insert more awesome sauce into EdgeSuite... *");
logger.info("**************************************************");

upgradeUtil.loadUpgradeScript('3.3.0/lib/expression-lib.js');

var iconHelper = new edge.upgrade.CompositeIconHelper();
var numberRulesetHelper = new edge.upgrade.NumberRulesetHelper();
var colorPaletteMap = [];
colorPaletteMap["Chart"] = "_system_chart";
colorPaletteMap["Fire"] = "_system_fire";
colorPaletteMap["Ice"] = "_system_ice";
colorPaletteMap["Spectrum"] = "_system_spectrum";
colorPaletteMap["ColorWheel"] = "_system_colorwheel";
colorPaletteMap["Greyscale"] = "_system_greyscale";
colorPaletteMap["Autumn"] = "_system_autumn";
colorPaletteMap["Spring"] = "_system_spring";
colorPaletteMap["Summer"] = "_system_summer";
colorPaletteMap["Evergreen"] = "_system_evergreen";
colorPaletteMap["Ocean"] = "_system_ocean";

upgradeUtil.updateAllObjects("ColorPaletteDO", function (colorPaletteDO) {
		
	colorPaletteMap[colorPaletteDO.name] = colorPaletteDO.id;
	
	return colorPaletteDO;
});

function getColorPaletteIdFromName(name) {
	var id = colorPaletteMap[name];
	if (id == undefined) {
		id = "_system_default";
	}
	return id;
}

/*
 * We Need to upgrade all the visualizations in this script because we need to share the CompositeIconHelper
 * and the NumberRulesetHelper, which are basically utilities that store information about icon and number
 * rules that it encounters so that upgrade scripts can correctly generate CompositeIcons and convert
 * number rules to font rules with static number formatter configuration.
 */

upgradeUtil.updateAllObjects("RestoreBundleDO", function (restoreBundleDO) {
	if (restoreBundleDO.backupClass == "edge.server.pipeline.visualization.mappers.RuleSetDO") {
		restoreBundleDO.backupClass = "edge.server.pipeline.visualization.rules.ExpRuleSetDO";

		var newExpRuleSets = [];
		var newRuleSet;
		for (var i = 0; i < restoreBundleDO.objects.length; i++) {
			var ruleSetDO = restoreBundleDO.objects[i];
			var ruleSetID = ruleSetDO.id;
			if (iconHelper.ruleSetIsIcon(ruleSetDO)) {
				if (iconHelper.ruleSetNeedsIconRuleSet(ruleSetDO)) {
					ruleSetDO.template = "icon";
					ruleSetDO.id = ruleSetID + "icon";
					newRuleSet = edge.upgrade.convertRuleSet(ruleSetDO, numberRulesetHelper);
					newExpRuleSets.push(newRuleSet);
				}
				
				if (iconHelper.ruleSetNeedsColorRuleSet(ruleSetDO)) {
					ruleSetDO.template = "fillcolor";
					ruleSetDO.id = ruleSetID + "color";
					newRuleSet = edge.upgrade.convertRuleSet(ruleSetDO, numberRulesetHelper);
					newExpRuleSets.push(newRuleSet);
				}
			} else {
				newRuleSet = edge.upgrade.convertRuleSet(ruleSetDO, numberRulesetHelper);
				newExpRuleSets.push(newRuleSet);
			}
		}
		restoreBundleDO.objects = newExpRuleSets;
	}
	return restoreBundleDO;
});

logger.info("**************************************************");
logger.info("* Upgrade All Visualization with new RuleSets    *");
logger.info("**************************************************");

upgradeUtil.updateAllObjects("DataVisualizationDO", function (dataVisualizationDO) {
	
	if (dataVisualizationDO.typeName == "Table") {
		logger.info("Upgrading a Table Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "columnConfig") {
				var columnConfig = JSON.parse(property.value);
				var columnDefs = columnConfig.columnDefs;
				for (var j = 0; j < columnDefs.length; j++) {
					var def = columnDefs[j];
					def.formatter = edge.upgrade.convertMegaFormatter(def.formatter, iconHelper, numberRulesetHelper);
				}
				property.value = edge.server.JsonMappedObject.toJsonString(columnConfig);
			}
			if (property.propertyDefName == "rowColorRule") {
				var color = JSON.parse(property.value);
				if (color == undefined || color.color == "transparent") {
					property.value = null;
				} else {
					property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertColorToDerivableColor(color));
				}
			}
		}
		//upgradeUtil.logObject(dataVisualizationDO);
	}
	
	if (dataVisualizationDO.typeName == "List" || dataVisualizationDO.typeName == "Text") {
		logger.info("Upgrading a List or Text Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "attributes") {
				var attributeRendererConfig = JSON.parse(property.value);
				for (var j = 0; j < attributeRendererConfig.attributeRendererDefs.length; j++) {
					var attrDef = attributeRendererConfig.attributeRendererDefs[j];
					attrDef.formatterConfig = edge.upgrade.convertMegaFormatter(attrDef.formatterConfig, iconHelper, numberRulesetHelper);
				}
				property.value = edge.server.JsonMappedObject.toJsonString(attributeRendererConfig);
			}
			if (property.propertyDefName == "labelFormatter") {
				var labelFormatter = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertTextToFontFormatter(labelFormatter));
			}
		}
	}

	if (dataVisualizationDO.typeName === "RegionMap") {
		logger.info("Upgrading a Region Map Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "markerIcon") {
				var markerIcon = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertIconToCompositeIcon(markerIcon, iconHelper));
			}
			if (property.propertyDefName === "regionLabelFormatter") {
				var labelFormatter = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertMegaFormatter(labelFormatter, iconHelper, numberRulesetHelper));
			}
            if (property.propertyDefName === "regionFill") {
				var regionFill = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertFillToDerivableColor(regionFill));
			}
		}
	}

	if (dataVisualizationDO.typeName === "Map") {
		logger.info("Upgrading a Icon Map Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName === "primaryIcon") {
				var markerIcon = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertIconToCompositeIcon(markerIcon, iconHelper));
			}
			if (property.propertyDefName === "marker_labelFormatter") {
				var labelFormatter = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertMegaFormatter(labelFormatter, iconHelper, numberRulesetHelper));
			}
		}
	}

	if (dataVisualizationDO.typeName === "HeatMap") {
		logger.info("Upgrading a HeatMap Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName === "palette") {
				var oldConfig = JSON.parse(property.value);
				var paletteConfig = {
						className:"edge.widget.heatmap.config.HeatMapPaletteConfig",
						usePalette: true,
						derivableColor: new edge.server.types.DerivableColorDO(),
						colorPalette: new edge.ui.complex.formatters.ColorPaletteFormatter()
				};
				paletteConfig.usePalette = !oldConfig.isDerived;
				if (paletteConfig.usePalette == true) {
					paletteConfig.colorPalette.paletteID = getColorPaletteIdFromName(oldConfig.paletteName);
				} else {
					paletteConfig.derivableColor.ruleSetID = oldConfig.ruleset.ruleSetID;
					var varMapper = new edge.server.types.RuleSetVariableMapperDO();
		            varMapper.variable = "var1";
		            varMapper.field = oldConfig.ruleset.ruleSetAttribute;
		            paletteConfig.derivableColor.variableMappings = [varMapper];
				}
				
				property.value = edge.server.JsonMappedObject.toJsonString(paletteConfig);
			}
		}
	}
		
	if (dataVisualizationDO.typeName === "Topo") {
		logger.info("Upgrading a Topology Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName === "nodeRenderers") {
				
				var nodeRenderers = JSON.parse(property.value);
				
				var nodeRendererDefs = nodeRenderers.nodeRendererDefs;
								
				for (var j = 0; j < nodeRendererDefs.length; j++) {
					var rDef = nodeRendererDefs[j];
					nodeRendererDefs[j] = edge.upgrade.convertTopoNodeRendererDef(rDef, iconHelper);
				}
			
				property.value = edge.server.JsonMappedObject.toJsonString(nodeRenderers);
			}
		}
	}

	if (dataVisualizationDO.typeName === "sm") {
		logger.info("Upgrading a Small Multiple Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName === "labelFormatter") {
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertTextToFontFormatter(JSON.parse(property.value)));
                break;
			}
			if (property.propertyDefName == "series") {
				var attributeRendererConfig = JSON.parse(property.value);
				for (var j = 0; j < attributeRendererConfig.attributeRendererDefs.length; j++) {
					var attrDef = attributeRendererConfig.attributeRendererDefs[j];
					attrDef.formatterConfig = edge.upgrade.convertMegaFormatter(attrDef.formatterConfig, iconHelper, numberRulesetHelper);
				}
				attributeRendererConfig.labelFormatter = edge.upgrade.convertTextToFontFormatter(attributeRendererConfig.labelFormatter);
				property.value = edge.server.JsonMappedObject.toJsonString(attributeRendererConfig);
			}
		}
	}

    if (dataVisualizationDO.typeName === "Timeline") {
		logger.info("Upgrading a Timeline Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "attributes") {
				var attributeRendererConfig = JSON.parse(property.value);
				for (var j = 0; j < attributeRendererConfig.attributeRendererDefs.length; j++) {
					var attrDef = attributeRendererConfig.attributeRendererDefs[j];
					attrDef.formatterConfig = edge.upgrade.convertMegaFormatter(attrDef.formatterConfig, iconHelper, numberRulesetHelper);
				}
				attributeRendererConfig.labelFormatter = edge.upgrade.convertTextToFontFormatter(attributeRendererConfig.labelFormatter);
				property.value = edge.server.JsonMappedObject.toJsonString(attributeRendererConfig);
			}
			if (property.propertyDefName === "labelFormatter") {
				var formatter = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertTextToFontFormatter(formatter));
			}
		}
	}
    
    if (dataVisualizationDO.typeName === "Gauge") {
		logger.info("Upgrading a Gauge Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "valueLabelConfig") {
				var numeric = JSON.parse(property.value);
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertNumericToDerivableNumber(numeric, numberRulesetHelper));;
			}
			if (property.propertyDefName === "primaryLabelConfig") {
				property.value = edge.server.JsonMappedObject.toJsonString(edge.upgrade.convertTextToDerivableFont(JSON.parse(property.value)));
			}
		}
	}
    
    if (dataVisualizationDO.typeName === "Chart") {
		logger.info("Upgrading a Gauge Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "series") {
				var seriesArray = JSON.parse(property.value);
				if (seriesArray[0].palette != undefined) {
					seriesArray[0].palette = getColorPaletteIdFromName(seriesArray[0].palette);
				}
				property.value = edge.server.JsonMappedObject.toJsonString(seriesArray);
			}
		}
	}

    if (dataVisualizationDO.typeName === "piechart") {
		logger.info("Upgrading a Pie Chart Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "series") {
				var config = JSON.parse(property.value);
				if (config.palette != undefined) {
					config.palette = getColorPaletteIdFromName(config.palette);
				}
				property.value = edge.server.JsonMappedObject.toJsonString(config);
			}
		}
	}

    if (dataVisualizationDO.typeName === "Flow") {
		logger.info("Upgrading a Flow Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "rendererConfig") {
				var oldConfig = JSON.parse(property.value);
				var newConfig = new edge.widget.flow.FlowWidgetRendererConfig();
				newConfig.headerConfig = edge.upgrade.convertTextToFontFormatter(oldConfig.headerConfig);
				newConfig.labelConfig = edge.upgrade.convertTextToFontFormatter(oldConfig.labelConfig);
		        
		        var newRendererDefs = [];
		        for (var i = 0; i < oldConfig.rendererDefs.length; i++) {
		            var oldRendererDef = oldConfig.rendererDefs[i];
		            var newRendererDef = new edge.widget.flow.FlowWidgetRendererDef();
		            newRendererDef.dataProducerName = oldRendererDef.dataProducerName;
		            newRendererDef.dataSourceId = oldRendererDef.dataSourceId;
		            newRendererDef.displayName = oldRendererDef.displayName;
		            newRendererDef.labelField = oldRendererDef.labelField;
		            var paletteFormatter = new edge.ui.complex.formatters.ColorPaletteFormatter();
		            paletteFormatter.paletteID = getColorPaletteIdFromName(oldRendererDef.palette.paletteName);
		            newRendererDef.palette = paletteFormatter;
		            newRendererDefs.push(newRendererDef);
		        }
		        newConfig.rendererDefs = newRendererDefs;
				property.value = edge.server.JsonMappedObject.toJsonString(newConfig);
			}
		}
	}

    if (dataVisualizationDO.typeName === "TreeMap") {
		logger.info("Upgrading a TreeMap Visualization...");
		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName == "rendererConfig") {
				var oldConfig = JSON.parse(property.value);
				var newConfig = new edge.widget.treemap.TreeMapRendererConfig();
				newConfig.labelConfig = edge.upgrade.convertTextToFontFormatter(oldConfig.labelConfig);
		        
		        var newRendererDefs = [];
		        for (var i = 0; i < oldConfig.rendererDefs.length; i++) {
		            var oldRendererDef = oldConfig.rendererDefs[i];
		            var newRendererDef = new edge.widget.treemap.TreeMapRendererDef();
		            newRendererDef.dataProducerName = oldRendererDef.dataProducerName;
		            newRendererDef.dataSourceId = oldRendererDef.dataSourceId;
		            newRendererDef.displayName = oldRendererDef.displayName;
		            newRendererDef.labelField = oldRendererDef.labelField;
		            newRendererDef.sizeField = oldRendererDef.sizeField;
		            var paletteFormatter = new edge.ui.complex.formatters.ColorPaletteFormatter();
		            paletteFormatter.paletteID = getColorPaletteIdFromName(oldRendererDef.palette.paletteName);
		            newRendererDef.palette = paletteFormatter;
		            newRendererDefs.push(newRendererDef);
		        }
		        newConfig.rendererDefs = newRendererDefs;
				property.value = edge.server.JsonMappedObject.toJsonString(newConfig);
			}
		}
	}
    
	return dataVisualizationDO;
});

logger.info("**************************************************");
logger.info("* Upgrade All Tooltip actions config             *");
logger.info("**************************************************");

upgradeUtil.updateAllObjects("ProducerInstanceDO", function (producerInstanceDO) {
	for (var vi = 0; vi < producerInstanceDO.visualizationInstances.length; vi++) {
		var visInstance = producerInstanceDO.visualizationInstances[vi];
		var actionsConfig = JSON.parse(visInstance.actionsConfig);
		if (actionsConfig != undefined && actionsConfig.actions.length > 0) {
			for (var i = 0; i < actionsConfig.actions.length; i++) {
				var config = actionsConfig.actions[i];
				if (config.className == "edge.core.widget.actions.tooltip.ActionTooltipConfig") {
					if (config.attributeRendererDefs) {
						for (var j = 0; j < config.attributeRendererDefs.length; j++) {
							var attrDef = config.attributeRendererDefs[j];
							attrDef.formatterConfig = edge.upgrade.convertMegaFormatter(attrDef.formatterConfig, iconHelper, numberRulesetHelper);
						}
					}
					
					if (config.labelFormatter != undefined) {
						config.labelFormatter = edge.upgrade.convertTextToFontFormatter(config.labelFormatter);
					} else {
						config.labelFormatter = new edge.ui.complex.formatters.FontFormatter();
					}
				}
			}
			visInstance.actionsConfig =  edge.server.JsonMappedObject.toJsonString(actionsConfig);
		}
	}
	return producerInstanceDO;
});

logger.info("**************************************************");
logger.info("* Upgrade All Expression Client Filters          *");
logger.info("**************************************************");

upgradeUtil.updateAllObjects("ClientFilterDO", function(filter) {
	
	if (filter.hasOwnProperty('config') && filter.config != undefined) {
		var config = JSON.parse(filter.config);
		if (config.className == "edge.core.admin.managers.clientfilter.expression.CustomExpressionFilterConfig" ) {
			for (var j = 0; j < config.filterDefs.length; j++) {
				var filterDef = config.filterDefs[j];
				var iconFormatter = new edge.ui.complex.formatters.IconFormatter();
				iconFormatter.icon = filterDef.icon.icon;
				iconFormatter.style = filterDef.icon.style;
				var colorFormatter = new edge.ui.complex.formatters.ColorFormatter();
				//upgradeUtil.logObject(filterDef.icon);
				colorFormatter.color = filterDef.icon.fillColor;
				filterDef.color = colorFormatter;
				filterDef.icon = iconFormatter;
			}
			//upgradeUtil.logObject(config);
			filter.config = JSON.stringify(config);
		}
	}
	
	return filter;
	
}, false);
