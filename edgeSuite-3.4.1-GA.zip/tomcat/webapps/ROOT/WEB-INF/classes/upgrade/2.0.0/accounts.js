logger.info("***********************************************");
logger.info("*       updating Accounts                     *");
logger.info("***********************************************");

var groupPath = "EmbeddedAccountAdapter/AccountGroup.json";
var userPath = "EmbeddedAccountAdapter/AccountUser.json";
var entryPath = "AccountAdapterManager/AccountAdapterEntry.json";

var users = null;
var groups = null;
if (upgradeUtil.fileExists(groupPath)) {
    var json = upgradeUtil.readFileByPath(groupPath);
    groups = JSON.parse(json);

    for (i = 0; i < groups.objects.length; i++) {
        var currentConfig = groups.objects[i];
        currentConfig.adapterName = currentConfig.adapterId;
        delete currentConfig.adapterId;
        currentConfig.hidden = false;
        currentConfig.attributes = {};
    }
}

if (upgradeUtil.fileExists(userPath)) {
    var json = upgradeUtil.readFileByPath(userPath);
    users = JSON.parse(json);

    for (i = 0; i < users.objects.length; i++) {
        var currentConfig = users.objects[i];
	currentConfig.adapterName = currentConfig.adapterId;
	delete currentConfig.adapterId;
	currentConfig.attributes = {};
	currentConfig.attributes.FirstName = currentConfig.firstName;
	delete currentConfig.firstName;
	currentConfig.attributes.LastName = currentConfig.lastName;
	delete currentConfig.lastName;
    }
}

var wrapperObj = {};
wrapperObj.doClass = "RestoreBundleDO";
wrapperObj.backupClass = "edge.server.account.adapter.AccountAdapterRestoreBundleDO";
wrapperObj.objects = [];
var acctRestoreBundle = {};
acctRestoreBundle.doClass = "AccountAdapterRestoreBundleDO";
acctRestoreBundle.bundles = [];

if( users != null ) {
    acctRestoreBundle.bundles.push(users);
}
if( groups != null ) {
    acctRestoreBundle.bundles.push(groups);
}

acctRestoreBundle.adapterDef = {};
acctRestoreBundle.adapterDef.doClass = "AccountAdapterDO";
acctRestoreBundle.adapterDef.id = "908p9a-fj89co47f7e2";
acctRestoreBundle.adapterDef.properties = {};
acctRestoreBundle.adapterDef.properties.doClass = "PropertyBundleDO";
acctRestoreBundle.adapterDef.properties.id = "908p9a-fj89co47f7e3";
acctRestoreBundle.adapterDef.properties.propertyValues = [];
var propertyValues = {};
propertyValues.doClass = "PropertyValueDO";
propertyValues.id = "908p9a-fj89co47f7e4";
propertyValues.propertyDefName = "name";
propertyValues.propertyTypeName = "String";
propertyValues.boundToParameter = "false";
propertyValues.value = "embedded";
propertyValues.metaJson = null;
acctRestoreBundle.adapterDef.properties.propertyValues.push(propertyValues);
acctRestoreBundle.adapterDef.adapterTypeName = "Embedded";
acctRestoreBundle.adapterDef.sharedConfigId = "kgl027-f4oqnsor93pa";
acctRestoreBundle.adapterDef.roleMappings = [];
    
wrapperObj.objects.push(acctRestoreBundle);
    
upgradeUtil.writeNewFile("AccountAdapterManager", "AccountAdapterRestoreBundleDO.json", JSON.stringify(wrapperObj));


if (upgradeUtil.fileExists(userPath)) {
    upgradeUtil.deleteFile(userPath);
}
if (upgradeUtil.fileExists(groupPath)) {
    upgradeUtil.deleteFile(groupPath);
}
if (upgradeUtil.fileExists(entryPath)) {
    upgradeUtil.deleteFile(entryPath);
}

var accountConfigs = '{' +
  '"backupClass" : "edge.server.account.adapter.AccountAdapterConfigDO",' +
  '"objects" : [ {' +
    '"doClass" : "AccountAdapterConfigDO",' +
    '"id" : "kgl027-f4oqnsor93pa",' +
    '"properties" : {' +
      '"doClass" : "PropertyBundleDO",' +
      '"id" : "kgl027-f4oqnsor93pb",' +
      '"propertyValues" : [ ]' +
    '},' +
    '"configTypeName" : "Embedded",' +
    '"propertyBundleDef" : null' +
  '} ],' +
  '"doClass" : "RestoreBundleDO"' +
'}';

upgradeUtil.writeNewFile("AccountAdapterManager", "AccountAdapterConfigDO.json", accountConfigs);

    
function logObject(object) {
	logger.info(JSON.stringify(object, true));
}

function logObjectWithLabel(label, object) {
	logger.info(label + ":" + JSON.stringify(object, true));
}
