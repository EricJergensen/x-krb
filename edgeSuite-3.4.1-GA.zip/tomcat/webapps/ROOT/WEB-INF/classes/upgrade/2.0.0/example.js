var json = upgradeUtil.readFileByPath("DataProducerService/AbstractTabularProducerDO.json");

//logger.info(json);
var obj = JSON.parse(json);
//logger.info(obj.doClass);
obj.newField="bob";
upgradeUtil.writeFile("DataProducerService/AbstractTabularProducerDO.json", JSON.stringify(obj));
upgradeUtil.deleteFile("DataProducerService/AbstractRelationalProducerDO.json");
