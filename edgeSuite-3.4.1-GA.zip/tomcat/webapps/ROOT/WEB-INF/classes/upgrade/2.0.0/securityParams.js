logger.info("***********************************************");
logger.info("*       updating Secured Variables            *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("CredentialSetDO", function(credentialSet) {
    if (credentialSet.credentials) {
        var credentials = credentialSet.credentials;
        for (var k = 0; k < credentials.length; k++) {
            var credential = credentials[k];
            var key = credential.key;
            var oldValue = credential.value;
            if (typeof oldValue === 'string' || oldValue instanceof String) {
                if (key === "Password") {
                    credential.value = {
                        "doClass": "SpEncryptedStringValueDO",
                        "isParameter": false,
                        "redacted": false,
                        "plainValue": oldValue
                    };
                } else {
                    // Username || Domain
                    credential.value = {
                        "doClass": "SpStringValueDO",
                        "isParameter": false,
                        "primitiveValue": oldValue
                    };
                }
            }
        }
    }
    return credentialSet;
});

upgradeUtil.updateAllObjects("PropertyValueDO", function(propertyValue) {
    if (propertyValue.propertyDefName === "credentials" || propertyValue.propertyDefName === "ssoCredentials") {
        var stringValue = propertyValue.value;
        var objValue = JSON.parse(stringValue);

        if (objValue.credentials) {
            var credentials = objValue.credentials;
            for (var k = 0; k < credentials.length; k++) {
                var credential = credentials[k];
                var key = credential.key;
                var oldValue = credential.value;
                if (typeof oldValue === 'string' || oldValue instanceof String) {
                    if (key === "Password") {
                        credential.value = {
                            "doClass": "SpEncryptedStringValueDO",
                            "isParameter": false,
                            "redacted": false,
                            "plainValue": oldValue
                        };
                    } else {
                        // Username || Domain
                        credential.value = {
                            "doClass": "SpStringValueDO",
                            "isParameter": false,
                            "primitiveValue": oldValue
                        };
                    }
                }
            }

            stringValue = JSON.stringify(objValue);
            propertyValue.value = stringValue;
        }
    }
    return propertyValue;
});


var configSqlPath = "config.sql";
if (upgradeUtil.fileExists(configSqlPath)) {
    var sql = upgradeUtil.readFileByPath(configSqlPath);
    var modifiedSql = sql.replace(/({"doClass":"CredentialPairDO","key":"(?:Username|Domain)","value":)(".*?")(,)/g,
                                  '$1{"doClass":"SpStringValueDO","isParameter":false,"primitiveValue":$2}$3');

    modifiedSql = modifiedSql.replace(/({"doClass":"CredentialPairDO","key":"Password","value":)(".*?")(,)/g,
                                      '$1{"doClass":"SpEncryptedStringValueDO","isParameter":false,"plainValue":$2}$3');

    if (modifiedSql != sql) {
        logger.info("File changed: " + configSqlPath);
        upgradeUtil.writeFile(configSqlPath, modifiedSql);
    }
}


var secParamsPath = "ParameterService/SecurityParameterDO.json";

if (upgradeUtil.fileExists(secParamsPath)) {
    var json = upgradeUtil.readFileByPath(secParamsPath);
    var secParams = JSON.parse(json);

    if (secParams.objects) {
        for (var i = 0; i < secParams.objects.length; i++) {
            var secParam = secParams.objects[i];
            var valueDef = secParam.valueDef;
            if (valueDef.sampleValue == null) {
                valueDef.sampleValue = {
                    "doClass": "CredentialSetDO",
                    "isParameter": false,
                    "credentials": [{
                        "doClass": "CredentialPairDO",
                        "key": "SampleUser",
                        "value": {
                            "doClass": "SpStringValueDO",
                            "isParameter": false,
                            "primitiveValue": "User"
                        },
                        "hidden": false,
                        "required": true
                    }, {
                        "doClass": "CredentialPairDO",
                        "key": "SamplePassword",
                        "value": {
                            "doClass": "SpEncryptedStringValueDO",
                            "isParameter": false,
                            "redacted": false,
                            "plainValue": "CHANGE_ME"
                        },
                        "hidden": true,
                        "required": false
                    }]
                };
            }

        }
    }

    upgradeUtil.writeFile(secParamsPath, JSON.stringify(secParams));
}