logger.info("**************************************************");
logger.info("* upgrade Topology Visualization Config          *");
logger.info("**************************************************");

upgradeUtil.updateAllObjects("DataVisualizationDO", function (dataVisualizationDO) {

	if (dataVisualizationDO.typeName === "Topo") {

		var properties = dataVisualizationDO.properties.propertyValues;
		for (var i = 0; i < properties.length; i++) {
			var property = properties[i];
			if (property.propertyDefName === "nodeRenderers") {
				
				var nodeRenderers = JSON.parse(property.value);
				
				var nodeRendererDefs = nodeRenderers.nodeRendererDefs;
								
				for (var j = 0; j < nodeRendererDefs.length; j++) {
					var rDef = nodeRendererDefs[j];
					
					if (rDef.labelAttribute != undefined && rDef.labelAttribute != null) {
						rDef.showLabel = true;
					} else {
						rDef.showLabel = false;
					}					
				}
			
				property.value = JSON.stringify(nodeRenderers);
			}
		}
	}
	return dataVisualizationDO;
});	
