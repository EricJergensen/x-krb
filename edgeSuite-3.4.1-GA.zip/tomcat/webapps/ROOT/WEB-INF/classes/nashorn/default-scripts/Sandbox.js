//
// prevent scripts from calling methods that affect the JVM / eS server in ways we can't control
//

function blockedFunction(functionName) {
    throw new Error("Not allowed to call " + functionName);
}

quit = function() { blockedFunction("quit"); };
exit = function() { blockedFunction("exit"); };
