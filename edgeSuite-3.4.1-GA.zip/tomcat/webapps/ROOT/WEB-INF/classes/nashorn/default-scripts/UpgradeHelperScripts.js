var upgradeUtil = {};

/********************************************************************************************************
 * wrapper functions for Java UpgradeUtil
 */

upgradeUtil.loadUpgradeScript = function(path) {
    load(upgradeUtil.getUpgradeScriptFolder().resolve("upgrade").resolve(path).toString());
};

upgradeUtil.listAllJsonFiles = function() {
	// returns List<String>
	return upgradeUtilJava.listAllJsonFiles();
};

upgradeUtil.readFileByPath = function(path) {
	//noinspection JSUnresolvedVariable
    return upgradeUtilJava.readFileByPath(path);
};

upgradeUtil.writeFile = function(path, buffer) {
    //noinspection JSUnresolvedVariable
    upgradeUtilJava.writeFile(path, buffer);
};

upgradeUtil.writeNewFile = function(path, file, buffer) {
	upgradeUtilJava.writeNewFile(path, file, buffer);
};

upgradeUtil.deleteFile = function(path) {
    //noinspection JSUnresolvedVariable
    upgradeUtilJava.deleteFile(path);
};

upgradeUtil.fileExists = function(path) {
	return upgradeUtilJava.fileExists(path);
};

upgradeUtil.getBean = function(name) {
    return upgradeUtilJava.getBean(name);
};

upgradeUtil.getUID = function() {
    return upgradeUtilJava.getUID();
};

upgradeUtil.getArchiveProductVersion = function () {
    return upgradeUtil.getArchiveModuleVersion("edge.core");
};

upgradeUtil.getArchiveModuleVersion = function (moduleName) {
    return adapterManifest.getVersion(moduleName);
};

upgradeUtil.getBean = function(name) {
    return upgradeUtilJava.getBean(name);
};

upgradeUtil.getUID = function() {
    return upgradeUtilJava.getUID();
};

upgradeUtil.getUpgradeScriptFolder = function() {
    //noinspection JSUnresolvedVariable
	return upgradeUtilJava.getUpgradeScriptFolder();
};

upgradeUtil.logObject = function(object) {
	logger.info(JSON.stringify(object, true));
};

upgradeUtil.logObjectWithLabel = function(label, object) {
	logger.info(label + ":" + JSON.stringify(object, true));
};


upgradeUtil.printObjectRecursive = function (obj, label) {
	for (var prop in obj) {
		if (obj.hasOwnProperty(prop)) {
			print(label + "[" + prop + "]: ", JSON.stringify(obj[prop]));
			if (typeof obj[prop] === 'object') {
				upgradeUtil.printObjectRecursive(obj[prop], label + "[" + prop + "]");
			}
		}
	}
}

/*********************************************************************************************************
 * Javascript help functions
 */

/**
 * Iterates over all JSON files, parses each, looks for all instances of doClass specified, then runs
 * supplied function on each doClass instance.
 *
 * @param doClass string name of the DO class to look for
 * @param callback function that can modify the doClass.  Must return the modified or unmodified object
 */
upgradeUtil.updateAllObjectsInFile = function(jsonFilePath, doClass, callback, includePropertyValue) {
    var reviver = function(key, value) {
        if (value !== null && typeof value === 'object') {
            if (value.hasOwnProperty("doClass")) {
                var instanceClass = value["doClass"];
                if (doClass === instanceClass) {
                    return callback(value);
                } else if (includePropertyValue && instanceClass === "PropertyValueDO") {

                    if (value["propertyTypeName"] === "JSON") {
                        var propValueString = value["value"];

                        if (propValueString.indexOf(doClass) !== -1 ) {
                            var parsedValue = JSON.parse(propValueString, reviver);

                            value["value"] = JSON.stringify(parsedValue);
                        }
                    }

                }

            }
        }
        return value;
    };

        var jsonIn = upgradeUtil.readFileByPath(jsonFilePath);

        var fileObject = JSON.parse(jsonIn, reviver);

        var jsonOut = JSON.stringify(fileObject, null, 2);

        if (jsonIn !== jsonOut) {
            upgradeUtil.writeFile(jsonFilePath, jsonOut);
        }
};

upgradeUtil.sort = function sort(propertyBundleDO) {
    if (propertyBundleDO.propertyValues) {
    		propertyBundleDO.propertyValues.sort(function (a,b) {
    			var nameA = a.propertyDefName; 
    			var nameB = b.propertyDefName;
    			if (nameA < nameB) {
    				return -1;
    			}
	    		if (nameA > nameB) {
			    return 1;
			}
	    		return 0;
    		});
	}
}

upgradeUtil.updateAllObjects = function(doClass, callback, includePropertyValue) {
  var jsonFileNames = upgradeUtil.listAllJsonFiles();

  for (var key in jsonFileNames) {
      var jsonFilePath = jsonFileNames[key];
      upgradeUtil.updateAllObjectsInFile(jsonFilePath, doClass, callback, includePropertyValue);
  }
};

upgradeUtil.findUpgradeBundle = function(bundleType) {
    return upgradeUtil.findUpgradeBundleInFiles(bundleType, upgradeUtil.listAllJsonFiles())
};

upgradeUtil.findUpgradeBundleInFiles = function(bundleTypeMatcher, jsonFileNames) {
    for (var key in jsonFileNames) {
        var jsonFilePath = jsonFileNames[key];
        if (upgradeUtil.fileExists(jsonFilePath)) {
            var jsonIn = upgradeUtil.readFileByPath(jsonFilePath);
            var bundle = JSON.parse(jsonIn);
            if (bundle.hasOwnProperty("doClass") && bundle["doClass"] === "RestoreBundleDO"
                && bundle.hasOwnProperty("backupClass") && bundleTypeMatcher(bundle["backupClass"])) {
                return {
                    "path": jsonFilePath,
                    "json": jsonIn
                };
            }
        }
    }
    return null;
};

upgradeUtil.getProperty = function getProperty(propName, configDO) {
	var propertyValues;
	if ( configDO.properties ) {
		propertyValues = configDO.properties.propertyValues;
	} else if ( configDO.propertyValues ) {
		propertyValues = configDO.propertyValues;
	}
	if ( propertyValues ) {
	    for (var i = 0; i < propertyValues.length; i++) {
	        var pv = propertyValues[i];
	        if (pv.propertyDefName === propName) {
	            return pv;
	        }
	    }
	}
    return null;
};

upgradeUtil.getPropertyValue = function getPropertyValue(propName, propertyValues) {
	var prop = upgradeUtil.getProperty(propName, propertyValues);
	if ( prop != null ) {
		return prop.value;
	}
	return null;
};

upgradeUtil.hashCode = function(toHash) {

    var hash = 0;

    if (toHash.length === 0) {
        return hash;
    }

    for (var i = 0; i < toHash.length; i++) {
        var mychar = toHash.charCodeAt(i);
        hash = ((hash << 5) - hash) + mychar;
        hash = hash & hash; // Convert to 32bit integer
    }

    return hash;
};

// pre-2.0 menu item hash
upgradeUtil.legacyMenuHash = function(name, parentPath) {
    return upgradeUtil._menuHash(true, name, parentPath);
};

upgradeUtil.menuHash = function(parentPath) {
    return upgradeUtil._menuHash(false, null, parentPath);
};

upgradeUtil._menuHash = function(classic, name, parentPath) {

    if( !parentPath ) {

        return "_";
    }

    var pathHash = null;
    // var logStr = null;
    if( classic ) {

        pathHash = upgradeUtil.hashCode( parentPath + "/" + name );
        // logStr = "hashing " + parentPath + "/" + name + ": ";
    } else {

        pathHash = upgradeUtil.hashCode(parentPath);
        // logStr = "hashing " + parentPath + ": ";
    }
    pathHash -= -2147483648; // subtract 32 bit min int to make unsigned int (0 is lowest)

    var pathHashString = pathHash.toString(16); // get hex value

    if (pathHashString.length < 8) { // 0 pad to 8 chars
        pathHashString = "00000000".substr(pathHashString.length) + pathHashString;
    }

    // 32 bits weren't really necessary, so decided to xor upper and lower 16 bits to get 4 char hex hash
    var upperHash = parseInt(pathHashString.substr(0, 4), 16);
    var lowerHash = parseInt(pathHashString.substr(4), 16);

    var smallHashString = (upperHash ^ lowerHash).toString(16);
    if (smallHashString.length < 4) { // 0 pad to 4 chars
        smallHashString = "00000000".substr(smallHashString.length + 4) + smallHashString;
    }

    // logger.info( logStr + smallHashString );
    return smallHashString;
};
