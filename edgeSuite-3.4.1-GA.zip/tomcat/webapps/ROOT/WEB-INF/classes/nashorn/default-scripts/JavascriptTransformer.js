// clones attributeDefs from all sources into the output ResultBundle
// TODO: WDM - I think transformName can be removed from args and we can use outputBundle.getDataDef().getProducerName() instead
function _fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle) {
    if (verifyJavaType(sourceProducers, "java.util.List")) {
        for (var it = sourceProducers.iterator(); it.hasNext();) {
            if (!verifyJavaType(it.next(), "edge.server.pipeline.ProducerDO")) {
                throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): sourceProducers must be List<ProducerDO>");
            }
        }
    } else {
        throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): sourceProducers must be List<ProducerDO>");
    }

    if (!verifyJavaType(transformName, "java.lang.String")) {
        throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): transformName must be non-null String");
    }

    if (!verifyJavaType(outputBundle, "edge.server.pipeline.data.document.ResultBundleDO")) {
        throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): outputBundle must be ResultBundleDO");
    }

    if (nodeVar != null) {
        if (typeof nodeVar !== 'object') {
            throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): nodeVar, if not null, must be a Javascript object");
        }
    }

    if (secVar != null) {
        if (typeof secVar !== 'object') {
            throw new Error("JavascriptTransformer.fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle): secVar, if not null, must be Collection<SecurityParameterValueDO>");
        }
    }

    var outputDefs = outputBundle.getDataDef().getDataAttributes();

    // TODO merge all source defs - when this is done, some of the other convenience/default functions below should
    // be updated to deal with all sources as well.
    // for (var i = 0; i < sourceProducers.size(); i++) {
    //     var producer = sourceProducers.get(i);
    //     var sourceDefs = producer.getAttributeDefs(nodeVar._asJavaCollection(), secVar._asJavaCollection());
    //     CloneUtil.cloneCollection(DataAttributeDO.class, outputDefs, sourceDefs);
    // }

    var producer = sourceProducers.get(0);
    var sourceDefs = producer.getAttributeDefs(nodeVar._asJavaCollection(), secVar._asJavaCollection());
    CloneUtil.cloneCollection(DataAttributeDO.class, outputDefs, sourceDefs);

    outputDefs.forEach(function(def) { def.setProducerName(transformName); });
}

function fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle) {
	return _fetchAttributeDefs(sourceProducers, nodeVar, secVar, transformName, outputBundle);
}

// prunes attributeDefs if no record has a value for that attribute
function pruneAttributeDefs(outputBundle) {
    if (!verifyJavaType(outputBundle, "edge.server.pipeline.data.document.ResultBundleDO")) {
        throw new Error("JavascriptTransformer.pruneAttributeDefs(outputBundle): outputBundle must be ResultBundleDO");
    }
    var toRemove = [];
    var outputDefs = outputBundle.getDataDef().getDataAttributes(); 
    var records = getData(outputBundle);
    for (var it = outputDefs.iterator(); it.hasNext(); ) {
        var attributeDef = it.next();
        var noValues = true;
        for (var i = 0; i < records.size(); i++) {
            var record = records.get(i);
            var value = getValue(record, attributeDef.getName());
            if (value != null) {
                noValues = false;
                break;
            }
        }
        if (noValues) {
            toRemove.push(attributeDef);
        }
    }
    toRemove.forEach(function(attr, index) {
        outputDefs.remove(attr);
    });
};

// takes a ResultBundle and returns the records contained within the bundle
function getData(resultBundle) {
    if (!verifyJavaType(resultBundle, "edge.server.pipeline.data.document.ResultBundleDO")) {
        throw new Error("JavascriptTransformer.getData(resultBundle): resultBundle must be ResultBundleDO");
    }
    return resultBundle.getResultSet().getData();
};

// compares the recordValue to the filterValue using the given comparison operator
function compareValues(recordValue, operator, filterValue) {
    switch(operator) {
        case "<":
            return recordValue < filterValue;
        case ">":
            return recordValue > filterValue;
        case "<=":
            return recordValue <= filterValue;
        case ">=":
            return recordValue >= filterValue;
        case "!=":
            return recordValue != filterValue;
        default:
            return recordValue == filterValue;
    }
};


// A generic way to process records by function. The function is passed a
// record and either returns a (modified) record or null if the record is
// to be skipped.
function recordIterator( sourceBundle, outputBundle, iterFunction ) {
    if ( typeof iterFunction !== "function" ) {
        throw new Error("JavascriptTransformer.recordIterator(sourceBundle, outputBundle, iterFunction) requires a function argument");
    } else if (!verifyJavaType(sourceBundle, "edge.server.pipeline.data.document.ResultBundleDO") || !verifyJavaType(outputBundle, "edge.server.pipeline.data.document.ResultBundleDO")) {
        throw new Error("JavascriptTransformer.recordIterator(sourceBundle, outputBundle, iterFunction) requires both a source and output ResultBundleDO");
    }
    
    outputBundle.getResultSet().copyColumnMappingFrom(sourceBundle.getResultSet());

    var sourceData = getData(sourceBundle);
    var outputData = getData(outputBundle);
    
    for (var i = 0, len = sourceData.size(); i < len; i++) {
        var resultRecord = iterFunction(sourceData.get(i));
        if ( resultRecord != null ) {
            outputData.add( resultRecord );
        }
    }
    return outputBundle;
};


function createOutputRecord( sourceRecord, sourceAttributes, outputResults ) {

    var outputRecord = outputResults.newRecord();
    var numSourceAttributes = sourceRecord.getColumnMapping().getNumColumns();

    for (var i = 0; i < numSourceAttributes; i++) {
        var attrName = sourceAttributes.get(i).getName();
        outputRecord.addColumn(attrName, sourceRecord.getValue(attrName));
    }

    return outputRecord;
}

// Uses the recordIterator to simply copy the sourceBundle data to the
// outputBundle.
function copyBundle( sourceBundle, outputBundle ) {

    var sourceAttributes = sourceBundle.getDataDef().getDataAttributes();
    var outputResults = outputBundle.getResultSet();

    return recordIterator( sourceBundle, outputBundle, function(r) { return createOutputRecord(r, this.sourceAttributes, this.outputResults); } );
}


// uses the recordIterator to filter the sourceBundle on filterField
function filterSourceByField(sourceBundle, outputBundle, filterField, operator, filterValue) {
    if (!verifyJavaType(filterField, "java.lang.String") || !verifyJavaType(operator, "java.lang.String")) {
        throw new Error("JavascriptTransformer.filterSourceByField(sourceBundle, outputBundle, filterField, operator, filterValue) requires non-null filterField and operator Strings");
    }

    return recordIterator( sourceBundle, outputBundle, function(r) {
        var sourceAttributes = sourceBundle.getDataDef().getDataAttributes();
        var outputResults = outputBundle.getResultSet();
        var value = getValue(r, filterField);
        if ( compareValues(value, operator, filterValue) ) {
            return createOutputRecord(r, sourceAttributes, outputResults);
        }
        else {
            return null;
        }
    } );
};

