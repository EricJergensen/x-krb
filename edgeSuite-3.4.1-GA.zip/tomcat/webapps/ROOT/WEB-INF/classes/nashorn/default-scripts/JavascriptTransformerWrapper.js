
function fetchAttributeDefsWrapper(sourceProducers, nodeVars, secVars, transformName, outputBundle) {

   fetchAttributeDefs(sourceProducers, convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars),
       transformName, outputBundle);
}

function transformerMainWrapper(sourceBundles, outputBundle, nodeVars, secVars) {

    return main(sourceBundles, outputBundle, convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars));
}

function transformGetAttributesWrapper(transform, sourceAttrs, nodeVars, secVars) {
	// getAttributes should return either jsAttributesSuccess() or jsAttributesFailure()
	// getAttributes(sourceAttrs, nodeVars, secVars) => { return { success : true|false, attributes : [{}], message : string }; }
	var result = getAttributes(convertSourceAttrsForJs(sourceAttrs), convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars));
	if (result.success) {
		return JavascriptAttributeResponseDO.makeSuccessResult(
				createAttributeList(result.attributes, transform),
				result.message);
	} else {
		return JavascriptAttributeResponseDO.makeErrorResult(result.message);
	}
}
	
function transformGetRecordsWrapper(transform, attributes, sourceRecords, nodeVars, secVars) {
	// getRecords should return either jsRecordsSuccess() or jsRecordsFailure()
	// getRecords(sourceRecords, nodeVars, secVars) => { return { success : true|false, records : [{}], message : string }; }
	var result = getRecords(convertSourceRecordsForJs(sourceRecords), convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars));
	if (result.success) {
		return JavascriptRecordsResponseDO.makeSuccessResult(
				createResultBundle(transform, result.records, attributes),
				result.message);
	} else {
		return JavascriptRecordsResponseDO.makeErrorResult(result.message);
	}
}
