
/*
 * Copyright 2016 Edge Technologies
 */

var List = Java.type("java.util.List");

var ProxyRuleWrapper = function(appContext, rule, ruleName) {

    this.appContext = appContext;
    this.rule = rule;
    this.ruleName = ruleName;
    this.infoService = appContext.getBean("infoService");

    var self = this;

    this.createWebSocketProxyContext = function(requestContext) {

        var feed = requestContext.getFeed();

        return {
            requestContext: requestContext,

            feed: feed,
            feedName: feed.getName()
        };
    };

    this.createHttpProxyContext = function(requestContext, event) {

        var appRequestContext = requestContext.getAppRequestContext();
        var appRequest = appRequestContext.getRequest();
        var feed = requestContext.getProxyUrl().getFeed();
        var connection = feed.getConnection();
        var endpoint = requestContext.getProxyUrl().getEndpoint();

        var ssoCredentials = appRequestContext.getSession().getSsoCredentials();
        var infoService = this.infoService;

        return {
            requestContext: requestContext,
            event: event,
            evalEnvironment: requestContext.getEvalEnvironment(),

            clientRequest: requestContext.getClientRequest(),
            clientResponse: requestContext.getClientResponse(),

            appRequestContext: appRequestContext,
            appSession: appRequestContext.getSession(),
            ssoCredentials: ssoCredentials ? ssoCredentials.getCredentials() : null,
            cookieCache: appRequestContext.getCookieWorker(),
            
            appRequest: appRequest, // this will sometimes be null in the SSO context
            appResponse: appRequestContext.getResponse(),
            requestUri: appRequest ? appRequest.getRequestUri() : null,

            feed: feed,
            feedName: feed.getName(),
            connection: connection,
            endpoint: endpoint,

            connectionProtocol: requestContext.getProxyUrl().isHttps() ? "https" : "http",

            getContentLocationId: function(location, protocol) {
                return connection.getConnector().getContentLocationId(endpoint, location, protocol);
            },

            info: {
                get: function(name) {
                    var value = infoService.getValue("info." + name);
                    if (value) {
                        if (value instanceof List) {
                            return Java.from(value);
                        } else {
                            return value.getFullyResolvedValue().getValue();
                        }
                    }
                    return null;
                }
            }
        };
    };
    
    this.createRequestContext = function(requestContext, event) {
        
        var ctx = this.createHttpProxyContext(requestContext, event);
        
        ctx.setResponsePipelineType = function(pipelineType) {
            this.appRequestContext.setResponsePipelineType(pipelineType);
        };

        return ctx;
    };

    this.createResponseContext = function(requestContext, event) {

        var ctx = this.createRequestContext(requestContext, event);

        ctx.responsePipeline = ctx.appRequestContext.getResponsePipeline();
        ctx.transformsIndex = ctx.responsePipeline.getTransformsIndex();
        ctx.rootSequence = ctx.responsePipeline.getChildTransform();

        return ctx;
    };

    this.createSsoContext = function(requestContext, event, requestNumber) {
        
        var ctx = this.createHttpProxyContext(requestContext, event);

        ctx.requestNumber = isDefined(requestNumber) ? requestNumber + 1 : 1;

        ctx.startSsoRequest = function(method, uri, onResponse) {
            this.requestContext.getAppRequestContext().startSsoSubRequest(method, uri,
                function(requestContext) {
                    // .name is ES6, but nashorn supports it
                    var methodName = onResponse.name ? onResponse.name.replace('Wrapper', '') : "<anonymous>";
                    var event = requestContext.getRequestProfile().createEvent(self.ruleName + "." + methodName);
                    onResponse(self.createSsoContext(requestContext, event, ctx.requestNumber));
                    event.onFinished(true, "");
                });

            // careful: AppRequestContext#startSsoSubRequest creates a new AppRequest
            this.appRequest = this.appRequestContext.getRequest();
            
            theBaseWeb.headerHandlers.onRequest(ctx);
        };

        ctx.startSsxRequest = function(method, uri, onResponse) {
            if (isNonNull(onResponse)) {
                logger.debug("Will use adapter's logout response handler");
                ctx.startSsoRequest(method, uri, onResponse);
            } else {
                logger.debug("Will use default logout response handler");
                ctx.startSsoRequest(method, uri, function onLogoutResponseDefault(ctx) {
                    ctx.appSession.signOffComplete(true);
                });
            }
        };

        // ctx.signOnAbort = function() {
        //
        //     this.appSession.signOnAbort();
        // };
        //
        // ctx.signOnComplete = function(established) {
        //
        //     this.appSession.signOnComplete(established);
        // };

        // ctx.ssoSessionEstablished = function() { this.appSession.signOnComplete(true); };
        // ctx.ssoSignOnFailed = function() { this.appSession.signOnComplete(false); };

        //
        // ctx.signOffComplete = function(signedOff) {
        //
        //     this.appSession.signOffComplete(signedOff);
        // };

        return ctx;
    };

    // Both content/data and SSO rules have this method.  Currently we can get away with what we're doing here, but
    // in future we may have different requirements for how our wrapper context is set up
    this.onRequest = function (requestContext) {

        var event = requestContext.getRequestProfile().createEvent(this.ruleName + ".onRequest");
        if (this.rule.onRequest) {
            this.rule.onRequest(this.createRequestContext(requestContext, event));
        }
        event.onFinished(true, "");
    };

    // same applies here as onRequest wrt SSO.
    this.onResponse = function (requestContext) {

        var event = requestContext.getRequestProfile().createEvent(this.ruleName + ".onResponse");
        if (this.rule.onResponse) {
            this.rule.onResponse(this.createResponseContext(requestContext, event));
        }
        event.onFinished(true, "");
    };

    this.signOn = function (requestContext) {

        var event = requestContext.getRequestProfile().createEvent(this.ruleName + ".signOn");
        this.rule.signOn(this.createSsoContext(requestContext, event));
        event.onFinished(true, "");
    };

    this.signOff = function (requestContext) {

        var event = requestContext.getRequestProfile().createEvent(this.ruleName + ".signOff");
        this.rule.signOff(this.createSsoContext(requestContext, event));
        event.onFinished(true, "");
    };

    this.isExpired = function (requestContext) {

        var event = requestContext.getRequestProfile().createEvent(this.ruleName + ".isExpired");
        var expired;
        if (this.rule.isExpired) {
            expired = this.rule.isExpired(this.createSsoContext(requestContext, event));
        } else {
            expired = false;
        }
        event.onFinished(true, "");

        return expired;
    };

    this.onWebSocketTextRequest = function (requestContext, message) {

        if (this.rule.onWebSocketTextRequest) {
            return this.rule.onWebSocketTextRequest(this.createWebSocketProxyContext(requestContext), message);
        } else {
            return message;
        }
    };

    this.onWebSocketTextResponse = function (requestContext, message) {

        if (this.rule.onWebSocketTextResponse) {
            return this.rule.onWebSocketTextResponse(this.createWebSocketProxyContext(requestContext), message);
        } else {
            return message;
        }
    };
};
