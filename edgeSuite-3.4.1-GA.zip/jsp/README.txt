Customizing the edgeSuite login and checkhealth pages
-----------------------------------------------------

This directory can be used to override the system provided login and checkhealth pages.

  * The custom login page must be named "login.edgejsp"
  
  * The custom checkhealth page must be named "checkhealth.edgejsp"

  * The system provided login page, checkhealth page, and resources can be used 
    as starting points by copying them from:

    [INSTALL_HOME]/tomcat/webapps/ROOT/WEB-INF/jsp/
    (NOTE: do not modify the system provided files in the location above; these
           files are cleaned; and the [INSTALL_HOME]/jsp/*jsp files are reapplied
           on re-initialization.)

  * Files in this custom location are automatically included and restored in
    backup archives.

  * Upgrading to a new release of edgeSuite may require updates to
    custom login and checkhealth pages.

  * Static resources for custom login pages should be placed in
    [INSTALL_HOME]/static-web/login/.


Further information
-------------------

  * Online Documentation: http://docs.edge-technologies.com
