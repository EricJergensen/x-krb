
var nodeVars = [];

if ((typeof parameters !== 'undefined') && parameters != null ) {
   while( parameters.hasNext() ) {
       var pair = parameters.next();
       nodeVars[pair.getKey()] = pair.getValue().getValue();
   }
}

// param is deprecated - not sure if anyone is using it, so will have to remain
var param = nodeVars;
