var ServerActionResponseDO = Java.type("edge.server.pipeline.connect.ServerActionResponseDO");

function feedMainWrapper(feedId, feedName, cachedAttributes, refetchAttributes, nodeVars, secVars) {

    return main(inputString, feedId, feedName, cachedAttributes, refetchAttributes, convertNodeVarsForJs(nodeVars),
        convertSecVarsForJs(secVars));
}

function createRecord( outputResults ) {

    var outputRecord = outputResults.newRecord();
    
    return outputRecord;
}

function makeActionSuccessResult() {
	return ServerActionResponseDO.makeSuccessResult();
}

function makeActionSuccessResult(successDetail) {
	return ServerActionResponseDO.makeSuccessResult(successDetail);
}

function makeActionFailureResult(errorDetail) {
	return ServerActionResponseDO.makeErrorResult(errorDetail);
}