// used to clone objects and collections
var CloneUtil = Java.type("edge.server.util.CloneUtil");

var DataAttributeDO = Java.type("edge.server.pipeline.data.document.DataAttributeDO");
var DataAttributeTypeDO = Java.type("edge.server.pipeline.data.document.DataAttributeTypeDO");

var TabularRecordDO = Java.type("edge.server.pipeline.data.document.TabularRecordDO");
var ResultBundleDO = Java.type("edge.server.pipeline.data.document.ResultBundleDO");
var TabularDataResultsDO = Java.type("edge.server.pipeline.data.document.TabularDataResultsDO");

var ParameterValueListDO = Java.type("edge.server.pipeline.parameter.ParameterValueListDO");

var ParameterValueDO = Java.type("edge.server.pipeline.parameter.ParameterValueDO");

var JavascriptAttributeResponseDO = Java.type("edge.server.pipeline.data.connectors.JavascriptAttributeResponseDO");
var JavascriptRecordsResponseDO = Java.type("edge.server.pipeline.data.connectors.JavascriptRecordsResponseDO");

var ProducerHelper = Java.type("edge.server.pipeline.data.util.ProducerHelper");

function jsAttributesSuccess(attrs, successMessage) {
	return { success : true, attributes : attrs, message : successMessage};
}

function jsAttributesFailure(failureMessage) {
	return { success : false, message : failureMessage};
}

function jsRecordsSuccess(recs, successMessage) {
	return { success : true, records : recs, message : successMessage};
}

function jsRecordsFailure(failureMessage) {
	return { success : false, message : failureMessage};
}

function makeParameterValueList(valueMap) {
	var list = new java.util.ArrayList();
	Object.keys(valueMap).forEach(function(key) {
		var paramVal = new ParameterValueDO(key, valueMap[key]);
		list.add(paramVal);
	});
	var paramList = new ParameterValueListDO(list);
	
	return paramList;
}

function verifyJavaType(someVar, fqClassName) {
    if (!(fqClassName instanceof Java.type("java.lang.String"))) {
        return false;
    } else {
        try {
            return someVar instanceof Java.type(fqClassName);
        } catch (err) {
            throw new Error("JavascriptTransformer.verifyJavaType(someVar, fqClassName): could not verify type for args \"someVar\" (" + someVar + ") and \"fqClassName\" + (" + fqClassName + ")");
        }
    }
};

// gets the value that is mapped to the given field
var getValueErrorMsg = "JavascriptTransformer.getValue(record, field): record must be TabularRecordDO and field must be non-null String";
function getValue(record, field) {
    if (record == null || field == null) {
        throw new Error(getValueErrorMsg);
    }
    try {
        return record.getValue(field);
    } catch(e) {
        throw new Error(getValueErrorMsg);
    }
};

// for the given record, this function maps the given value to the given field
var setValueErrorMsg = "JavascriptTransformer.setValue(record, field, value): record must be TabularRecordDO and field must be non-null String";
function setValue(record, field, value) {
    if (record == null || field == null) {
        throw new Error(setValueErrorMsg);
    }
    try {
        return record.addColumn(field, value);
    } catch(e) {
        throw new Error(setValueErrorMsg);
    }
};

// allows you to set multiple values with a single function call
function setValues(record, propsObject) {
    for (var prop in propsObject) {
        record = setValue(record, prop, propsObject[prop]);
    }
    return record;
};

// creates a new attribute on the output ResultBundle
// takes a producerName (typically the transform name), the output ResultBundle, a string to indicate the attribute name, and a string to indicate the type
//TODO: deprecate this function in eS 3.4
function addAttributeDef(producerName, outputBundle, defName, defType) {
    if (!verifyJavaType(producerName, "java.lang.String")) {
        throw new Error("JavascriptTransformer.addAttributeDef(producerName, outputBundle, defName, defType): producerName must be non-null String");
    }
    if (!verifyJavaType(outputBundle, "edge.server.pipeline.data.document.ResultBundleDO")) {
        throw new Error("JavascriptTransformer.addAttributeDef(producerName, outputBundle, defName, defType): outputBundle must be ResultBundleDO");
    }
    if (!verifyJavaType(defName, "java.lang.String") || !verifyJavaType(defType, "java.lang.String")) {
        throw new Error("JavascriptTransformer.addAttributeDef(producerName, outputBundle, defName, defType): defName and defType must be non-null Strings");
    }
    var DataAttributeTypeDO = Java.type("edge.server.pipeline.data.document.DataAttributeTypeDO");
    var attributeDefSet = outputBundle.getDataDef().getDataAttributes();
    for (var it = attributeDefSet.iterator(); it.hasNext(); ) {
        var attributeDef = it.next();
        if (attributeDef.getSourceName().equals(defName)) {
            // attributeDef already exists, no need to make a new one
            return;
        }
    }

    var type;
    switch(defType.toUpperCase()) {
        case "INT":
            type = DataAttributeTypeDO.INT;
            break;
        case "LONG":
            type = DataAttributeTypeDO.LONG;
            break;
        case "NUMBER":
            type = DataAttributeTypeDO.NUMBER;
            break;
        case "BOOLEAN":
            type = DataAttributeTypeDO.BOOLEAN;
            break;
        case "DATE":
            type = DataAttributeTypeDO.DATE;
            break;
        default:
            type = DataAttributeTypeDO.STRING;
    }
    var newAttribute = new DataAttributeDO(producerName, type, defName);
    attributeDefSet.add(newAttribute);

    return outputBundle;
}

function convertNodeVarsForJs(nodeVars) {

    var jsNodeVars = {};
    nodeVars.forEach(function(nodeVar) {
        jsNodeVars[nodeVar.getName()] = nodeVar.getValue();
    });
    jsNodeVars._asJavaCollection = function() { return nodeVars; };
    return jsNodeVars;
}

function convertSecVarsForJs(secVars) {

    var jsSecVars = {};
    secVars.forEach(function(secVar) {
        jsSecVars[secVar.getName()] = secVar.getValue().getValue();
    });
    jsSecVars._asJavaCollection = function() { return secVars; };
    return jsSecVars;
}

function inTestMode(jsSecVars) {
	for each (var secVar in jsSecVars) {
		if ( secVar.getName() === "es_testMode" ) { 
			return true;
		}
	}
	return false;
}

// TODO should some of the properties be read only?
var jsDataAttribute = (function(){
	  function jsDataAttribute(javaDataAttribute) {
	    this._asJavaObject = javaDataAttribute;
	  }

//		var sampleAttr = {
//			name : 'foo',
//			type : 'string', // 'string'|'int'|'long'|'number'|'boolean'|'date'
//			isId : false, // true|false
//			units : null, // 'millis'|'seconds' (if attribute is a timestamp)
//			format : null // string consisting of valid Java SimpleDateFormat pattern
//		};
	  
	  // Read/Write Properties: name, type, isId, units, format
	  Object.defineProperty(jsDataAttribute.prototype, "name", {
	      get: function () {
	          return this._asJavaObject.getName();
	      },
	      set: function (name) {
	          this._asJavaObject.setName(name);
	      },
	      enumerable: true
	  });
	  Object.defineProperty(jsDataAttribute.prototype, "type", {
	      get: function () {
	    	  	// type is documented in example as 'string'|'int'|'long'|'number'|'boolean'|'date'
	    	  	// so return lowercase string.  will make conversion to uppercase on the server side
	          return this._asJavaObject.getType().toString().toLowerCase();
	      },
	      set: function (type) {
	          this._asJavaObject.setType(DataAttributeTypeDO.valueOf(type.toUpperCase()));
	      },
	      enumerable: true
	  });
	  Object.defineProperty(jsDataAttribute.prototype, "isId", {
	      get: function () {
	          return this._asJavaObject.isId();
	      }, set: function (isId) {
	          this._asJavaObject.setIsId(isId);
	      },
	      enumerable: true
	  });
	  Object.defineProperty(jsDataAttribute.prototype, "units", {
	      get: function () {
	          return this._asJavaObject.getUnits();
	      },
	      set: function (units) {
	          this._asJavaObject.setUnits(units);
	      },
	      enumerable: true
	  });
	  Object.defineProperty(jsDataAttribute.prototype, "format", {
	      get: function () {
	          return this._asJavaObject.getFormat();
	      },
	      set: function (format) {
	          this._asJavaObject.setFormat(format);
	      },
	      enumerable: true
	  });
	  
	  // Read-only properties: producerName, sourceName, ordinalPosition
	  Object.defineProperty(jsDataAttribute.prototype, "producerName", {
	      get: function () {
	          return this._asJavaObject.getProducerName();
	      },
	      enumerable: true
	  });
	  
	  
	  Object.defineProperty(jsDataAttribute.prototype, "sourceName", {
	      get: function () {
	          return this._asJavaObject.getSourceName();
	      },
	      enumerable: true
	  });
	 
	  Object.defineProperty(jsDataAttribute.prototype, "ordinalPosition", {
	      get: function () {
	          return this._asJavaObject.getOrdinalPosition();
	      },
	      enumerable: true
	  });
	  return jsDataAttribute;
	})();

function convertSourceAttrsForJs(sourceAttrs) {
	// sourceAttrs == List<List<DataAttributeDO>>
	var jsDataAttributes = []; // [[{}]]
	
	sourceAttrs.forEach(function(attrList) {
		// attrList == List<DataAttributeDO>
		var convertedList = []; // [{}]
		attrList.forEach(function(dataAttr) {
			// dataAttr == DataAttributeDO
			var attr = new jsDataAttribute(dataAttr);
			convertedList.push(attr);
		});
		jsDataAttributes.push(convertedList);
	});

    return jsDataAttributes;
}

function convertSourceRecordsForJs(sourceRecords) {
	// sourceRecords = List<List<TabularRecordDO>>
	var jsRecords = []; // [[{}]]
	sourceRecords.forEach(function(recordList) {
		// recordList == List<TabularRecordDO>
		var convertedList = []; // [{}]
		recordList.forEach(function(javaRecord) {
			// javaRecord == TabularRecordDO
			var jsRecord = {};
			jsRecord._asJavaObject = javaRecord;
			jsRecord._clone = null;
			
			jsRecord._get = function(name) {
				var value;
				if (this._clone != null) {
					value = this._clone.getValue(name);
				} else {
					value = this._asJavaObject.getValue(name);
				}
				
				if (value instanceof java.lang.Number) {
					// Integer, Long, Number
					// Number() function returns value as Double (typeof == 'number')
					return Number(value);
				} else if (value instanceof java.lang.Boolean) {
					return value.booleanValue(); // (typeof == 'boolean')
				} else {
					// String, Date, null (typeof == 'string' or 'object')
					return value;
				}
			};
			
			jsRecord._set = function(name, newValue) {
				if (this._clone != null) {
					this._clone.setValue(name, newValue);
				} else {
					this._clone = new TabularRecordDO(this._asJavaObject);
					this._clone.setValue(name, newValue);
				}
			};
			
			var columnNames = javaRecord.getColumnMapping().getColumnNames();
			// columnNames == Set<String>
			columnNames.forEach(function(name) {
				Object.defineProperty(jsRecord, name, {
				    get: function() {
				      return this._get(name);
				    },
				    set: function(newValue) {
				      this._set(name, newValue);
				    },
				    enumerable : true
				  });
			});
			convertedList.push(jsRecord);
		});
		jsRecords.push(convertedList);
	});
	return jsRecords;
}

function createAttributeList(attributes, producer) {
	 // attributes == Java list or JS array of DataAttributeDO or
	  //                objects that can map to DataAttributeDO
	  // producer == FeedDO or TransformDO
	 
	  var newList = new java.util.ArrayList();
	  
	  var ordinalPosition = 1;
	 
	  if (attributes) {
	    attributes.forEach(function(attr) {
	      if (attr instanceof DataAttributeDO) {
	        var clone = new DataAttributeDO(producer, attr.getType(), attr.getName());
	        clone.setIsId(attr.isId());
	        clone.setUnits(attr.getUnits());
	        clone.setFormat(attr.getFormat());
	        clone.setOrdinalPosition(ordinalPosition++);
	        newList.add(clone)
	      } else {
	        var jsType = (attr.type) ? attr.type : "STRING";
	        var javaType = DataAttributeTypeDO.valueOf(jsType.toUpperCase());
	        var newAttr = new DataAttributeDO(producer, javaType, attr.name);
	        newAttr.setIsId(Boolean(attr.isId));
	        newAttr.setUnits(attr.units);
	        newAttr.setFormat(attr.format);
	        newAttr.setOrdinalPosition(ordinalPosition++);
	        newList.add(newAttr);
	      }
	    });
	  }
	 
	  ProducerHelper.makeSafeAttributeSet(newList);
	  return newList;
}

function createResultBundle(producer, records, attributes) {
 
  //records == Java list or JS array of TabularRecordDO or
  //                objects that can map to TabularRecordDO
  // attributes == List<DataAttributeDO>
 
  var table = new TabularDataResultsDO(producer.getName());
  var rb = ResultBundleDO.makeTabularResultBundle(producer.getId(),
                      producer.getName(), table, attributes);
 
  records.forEach(function(record) {
    var tabularRecord = table.newRecord();
    attributes.forEach(function(attr) {
      var attrName = attr.getSourceName();
      if (record instanceof TabularRecordDO) {
    	  	tabularRecord.addColumn(attr, "" + record.getValue(attrName));
      } else {
          var value = record[attrName];
          if (value && (value instanceof java.util.Date || (value.constructor && (value.constructor() === Date())))) {
        	  	// do this for both Java Date and JS Date
        	  
	        	  // stringified date returns ISO 8601 string that doesn't parse without format pattern (returns null)
	        	  // workaround to get accurate date value (client will show format 2012-12-03 12:00:09)
	        	  
	        	  attr.setUnits("millis");
	        	  attr.setFormat(null);
	        	  value = value.getTime();

          }
          tabularRecord.addColumn(attr, "" + value);
        }
    });
    rb.getResultSet().addRecord(tabularRecord);
  });
 
  return rb;
}
