print("************************************************************");
print("*  Generating Summary Report via SummarizeArchiveUtil.js   *");
print("************************************************************");
print("");

if (!String.prototype.repeat) {
  String.prototype.repeat = function(count) {
    'use strict';
    if (this == null) {
      throw new TypeError('can\'t convert ' + this + ' to object');
    }
    var str = '' + this;
    count = +count;
    if (count != count) {
      count = 0;
    }
    if (count < 0) {
      throw new RangeError('repeat count must be non-negative');
    }
    if (count == Infinity) {
      throw new RangeError('repeat count must be less than infinity');
    }
    count = Math.floor(count);
    if (str.length == 0 || count == 0) {
      return '';
    }
    // Ensuring count is a 31-bit integer allows us to heavily optimize the
    // main part. But anyway, most current (August 2014) browsers can't handle
    // strings 1 << 28 chars or longer, so:
    if (str.length * count >= 1 << 28) {
      throw new RangeError('repeat count must not overflow maximum string size');
    }
    var rpt = '';
    for (var i = 0; i < count; i++) {
      rpt += str;
    }
    return rpt;
  }
}

if (!String.prototype.padEnd) {
    String.prototype.padEnd = function padEnd(targetLength,padString) {
        targetLength = targetLength>>0; //floor if number or convert non-number to 0;
        padString = String((typeof padString !== 'undefined' ? padString : ' '));
        if (this.length > targetLength) {
            return String(this);
        }
        else {
            targetLength = targetLength-this.length;
            if (targetLength > padString.length) {
                padString += padString.repeat(targetLength/padString.length); //append to original to ensure we are longer than needed
            }
            return String(this) + padString.slice(0,targetLength);
        }
    };
}

var archiveContents = [];

function getRecord(recordName) {
	if (archiveContents[recordName] == undefined) {
		archiveContents[recordName] = [];
	} 
	return archiveContents[recordName];
}

function recordBackupBundle(restoreBundleDO, nestedDO) {
		var recordName = nestedDO ? nestedDO : restoreBundleDO.backupClass;
    var record = getRecord(recordName);
    for (var i = 0; i < restoreBundleDO.objects.length; i++) {
        var thisObject = restoreBundleDO.objects[i];
				if (nestedDO && thisObject.doClass.indexOf(nestedDO) == -1) {
					continue;
				} 
        var name = "";
        if (thisObject.hasOwnProperty("name")) {
            name = thisObject.name;
        } else if (thisObject.hasOwnProperty("parameterName")) {
            name = thisObject.parameterName;
        } else if (thisObject.hasOwnProperty("properties")) {
            for (var j = 0; j < thisObject.properties.propertyValues.length; j++) {
                var property = thisObject.properties.propertyValues[j];
                if (property.propertyDefName == "name") {
                    name = property.value;
                    break;
                }
            }
        }
        record.push({id:thisObject.id, name:name});
    }
}

var RESTORE_BUNDLE = [
	{backupClass:"edge.server.pipeline.connect.ConnectionDO", label: "Connections"},
	{backupClass:"edge.server.pipeline.data.AbstractTabularProducerDO", label: "Feeds", nestedDO:"DataFeedDO"},
	{backupClass:"edge.server.pipeline.data.AbstractTabularProducerDO", label: "Transforms", nestedDO:"TransformDO"},
	{backupClass:"edge.server.pipeline.data.relational.AbstractRelationalProducerDO", label: "Relational Models"},
	{backupClass:"edge.server.pipeline.data.visualization.DataVisualizationDO", label: "Visualizations"},
	{backupClass:"edge.server.proxy.pipeline.ProxyFeedDO", label: "Web Content Feeds"},
	{backupClass:"edge.server.proxy.pipeline.ProxyVisualizationDO", label: "Web Content Visualizations"},
	{backupClass:"edge.server.pipeline.parameter.ParameterConstraintDO", label: "Constraints"},
	{backupClass:"edge.server.pipeline.parameter.SecurityParameterDO", label: "Secured Variables"},
	{backupClass:"edge.server.pipeline.data.ServerActionDO", label: "Server Actions"},
	{backupClass:"edge.server.pipeline.visualization.mappers.RuleSetDO", label: "Rule Sets"},
	{backupClass:"edge.server.pipeline.visualization.ColorPaletteDO", label: "Color Palettes"},
	{backupClass:"edge.server.pipeline.visualization.ClientFilterDO", label: "Client Filters"},
	{backupClass:"edge.server.maps.MapLayerDO", label: "Map Layers"}	
];

upgradeUtil.updateAllObjects("RestoreBundleDO", function (restoreBundleDO) {
	for (var i = 0, l = RESTORE_BUNDLE.length; i < l; i++) {
		var info = RESTORE_BUNDLE[i];
		if (restoreBundleDO.backupClass.indexOf(info.backupClass) != -1) {
			recordBackupBundle(restoreBundleDO, info.nestedDO);
		}
	}
	return restoreBundleDO;
});

upgradeUtil.updateAllObjects("PageDO", function (PageDO) {
	var fakeBundle = {backupClass:"edge.server.content.AContentNodeDO",objects:[PageDO]};
	recordBackupBundle(fakeBundle, "PageDO" );
	return PageDO;
});


upgradeUtil.updateAllObjects("PropertyBundleDO", function(propertyBundleDO) {
    upgradeUtil.sort(propertyBundleDO);
    return propertyBundleDO;
});

RESTORE_BUNDLE.unshift({backupClass:"edge.server.content.AContentNodeDO", label: "Pages", nestedDO:"PageDO"});

function echoDOs(doObjects) {
	doObjects.sort(function (a,b) {
		  var nameA = a.name.toLowerCase(); 
		  var nameB = b.name.toLowerCase();
		  var idA = a.id;
		  var idB = b.id; 
		  if (idA < idB) {
		    return -1;
		  }
		  if (idA > idB) {
		    return 1;				
		  }
		  if (nameA < nameB) {
		    return -1;
		  }
		  if (nameA > nameB) {
		    return 1;
		  }
		  return 0;
	});
	for (var i = 0; i < doObjects.length; i++) {
		var doObject = doObjects[i];
		if (doObject.id == null) {
			doObject.id = "N/A";
		}
		
		if ( doObject.parentPath ) {
			print("ID: " + doObject.id.padEnd(30) + " Name: " + doObject.name + " ParentPath: " + doObject.parentPath);
		} else {
			print("ID: " + doObject.id.padEnd(30) + " Name: " + doObject.name);
		}
	}
}

function printResults() {
	for (var i = 0, l = RESTORE_BUNDLE.length; i < l; i++) {
		var info = RESTORE_BUNDLE[i];
		var record = getRecord(info.nestedDO ? info.nestedDO : info.backupClass);
		print(info.label+ ": " + record.length);
		print("------------------------")
		echoDOs(record);
		print("");
	}
}

printResults();
