angular.module('edgeCore.TPLS', ['edge/core/admin/admin.tpl.html', 'edge/core/admin/adminbar/edgeAdminBar.tpl.html', 'edge/core/admin/backup/backup.tpl.html', 'edge/core/admin/backup/dialogs/commit-restore-dialog.tpl.html', 'edge/core/admin/backup/dialogs/full-restore-wizard-dialog.tpl.html', 'edge/core/admin/backup/dialogs/partial-restore-wizard-dialog.tpl.html', 'edge/core/admin/backup/dialogs/restore-result.tpl.html', 'edge/core/admin/backup/dialogs/save-archive-dialog.tpl.html', 'edge/core/admin/backup/edgeRestoreResultChart.tpl.html', 'edge/core/admin/managers/clientfilter/client-filter-manage-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/daterange/client-filter-daterange-create-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeControl.tpl.html', 'edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeListItem.tpl.html', 'edge/core/admin/managers/clientfilter/daterange/edgeDateRangeFilterInstanceConfig.tpl.html', 'edge/core/admin/managers/clientfilter/daterangeslider/client-filter-daterangeslider-create-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderControl.tpl.html', 'edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderListItem.tpl.html', 'edge/core/admin/managers/clientfilter/daterangeslider/edgeDateRangeSliderFilterInstanceConfig.tpl.html', 'edge/core/admin/managers/clientfilter/expression/client-filter-exp-create-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/expression/client-filter-exp-filterdef-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpControl.tpl.html', 'edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpListItem.tpl.html', 'edge/core/admin/managers/clientfilter/expression/edgeCustomExpressionConfigInstance.tpl.html', 'edge/core/admin/managers/clientfilter/manage-visualization-filters-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterControl.tpl.html', 'edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterInstanceConfig.tpl.html', 'edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterListItem.tpl.html', 'edge/core/admin/managers/clientfilter/realtime/client-filter-realtime-create-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeControl.tpl.html', 'edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeListItem.tpl.html', 'edge/core/admin/managers/clientfilter/realtime/edgeRealtimeFilterInstanceConfig.tpl.html', 'edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterControl.tpl.html', 'edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterListItem.tpl.html', 'edge/core/admin/managers/clientfilter/sort/edgeSortFilterControl.tpl.html', 'edge/core/admin/managers/clientfilter/sort/edgeSortFilterListItem.tpl.html', 'edge/core/admin/managers/clientfilter/sort/sort-configure-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/string/client-filter-string-create-dialog.tpl.html', 'edge/core/admin/managers/clientfilter/string/edgeClientFilterStringControl.tpl.html', 'edge/core/admin/managers/clientfilter/string/edgeClientFilterStringListItem.tpl.html', 'edge/core/admin/managers/clientfilter/string/edgeStringFilterInstanceConfig.tpl.html', 'edge/core/admin/managers/cluster/cluster-add-dialog.tpl.html', 'edge/core/admin/managers/cluster/cluster-init-dialog.tpl.html', 'edge/core/admin/managers/cluster/cluster.tpl.html', 'edge/core/admin/managers/cluster/make-admin-dialog.tpl.html', 'edge/core/admin/managers/cluster/snapshot-create-dialog.tpl.html', 'edge/core/admin/managers/cluster/snapshot-deploy-dialog.tpl.html', 'edge/core/admin/managers/colorpalette/color-palette-create-dialog.tpl.html', 'edge/core/admin/managers/colorpalette/color-palette-manage-dialog.tpl.html', 'edge/core/admin/managers/config/server-config-dialog.tpl.html', 'edge/core/admin/managers/config/server-config-item-edit-dialog.tpl.html', 'edge/core/admin/managers/content/DeleteContentDialog.tpl.html', 'edge/core/admin/managers/content/manage-content.tpl.html', 'edge/core/admin/managers/drivers/drivers.tpl.html', 'edge/core/admin/managers/drivers/PathNameEntryDialog.tpl.html', 'edge/core/admin/managers/drivers/RenameDriverDialog.tpl.html', 'edge/core/admin/managers/managers.tpl.html', 'edge/core/admin/managers/maps/edit-map-apikey-dialog.tpl.html', 'edge/core/admin/managers/maps/manage-map-layers.tpl.html', 'edge/core/admin/managers/maps/mapLayerWizard.tpl.html', 'edge/core/admin/managers/modules/add-content-bundle-dialog.tpl.html', 'edge/core/admin/managers/modules/add-content-bundle-success-dialog.tpl.html', 'edge/core/admin/managers/modules/import-license-dialog.tpl.html', 'edge/core/admin/managers/modules/import-module-dialog.tpl.html', 'edge/core/admin/managers/modules/import-module-prompt-dialog.tpl.html', 'edge/core/admin/managers/modules/import-module-success-dialog.tpl.html', 'edge/core/admin/managers/modules/license-viewer-dialog.tpl.html', 'edge/core/admin/managers/modules/module-connections-dialog.tpl.html', 'edge/core/admin/managers/modules/modules.tpl.html', 'edge/core/admin/managers/sessions/sessions.tpl.html', 'edge/core/admin/managers/system/edgeAdaptersInfo.tpl.html', 'edge/core/admin/managers/system/edgeSystemInfo.tpl.html', 'edge/core/admin/managers/system/system-info-dialog.tpl.html', 'edge/core/admin/page/add-folder-dialog.tpl.html', 'edge/core/admin/page/add-page-dialog.tpl.html', 'edge/core/admin/pipeline/attrDefList/edgeAttrDefListChooser.tpl.html', 'edge/core/admin/pipeline/CloneNodeDialog.tpl.html', 'edge/core/admin/pipeline/confirm-node-delete-dialog.tpl.html', 'edge/core/admin/pipeline/connect/ChooseConnectionType.tpl.html', 'edge/core/admin/pipeline/connect/connect-wizard.tpl.html', 'edge/core/admin/pipeline/connect/edgeConnectionEndpointDef.tpl.html', 'edge/core/admin/pipeline/connect/edit-database-endpoint-dialog.tpl.html', 'edge/core/admin/pipeline/connect/edit-proxy-endpoint-dialog.tpl.html', 'edge/core/admin/pipeline/connect/failover-connect-wizard.tpl.html', 'edge/core/admin/pipeline/connect/proxy-connect-wizard.tpl.html', 'edge/core/admin/pipeline/connect/proxy-failover-connect-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/ChooseConsumerType.tpl.html', 'edge/core/admin/pipeline/consumer/consumer-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/datapreview/columnTemplate.tpl.html', 'edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreview.tpl.html', 'edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreviewTable.tpl.html', 'edge/core/admin/pipeline/consumer/edgeFileChooser.tpl.html', 'edge/core/admin/pipeline/consumer/edgeParamAssertsListEditor.tpl.html', 'edge/core/admin/pipeline/consumer/edgeParamControl.tpl.html', 'edge/core/admin/pipeline/consumer/edgeParamsListEditor.tpl.html', 'edge/core/admin/pipeline/consumer/edgeProducersChooser.tpl.html', 'edge/core/admin/pipeline/consumer/edgeSecVarsChooser.tpl.html', 'edge/core/admin/pipeline/consumer/flowmodel/edgeRmMetaAttributeEditor.tpl.html', 'edge/core/admin/pipeline/consumer/flowmodel/edit-node-value-aggregation-dialog.tpl.html', 'edge/core/admin/pipeline/consumer/flowmodel/flowmodel-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/date2LongTypeEditor.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/edgeGUISelectTypeEditor.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeConfig.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeDef.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortConfig.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortDef.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/guiSelectConfigWizard.tpl.html', 'edge/core/admin/pipeline/consumer/guiselect/preview-sql-dialog.tpl.html', 'edge/core/admin/pipeline/consumer/json/edgeJsonAttributeDef.tpl.html', 'edge/core/admin/pipeline/consumer/json/edgeJsonPreview.tpl.html', 'edge/core/admin/pipeline/consumer/json/edgeJsonTreenode.tpl.html', 'edge/core/admin/pipeline/consumer/json/json-feed-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/relmodel/add-linkdef-dialog.tpl.html', 'edge/core/admin/pipeline/consumer/relmodel/relmodel-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/streamers/file-streamer-config.tpl.html', 'edge/core/admin/pipeline/consumer/streamers/shell-streamer-config.tpl.html', 'edge/core/admin/pipeline/consumer/streamers/webdata-streamer-config.tpl.html', 'edge/core/admin/pipeline/consumer/treemapmodel/treemapmodel-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/xls/xls-feed-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/xml/edgeXmlTreenode.tpl.html', 'edge/core/admin/pipeline/consumer/xml/xml-feed-wizard.tpl.html', 'edge/core/admin/pipeline/consumer/xml/xslt/xml-xslt-feed-wizard.tpl.html', 'edge/core/admin/pipeline/dialogs/CredentialsNeeded.tpl.html', 'edge/core/admin/pipeline/dialogs/DataRetrievalError.tpl.html', 'edge/core/admin/pipeline/dialogs/SaveFailed.tpl.html', 'edge/core/admin/pipeline/dialogs/SecParamNeeded.tpl.html', 'edge/core/admin/pipeline/edit-pipeline-dialog.tpl.html', 'edge/core/admin/pipeline/jobstatus/jobs.tpl.html', 'edge/core/admin/pipeline/proxy/edgeProxyAppChooser.tpl.html', 'edge/core/admin/pipeline/proxy/edgeProxyAppVersionChooser.tpl.html', 'edge/core/admin/pipeline/proxy/edgeProxyRuleChooser.tpl.html', 'edge/core/admin/pipeline/proxy/edgeSsoHandlerChooser.tpl.html', 'edge/core/admin/pipeline/proxy/proxy-feed-wizard.tpl.html', 'edge/core/admin/pipeline/select-pipe-node.tpl.html', 'edge/core/admin/pipeline/serveraction/server-action-wizard.tpl.html', 'edge/core/admin/pipeline/view-pipes.tpl.html', 'edge/core/admin/pipeline/visualization/ChooseVisualizationType.tpl.html', 'edge/core/admin/provision/defaults/provision-defaults.tpl.html', 'edge/core/admin/provision/global-security-variable-edit.tpl.html', 'edge/core/admin/provision/groups/domains/ChooseDomainType.tpl.html', 'edge/core/admin/provision/groups/domains/ldapAdapterWizard.tpl.html', 'edge/core/admin/provision/groups/domains/ldapCleanupResult.tpl.html', 'edge/core/admin/provision/groups/domains/ldapConfigWizard.tpl.html', 'edge/core/admin/provision/groups/edgePasswordPolicy.tpl.html', 'edge/core/admin/provision/groups/edit-domain-dialog.tpl.html', 'edge/core/admin/provision/groups/edit-role-dialog.tpl.html', 'edge/core/admin/provision/groups/provision-domains.tpl.html', 'edge/core/admin/provision/groups/provision-roles.tpl.html', 'edge/core/admin/provision/kiosk/edgeKioskPagesEditor.tpl.html', 'edge/core/admin/provision/kiosk/edgeKioskPagevarControl.tpl.html', 'edge/core/admin/provision/kiosk/edit-page-setting-dialog.tpl.html', 'edge/core/admin/provision/security-credential-edit.tpl.html', 'edge/core/admin/provision/security-variable-edit.tpl.html', 'edge/core/admin/provision/users/add-existing-user-dialog.tpl.html', 'edge/core/admin/provision/users/add-role-to-user-dialog.tpl.html', 'edge/core/admin/provision/users/edit-user-dialog.tpl.html', 'edge/core/admin/provision/users/provision-users.tpl.html', 'edge/core/base/defaultpage/default.tpl.html', 'edge/core/base/error/error.tpl.html', 'edge/core/base/notification/modal/modalNotification.tpl.html', 'edge/core/base/notification/toaster/edgeToasterNotification.tpl.html', 'edge/core/base/serviceability/about/aboutDialog.tpl.html', 'edge/core/base/serviceability/messages/messages-dialog.tpl.html', 'edge/core/base/serviceability/messages/stack-trace-dialog.tpl.html', 'edge/core/base/services/popup/edgeVerticalPopupMenuItem.tpl.html', 'edge/core/base/services/upload/upload-file-dialog.tpl.html', 'edge/core/base/tools/edgeServerMessage.tpl.html', 'edge/core/communication/change-password.tpl.html', 'edge/core/connect/admin/view/view-connections.tpl.html', 'edge/core/nav/banner/edgeBanner.tpl.html', 'edge/core/nav/breadcrumb/edgeRouterBreadcrumbBar.tpl.html', 'edge/core/nav/hamburger/edgeHamburgerMenu.tpl.html', 'edge/core/nav/menubar/edgeMenuBar.tpl.html', 'edge/core/nav/menubar/edgeMenuBarTab.tpl.html', 'edge/core/nav/menubar/edgePopupMenuItem.tpl.html', 'edge/core/nav/quicksearch/edgeQuickSearch.tpl.html', 'edge/core/nav/systemmenu/edgeSystemMenu.tpl.html', 'edge/core/nav/systemmenu/edgeSystemMenuItemRenderer.tpl.html', 'edge/core/page/breadcrumb/edgePageBreadcrumbBar.tpl.html', 'edge/core/page/dialogs/PageNotFound.tpl.html', 'edge/core/page/layout/cell/edgePageLayoutCell.tpl.html', 'edge/core/page/layout/edgePageLayout.tpl.html', 'edge/core/page/layout/row/edgePageLayoutInternalRow.tpl.html', 'edge/core/page/layout/row/edgePageLayoutRow.tpl.html', 'edge/core/page/pagevars/delete-pagevar-confirm-dialog.tpl.html', 'edge/core/page/pagevars/edgePagevarControl.tpl.html', 'edge/core/page/pagevars/edgePageVarEditor.tpl.html', 'edge/core/page/pagevars/edgePageVarMappingControl.tpl.html', 'edge/core/page/pagevars/edgePageVarMappingList.tpl.html', 'edge/core/page/pagevars/edit-pagevar-dialog.tpl.html', 'edge/core/page/pagevars/pagevar-manager-dialog.tpl.html', 'edge/core/page/parameters/edit-param-property.tpl.html', 'edge/core/page/parameters/edit-secparam-property.tpl.html', 'edge/core/page/parameters/parameter-chooser-dialog.tpl.html', 'edge/core/page/parameters/secparam-chooser-dialog.tpl.html', 'edge/core/pipes/edgePipes.tpl.html', 'edge/core/pipes/edgePipesTable.tpl.html', 'edge/core/pipes/edgePipesTreeTable.tpl.html', 'edge/core/pipes/pipes-settings-dialog.tpl.html', 'edge/core/pipes/reparent-node-dialog.tpl.html', 'edge/core/pipes/search/edgePipelineSearch.tpl.html', 'edge/core/prefs/preferences.tpl.html', 'edge/core/prefs/user-password-changer.tpl.html', 'edge/core/present/admin/pages/dialogs/AddVisualizationDialog.tpl.html', 'edge/core/present/admin/pages/dialogs/edit-visualization-instances-dialog.tpl.html', 'edge/core/present/admin/pages/dialogs/page-options-dialog.tpl.html', 'edge/core/present/admin/pages/dialogs/SelectProducerDialog.tpl.html', 'edge/core/present/admin/pages/manage-pages.tpl.html', 'edge/core/rules/dialogs/clone-ruleset-dialog.tpl.html', 'edge/core/rules/dialogs/edit-formatter-dialog.tpl.html', 'edge/core/rules/dialogs/edit-ruleset-dialog.tpl.html', 'edge/core/rules/dialogs/js-help-dialog.tpl.html', 'edge/core/rules/dialogs/new-ruleset-dialog.tpl.html', 'edge/core/rules/edgeExpRuleBuilder.tpl.html', 'edge/core/rules/edgeRuleBuilder.tpl.html', 'edge/core/rules/edgeRuleSetStyleConfigPreview.tpl.html', 'edge/core/rules/manage-rulesets.tpl.html', 'edge/core/test/integration/integration.tpl.html', 'edge/core/view/edgeView.tpl.html', 'edge/core/view/edgeViewSidebarContent.tpl.html', 'edge/core/widget/actions/edgeManageActionsDialogFooter.tpl.html', 'edge/core/widget/actions/launchurl/action-launch-url-wizard.tpl.html', 'edge/core/widget/actions/manage-actions-dialog.tpl.html', 'edge/core/widget/actions/multiselect/action-multiselect-wizard.tpl.html', 'edge/core/widget/actions/serverupdate/action-server-update-wizard.tpl.html', 'edge/core/widget/actions/serverupdate/user-prompter-dialog.tpl.html', 'edge/core/widget/actions/setpagevar/action-set-page-var-wizard.tpl.html', 'edge/core/widget/actions/showrecord/action-show-record-dialog.tpl.html', 'edge/core/widget/actions/showrecord/action-show-record-wizard.tpl.html', 'edge/core/widget/actions/showwidget/action-show-widget-wizard.tpl.html', 'edge/core/widget/actions/switchpage/action-switch-page-wizard.tpl.html', 'edge/core/widget/actions/switchpage/edgePageVarMapper.tpl.html', 'edge/core/widget/actions/tooltip/action-tooltip-wizard.tpl.html', 'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html', 'edge/core/widget/actions/tooltip/edgeTooltipContents.tpl.html', 'edge/core/widget/edgeWidgetContainer.tpl.html', 'edge/core/widget/save-dataset-dialog.tpl.html', 'edge/core/widget/secparams/security-credential-prompt.tpl.html']);

angular.module("edge/core/admin/admin.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/admin.tpl.html",
    "<edge-router-breadcrumb-bar></edge-router-breadcrumb-bar>\n" +
    "<div class=\"page-wrapper\" ng-if=\"currentStateName === 'admin'\">\n" +
    "    <div class=\"container eeList\">\n" +
    "        <h1 translate>Administration</h1>\n" +
    "\n" +
    "        <div class=\"edge-product-tasks list-group\">\n" +
    "            <a ui-sref=\"admin.connect\" class=\"list-group-item\">\n" +
    "\n" +
    "                <div class=\"task-icon pull-left\"><i class=\"icon icon_connect\"></i></div>\n" +
    "\n" +
    "                <h4 class=\"list-group-item-heading\" translate>Connect</h4>\n" +
    "                <p class=\"list-group-item-text\" translate>Manage connections to data sources</p>\n" +
    "\n" +
    "            </a>\n" +
    "\n" +
    "            <a ui-sref=\"admin.pipes\" class=\"list-group-item\">\n" +
    "\n" +
    "                <div class=\"task-icon pull-left\"><i class=\"icon icon_transform_data\"></i></div>\n" +
    "\n" +
    "                <h4 class=\"list-group-item-heading\" translate>Transform</h4>\n" +
    "                <p class=\"list-group-item-text\" translate>Transform, enrich, and filter data sets</p>\n" +
    "\n" +
    "            </a>\n" +
    "\n" +
    "            <a ui-sref=\"managepages\" class=\"list-group-item\">\n" +
    "\n" +
    "                <div class=\"task-icon pull-left\"><i class=\"icon icon_visualization\"></i></div>\n" +
    "\n" +
    "                <h4 class=\"list-group-item-heading\" translate>Visualize</h4>\n" +
    "                <p class=\"list-group-item-text\" translate>Visualize your data</p>\n" +
    "\n" +
    "            </a>\n" +
    "\n" +
    "            <a ui-sref=\"admin.provisiondomains\" class=\"list-group-item\">\n" +
    "\n" +
    "                <div class=\"task-icon pull-left\"><i class=\"icon icon_user\"></i></div>\n" +
    "\n" +
    "                <h4 class=\"list-group-item-heading\" translate>Provision</h4>\n" +
    "                <p class=\"list-group-item-text\" translate>Manage Domains, Roles, Users, and content provisioning</p>\n" +
    "\n" +
    "            </a>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "<div ui-view id=\"admin\"></div>\n" +
    "");
}]);

angular.module("edge/core/admin/adminbar/edgeAdminBar.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/adminbar/edgeAdminBar.tpl.html",
    "<div id=\"sidebar-wrapper\" ng-if=\"::$root.isAdmin\">\n" +
    "    <nav id=\"adminToolbar\">\n" +
    "        <ul class=\"sidebar-nav nav\">\n" +
    "            <!--<li class=\"sidebar-brand\">\n" +
    "                <center>\n" +
    "                    <a href=\"http://localhost:8080/#/admin\">\n" +
    "                        <img src=\"../src/edge/assets/images/Y-logo.png\" class=\"logo\" title=\"Home\"></img>\n" +
    "                    </a>\n" +
    "                </center>\n" +
    "            </li>-->\n" +
    "            <li>\n" +
    "                <a ui-sref=\"managepages\" title=\"{{::'Visualize Data' | translate}}\">\n" +
    "                    <i class=\"icon icon_visualization nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.pipes\" title=\"{{::'Pipeline' | translate}}\">\n" +
    "                    <i class=\"icon icon_transform_data nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li role=\"separator\" class=\"divider-horizontal\"></li>\n" +
    "            <!-- Todo: Provision USERS needs to be a single page, with a switch to change between (Manage By Users / Manage By Groups) -->\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.provisiondomains\" title=\"{{::'Provision' | translate}}\">\n" +
    "                    <i class=\"icon icon_user nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.manage.content\" title=\"{{::'Pages' | translate}}\">\n" +
    "                    <i class=\"icon icon_manage_pages nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <!-- Todo: User Defined Shortcuts would go here.  They can be added/subtracted. -->\n" +
    "            <li role=\"separator\" class=\"divider-horizontal\"></li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.connect\" title=\"{{::'Connections' | translate}}\">\n" +
    "                    <i class=\"icon icon_connect nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.manage.rules\" title=\"{{::'Rule Sets' | translate}}\">\n" +
    "                    <i class=\"icon icon_ruleset nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.manage.parameters\" title=\"{{::'Constraints' | translate}}\">\n" +
    "                    <i class=\"icon icon_var nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ui-sref=\"admin.backup\" title=\"{{::'Backup & Restore' | translate}}\">\n" +
    "                    <i class=\"icon icon_backup nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a ng-click=\"clientFilters()\" title=\"{{::'Client Filters' | translate}}\">\n" +
    "                    <i class=\"icon icon_filter nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "            <li id=\"navAddNewPage\">\n" +
    "                <a href ng-click=\"addPage()\" title=\"{{::'Add New Page' | translate}}\">\n" +
    "                    <i class=\"icon icon_page_new nav-icon\"></i>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "    </nav>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/backup.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/backup.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header label=\"{{::'Backup & Restore' | translate}}\">\n" +
    "            <div class=\"btn-group pull-right\">\n" +
    "                <button class=\"edgeSmallToggleButton btn btn-default btn-sm\" ng-class=\"{'toggledOn' : Controller.viewMode == 'backups'}\"\n" +
    "                        ng-click=\"Controller.showArchives();\"><span translate>Backups</span></button>\n" +
    "                <button class=\"edgeSmallToggleButton btn btn-default btn-sm\" ng-class=\"{'toggledOn' : Controller.viewMode == 'snapshots'}\"\n" +
    "                        ng-click=\"Controller.showSnapshots();\"><span translate>Recovery</span></button>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <div ui-grid=\"Controller.dataGridOptions\"\n" +
    "                 ui-grid-selection\n" +
    "                 ui-grid-resize-columns\n" +
    "                 class=\"grid backupgrid\" style=\"height: 100%\"></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.uploadBackup()\">\n" +
    "                    <span translate>Upload</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-click=\"panelScope.Controller.downloadBackup()\"\n" +
    "                        ng-disabled=\"panelScope.Controller.selectedBackup==null\">\n" +
    "                    <span translate>Download</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group pull-right\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.createBackup()\">\n" +
    "                    <span translate>Backup</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group pull-right\" style=\"margin-right:5px;\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.restoreBackup()\"\n" +
    "                        ng-disabled=\"panelScope.Controller.selectedBackup==null\">\n" +
    "                    <span translate>Restore</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/dialogs/commit-restore-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/dialogs/commit-restore-dialog.tpl.html",
    "<div ng-controller=\"CommitRestoreDialogController as ctrlr\" style=\"height:100%;\"\n" +
    "     ng-class=\"ctrlr.getDialogClass()\"\n" +
    "     class=\"importModule alert\" role=\"alert\">\n" +
    "    <div ng-if=\"ctrlr.state == ctrlr.STATE_RESTORE_IN_PROGRESS\" style=\"position: relative; height: 75px;width:100%;\">\n" +
    "        <span us-spinner=\"ctrlr.spinnerConfig\"></span>\n" +
    "        <span class=\"oneDot5emFont\" translate>Restore In Progress...</span>\n" +
    "    </div>\n" +
    "    <div ng-if=\"ctrlr.state == ctrlr.STATE_RESTORE_SUCCESS\">\n" +
    "        <table style=\"table-layout: fixed;width: 100%;\">\n" +
    "            <tr>\n" +
    "                <td style=\"width:75px;\">\n" +
    "                    <i class=\"icon icon_check text-success\" style=\"font-size:48px;\"></i>\n" +
    "                </td>\n" +
    "                <td style=\"vertical-align: middle;padding:0px 10px;\">\n" +
    "                    <div class=\"oneDot5emFont\" translate>Restore successful.</div>\n" +
    "                    <div translate>Please refresh your client to get the new content.</div>\n" +
    "                    <div translate>It is recommended that you restart your server after performing a restore.</div>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <div ng-if=\"ctrlr.state == ctrlr.STATE_SOFT_FAILURES\">\n" +
    "        <table style=\"table-layout: fixed;width: 100%;\">\n" +
    "            <tr>\n" +
    "                <td style=\"width:75px;\">\n" +
    "                    <i class=\"icon icon_exclamation_triangle text-warning\" style=\"font-size:48px;\"></i>\n" +
    "                </td>\n" +
    "                <td style=\"vertical-align: middle;padding:0px 10px;\">\n" +
    "                    <div class=\"oneDot5emFont\" translate>Restore successful.</div><br>\n" +
    "                    <span translate>However, there were some non-fatal errors - please contact your system\n" +
    "                        administrator and review the server logs.</span><br>\n" +
    "                    <div class=\"well well-sm restore-server-errors\" ng-if=\"ctrlr.softErrors.length > 0\"><div ng-repeat=\"error in ctrlr.softErrors\">{{error.detail}}</div></div>\n" +
    "                    <div translate>Please refresh your client to get the new content.</div>\n" +
    "                    <div translate>It is recommended that you restart your server after performing a restore.</div>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <div ng-if=\"ctrlr.state == ctrlr.STATE_RESTORE_FAILED\">\n" +
    "        <table style=\"table-layout: fixed;width: 100%;\">\n" +
    "            <tr>\n" +
    "                <td style=\"width:75px;\">\n" +
    "                    <i class=\"icon icon_exclamation_triangle text-danger\" style=\"font-size:48px;\"></i>\n" +
    "                </td>\n" +
    "                <td style=\"vertical-align: middle;padding:10px;\">\n" +
    "                    <p class=\"oneDot5emFont\" translate>Restore failed.</p>\n" +
    "                    <span translate>Please contact your system administrator and review the server logs.</span>\n" +
    "                    <div class=\"well well-sm restore-server-errors\" ng-if=\"ctrlr.restoreStatus.errorCause || ctrlr.restoreStatus.errorDetail\">\n" +
    "                        {{ctrlr.restoreStatus.errorCause}}<br>\n" +
    "                        {{ctrlr.restoreStatus.errorDetail}}\n" +
    "                    </div>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"ctrlr.state == ctrlr.STATE_RESTORE_IN_PROGRESS\"\n" +
    "                    ng-click=\"ctrlr.refreshClient()\"><span translate>Refresh Client</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/dialogs/full-restore-wizard-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/dialogs/full-restore-wizard-dialog.tpl.html",
    "<div ng-controller=\"FullRestoreDialogController as ctrlr\" style=\"height:100%;\">\n" +
    "    <edge-wizard force-progression=\"true\"\n" +
    "                 dialog-mode=\"true\"\n" +
    "                 save-button-label=\"{{::ctrlr.getSaveButtonLabel()}}\"\n" +
    "                 on-save=\"ctrlr.handleSave\"\n" +
    "                 on-cancel=\"ctrlr.handleCancel\"\n" +
    "                 sidebar-size=\"0.15\">\n" +
    "        <edge-wizard-step label=\"{{::'Restore Options' | translate}}\" index=\"0\"\n" +
    "            validating-message=\"{{::'Processing archive...'|translate}}\"\n" +
    "            validate=\"ctrlr.simulateRestore()\" use-form-validation=\"profile\">\n" +
    "            <form name=\"profile\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Restore Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-labeled-control label=\"{{::'Clear Custom Folders' | translate}}\" validation=\"false\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.clearCustomFolders\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-if=\"ctrlr.viewMode == 'backups'\" label=\"{{::'Restore Users' | translate}}\" validation=\"false\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.restoreUsers\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Restore License' | translate}}\" validation=\"false\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.restoreLicense\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-if=\"ctrlr.viewMode == 'backups'\" label=\"{{::'Preview Contents' | translate}}\" validation=\"false\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.showPreview\">\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"ctrlr.showPreview\" label=\"{{::'Summary' | translate}}\" index=\"1\">\n" +
    "            <edge-restore-result-chart ng-if=\"ctrlr.restoreStatus\" restore-status=\"ctrlr.restoreStatus\">\n" +
    "            </edge-restore-result-chart>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/dialogs/partial-restore-wizard-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/dialogs/partial-restore-wizard-dialog.tpl.html",
    "<div ng-controller=\"PartialRestoreDialogController as ctrlr\" style=\"height:100%;\">\n" +
    "    <edge-wizard force-progression=\"true\"\n" +
    "                 dialog-mode=\"true\"\n" +
    "                 save-button-label=\"{{::'Restore Archive' | translate}}\"\n" +
    "                 on-save=\"ctrlr.handleSave\"\n" +
    "                 on-cancel=\"ctrlr.handleCancel\"\n" +
    "                 sidebar-size=\"0.15\">\n" +
    "        <edge-wizard-step label=\"{{::'Restore Options' | translate}}\" index=\"0\"\n" +
    "            validating-message=\"{{::'Processing archive...'|translate}}\"\n" +
    "            validate=\"ctrlr.simulateRestore()\" use-form-validation=\"profile\">\n" +
    "            <form name=\"profile\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Restore Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-labeled-control label=\"{{::'Restore Profile' | translate}}\" helptext=\"{{::'A restore profile saves the decisions made for each conflict in a partial backup.  The product will use those saved decisions as defaults for subsequent restore iterations, helping to streamline the restore process.' | translate}}\">\n" +
    "                    <select class=\"form-control\"\n" +
    "                            name=\"profileName\"\n" +
    "                            ng-model=\"ctrlr.selectedProfileName\"\n" +
    "                            ng-change=\"ctrlr.profileSelected()\"\n" +
    "                            ng-options=\"name for name in ctrlr.profileNames\">\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "                <div ng-if=\"ctrlr.restoreProfile != undefined\">\n" +
    "                    <edge-labeled-control label=\"{{::'Collision Strategy' | translate}}\">\n" +
    "                        <edge-radio-group name=\"collisionStragety\"\n" +
    "                                          ng-model=\"ctrlr.restoreProfile.collisionStrategy\">\n" +
    "                            <edge-radio-button ng-value=0>\n" +
    "                                <span translate>Overwrite</span><br/>\n" +
    "                                <span class=\"text-muted\"\n" +
    "                                      translate>Replace existing source content with content in archive.</span><br/>\n" +
    "                            </edge-radio-button>\n" +
    "                            <!--\n" +
    "                            <edge-radio-button ng-value=1>\n" +
    "                                <span translate>New</span><br/>\n" +
    "                                <span class=\"text-muted\"\n" +
    "                                      translate>Create new objects for everything, which can result in duplicates.</span><br/>\n" +
    "                            </edge-radio-button> -->\n" +
    "                            <edge-radio-button ng-value=2>\n" +
    "                                <span translate>Ignore</span><br/>\n" +
    "                                <span class=\"text-muted\"\n" +
    "                                      translate>Keep existing content as is. Only add NEW content, and ignore duplicates.</span><br/>\n" +
    "                            </edge-radio-button>\n" +
    "                        </edge-radio-group>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control label=\"{{::'Restore Suffix' | translate}}\" helptext=\"{{::'This suffix is applied to the names of elements when a conflict is detected.  It helps with the versioning of content when partial backups are iteratively applied.' | translate}}\">\n" +
    "                        <input type=\"text\"\n" +
    "                               class=\"form-control\"\n" +
    "                               name=\"restoreSuffix\"\n" +
    "                               ng-model=\"ctrlr.restoreProfile.restoreSuffix\">\n" +
    "                        </input>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conflict Resolution' | translate}}\" index=\"1\"\n" +
    "            validating-message=\"{{::'Reprocessing archive...'|translate}}\"\n" +
    "            validate=\"ctrlr.validateResolution()\">\n" +
    "            <div class=\"panel panel-default\" style=\"height:100%\">\n" +
    "                <div class=\"panel-body\">\n" +
    "                    <div ng-if=\"ctrlr.conflictFilter.count < 1 && ! ctrlr.nonConflictFilter.on && ! ctrlr.conflictFilter.on\">\n" +
    "                        <div class=\"alert alert-success\" style=\"top:auto;transform:none;margin:20px;\">\n" +
    "                            <span translate>There were no collisions with existing content on the server.</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <edge-list ng-if=\"ctrlr.conflictFilter.on || ctrlr.nonConflictFilter.on\"\n" +
    "                            items=\"ctrlr.filteredEntityActions\" selectable=\"false\">\n" +
    "                        <table class=\"edge-restore-status-item\">\n" +
    "                            <tr>\n" +
    "                                <td><i class=\"icon\" title=\"{{listScope.ctrlr.getIconTooltip(item)}}\"\n" +
    "                                       ng-class=\"listScope.ctrlr.getIcon(item)\"></i>\n" +
    "                                    <i class=\"entity-icon icon\" title=\"{{listScope.ctrlr.getEntityDef(item).label}}\" ng-class=\"listScope.ctrlr.entityDefMap[item.className].icon\"></i>\n" +
    "                                    <span class=\"entity-name\" title=\"{{listScope.ctrlr.getArchiveNameTitle(item)}}\">\n" +
    "                                        {{item.archiveName}}\n" +
    "                                    </span>\n" +
    "                                    <i class=\"entity-type icon icon_arrows_h\"></i>\n" +
    "                                    <span class=\"entity-name\" title=\"{{listScope.ctrlr.getSystemNameTitle(item)}}\">\n" +
    "                                        <span ng-if=\"item.systemName\">{{item.systemName}}</span>\n" +
    "                                        <span ng-if=\"! item.systemName\" translate>'N/A'</span>\n" +
    "                                    </span>\n" +
    "                                </td>\n" +
    "                                <td ng-if=\"listScope.ctrlr.showCollisionStrategy(item)\" class=\"collision-strategy-buttons\" style=\"width: 20%\">\n" +
    "                                    <div class=\"btn-group\">\n" +
    "                                        <button class=\"btn btn-default btn-sm edgeXSmallToggleButton\"\n" +
    "                                                title=\"{{::'Replace what is on the server with what is in the archive.' | translate}}\"\n" +
    "                                                ng-class=\"{'toggledOn' : listScope.ctrlr.getCollisionStrategy(item) == 0}\"\n" +
    "                                                ng-click=\"listScope.ctrlr.setCollisionStrategy(item, listScope.ctrlr.CollisionStrategyDO.OVERWRITE)\" translate>\n" +
    "                                                Overwrite\n" +
    "                                        </button>\n" +
    "                                        <button class=\"btn btn-default btn-sm edgeXSmallToggleButton\"\n" +
    "                                                title=\"{{::'Keep what is on the server.  Ignore what is in the archive.' | translate}}\"\n" +
    "                                                ng-class=\"{'toggledOn' : listScope.ctrlr.getCollisionStrategy(item) == 2}\"\n" +
    "                                                ng-click=\"listScope.ctrlr.setCollisionStrategy(item, listScope.ctrlr.CollisionStrategyDO.DROP)\" translate>\n" +
    "                                                Ignore\n" +
    "                                        </button>\n" +
    "                                    </div>\n" +
    "                                </td>\n" +
    "                            </tr>\n" +
    "                        </table>\n" +
    "                    </edge-list>\n" +
    "                </div>\n" +
    "                <div class=\"panel-footer\">\n" +
    "                    <div class=\"edgeClientFilterButtonBar btn-group pull-left\">\n" +
    "                        <button ng-disabled=\"filterDef.count < 1\" class=\"btn btn-default edgeClientFilterButton\" ng-repeat=\"filterDef in ctrlr.entityConflictFilters\"\n" +
    "                            ng-click=\"filterDef.on = ! filterDef.on; ctrlr.doFilter()\" ng-class=\"{'filterOn':filterDef.on}\">\n" +
    "                            <span>{{filterDef.label}} {{filterDef.count}}</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <div class=\"edgeClientFilterButtonBar btn-group pull-right\">\n" +
    "                        <button ng-disabled=\"filterDef.count < 1\" class=\"btn btn-default edgeClientFilterButton\" ng-repeat=\"filterDef in ctrlr.entityFilters\"\n" +
    "                            ng-click=\"filterDef.on = ! filterDef.on; ctrlr.doFilter()\" ng-class=\"{'filterOn':filterDef.on}\">\n" +
    "                            <span class=\"icon\" ng-class=\"[filterDef.icon]\">&nbsp;{{filterDef.label}} {{filterDef.count}}</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Summary' | translate}}\" index=\"2\">\n" +
    "            <edge-restore-result-chart ng-if=\"ctrlr.restoreStatus\" restore-status=\"ctrlr.restoreStatus\">\n" +
    "            </edge-restore-result-chart>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/dialogs/restore-result.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/dialogs/restore-result.tpl.html",
    "<div style=\"padding:0px 10px 10px 10px;height:100%;\">\n" +
    "    <edge-restore-result-chart restore-status=\"restoreStatus\">></edge-restore-result-chart>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/dialogs/save-archive-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/dialogs/save-archive-dialog.tpl.html",
    "<div style=\"max-height:320px;\">\n" +
    "<span translate>\n" +
    "    Provide a name for the archive, a file extension is added automatically. If left blank a name will be generated based on the current date/time.\n" +
    "</span>\n" +
    "    <br/>\n" +
    "    <br/>\n" +
    "    <form name=\"setExportName\" class=\"form-horizontal\" ng-disabled=\"Controller.backupInProgress\">\n" +
    "        <edge-property-control class=\"col-sm-12\"\n" +
    "                               label-width=\"3\"\n" +
    "                               validation=\"true\"\n" +
    "                               property-def=\"::Controller.exportNameDef\"\n" +
    "                               property-value=\"Controller.exportNameValue\"></edge-property-control>\n" +
    "\n" +
    "        <edge-labeled-control label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Backup Type'|translate}}\">\n" +
    "            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "            <input type=hidden name=\"backupType\" ng-model=\"Controller.backupType\" ng-required=\"true\">\n" +
    "            <ui-select ng-required=\"true\" ng-model=\"Controller.backupType\" style=\"max-width:200px\">\n" +
    "                <ui-select-match theme=\"bootstrap\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item.value as item in Controller.exportTypes\" position='up'>\n" +
    "                    <span>{{item.label}}</span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"3\" validation=\"false\" label=\"{{::'Include Log Files' | translate}}\">\n" +
    "            <input type=\"checkbox\" edge-boolean-switch ng-model=\"Controller.includeLogs\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{'Content' | translate}}\" validation=\"true\" required=\"true\"\n" +
    "                              element-name=\"selectedNode\" ng-if=\"Controller.backupType == 1\">\n" +
    "            <input name=\"selectedNode\" type=\"hidden\" ng-model=\"Controller.entities\">\n" +
    "            <div class=\"form-control\" style=\"height:100%\">\n" +
    "                <edge-provision-tree tree-model=\"Controller.treeModel.rootFolder\"\n" +
    "                                     selected-node=\"Controller.selectedTreeNode\">\n" +
    "                </edge-provision-tree>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "        <div style=\"clear: both;\"></div>\n" +
    "    </form>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/backup/edgeRestoreResultChart.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/backup/edgeRestoreResultChart.tpl.html",
    "<div>\n" +
    "    <style>\n" +
    "        .restored-entities {\n" +
    "            padding: 2px 6px;\n" +
    "        }\n" +
    "\n" +
    "        .restored-entities .entity {\n" +
    "            font-size: .9em;\n" +
    "        }\n" +
    "\n" +
    "        .animationIf {\n" +
    "            height:250px;\n" +
    "        }\n" +
    "\n" +
    "        .animationIf.ng-enter{\n" +
    "            -webkit-transition: height ease-in-out 0.3s;\n" +
    "            -moz-transition: height ease-in-out 0.3s;\n" +
    "            -ms-transition: height ease-in-out 0.5s;\n" +
    "            -o-transition: height ease-in-out 0.3s;\n" +
    "            transition: height ease-in-out 0.3s;\n" +
    "        }\n" +
    "        .animationIf.ng-leave{\n" +
    "            -webkit-transition: none;\n" +
    "            -moz-transition: none;\n" +
    "            -ms-transition: none;\n" +
    "            -o-transition: none;\n" +
    "            transition: none;\n" +
    "        }\n" +
    "        .animationIf.ng-enter,\n" +
    "        .animationIf.ng-leave.ng-leave-active {\n" +
    "            height: 50px;\n" +
    "        }\n" +
    "        .animationIf.ng-leave,\n" +
    "        .animationIf.ng-enter.ng-enter-active {\n" +
    "            height: 250px;\n" +
    "        }\n" +
    "    </style>\n" +
    "    <div class=\"restoreChart\"></div>\n" +
    "    <div class=\"panel panel-default animationIf\"\n" +
    "         ng-if=\"ctrlr.openDetailsKey == entityDef.key\"\n" +
    "         ng-repeat=\"entityDef in ctrlr.entityDefs\">\n" +
    "        <div class=\"panel-heading\" ng-style=\"{'background':ctrlr.selectedColor, 'color':ctrlr.selectedFontColor}\">\n" +
    "            <i class=\"icon {{::entityDef.icon}}\" ng-style=\"{'color':ctrlr.selectedFontColor}\"></i>\n" +
    "            {{entityDef.label}}\n" +
    "            <span translate>Added:</span> {{ctrlr.entities[entityDef.key].length}}\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\">\n" +
    "            <div class=\"restored-entities\">\n" +
    "                <div class=\"entity\"\n" +
    "                     ng-repeat=\"entity in ctrlr.entities[entityDef.key] track by $index\">{{::entity}}\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/client-filter-manage-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/client-filter-manage-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterManageDialogController as ctrlr\" style=\"height:100%;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"pull-right\" style=\"margin-right:5px;\">\n" +
    "            <nav class=\"toolbar navbar navbar-default\" role=\"navigation\">\n" +
    "                <form class=\"navbar-form navbar-left\" role=\"search\">\n" +
    "                    <div class=\"form-inline\">\n" +
    "                        <div class=\"form-group\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                                <input type=\"search\" ng-model=\"ctrlr.filter\" class=\"form-control\"\n" +
    "                                       placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == true }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Reverse Alphabetical' | translate}}\"><i\n" +
    "                                    class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </form>\n" +
    "            </nav>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-list items=\"ctrlr.clientFilters\"\n" +
    "               q=\"{name:ctrlr.filter}\"\n" +
    "               sort=\"name\"\n" +
    "               type=\"simple\"\n" +
    "               reverse=\"ctrlr.reverse\"\n" +
    "               selected-item=\"ctrlr.selectedClientFilter\">\n" +
    "        <edge-client-filter-list-item filter=\"item\"\n" +
    "                                      ng-dblclick=\"listScope.ctrlr.editClientFilter()\"></edge-client-filter-list-item>\n" +
    "    </edge-list>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"pull-left btn-group dropup\">\n" +
    "                <button class=\"btn btn-default dropup dropdown-toggle\"\n" +
    "                        title=\"{{::'Add New Filter' | translate}}\"\n" +
    "                        data-toggle=\"dropdown\"\n" +
    "                        aria-haspopup=\"true\"\n" +
    "                        aria-expanded=\"false\">\n" +
    "                    <i class=\"btn_icon icon icon_plus\"></i>&nbsp;<span translate>Add</span>&nbsp;<span class=\"caret\"></span>\n" +
    "                </button>\n" +
    "                <ul class=\"dropdown-menu\">\n" +
    "                    <li ng-click=\"ctrlr.addCustomExpFilter()\">\n" +
    "                        <a><span translate>Custom Expression Filter</span></a></li>\n" +
    "                    <li ng-click=\"ctrlr.addStringFilter()\">\n" +
    "                        <a><span translate>String Constraint Filter</span></a></li>\n" +
    "                    <li ng-click=\"ctrlr.addRealtimeFilter()\">\n" +
    "                        <a><span translate>Realtime Date Filter</span></a></li>\n" +
    "                </ul>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        title=\"{{::'Edit Selected' | translate}}\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedClientFilter || ctrlr.selectedClientFilter.getConfig().systemFilter\"\n" +
    "                        ng-click=\"ctrlr.editClientFilter()\"><i class=\"btn_icon icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        title=\"{{::'Clone Selected' | translate}}\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedClientFilter || ctrlr.selectedClientFilter.getConfig().systemFilter\"\n" +
    "                        ng-click=\"ctrlr.cloneClientFilter()\"><i class=\"btn_icon icon icon_copy\"></i></button>\n" +
    "                <button class=\"btn btn-danger\"\n" +
    "                        title=\"{{::'Delete Selected' | translate}}\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedClientFilter || ctrlr.selectedClientFilter.getConfig().systemFilter\"\n" +
    "                        ng-click=\"ctrlr.deleteClientFilter()\"><i class=\"btn_icon icon icon_trash\"></i></button>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    ng-if=\"! ctrlr.useAsSelectDialog\"\n" +
    "                    ng-click=\"ctrlr.handleClose()\"><span translate>Close</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-if=\"ctrlr.useAsSelectDialog\"\n" +
    "                    ng-click=\"ctrlr.handleCancel()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-if=\"ctrlr.useAsSelectDialog\"\n" +
    "                    ng-click=\"ctrlr.handleSelect()\"><span translate>Use Selected</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterange/client-filter-daterange-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterange/client-filter-daterange-create-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterDateRangeCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Client Filter Name' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"filterName\"\n" +
    "                   ng-model=\"ctrlr.clientFilter.name\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-class=\"{'pulse':ctrlr.needsSave}\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"\n" +
    "                    translate>Save\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeControl.tpl.html",
    "<div style=\"display:inline-block;height:24px;\">\n" +
    "    <edge-date-range class=\"edge-date-range-sm\"\n" +
    "                     start-date=\"cCtrlr.startDate\"\n" +
    "                     end-date=\"cCtrlr.endDate\"\n" +
    "                     min-date=\"cCtrlr.minDate\"\n" +
    "                     max-date=\"cCtrlr.maxDate\"\n" +
    "                     on-change=\"cCtrlr.onChange(startEndpoint, endEndpoint)\"\n" +
    "                     show-time=\"cCtrlr.allowTime\"\n" +
    "                     is-mobile=\"cCtrlr.isMobile\"></edge-date-range>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterange/edgeClientFilterDateRangeListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "    <i class=\"icon icon_calendar_o\" style=\"font-size:18px;margin-right:10px;\"></i><b translate>Date Range Filter</b>\n" +
    "    <code class=\"pull-right\"><span translate>System Filter</span>&nbsp;<i class=\"icon icon_lock\"></i></code>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterange/edgeDateRangeFilterInstanceConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterange/edgeDateRangeFilterInstanceConfig.tpl.html",
    "<table style=\"table-layout: fixed;width:100%;\">\n" +
    "    <tr>\n" +
    "        <td style=\"vertical-align: middle;width:200px;\">\n" +
    "            <i class=\"icon icon_calendar_o client-filter-icon\"></i><span class=\"client-filter-name\" translate>Date Range Filter</span>\n" +
    "        </td>\n" +
    "        <td style=\"padding-top:10px; padding-right: 20px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Attribute to Filter' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          style=\"margin-bottom:10px\">\n" +
    "                        <input type=\"hidden\"\n" +
    "                               ng-attr-name=\"{{::drficCtrlr.instanceId}}_attributeName\"\n" +
    "                               ng-required=\"true\"\n" +
    "                               ng-model=\"drficCtrlr.instance.config.attributeName\">\n" +
    "                        <ui-select append-to-body=\"true\"\n" +
    "                                   ng-model=\"drficCtrlr.instance.config.attributeName\"\n" +
    "                                   theme=\"bootstrap\">\n" +
    "                            <ui-select-match placeholder=\"{{::'Choose a date attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item.name as item in drficCtrlr.dateAttributes | filter: $select.search\">\n" +
    "                                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <div ng-if=\"drficCtrlr.dateAttributes.length == 0\"\n" +
    "                         class=\"alert alert-warning\"\n" +
    "                         style=\"margin:0px;\">\n" +
    "                        <span translate>No date fields have been found on this dataset.</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{::'Show Time' | translate}}\" label-width=\"6\" validation=\"false\">\n" +
    "                        <input type=\"checkbox\" edge-boolean-switch ng-model=\"drficCtrlr.instance.config.allowTime\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterangeslider/client-filter-daterangeslider-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterangeslider/client-filter-daterangeslider-create-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterDateRangeSliderCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Client Filter Name' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"filterName\"\n" +
    "                   ng-model=\"ctrlr.clientFilter.name\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-class=\"{'pulse':ctrlr.needsSave}\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"\n" +
    "                    translate>Save\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderControl.tpl.html",
    "<div style=\"display:inline-block;\">\n" +
    "    <edge-date-range-slider\n" +
    "            size=\"cCtrlr.sliderSize\"\n" +
    "            min-date=\"cCtrlr.minDate\"\n" +
    "            max-date=\"cCtrlr.maxDate\"\n" +
    "            on-change=\"cCtrlr.onChange(startEndpoint, endEndpoint)\"\n" +
    "            start-date=\"cCtrlr.startDate.date\"\n" +
    "            end-date=\"cCtrlr.endDate.date\"\n" +
    "            granularity=\"cCtrlr.granularity\"\n" +
    "            sparkline-type=\"cCtrlr.sparklineType\"\n" +
    "            sparkline-data=\"cCtrlr.sparklineData\"></edge-date-range-slider>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterangeslider/edgeClientFilterDateRangeSliderListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "    <i class=\"icon icon_calendar_o\"\n" +
    "       style=\"font-size:18px;margin-right:10px;\"></i><b translate>Date Range Slider Filter</b> <code class=\"pull-right\"><span\n" +
    "        translate>System Filter</span>&nbsp;<i class=\"icon icon_lock\"></i></code>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/daterangeslider/edgeDateRangeSliderFilterInstanceConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/daterangeslider/edgeDateRangeSliderFilterInstanceConfig.tpl.html",
    "<table style=\"table-layout: fixed;width:100%;\">\n" +
    "    <tr>\n" +
    "        <td style=\"vertical-align: middle;width:200px;\">\n" +
    "            <i class=\"icon icon_calendar_o client-filter-icon\"></i><span class=\"client-filter-name\" translate>Date Range Slider Filter</span>\n" +
    "        </td>\n" +
    "        <td style=\"padding-top:10px; padding-right: 30px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Attribute to Filter' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          style=\"margin-bottom:10px\">\n" +
    "                        <input type=\"hidden\"\n" +
    "                               ng-attr-name=\"{{::drficCtrlr.instanceId}}_attributeName\"\n" +
    "                               ng-model=\"drficCtrlr.instance.config.attributeName\"\n" +
    "                               ng-required=\"true\">\n" +
    "                        <ui-select append-to-body=\"true\"\n" +
    "                                   ng-model=\"drficCtrlr.instance.config.attributeName\"\n" +
    "                                   theme=\"bootstrap\">\n" +
    "                            <ui-select-match placeholder=\"{{::'Choose a date attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item.name as item in drficCtrlr.dateAttributes | filter: $select.search\">\n" +
    "                                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <div ng-if=\"drficCtrlr.dateAttributes.length == 0\"\n" +
    "                         class=\"alert alert-warning\"\n" +
    "                         style=\"margin:0px;\">\n" +
    "                        <span translate>No date fields have been found on this dataset.</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{::'Selection Granularity' | translate}}\"\n" +
    "                                          label-width=\"6\"\n" +
    "                                          style=\"margin-bottom:10px\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <select ng-model=\"drficCtrlr.instance.config.granularity\" class=\"form-control\">\n" +
    "                            <option value=\"auto\" translate>Auto Calculate</option>\n" +
    "                            <option value=\"years\" translate>Years</option>\n" +
    "                            <option value=\"months\" translate>Months</option>\n" +
    "                            <option value=\"days\" translate>Days</option>\n" +
    "                            <option value=\"hours\" translate>Hours</option>\n" +
    "                            <option value=\"minutes\" translate>Minutes</option>\n" +
    "                            <option value=\"seconds\" translate>Seconds</option>\n" +
    "                            <option value=\"milliseconds\" translate>Milliseconds</option>\n" +
    "                        </select>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{::'Control Height' | translate}}\"\n" +
    "                                          label-width=\"6\"\n" +
    "                                          style=\"margin-bottom:10px\"\n" +
    "                                          validation=\"true\">\n" +
    "                        <edge-number-spinner ng-model=\"drficCtrlr.instance.config.controlHeight\"\n" +
    "                                             minimum=\"24\"\n" +
    "                                             maximum=\"64\"\n" +
    "                                             inputname=\"{{::drficCtrlr.instanceId}}_controlHeight\"\n" +
    "                                             isrequired=\"true\"\n" +
    "                                             style=\"max-width:100px\"\n" +
    "                                             ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                             step=\"12\"></edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{::'Show Sparkline' | translate}}\"\n" +
    "                                          label-width=\"6\"\n" +
    "                                          style=\"margin-bottom:10px\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               edge-boolean-switch\n" +
    "                               ng-model=\"drficCtrlr.instance.config.showSparkline\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control\n" +
    "                            ng-if=\"drficCtrlr.instance.config.showSparkline\"\n" +
    "                            label=\"{{::'Sparkline Type' | translate}}\"\n" +
    "                            label-width=\"6\"\n" +
    "                            style=\"margin-bottom:10px\"\n" +
    "                            validation=\"false\">\n" +
    "                        <select ng-model=\"drficCtrlr.instance.config.sparklineType\" class=\"form-control\">\n" +
    "                            <option value=\"area\" translate>Area</option>\n" +
    "                            <option value=\"column\" translate>Column</option>\n" +
    "                        </select>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\" ng-if=\"drficCtrlr.instance.config.showSparkline\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{::'Aggregation Type' | translate}}\"\n" +
    "                                          label-width=\"6\"\n" +
    "                                          ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                          style=\"margin-bottom:10px\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <select ng-model=\"drficCtrlr.instance.config.summarizeAggregationType\"\n" +
    "                                class=\"form-control\"\n" +
    "                                ng-options=\"type.type as type.displayName for type in drficCtrlr.aggregationTypes\">\n" +
    "                        </select>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control ng-if=\"drficCtrlr.instance.config.showSparkline && drficCtrlr.instance.config.summarizeAggregationType != 0\"\n" +
    "                                          label=\"{{::'Sparkline Data' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          style=\"margin-bottom:10px\"\n" +
    "                                          validation=\"true\" required=\"true\">\n" +
    "                        <input type=\"hidden\"\n" +
    "                               ng-attr-name=\"{{::drficCtrlr.instanceId}}_sparklineAttribute\"\n" +
    "                               ng-model=\"drficCtrlr.instance.config.sparklineAttribute\"\n" +
    "                               ng-required=\"true\">\n" +
    "                        <ui-select append-to-body=\"true\"\n" +
    "                                   ng-model=\"drficCtrlr.instance.config.sparklineAttribute\"\n" +
    "                                   theme=\"bootstrap\">\n" +
    "                            <ui-select-match placeholder=\"{{::'Choose a numeric attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item.name as item in drficCtrlr.numberAttributes | filter: $select.search\">\n" +
    "                                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <div ng-if=\"drficCtrlr.numberAttributes.length === 0 && drficCtrlr.instance.config.summarizeAggregationType > 0\"\n" +
    "                         class=\"alert alert-warning\"\n" +
    "                         style=\"margin:0px;\">\n" +
    "                        <span translate>No numeric fields have been found on this dataset.</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\" ng-if=\"drficCtrlr.instance.config.showSparkline\">\n" +
    "                <edge-labeled-control label=\"{{::'Bucket Interval' | translate}}\" validation=\"true\" label-width=\"3\">\n" +
    "                    <div style=\"height:32px;\">\n" +
    "                        <div class=\"col-sm-4\">\n" +
    "                            <edge-number-spinner ng-model=\"drficCtrlr.instance.config.summarizeIntervalValue\"\n" +
    "                                                 minimum=\"1\"\n" +
    "                                                 maximum=\"1000\"\n" +
    "                                                 inputname=\"{{::drficCtrlr.instanceId}}_intervalVal\"\n" +
    "                                                 isrequired=\"true\"\n" +
    "                                                 ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                                 step=\"1\"></edge-number-spinner>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-4\">\n" +
    "                            <select ng-model=\"drficCtrlr.instance.config.summarizeInterval\"\n" +
    "                                    class=\"form-control\"\n" +
    "                                    ng-dblclick=\"$event.stopPropagation()\">\n" +
    "                                <option value=\"years\" translate>Years</option>\n" +
    "                                <option value=\"months\" translate>Months</option>\n" +
    "                                <option value=\"days\" translate>Days</option>\n" +
    "                                <option value=\"hours\" translate>Hours</option>\n" +
    "                                <option value=\"minutes\" translate>Minutes</option>\n" +
    "                                <option value=\"seconds\" translate>Seconds</option>\n" +
    "                            </select>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/expression/client-filter-exp-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/expression/client-filter-exp-create-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterExpCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Client Filter Name' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"filterName\"\n" +
    "                   ng-model=\"ctrlr.clientFilter.name\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{'Log Missing Attributes' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              helptext=\"{{'If this filter is applied to a dataset that is missing some of the attributes used in the rules, log a message to admin users that use it.' | translate}}\">\n" +
    "            <input type=\"checkbox\"\n" +
    "                   name=\"logMissingAttr\"\n" +
    "                   edge-boolean-switch\n" +
    "                   ng-model=\"ctrlr.clientFilter.getConfig().logMissingAttr\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-panel style=\"height:300px\">\n" +
    "        <edge-panel-header label=\"{{'Filters' | translate}}\"></edge-panel-header>\n" +
    "        <edge-panel-body>\n" +
    "            <edge-list items=\"ctrlr.filterDefs\" selected-item=\"ctrlr.selectedFilterDef\" type=\"reorderable\">\n" +
    "                <div ng-dblclick=\"listScope.ctrlr.editFilterDef(false)\" class=\"with-padding\" style=\"cursor: pointer;\">\n" +
    "                    <div style=\"pointer-events:none;\">\n" +
    "                        <img ng-src=\"{{listScope.ctrlr.getFilterDefIcon(item)}}\"\n" +
    "                             width=\"24\"\n" +
    "                             height=\"24\"\n" +
    "                             style=\"margin-right:10px;\">{{item.label}}\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-success\"\n" +
    "                        ng-click=\"ctrlr.editFilterDef(true)\">\n" +
    "                    <i class=\"icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-warning\"\n" +
    "                        ng-click=\"ctrlr.editFilterDef(false)\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedFilterDef\">\n" +
    "                    <i class=\"icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-danger\"\n" +
    "                        ng-click=\"ctrlr.deleteFilterDef()\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedFilterDef\">\n" +
    "                    <i class=\"icon icon_trash\"></i></button>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-class=\"{'pulse':ctrlr.needsSave}\"\n" +
    "                    ng-disabled=\"!ctrlr.canSave()\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"\n" +
    "                    translate>Save\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/expression/client-filter-exp-filterdef-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/expression/client-filter-exp-filterdef-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterExpDefWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\" on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Filter'|translate}}\" index=\"0\" validate=\"WizardCtrlr.validateExpression()\">\n" +
    "            <form namne=\"expressionForm\">\n" +
    "                <edge-expression-builder group=\"WizardCtrlr.filterDefClone.expression\"\n" +
    "                                         data-sources=\"WizardCtrlr.dataAttributes\"></edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Configure'|translate}}\" index=\"1\" use-form-validation=\"clientFilterDefForm\">\n" +
    "            <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{'Label' | translate}}\"\n" +
    "                                      label-width=\"4\"\n" +
    "                                      validation=\"true\"\n" +
    "                                      required=\"true\">\n" +
    "                    <input type=\"text\"\n" +
    "                           class=\"form-control\"\n" +
    "                           name=\"clientFilterLabel\"\n" +
    "                           ng-model=\"WizardCtrlr.filterDefClone.label\"\n" +
    "                           ng-required=\"true\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-icon-formatter formatter=\"WizardCtrlr.filterDefClone.icon\"\n" +
    "                                     options=\"WizardCtrlr.iconOptions\"\n" +
    "                                     attribute-defs=\"WizardCtrlr.dataAttributes\"></edge-icon-formatter>\n" +
    "                <edge-color-formatter formatter=\"WizardCtrlr.filterDefClone.color\"\n" +
    "                                      attribute-defs=\"WizardCtrlr.dataAttributes\"></edge-color-formatter>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpControl.tpl.html",
    "<div style=\"display: inline-block\">\n" +
    "    <div class=\"edgeClientFilterButtonBar btn-group\" ng-if=\"::cfcCtrlr.showButtons()\">\n" +
    "        <button class=\"btn btn-default edgeClientFilterButton\"\n" +
    "                ng-repeat=\"filterDef in filter.clientFilterDO.getConfig().filterDefs\"\n" +
    "                ng-attr-title=\"{{cfcCtrlr.showLabel() ? '' : filterDef.label}}\"\n" +
    "                ng-click=\"cfcCtrlr.toggleFilterDef(filterDef)\"\n" +
    "                ng-class=\"{'filterOn':cfcCtrlr.isFilterActive(filterDef)}\">\n" +
    "            <img ng-if=\"::cfcCtrlr.showIcon()\"\n" +
    "                 ng-src=\"{{cfcCtrlr.getIconForFilterDef(filterDef)}}\"\n" +
    "                 width=\"16\"\n" +
    "                 height=\"16\"><span class=\"edgeClientFilterButtonLabel\"\n" +
    "                                   ng-if=\"::cfcCtrlr.showLabel()\">{{filterDef.label}}</span><span class=\"edgeClientFilterButtonCounts\"\n" +
    "                                                                                                ng-if=\"::cfcCtrlr.showCounts()\">{{cfcCtrlr.counts[filterDef.id]}}</span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "    <div class=\"edgeClientFilterSelect\" ng-if=\"::(!cfcCtrlr.showButtons())\">\n" +
    "        <ui-select ng-model=\"cfcCtrlr.dropdownSelection\"\n" +
    "                   ng-change=\"cfcCtrlr.handleDropdownChanged()\"\n" +
    "                   theme=\"bootstrap\"\n" +
    "                   class=\"ui-select-small\">\n" +
    "            <ui-select-match>\n" +
    "                <img ng-if=\"cfcCtrlr.showIcon() && cfcCtrlr.getIconForFilterDef($select.selected).length > 0\"\n" +
    "                     ng-src=\"{{cfcCtrlr.getIconForFilterDef($select.selected)}}\"\n" +
    "                     width=\"16\"\n" +
    "                     height=\"16\"><span ng-if=\"cfcCtrlr.showLabel() || cfcCtrlr.getIconForFilterDef(filterDef).length == 0\"\n" +
    "                                       class=\"edgeClientFilterButtonLabel\">{{$select.selected.label}}</span>\n" +
    "                <span class=\"edgeClientFilterButtonCounts\"\n" +
    "                        ng-if=\"::cfcCtrlr.showCounts()\">{{cfcCtrlr.counts[$select.selected.id]}}</span>\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices position=\"up\" repeat=\"filterDef in cfcCtrlr.getDropdownChoices()\">\n" +
    "                <img ng-if=\"cfcCtrlr.showIcon() && cfcCtrlr.getIconForFilterDef(filterDef).length > 0\"\n" +
    "                     ng-src=\"{{cfcCtrlr.getIconForFilterDef(filterDef)}}\"\n" +
    "                     width=\"16\"\n" +
    "                     height=\"16\"><span ng-if=\"cfcCtrlr.showLabel() || cfcCtrlr.getIconForFilterDef(filterDef).length == 0\"\n" +
    "                                       class=\"edgeClientFilterButtonLabel\">{{filterDef.label}}</span><span\n" +
    "                    class=\"edgeClientFilterButtonCounts\"\n" +
    "                    ng-if=\"::cfcCtrlr.showCounts()\">{{cfcCtrlr.counts[filterDef.id]}}</span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/expression/edgeClientFilterExpListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "    <i class=\"icon icon_code client-filter-icon\"></i><b style=\"pointer-events:none;\">{{filter.name}}</b>\n" +
    "    <code class=\"pull-right\"><span translate>Custom Expression Filter</span></code>\n" +
    "    <div style=\"display:flex;width:100%;flex-wrap:wrap; margin-left: 20px;\">\n" +
    "        <div ng-repeat=\"filterDef in filter.getConfig().filterDefs\" style=\"display: inline-block;margin-right:20px;\">\n" +
    "            <img ng-src=\"{{getFilterDefIcon(filterDef)}}\" width=\"24\" height=\"24\" style=\"margin-right:3px;\">{{filterDef.label}}\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/expression/edgeCustomExpressionConfigInstance.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/expression/edgeCustomExpressionConfigInstance.tpl.html",
    "<table style=\"table-layout: fixed;width:100%;\">\n" +
    "    <tr>\n" +
    "        <td style=\"vertical-align: middle;width:200px;\">\n" +
    "            <i class=\"icon icon_code client-filter-icon\"></i><span class=\"client-filter-name\">{{filterName}}</span>\n" +
    "        </td>\n" +
    "        <td style=\"padding-top:10px; padding-right: 20px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <edge-labeled-control label=\"{{::'Renderer Type' | translate}}\"\n" +
    "                                      label-width=\"3\"\n" +
    "                                      validation=\"false\">\n" +
    "                    <div class=\"col-sm-6\" style=\"padding-left: 3px\">\n" +
    "                        <select ng-model=\"instance.config.rendererType\"\n" +
    "                                class=\"form-control\"\n" +
    "                                ng-options=\"type.value as type.label for type in rendererTypes\"></select>\n" +
    "                    </div>\n" +
    "                    <div class=\"col-sm-6\" style=\"padding-right: 5px\">\n" +
    "                        <select ng-model=\"instance.config.renderer\"\n" +
    "                                class=\"form-control\"\n" +
    "                                ng-options=\"renderer.value as renderer.label for renderer in renderers\"></select>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "            <div class=\"row\" ng-if=\"instance.config.rendererType == 'dropdown'\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Cleared Label' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          helptext=\"{{::'The label to use when the filter is cleared while using the DropDown control' | translate}}\">\n" +
    "                        <input type=\"text\"\n" +
    "                               class=\"form-control\"\n" +
    "                               ng-attr-name=\"{{::instanceId}}_allLabel\"\n" +
    "                               ng-required=\"true\"\n" +
    "                               ng-model=\"instance.config.allLabel\"\n" +
    "                               style=\"max-width:230px;\"\n" +
    "                               ng-dblclick=\"$event.stopPropagation()\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Show Counts' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"false\"\n" +
    "                                          ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                          helptext=\"{{::'If on, will provide the number of records that match each filter.' | translate}}\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               edge-boolean-switch\n" +
    "                               ng-model=\"instance.config.showCount\"\n" +
    "                               name=\"showCount\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/manage-visualization-filters-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/manage-visualization-filters-dialog.tpl.html",
    "<div ng-controller=\"ManageVisualizationFiltersDialogController as ctrlr\" style=\"height:100%;max-height:400px;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div style=\"clear:both;margin-top:10px;\">\n" +
    "            <div class=\"col-sm-4\"><label translate>Filter Name</label></div>\n" +
    "            <div class=\"col-sm-8\"><label translate>Configure</label></div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <form name=\"filterInstanceConfig\" class=\"form-horizontal\">\n" +
    "        <edge-list ng-if=\"ctrlr.filtersLoaded\"\n" +
    "                   items=\"ctrlr.clientFilters.instances\"\n" +
    "                   selected-item=\"ctrlr.selectedInstance\"\n" +
    "                   type=\"reorderable\">\n" +
    "            <div ng-dblclick=\"listScope.ctrlr.editClientFilter()\">\n" +
    "                <edge-client-filter-instance-config instance=\"item\"\n" +
    "                                                    wctrlr=\"listScope.ctrlr.widgetController\"></edge-client-filter-instance-config>\n" +
    "            </div>\n" +
    "        </edge-list>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"pull-left btn-group\">\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        title=\"{{::'Add New Filter' | translate}}\"\n" +
    "                        ng-click=\"ctrlr.addClientFilter()\"><i class=\"btn_icon icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        title=\"{{::'Edit Selected Filter' | translate}}\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedInstance || ctrlr.selectedInstance.clientFilterDO.getConfig().systemFilter\"\n" +
    "                        ng-click=\"ctrlr.editClientFilter()\"><i class=\"btn_icon icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-danger\"\n" +
    "                        title=\"{{::'Delete Selected' | translate}}\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedInstance\"\n" +
    "                        ng-click=\"ctrlr.deleteClientFilter()\"><i class=\"btn_icon icon icon_trash\"></i></button>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\" ng-click=\"ctrlr.handleSave()\" translate>Apply</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterControl.tpl.html",
    "<div style=\"display: inline-block;height:24px;\">\n" +
    "    <div class=\"input-group\">\n" +
    "        <span class=\"input-group-btn\" style=\"width:21px;\">\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    type=\"button\"\n" +
    "                    ng-disabled=\"!pfcCtrlr.canPrevious\"\n" +
    "                    ng-click=\"pfcCtrlr.firstPage()\"\n" +
    "                    style=\"width: 21px;height: 24px;line-height: 15px;padding: 1px 5px 0px 5px;margin-right:0px;\"><i class=\"icon icon_angle_double_left\"></i></button>\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    type=\"button\"\n" +
    "                    ng-disabled=\"!pfcCtrlr.canPrevious\"\n" +
    "                    ng-click=\"pfcCtrlr.previousPage()\"\n" +
    "                    style=\"width: 21px;height: 24px;line-height: 15px;padding: 1px 7px 0px 7px;\"><i class=\"icon icon_angle_left\"></i></button>\n" +
    "        </span>\n" +
    "        <div class=\"form-control\"\n" +
    "             style=\"font-size: 0.8em;height: 24px;padding:0 8px;line-height:24px;border-right:none;white-space:nowrap;width:auto;\">\n" +
    "            {{pfcCtrlr.currentPageNumber}} of {{pfcCtrlr.pageCount}}</div>\n" +
    "        <span class=\"input-group-btn\" style=\"width:21px;\">\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    type=\"button\"\n" +
    "                    ng-disabled=\"!pfcCtrlr.canAdvance\"\n" +
    "                    ng-click=\"pfcCtrlr.advancePage()\"\n" +
    "                    style=\"width: 21px;height: 24px;line-height: 15px;padding: 1px 8px 0px 8px;\"><i class=\"icon icon_angle_right\"></i></button>\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    type=\"button\"\n" +
    "                    ng-disabled=\"!pfcCtrlr.canAdvance\"\n" +
    "                    ng-click=\"pfcCtrlr.lastPage()\"\n" +
    "                    style=\"width: 21px;height: 24px;line-height: 15px;padding: 1px 6px 0px 6px;\"><i class=\"icon icon_angle_double_right\"></i></button>\n" +
    "        </span>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterInstanceConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterInstanceConfig.tpl.html",
    "<table style=\"table-layout: fixed;width:100%;\">\n" +
    "    <tr>\n" +
    "        <td style=\"vertical-align: middle;width:200px;\">\n" +
    "            <i class=\"icon icon_page_o client-filter-icon\"></i><span class=\"client-filter-name\" translate>Pagination Filter</span>\n" +
    "        </td>\n" +
    "        <td style=\"padding-top:10px; padding-right: 20px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Rows Per Page' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          style=\"margin-bottom:10px\">\n" +
    "                        <edge-number-spinner ng-model=\"pficCtrlr.instance.config.rowsPerPage\"\n" +
    "                                             minimum=\"1\"\n" +
    "                                             maximum=\"10000\"\n" +
    "                                             inputname=\"{{::pficCtrlr.instanceId}}_rowsPerPage\"\n" +
    "                                             style=\"max-width:100px\"\n" +
    "                                             isrequired=\"true\"\n" +
    "                                             ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                             step=\"5\"></edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/pagination/edgePaginationFilterListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "    <i class=\"icon icon_copy\" style=\"font-size:18px;margin-right:10px;\"></i><b translate>Pagination Filter</b> <code class=\"pull-right\"><span\n" +
    "        translate>System Filter</span>&nbsp;<i class=\"icon icon_lock\"></i></code>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/realtime/client-filter-realtime-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/realtime/client-filter-realtime-create-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterRealtimeCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Client Filter Name' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"filterName\"\n" +
    "                   ng-model=\"ctrlr.clientFilter.name\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\"\n" +
    "                              label=\"{{'Realtime Constraint'|translate}}\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_database\"></i></span>\n" +
    "                <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <input type=hidden name=\"constraint\" ng-model=\"ctrlr.selectedConstraint\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\"\n" +
    "                           ng-model=\"ctrlr.selectedConstraint\"\n" +
    "                           append-to-body=\"true\">\n" +
    "                    <ui-select-match theme=\"bootstrap\">\n" +
    "                        {{$select.selected.name}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in ctrlr.constraints | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                        <small class=\"pull-right\" ng-bind-html=\"item.propertyTypeName\"></small>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\"\n" +
    "                        ng-click=\"ctrlr.addConstraint()\"><i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"ctrlr.editConstraint()\"\n" +
    "                        ng-disabled=\"ctrlr.selectedConstraint==null || ctrlr.selectedConstraint.id.indexOf('DEFAULT_') == 0\"><i\n" +
    "                        class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "            </span>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-class=\"{'pulse':ctrlr.needsSave}\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"\n" +
    "                    translate>Save\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeControl.tpl.html",
    "<div style=\"display:inline-block;\">\n" +
    "    <select class=\"form-control\"\n" +
    "            ng-model=\"cfrCtrlr.selectedConstraint\"\n" +
    "            ng-change=\"cfrCtrlr.handleConstraintChange()\"\n" +
    "            ng-options=\"constraint.label for constraint in cfrCtrlr.constraintValues\">\n" +
    "    </select>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/realtime/edgeClientFilterRealtimeListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "    <i class=\"icon icon_clock_o\" style=\"font-size:18px;margin-right:10px;\"></i><b>{{filter.name}}</b>\n" +
    "    <code class=\"pull-right\"><span translate>Realtime Date Filter</span></code>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/realtime/edgeRealtimeFilterInstanceConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/realtime/edgeRealtimeFilterInstanceConfig.tpl.html",
    "<table style=\"table-layout: fixed;width:100%;\">\n" +
    "    <tr>\n" +
    "        <td style=\"vertical-align: middle;width:200px;\">\n" +
    "            <i class=\"icon icon_clock_o client-filter-icon\"></i><span class=\"client-filter-name\">{{rficCtrlr.filterName}}</span>\n" +
    "        </td>\n" +
    "        <td style=\"padding-top:10px; padding-right: 20px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Attribute to Filter' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          style=\"margin-bottom:10px\">\n" +
    "                        <input ng-attr-name=\"{{::rficCtrlr.instanceId}}_attributeName\"\n" +
    "                               type=\"hidden\"\n" +
    "                               ng-model=\"rficCtrlr.instance.config.attributeName\"\n" +
    "                               ng-required=\"true\">\n" +
    "                        <ui-select append-to-body=\"true\"\n" +
    "                                   ng-model=\"rficCtrlr.instance.config.attributeName\"\n" +
    "                                   theme=\"bootstrap\">\n" +
    "                            <ui-select-match placeholder=\"{{::'Choose a date attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item.name as item in rficCtrlr.dateAttributes | filter: $select.search\">\n" +
    "                                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <div ng-if=\"rficCtrlr.dateAttributes.length == 0\"\n" +
    "                         class=\"alert alert-warning\"\n" +
    "                         style=\"margin:0px;\">\n" +
    "                        <span translate>No date fields have been found on this dataset.</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-12\">\n" +
    "                    <edge-labeled-control label=\"{{::'Cleared Label' | translate}}\"\n" +
    "                                          label-width=\"3\"\n" +
    "                                          validation=\"true\"\n" +
    "                                          required=\"true\"\n" +
    "                                          helptext=\"{{::'The label to use when the filter is cleared.' | translate}}\">\n" +
    "                        <input type=\"text\"\n" +
    "                               class=\"form-control\"\n" +
    "                               ng-attr-name=\"{{::rficCtrlr.instanceId}}_allLabel\"\n" +
    "                               ng-model=\"instance.config.allLabel\"\n" +
    "                               ng-required=\"true\"\n" +
    "                               style=\"max-width:230px;\"\n" +
    "                               ng-dblclick=\"$event.stopPropagation()\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterControl.tpl.html",
    "<div style=\"display: inline-block;height:24px;\">\n" +
    "    <div class=\"input-group dropup search-field-filter\" style=\"height:24px;width:100px;\">\n" +
    "        <span class=\"input-group-addon\"\n" +
    "              data-toggle=\"dropdown\"\n" +
    "              aria-haspopup=\"true\"\n" +
    "              aria-expanded=\"false\"\n" +
    "              style=\"height:24px;line-height:7px;font-size:10px;padding:0px 4px;cursor:pointer;\">\n" +
    "            <table style=\"table-layout:fixed;height:22px;pointer-events:none\">\n" +
    "                <tr>\n" +
    "                <td><i class=\"icon icon_search\" style=\"font-size:10px;\"></i></td>\n" +
    "                <td ng-if=\"sffcCtrlr.filterDef.fieldToSearch != 'All'\"\n" +
    "                    style=\"white-space: nowrap;overflow: hidden;text-overflow: ellipsis; max-width:60px; padding:0px 3px;\">\n" +
    "                    <span>{{sffcCtrlr.filterDef.fieldToSearch}}</span>\n" +
    "                </td>\n" +
    "                <td><span class=\"caret\"></span></td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "            </span>\n" +
    "\n" +
    "        <div class=\"dropdown-menu\" ng-click=\"$event.stopPropagation();\">\n" +
    "            <form class=\"form-horizontal\" style=\"padding:10px\">\n" +
    "                <edge-labeled-control label=\"{{'Case Sensitive' | translate}}\" top-label=\"true\" class=\"boolean-switch-sm\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"sffcCtrlr.filterDef.caseSensitive\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{'Limit To Attribute' | translate}}\"\n" +
    "                                      top-label=\"true\"\n" +
    "                                      ng-if=\"sffcCtrlr.dataAttributes.length > 0\">\n" +
    "                    <select name=\"fieldChoice\"\n" +
    "                            class=\"form-control input-sm\"\n" +
    "                            ng-model=\"sffcCtrlr.filterDef.fieldToSearch\">\n" +
    "                        <option value=\"All\" translate>All</option>\n" +
    "                        <option value=\"{{field.name}}\"\n" +
    "                                ng-repeat=\"field in sffcCtrlr.dataAttributes\">{{field.name}}\n" +
    "                        </option>\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "                <button class=\"btn btn-success pull-right edgeClientFilterButton\"\n" +
    "                        ng-click=\"sffcCtrlr.applyFilterChanges()\">\n" +
    "                    <span translate>Apply</span>\n" +
    "                </button>\n" +
    "            </form>\n" +
    "        </div>\n" +
    "        <input type=\"search\"\n" +
    "               ng-model=\"sffcCtrlr.filterDef.searchString\"\n" +
    "               ng-change=\"sffcCtrlr.searchFieldChanged()\"\n" +
    "               class=\"form-control\"\n" +
    "               style=\"height:24px;width:100px;\"\n" +
    "               placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/search/edgeSearchFieldFilterListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px 10px\" ng-style=\"{'padding-left': !showFilterListItem ? '20px' : '4px'}\">\n" +
    "    <i class=\"pull-left icon icon_search client-filter-icon\" style=\"margin-top: 4px;\"></i>\n" +
    "    <div class=\"pull-left text-bold\" translate>Search Field Filter</div>\n" +
    "    <code class=\"pull-right\"><span translate>System Filter</span>&nbsp;<i class=\"icon icon_lock\"></i></code>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/sort/edgeSortFilterControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/sort/edgeSortFilterControl.tpl.html",
    "<div style=\"display: inline-block;height:24px;\">\n" +
    "    <button type=\"button\"\n" +
    "            title=\"{{::'Sort' | translate}}\"\n" +
    "            class=\"edgeSmallToggleButton btn btn-default\"\n" +
    "            ng-class=\"{'toggledOn': sfcc.activeSortOptions.length > 0}\"\n" +
    "            uib-popover-template=\"'edge/core/admin/managers/clientfilter/sort/sort-configure-dialog.tpl.html'\"\n" +
    "            popover-placement=\"top-left auto\"\n" +
    "            popover-class=\"edgeConfigureSortPopup\"\n" +
    "            popover-append-to-body='true'\n" +
    "            popover-is-open=\"sfcc.sortConfigureOpen\"\n" +
    "            popover-trigger=\"'none'\"\n" +
    "            ng-click=\"sfcc.configureSort()\">\n" +
    "        <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "    </button>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/sort/edgeSortFilterListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/sort/edgeSortFilterListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px 10px;\" ng-style=\"{'padding-left': !showFilterListItem ? '20px' : '4px'}\">\n" +
    "    <i class=\"pull-left icon icon_sort_amount_asc client-filter-icon\" style=\"margin-top: 4px;\"></i>\n" +
    "    <div class=\"pull-left text-bold\" translate>Sort</div>\n" +
    "    <code class=\"pull-right\"><span translate>System Filter</span>&nbsp;<i class=\"icon icon_lock\"></i></code>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/sort/sort-configure-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/sort/sort-configure-dialog.tpl.html",
    "<div id=\"edgeSortFilterDialog\" class=\"panel panel-default\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <div class=\"panel-title\" translate>Sort</div>\n" +
    "    </div>\n" +
    "    <div class=\"panel-body edgeSortFilterPanelBody\" style=\"min-height:100px;min-width:494px;max-height:210px;\">\n" +
    "        <edge-list items=\"sfcc.activeSortOptions\" type=\"reorderable\" selected-item=\"sfcc.selectedSort\">\n" +
    "            <div class=\"row with-padding\">\n" +
    "                <div class=\"col-sm-8\">\n" +
    "                    <ui-select ng-model=\"item.attributeName\" theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "                        <ui-select-match placeholder=\"{{::'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item.name as item in listScope.sfcc.dataAttributes | filter: $select.search\">\n" +
    "                            <small style=\"top:0px\" class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                            <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <select class=\"form-control\" ng-model=\"item.reverseSort\" ng-options=\"o.value as o.label for o in listScope.sfcc.sortDirectionOptions\">\n" +
    "                    </select>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-list>\n" +
    "    </div>\n" +
    "    <div class=\"panel-footer\">\n" +
    "        <div class=\"btn-group\">\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"sfcc.addSort()\"><i class=\"icon icon_plus\"></i></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"sfcc.removeSort()\" ng-disabled=\"sfcc.selectedSort == undefined\"><i class=\"icon icon_trash\"></i></button>\n" +
    "        </div>\n" +
    "        <button type=\"button\" class=\"btn btn-default\" ng-click=\"sfcc.clearSorts()\"translate>Clear All</button>\n" +
    "        <button type=\"button\" class=\"btn btn-success pull-right\" ng-click=\"sfcc.applySorts()\" translate>Apply</button>\n" +
    "        <button type=\"button\" class=\"btn btn-default pull-right\" ng-click=\"sfcc.cancel()\" style=\"margin-right:5px;\" translate>Cancel</button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/clientfilter/string/client-filter-string-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/string/client-filter-string-create-dialog.tpl.html",
    "<div ng-controller=\"ClientFilterStringCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"clientFilterDefForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Client Filter Name' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"filterName\"\n" +
    "                   ng-model=\"ctrlr.clientFilter.name\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\"\n" +
    "                              label=\"{{'String Constraint'|translate}}\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_database\"></i></span>\n" +
    "                <input type=hidden name=\"constraint\" ng-model=\"ctrlr.selectedConstraint\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\"\n" +
    "                           ng-model=\"ctrlr.selectedConstraint\"\n" +
    "                           append-to-body=\"true\">\n" +
    "                    <ui-select-match theme=\"bootstrap\">\n" +
    "                        {{$select.selected.name}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in ctrlr.constraints | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                        <small class=\"pull-right\" ng-bind-html=\"item.propertyTypeName\"></small>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\"\n" +
    "                        ng-click=\"ctrlr.addConstraint()\"><i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"ctrlr.editConstraint()\"\n" +
    "                        ng-disabled=\"ctrlr.selectedConstraint==null || ctrlr.selectedConstraint.id.indexOf('DEFAULT_') == 0\"><i\n" +
    "                        class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "            </span>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-class=\"{'pulse':ctrlr.needsSave}\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"\n" +
    "                    translate>Save\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/string/edgeClientFilterStringControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/string/edgeClientFilterStringControl.tpl.html",
    "<div style=\"display:inline-block;\">\n" +
    "    <select class=\"form-control\"\n" +
    "            ng-model=\"cfrCtrlr.selectedConstraint\"\n" +
    "            ng-change=\"cfrCtrlr.handleConstraintChange()\"\n" +
    "            ng-options=\"constraint.label for constraint in cfrCtrlr.constraintValues\">\n" +
    "\n" +
    "    </select>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/string/edgeClientFilterStringListItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/string/edgeClientFilterStringListItem.tpl.html",
    "<div class=\"row\" style=\"padding:10px 20px;pointer-events:none;\">\n" +
    "   <i class=\"icon icon_commenting_o client-filter-icon\"></i><b>{{filter.name}}</b>\n" +
    "   <code class=\"pull-right\"><span translate>String Filter</span></code>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/clientfilter/string/edgeStringFilterInstanceConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/clientfilter/string/edgeStringFilterInstanceConfig.tpl.html",
    "<div class=\"row\">\n" +
    "    <div class=\"col-sm-3\" style=\"vertical-align:middle;line-height: 98px;\">\n" +
    "        <i class=\"icon icon_commenting_o client-filter-icon\"></i><span class=\"client-filter-name\">{{sficCtrlr.filterName}}</span>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-9\" style=\"padding-top:10px;padding-right: 25px;\">\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Attribute to Filter' | translate}}\"\n" +
    "                                      label-width=\"3\"\n" +
    "                                      validation=\"true\"\n" +
    "                                      required=\"true\"\n" +
    "                                      style=\"margin-bottom:10px\">\n" +
    "                    <input type=\"hidden\"\n" +
    "                           ng-required=\"true\"\n" +
    "                           ng-model=\"sficCtrlr.instance.config.attributeName\"\n" +
    "                           ng-attr-name=\"{{::sficCtrlr.instanceId}}_attributeName\">\n" +
    "                    <ui-select append-to-body=\"true\"\n" +
    "                               ng-model=\"sficCtrlr.instance.config.attributeName\"\n" +
    "                               theme=\"bootstrap\">\n" +
    "                        <ui-select-match placeholder=\"{{::'Choose a string attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item.name as item in sficCtrlr.stringAttributes | filter: $select.search\">\n" +
    "                            <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                            <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "                <div ng-if=\"sficCtrlr.stringAttributes.length == 0\" class=\"alert alert-warning\" style=\"margin:0px;\">\n" +
    "                    <span translate>No string fields have been found on this dataset.</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Cleared Label' | translate}}\"\n" +
    "                                      label-width=\"3\"\n" +
    "                                      validation=\"true\"\n" +
    "                                      required=\"true\"\n" +
    "                                      helptext=\"{{::'The label to use when the filter is cleared.' | translate}}\">\n" +
    "                    <input type=\"text\"\n" +
    "                           class=\"form-control\"\n" +
    "                           ng-attr-name=\"{{::sficCtrlr.instanceId}}_allLabel\"\n" +
    "                           ng-required=\"true\"\n" +
    "                           ng-model=\"instance.config.allLabel\"\n" +
    "                           style=\"max-width:230px;\"\n" +
    "                           ng-dblclick=\"$event.stopPropagation()\">\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/cluster/cluster-add-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/cluster-add-dialog.tpl.html",
    "<div ng-controller=\"ClusterAddController as ctrlr\">\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <div ng-if=\"ctrlr.showError\" class=\"alert alert-danger\" translate>\n" +
    "            An instance with the same alias already exists, please enter a different alias.\n" +
    "        </div>\n" +
    "        <edge-labeled-control label=\"{{::'Alias' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"alias\" ng-model=\"ctrlr.alias\" required ng-pattern=\"/^\\w{1}[ \\w]*$/\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Instance Url' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" ng-disabled=\"true\" type=\"text\" name=\"instanceUrl\" ng-model=\"ctrlr.instanceUrl\" required ng-pattern=\"/^([Hh][Tt][Tt][Pp][Ss]?):\\/\\/(\\[[0-9a-fA-F:]+\\]|[^\\s/$.?#][^\\s:/]*)(:\\d{1,5})?\\/?$/\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-default\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-success\" ng-click=\"ctrlr.add()\" translate>Add</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/cluster/cluster-init-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/cluster-init-dialog.tpl.html",
    "<div ng-controller=\"ClusterInitController as ctrlr\">\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{::'Alias' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"alias\" ng-model=\"ctrlr.alias\" required ng-pattern=\"/^\\w{1}[ \\w]*$/\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Instance Url' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" ng-disabled=\"true\" type=\"text\" name=\"instanceUrl\" ng-model=\"ctrlr.instanceUrl\" required ng-pattern=\"/^([Hh][Tt][Tt][Pp][Ss]?):\\/\\/(\\[[0-9a-fA-F:]+\\]|[^\\s/$.?#][^\\s:/]*)(:\\d{1,5})?\\/?$/\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Content Url' | translate}}\" validation=\"true\" ng-if=\"false\">\n" +
    "            <!-- TODO: remove ng-if false once contentUrl is supported -->\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"contentUrl\" ng-model=\"ctrlr.contentUrl\" required ng-pattern=\"/^([Hh][Tt][Tt][Pp][Ss]?):\\/\\/(\\[[0-9a-fA-F:]+\\]|[^\\s/$.?#][^\\s:/]*)(:\\d{1,5})?\\/?$/\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Admin Url' | translate}}\" validation=\"true\" ng-if=\"false\">\n" +
    "            <!-- TODO: remove ng-if false once adminUrl is supported -->\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"adminUrl\" ng-model=\"ctrlr.adminUrl\" required ng-pattern=\"/^([Hh][Tt][Tt][Pp][Ss]?):\\/\\/(\\[[0-9a-fA-F:]+\\]|[^\\s/$.?#][^\\s:/]*)(:\\d{1,5})?\\/?$/\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-default\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-success\" ng-click=\"ctrlr.init()\" translate>Initialize</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/cluster/cluster.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/cluster.tpl.html",
    "<edge-view>\n" +
    "    <div class=\"row\">\n" +
    "        <edge-panel resize=\"Controller.panelResized\" on-init=\"Controller.initPanelTabs()\" id=\"ClusterPanel\">\n" +
    "            <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                    <li class=\"active\">\n" +
    "                        <a data-toggle=\"tab\" data-target=\"#status\" id=\"statusTab\" style=\"margin-left: 10px; padding:7px 15px\">\n" +
    "                            <span translate>Cluster Status</span>\n" +
    "                        </a>\n" +
    "                    </li>\n" +
    "                    <li>\n" +
    "                        <a data-toggle=\"tab\" data-target=\"#snapshot\" id=\"snapshotTab\" style=\"padding:7px 15px\">\n" +
    "                            <span translate>Snapshots</span>\n" +
    "                        </a>\n" +
    "                    </li>\n" +
    "                </ul>\n" +
    "            </edge-panel-header>\n" +
    "            <edge-panel-body style=\"overflow:hidden\">\n" +
    "                <div class=\"tab-content\" style=\"height:100%\">\n" +
    "                    <div id=\"status\" class=\"tab-pane fade in active\">\n" +
    "                        <div ui-grid=\"Controller.statusDataGridOptions\" ng-if=\"Controller.activeTab === '#status'\" ui-grid-selection ui-grid-resize-columns class=\"grid backupgrid\"></div>\n" +
    "                    </div>\n" +
    "                    <div id=\"snapshot\" class=\"tab-pane fade\">\n" +
    "                        <div ui-grid=\"Controller.snapshotDataGridOptions\" ng-if=\"Controller.activeTab === '#snapshot'\" ui-grid-selection ui-grid-resize-columns class=\"grid backupgrid\"></div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-panel-body>\n" +
    "            <edge-panel-footer>\n" +
    "                <!--<button class=\"btn btn-default\" ng-click=\"Controller.deleteSession()\" title=\"{{::'Terminate' | translate}}\">-->\n" +
    "                    <!--<i class=\"icon icon_trash\"></i>-->\n" +
    "                <!--</button>-->\n" +
    "                    <button class=\"btn btn-default\" ng-click=\"Controller.refreshTable()\"\n" +
    "                            title=\"{{::'Refresh' | translate}}\">\n" +
    "                        <i class=\"icon icon_refresh\"></i>\n" +
    "                    </button>\n" +
    "                    <button ng-if=\"Controller.canInit && Controller.activeTab === '#status'\" class=\"btn btn-default\" ng-click=\"Controller.initializeCluster()\">\n" +
    "                        <span translate>Initialize</span>\n" +
    "                    </button>\n" +
    "                    <button ng-if=\"Controller.activeTab === '#status'\" ng-disabled=\"!Controller.canAdd\"\n" +
    "                            class=\"btn btn-default\"  ng-click=\"Controller.addCluster(false)\"\n" +
    "                            title=\"{{::'Add' | translate}}\">\n" +
    "                        <i class=\"icon icon_plus\"></i>\n" +
    "                    </button>\n" +
    "                    <button ng-if=\"Controller.activeTab === '#status'\" ng-disabled=\"!Controller.canDelete\"\n" +
    "                            class=\"btn btn-default\" ng-click=\"Controller.deleteFromCluster()\"\n" +
    "                            title=\"{{::'Delete' | translate}}\">\n" +
    "                        <i class=\"icon icon_trash\"></i>\n" +
    "                    </button>\n" +
    "                    <div class=\"btn-group pull-right\" ng-if=\"Controller.activeTab === '#status'\">\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"Controller.makeAdmin()\" ng-disabled=\"! Controller.canMakeAdmin\">\n" +
    "                            <span translate>Make Admin</span>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"Controller.login()\" ng-disabled=\"! Controller.canLogin\">\n" +
    "                            <span translate>Login</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <button class=\"btn btn-default\" ng-if=\"Controller.activeTab === '#snapshot'\" ng-disabled=\"!Controller.canCreateSnapshot()\" ng-click=\"Controller.createSnapshot()\">\n" +
    "                        <span translate>Create Snapshot</span>\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-default\" ng-if=\"Controller.activeTab === '#snapshot'\" ng-disabled=\"!Controller.canDeleteSnapshot()\" ng-click=\"Controller.deleteSnapshot()\">\n" +
    "                        <span translate>Delete Snapshot</span>\n" +
    "                    </button>\n" +
    "                <button class=\"btn btn-default\" ng-if=\"Controller.activeTab === '#snapshot'\" ng-disabled=\"!Controller.canDeploySnapshot()\" ng-click=\"Controller.deploySnapshot()\">\n" +
    "                    <span translate>Deploy Snapshot</span>\n" +
    "                </button>\n" +
    "            </edge-panel-footer>\n" +
    "        </edge-panel>\n" +
    "    </div>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/cluster/make-admin-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/make-admin-dialog.tpl.html",
    "<div>\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <div ng-if=\"ctrlr.state === 'WARNING'\" class=\"alert alert-warning\" translate>\n" +
    "            Changing the designated admin of a cluster will result in the current admin and new admin installing the most recently created snapshot. Any unsaved config changes will be lost. Continue?\n" +
    "        </div>\n" +
    "        <div ng-if=\"ctrlr.state === 'UPDATE'\" class=\"alert alert-info\" translate>\n" +
    "            Designating new admin server...\n" +
    "        </div>\n" +
    "        <div ng-if=\"ctrlr.state === 'SUCCESS'\" class=\"alert alert-success\" translate>\n" +
    "            The admin server has been changed. Additionally, the latest snapshot has been deployed and will soon be available on both the new admin and the former admin servers.\n" +
    "        </div>\n" +
    "        <div ng-if=\"ctrlr.state === 'ERROR'\" class=\"alert alert-danger\" translate>\n" +
    "            {{ctrlr.errorMsg}}\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\" ng-disabled=\"ctrlr.state === 'UPDATE'\">\n" +
    "            <button class=\"btn btn-default\" ng-if=\"ctrlr.state !== 'SUCCESS' && ctrlr.state !== 'ERROR'\" ng-click=\"ctrlr.handleClose()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-default\" ng-if=\"ctrlr.state !== 'SUCCESS' && ctrlr.state !== 'ERROR'\" ng-click=\"ctrlr.handleMakeAdmin()\" translate>Continue</button>\n" +
    "            <button class=\"btn btn-default\" ng-if=\"ctrlr.state === 'SUCCESS' || ctrlr.state === 'ERROR'\" ng-click=\"ctrlr.handleClose()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/managers/cluster/snapshot-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/snapshot-create-dialog.tpl.html",
    "<div ng-controller=\"SnapshotCreateController as ctrlr\">\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{::'Description' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"description\" ng-model=\"ctrlr.description\" required ng-pattern=\"/^\\w{1}[ \\w]*$/\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-default\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button ng-disabled=\"ctrlr.activelySaving\" class=\"btn btn-success\" ng-click=\"ctrlr.add()\" translate>Create</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/cluster/snapshot-deploy-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/cluster/snapshot-deploy-dialog.tpl.html",
    "<div>\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <div ng-if=\"ctrlr.activelyDeploying\" class=\"alert alert-info\" translate>\n" +
    "            Scheduling snapshot deployment...\n" +
    "        </div>\n" +
    "        <div ng-if=\"!ctrlr.activelyDeploying && !ctrlr.showError\" class=\"alert alert-success\" translate>\n" +
    "            Snapshot has been deployed and will be available on all content servers momentarily.\n" +
    "        </div>\n" +
    "        <div ng-if=\"ctrlr.showError\" class=\"alert alert-danger\" translate>\n" +
    "            {{ctrlr.errorMsg}}\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-disabled=\"ctrlr.activelyDeploying\" class=\"btn btn-default\" ng-click=\"ctrlr.handleClose()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/colorpalette/color-palette-create-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/colorpalette/color-palette-create-dialog.tpl.html",
    "<div ng-controller=\"ColorPaletteCreateDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"createColorPaletteForm\" class=\"form-horizontal\">\n" +
    "        <div ng-if=\"ctrlr.dupName\" class=\"alert alert-danger\" style=\"margin: 0 0 20px 0;\" translate>Duplicate palette name; please enter another name.</div>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Palette Name' | translate}}\" label-width=\"4\"\n" +
    "                                      validation=\"::!ctrlr.isEdit\" required=\"::!ctrlr.isEdit\">\n" +
    "                    <input type=\"text\" class=\"form-control\" name=\"paletteName\" ng-model=\"ctrlr.colorPalette.name\"\n" +
    "                           ng-required=\"::!ctrlr.isEdit\" ng-pattern=\"/^\\w{1}[ \\w]*$/\" ng-disabled=\"::ctrlr.isEdit\" edge-focus>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Palette Type' | translate}}\" label-width=\"4\">\n" +
    "                    <select class=\"form-control\" name=\"paletteType\" ng-model=\"ctrlr.colorPalette.type\"\n" +
    "                            placeholder=\"{{::'Choose a palette type...' | translate}}\" ng-required=\"true\">\n" +
    "                        <option ng-repeat=\"paletteType in ::ctrlr.paletteTypes\" value=\"{{::paletteType.type}}\">\n" +
    "                            {{::paletteType.name}}\n" +
    "                        </option>\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"ctrlr.colorPalette.type === 'monochrome' || ctrlr.colorPalette.type === 'duotone'\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Max Colors' | translate}}\" label-width=\"4\">\n" +
    "                    <select class=\"form-control\" name=\"maxSize\" ng-model=\"ctrlr.colorPalette.maxSize\"\n" +
    "                            ng-options=\"size as size for size in ::[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]\">\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"ctrlr.colorPalette.type === 'monochrome' || ctrlr.colorPalette.type === 'duotone'\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Primary Color' | translate}}\" validation=\"true\" label-width=\"4\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <div class=\"input-group-addon\" style=\"padding:4px;\">\n" +
    "                            <div class=\"edgeColorPickerPreview\" ng-style=\"{'background-color':ctrlr.colorPalette.colors[0]}\"></div>\n" +
    "                        </div>\n" +
    "                        <input name=\"color0\" class=\"form-control\" colorpicker=\"hex\" type=\"text\" ng-model=\"ctrlr.colorPalette.colors[0]\" ng-trim=\"true\" ng-required=\"true\" ng-pattern=\"validateColor\"/>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"ctrlr.colorPalette.type === 'duotone'\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Secondary Color' | translate}}\" validation=\"true\" label-width=\"4\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <div class=\"input-group-addon\" style=\"padding:4px;\">\n" +
    "                            <div class=\"edgeColorPickerPreview\" ng-style=\"{'background-color':ctrlr.colorPalette.colors[1]}\"></div>\n" +
    "                        </div>\n" +
    "                        <input name=\"color1\" class=\"form-control\" colorpicker=\"hex\" type=\"text\" ng-model=\"ctrlr.colorPalette.colors[1]\" ng-trim=\"true\" ng-required=\"true\" ng-pattern=\"validateColor\"/>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"ctrlr.colorPalette.type === 'custom'\">\n" +
    "            <edge-labeled-control label=\"{{::'Custom Colors' | translate}}\" label-width=\"4\">\n" +
    "                <div class=\"panel\">\n" +
    "                    <div class=\"panel-body\" style=\"flex-basis: auto; height:250px\">\n" +
    "                        <div class=\"list-group eeList stringList\" sv-root sv-part=\"ctrlr.colorPalette.colors\">\n" +
    "                            <div class=\"list-group-item\" style=\"display: flex; padding-right:20px;\" sv-element\n" +
    "                                ng-repeat=\"item in ctrlr.colorPalette.colors track by $index\"\n" +
    "                                ng-class=\"{even: $even, odd: $odd, selected: ctrlr.selectedIndex === $index}\"\n" +
    "                                ng-click=\"ctrlr.selectedIndex = $index\">\n" +
    "                                <div class=\"grabby\" sv-handle style=\"padding: 10px;\">\n" +
    "                                    <label class=\"drag-label\">{{$index + 1}}</label>\n" +
    "                                </div>\n" +
    "                                <edge-labeled-control label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                                <div class=\"with-padding input-group\">\n" +
    "                                    <div class=\"input-group-addon\" style=\"padding:4px;\">\n" +
    "                                        <div class=\"edgeColorPickerPreview\" ng-style=\"{'background-color':item}\"></div>\n" +
    "                                    </div>\n" +
    "                                    <input class=\"form-control\" type=\"text\" name=\"{{'color'+$index}}\"\n" +
    "                                        colorpicker=\"hex\" ng-trim=\"true\" ng-required=\"true\"\n" +
    "                                        ng-model=\"ctrlr.colorPalette.colors[$index]\"\n" +
    "                                        ng-pattern=\"validateColor\" edge-focus-on>\n" +
    "                                </div>\n" +
    "                                </edge-labeled-control>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-footer\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\" ng-click=\"ctrlr.addCustomColor()\">\n" +
    "                                <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-danger\" ng-disabled=\"ctrlr.selectedIndex === null\"\n" +
    "                                    ng-click=\"ctrlr.deleteCustomColor()\">\n" +
    "                                <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-12\">\n" +
    "                <edge-labeled-control label=\"{{::'Preview' | translate}}\" label-width=\"4\" style=\"margin-bottom: 0;\">\n" +
    "                    <div class=\"edgeColorPaletteManagePreview\">\n" +
    "                        <div class=\"edgePaletteColorCreateDiv\" ng-style=\"{'background-color':color}\"\n" +
    "                             ng-repeat=\"color in ctrlr.colors track by $index\"></div>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleSave()\" translate>Save</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/colorpalette/color-palette-manage-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/colorpalette/color-palette-manage-dialog.tpl.html",
    "<div ng-controller=\"ColorPaletteManageDialogController as ctrlr\" style=\"height:100%;max-height:400px;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-list items=\"ctrlr.colorPalettes\" q=\"{name: ctrlr.q}\" sort=\"name\" selected-item=\"ctrlr.selectedColorPalette\" ng-dblclick=\"ctrlr.activatePalette()\">\n" +
    "        <div class=\"row with-padding\" style=\"height:90px\">\n" +
    "            <div style=\"padding: 4px\">\n" +
    "                <span ng-if=\"!item.isEditable()\"><i class=\"icon icon_locked\" title=\"{{::'System Default' | translate}}\"></i></span>\n" +
    "                <b>{{item.name}}</b><br>\n" +
    "                <small>{{item.type}}</small>\n" +
    "                <div class=\"edgeColorPaletteManagePreview\">\n" +
    "                    <div class=\"edgePaletteColorManageDiv\" ng-repeat=\"color in item.previewcolors track by $index\"\n" +
    "                         ng-style=\"{'background-color':color}\"></div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"pull-left btn-group\">\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-click=\"ctrlr.createPalette()\"\n" +
    "                        title=\"{{::'Add New Palette' | translate}}\">\n" +
    "                    <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedColorPalette || !ctrlr.selectedColorPalette.isEditable()\"\n" +
    "                        ng-click=\"ctrlr.editPalette()\"\n" +
    "                        title=\"{{::'Edit Selected' | translate}}\">\n" +
    "                    <i class=\"btn_icon icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-warning\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedColorPalette || !ctrlr.selectedColorPalette.isCopyable()\"\n" +
    "                        ng-click=\"ctrlr.copyPalette()\"\n" +
    "                        title=\"{{::'Duplicate Selected' | translate}}\">\n" +
    "                    <i class=\"icon icon_copy btn_icon\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-danger\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedColorPalette || !ctrlr.selectedColorPalette.isEditable()\"\n" +
    "                        ng-click=\"ctrlr.deletePalette()\"\n" +
    "                        title=\"{{::'Delete Selected' | translate}}\">\n" +
    "                    <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/config/server-config-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/config/server-config-dialog.tpl.html",
    "<div ng-controller=\"ServerConfigDialogController as ctrlr\" style=\"height: 100%\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div style=\"margin-top: 10px;\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\" translate>Scope</span>\n" +
    "                            <ui-select ng-model=\"ctrlr.selectedScope\" theme=\"bootstrap\">\n" +
    "                                <ui-select-match placeholder=\"{{'Choose a scope...' | translate}}\">{{$select.selected.label}}\n" +
    "                                    <b ng-if=\"ctrlr.scopeIsImmutable()\" class=\"text-danger\">[<span\n" +
    "                                            translate>READ ONLY</span>]</b>\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item.value as item in ctrlr.scopes | filter: $select.search\">\n" +
    "                                    <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <div class=\"form-group\" ng-if=\"ctrlr.selectedScope == 4\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\" translate>Group</span>\n" +
    "                            <ui-select ng-model=\"ctrlr.selectedGroup\" theme=\"bootstrap\">\n" +
    "                                <ui-select-match placeholder=\"{{'Choose a group...' | translate}}\">{{$select.selected.name}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item in ctrlr.groups | filter: $select.search\">\n" +
    "                                    <div ng-bind-html=\"item.name | highlight: $select.search\"></div>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                            <input type=\"search\" ng-model=\"ctrlr.searchString\" class=\"form-control\"\n" +
    "                                   placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ui-grid=\"ctrlr.gridOptions\" ui-grid-edit ui-grid-auto-resize ui-grid-selection class=\"grid\"\n" +
    "         style=\"height:100%;min-height:100%\"></div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"pull-left btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-disabled=\"ctrlr.scopeIsImmutable()\"\n" +
    "                        ng-click=\"ctrlr.addConfigItem()\"><i class=\"btn_icon icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-default\" ng-disabled=\"!ctrlr.selectedConfigItem || ctrlr.scopeIsImmutable()\"\n" +
    "                        ng-click=\"ctrlr.editConfigItem()\"><i class=\"btn_icon icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-danger\" ng-disabled=\"!ctrlr.selectedConfigItem || ctrlr.scopeIsImmutable()\"\n" +
    "                        ng-click=\"ctrlr.deleteConfigItem()\"><i class=\"btn_icon icon icon_trash\"></i></button>\n" +
    "                <div class=\"dropup\" style=\"display: inline-block;\">\n" +
    "                <button class=\"btn btn-default dropdown-toggle\"\n" +
    "                        ng-disabled=\"!ctrlr.selectedConfigItem\"\n" +
    "                        type=\"button\"\n" +
    "                        id=\"cloneMenu\"\n" +
    "                        data-toggle=\"dropdown\"\n" +
    "                        aria-haspopup=\"true\"\n" +
    "                        aria-expanded=\"false\"\n" +
    "                        title=\"{{'Clone Selected' | translate}}\">\n" +
    "                    <i class=\"btn_icon icon icon_copy\"></i>\n" +
    "                    <span class=\"caret\"></span>\n" +
    "                </button>\n" +
    "                <ul class=\"dropdown-menu\" aria-labelledby=\"cloneMenu\">\n" +
    "                    <li><a href translate ng-click=\"ctrlr.cloneSelectedToGlobal()\">Clone To GLOBAL</a></li>\n" +
    "                    <li><a href translate ng-click=\"ctrlr.cloneSelectedToUser()\">Clone To USER</a></li>\n" +
    "                </ul>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/config/server-config-item-edit-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/config/server-config-item-edit-dialog.tpl.html",
    "<div ng-controller=\"ServerConfigItemEditDialogController as ctrlr\" style=\"height: 100%\">\n" +
    "    <form name=\"configItem\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{'Config Key' | translate}}\" validation=\"true\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"configKey\" ng-model=\"ctrlr.configItem.configKey\" required>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{'Value' | translate}}\" validation=\"true\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"value\" ng-model=\"ctrlr.configItem.value\" required>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\" translate>Cancel and Close</button>\n" +
    "            <button class=\"btn btn-success\" ng-click=\"ctrlr.handleSave()\" translate>Save and Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/content/DeleteContentDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/content/DeleteContentDialog.tpl.html",
    "<span translate>Are you sure you want to remove the selected content?</span>\n" +
    "<br><br>\n" +
    "<div class='alert alert-danger' role='alert'>\n" +
    "    <span translate>Note: If deleting a folder, all children will be deleted too.</span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/content/manage-content.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/content/manage-content.tpl.html",
    "<edge-view>\n" +
    "    <script type=\"text/ng-template\" id=\"manage_content_nodes_renderer.html\">\n" +
    "        <div ui-tree-handle class=\"tree-node tree-node-content\" style=\"cursor: pointer\">\n" +
    "            <i ng-click=\"this.toggle()\" class=\"tree-branch-head\"\n" +
    "               ng-class=\"{ 'tree-icon icon_toggle_collapsed': collapsed, 'tree-icon icon_toggle_expanded': !collapsed, 'invisible': !node.children || node.children.length == 0 }\"></i>\n" +
    "                            <span class=\"tree-node-label\"\n" +
    "                                  ng-dblclick=\"ctrlr.handleDblClickNode(node)\"\n" +
    "                                  ng-class=\"ctrlr.nodeClass(node)\" ng-mousedown=\"ctrlr.nodeSelected(node)\">\n" +
    "                                <i class=\"tree-icon tree-node-icon\"\n" +
    "                                   ng-class=\"{'icon_folder':node.folder, 'icon_prov_page':!node.folder}\"></i>\n" +
    "                                {{node.displayName ? node.displayName : node.name}}</span>\n" +
    "        </div>\n" +
    "        <ol ng-if=\"node.children\" ui-tree-nodes ng-model=\"node.children\" ng-class=\"{ 'hidden': collapsed }\">\n" +
    "            <li ng-repeat=\"node in node.children\" ui-tree-node ng-include=\"'manage_content_nodes_renderer.html'\">\n" +
    "            </li>\n" +
    "        </ol>\n" +
    "    </script>\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-body>\n" +
    "            <div ui-tree data-drag-enabled=\"false\" style=\"user-select: none;padding:10px;\">\n" +
    "                <ol ui-tree-nodes ng-model=\"ctrlr.treeModel\" id=\"tree-root\">\n" +
    "                    <li class=\"contentRootNode\" ng-repeat=\"node in ctrlr.treeModel\" ui-tree-node\n" +
    "                        ng-include=\"'manage_content_nodes_renderer.html'\"></li>\n" +
    "                </ol>\n" +
    "            </div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button type=\"button\" class=\"btn btn-success\" ng-click=\"ctrlr.addFolder()\"\n" +
    "                            title=\"{{::'Add Folder' | translate}}\">\n" +
    "                        <i class=\"icon icon_folder_new\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-success\" ng-click=\"ctrlr.addPage()\"\n" +
    "                            title=\"{{::'Add Page' | translate}}\">\n" +
    "                        <i class=\"icon icon_page_new\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-warning\" ng-click=\"ctrlr.editSelectedContent()\"\n" +
    "                            ng-disabled=\"ctrlr.selectedContent === null || ctrlr.selectedContent == ctrlr.rootFolder.children[0]\"\n" +
    "                            title=\"{{::'Edit Selected' | translate}}\">\n" +
    "                        <i class=\"icon icon_pencil\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-danger\" ng-click=\"ctrlr.deleteSelectedContent()\"\n" +
    "                            ng-disabled=\"ctrlr.selectedContent === null || ctrlr.selectedContent == ctrlr.rootFolder.children[0]\"\n" +
    "                            title=\"{{::'Delete Selected' | translate}}\">\n" +
    "                        <i class=\"icon icon_trash\"></i>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "                <div class=\"pull-left btn-group\">\n" +
    "                    <button type=\"button\" class=\"btn btn-danger\" ng-click=\"ctrlr.moveSelectedContent(true)\"\n" +
    "                            ng-disabled=\"ctrlr.selectedContent === null || ctrlr.selectedContent == ctrlr.rootFolder.children[0] || ctrlr.isSelectedContentFirstChild()\"\n" +
    "                            title=\"{{::'MoveUp Selected' | translate}}\">\n" +
    "                        <i class=\"icon icon_chevron_up\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-danger\" ng-click=\"ctrlr.moveSelectedContent(false)\"\n" +
    "                            ng-disabled=\"ctrlr.selectedContent === null || ctrlr.selectedContent == ctrlr.rootFolder.children[0] || ctrlr.isSelectedContentLastChild()\"\n" +
    "                            title=\"{{::'MoveDown Selected' | translate}}\">\n" +
    "                        <i class=\"icon icon_chevron_down\"></i>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/drivers/drivers.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/drivers/drivers.tpl.html",
    "<edge-view>\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-8\">\n" +
    "            <edge-panel collapsible=\"false\" collapsed=\"false\">\n" +
    "                <edge-panel-header label=\"{{'Drivers Reported by Server'|translate}}\">\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' : panelScope.Controller.dreverse == false }\"\n" +
    "                                    ng-click=\"panelScope.Controller.dreverse = false\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{'Sort Alphabetically' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' :panelScope.Controller.dreverse == true }\"\n" +
    "                                    ng-click=\"panelScope.Controller.dreverse = true\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_desc\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input\n" +
    "                                type=\"search\"\n" +
    "                                ng-model=\"panelScope.Controller.dq\"\n" +
    "                                class=\"form-control\"\n" +
    "                                placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div ng-if=\"!panelScope.Controller.drivers\" class=\"alert alert-info\">\n" +
    "                        <span translate>Loading drivers...</span>\n" +
    "                    </div>\n" +
    "                    <edge-list ng-if=\"panelScope.Controller.drivers\"\n" +
    "                               items=\"panelScope.Controller.drivers\"\n" +
    "                               sort=\"name\"\n" +
    "                               selected-item=\"panelScope.Controller.selectedDriver\"\n" +
    "                               q=\"panelScope.Controller.dq\"\n" +
    "                               reverse=\"panelScope.Controller.dreverse\">\n" +
    "                        <div class=\"row with-padding\">\n" +
    "                            <div class=\"col-sm-9\">\n" +
    "                                <i class=\"fa fa-cube list-icon\"></i> <span>{{item.displayName || item.name}}</span>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <div class=\"badge pull-right\"\n" +
    "                                     ng-class=\"{'badge-success':item.activated}\">\n" +
    "                                    <i ng-if=\"item.activated\" class=\"icon icon_check\"/><i ng-if=\"!item.activated\"\n" +
    "                                                                                          class=\"icon icon_minus_circle\"/>{{item.activated ? \" Activated\" : \"Disabled\"}}\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-success\"\n" +
    "                                ng-if=\"panelScope.Controller.selectedDriver.activated === false\"\n" +
    "                                ng-click=\"panelScope.Controller.activateSelectedDriver(true)\">\n" +
    "                            <span translate>Activate</span>\n" +
    "                        </button>\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-danger\"\n" +
    "                                ng-if=\"panelScope.Controller.selectedDriver.activated === true\"\n" +
    "                                ng-click=\"panelScope.Controller.activateSelectedDriver(false)\">\n" +
    "                            <span translate>Deactivate</span>\n" +
    "                        </button>\n" +
    "\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-warning\"\n" +
    "                                ng-disabled=\"!panelScope.Controller.selectedDriver || panelScope.Controller.selectedDriver.activated\"\n" +
    "                                ng-click=\"panelScope.Controller.renameSelectedDriver(false)\">\n" +
    "                            <span translate>Rename Driver</span>\n" +
    "                        </button>\n" +
    "\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-danger pull-right\"\n" +
    "                                ng-click=\"panelScope.Controller.restartServer()\">\n" +
    "                            <i class=\"icon icon_recycle\"></i><span translate>Restart Server</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <edge-panel collapsible=\"false\" collapsed=\"false\">\n" +
    "                <edge-panel-header label=\"{{'Driver Search Paths'|translate}}\"></edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"panelScope.Controller.paths\"\n" +
    "                               selected-item=\"panelScope.Controller.selectedPath\"\n" +
    "                               q=\"panelScope.Controller.q\"\n" +
    "                               reverse=\"panelScope.Controller.reverse\">\n" +
    "                        <div class=\"with-padding\"><span>{{item}}</span></div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-success\"\n" +
    "                                    ng-click=\"panelScope.Controller.addNewPath()\"\n" +
    "                                    title=\"{{'Add' | translate}}\">\n" +
    "                                <i class=\"icon icon_plus\"></i>\n" +
    "                            </button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-danger\"\n" +
    "                                    ng-click=\"panelScope.Controller.deleteSelectedPath()\"\n" +
    "                                    ng-disabled=\"!panelScope.Controller.selectedPath\"\n" +
    "                                    title=\"{{'Add' | translate}}\">\n" +
    "                                <i class=\"icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</edge-view>");
}]);

angular.module("edge/core/admin/managers/drivers/PathNameEntryDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/drivers/PathNameEntryDialog.tpl.html",
    "<form name=\"choosePathName\">\n" +
    "    <edge-property-editor config=\"pathConfig\"></edge-property-editor>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/drivers/RenameDriverDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/drivers/RenameDriverDialog.tpl.html",
    "<form name=\"driverNameForm\">\n" +
    "    <edge-property-editor config=\"driverNameConfig\"></edge-property-editor>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/managers.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/managers.tpl.html",
    "<ui-view></ui-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/maps/edit-map-apikey-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/maps/edit-map-apikey-dialog.tpl.html",
    "<form name=\"mapApiKeyForm\" class=\"form-horizontal\">\n" +
    "    <div ng-if=\"duplicate\" class=\"alert alert-danger\" role=\"alert\" translate>\n" +
    "        A map layer API key with the same name already exists, please enter another name.\n" +
    "    </div>\n" +
    "    <div ng-if=\"! isEdit\">\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Name' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" type=\"text\" ng-required=\"true\" ng-pattern=\"/^[\\w]+$/\" name=\"apiKyeName\" ng-model=\"selectedKey.name\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Value' | translate}}\" validation=\"true\">\n" +
    "            <input class=\"form-control\" type=\"text\" ng-required=\"true\" name=\"apiKyeValue\" ng-model=\"selectedKey.value\">\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <edge-labeled-control ng-if=\"isEdit\" label-width=\"3\" label=\"{{::selectedKey.name}}\" validation=\"true\">\n" +
    "        <input class=\"form-control\" type=\"text\" ng-required=\"true\" name=\"apiKyeValue\" ng-model=\"selectedKey.value\">\n" +
    "    </edge-labeled-control>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/maps/manage-map-layers.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/maps/manage-map-layers.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel resize=\"Controller.panelResized\">\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"pull-left input-group pipeline-search\">\n" +
    "                    <span class=\"input-group-addon\" translate>Map Layers</span>\n" +
    "                    <ui-select ng-model=\"Controller.selectedViewType\" theme=\"bootstrap\" on-select=\"Controller.toggleView()\">\n" +
    "                        <ui-select-match>\n" +
    "                            {{$select.selected.displayName}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item.name as item in Controller.viewTypes | filter: {displayName: $select.search}\">\n" +
    "                            <div ng-bind-html=\"item.displayName | highlight: $select.search\"></div>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </div>\n" +
    "                <div class=\"panel-heading-control pull-right\">\n" +
    "                    <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input\n" +
    "                                type=\"search\"\n" +
    "                                ng-model=\"panelScope.Controller.q\"\n" +
    "                                class=\"form-control\"\n" +
    "                                placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <div ui-grid=\"Controller.dataGridOptions\"\n" +
    "                 ui-grid-selection\n" +
    "                 ui-grid-resize-columns\n" +
    "                 class=\"grid modulegrid managemaplayersgrid\"></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"pull-left btn-group\">\n" +
    "                <button class=\"btn btn-success\" ng-click=\"::panelScope.Controller.editLayer(true)\" title=\"{{::'Add' | translate}}\">\n" +
    "                    <i class=\"icon icon_plus btn_icon\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-warning\" ng-click=\"panelScope.Controller.editLayer()\"\n" +
    "                        ng-disabled=\"!panelScope.Controller.selectedRow.visible || !panelScope.Controller.selectedRow.entity.isUserLayer()\"\n" +
    "                        title=\"{{::'Edit' | translate}}\">\n" +
    "                    <i class=\"icon icon_pencil btn_icon\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-warning\" ng-click=\"panelScope.Controller.copyLayer()\"\n" +
    "                        ng-disabled=\"!panelScope.Controller.selectedRow.visible\"\n" +
    "                        title=\"{{::'Duplicate Selected' | translate}}\">\n" +
    "                    <i class=\"icon icon_copy btn_icon\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-danger\" ng-click=\"::panelScope.Controller.deleteLayer()\"\n" +
    "                    ng-disabled=\"!panelScope.Controller.selectedRow.visible || !panelScope.Controller.selectedRow.entity.isUserLayer()\"\n" +
    "                        title=\"{{::'Delete' | translate}}\">\n" +
    "                    <i class=\"icon icon_trash btn_icon\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"pull-right badge\" translate translate-params-total=\"Controller.dataGridOptions.data.length\" translate-params-filtered=\"Controller.filteredCount\">\n" +
    "                {{filtered}} of {{total}} Layers\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/maps/mapLayerWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/maps/mapLayerWizard.tpl.html",
    "<div ng-controller=\"MapLayerWizardController as mapLayerCtrlr\" style=\"height:100%\" block-ui=\"connectionTest\">\n" +
    "    <edge-wizard force-progression=\"mapLayerCtrlr.isNew\" dialog-mode=\"true\"\n" +
    "                 on-save=\"mapLayerCtrlr.handleSave\">\n" +
    "        <edge-wizard-step label=\"{{::'Basic Config'|translate}}\" use-form-validation=\"layerForm\" index=\"1\"\n" +
    "            validate=\"mapLayerCtrlr.validateConfiguration()\">\n" +
    "            <form name=\"layerForm\" class=\"form-horizontal ui-select-jointed-group\">\n" +
    "                <div ng-if=\"mapLayerCtrlr.layer.apiKeyName && ! mapLayerCtrlr.selectedKey\" class=\"alert alert-danger alert-dismissible\" role=\"alert\">\n" +
    "                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>\n" +
    "                    <span translate translate-params-key-name=\"mapLayerCtrlr.layer.apiKeyName\">API key '{{keyName}}' no longer exists, please select another one.</span>\n" +
    "                </div>\n" +
    "                <edge-labeled-control ng-if=\"mapLayerCtrlr.isNew\" class=\"col-sm-9\" label-width=\"4\" label=\"{{::'Name'|translate}}\"\n" +
    "                    helptext=\"{{::'Unique name for this map layer'|translate}}\" validation=\"true\">\n" +
    "                    <input class=\"form-control\" type=\"text\" name=\"name\" edge-focus-on ng-required=\"true\" ng-model=\"mapLayerCtrlr.layer.name\" ng-pattern=\"/^\\w[\\w-]*$/\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-if=\"! mapLayerCtrlr.isNew\" class=\"col-sm-9\" label-width=\"4\" label=\"{{::'Name'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" readonly=\"true\" name=\"name\" ng-model=\"mapLayerCtrlr.layer.name\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control style=\"clear: both\" class=\"col-sm-9\" label-width=\"4\" validation=\"true\" label=\"{{::'Display Name'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" name=\"displayName\" ng-required=\"true\" ng-model=\"mapLayerCtrlr.layer.displayName\" ng-pattern=\"/^\\w[\\w- :\\+]*$/\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-property-control style=\"clear: both\" class=\"col-sm-9\" label-width=\"4\" validation=\"true\" property-def=\"::mapLayerCtrlr.typeDef\" property-value=\"::mapLayerCtrlr.layer\" items=\"::mapLayerCtrlr.sourceTyps\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-labeled-control style=\"clear: both\" label-width=\"3\" label=\"{{::'Layer URL'|translate}}\" helptext=\"{{::'Example: Protocol relative: //tile.com/maps/{z}/{x}/{y}.png?api_key={key}. Locally hosted tiles: /custom/maps/{z}/{x}/{y}.png.'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" name=\"httpurl\" ng-model=\"mapLayerCtrlr.urls.httpUrl\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label-width=\"3\" ng-if=\"mapLayerCtrlr.showHttps\" label=\"{{::'Layer Https URL'|translate}}\" helptext=\"{{::'Enter a value only if the layer has two distinct url patterns for http and https requests. Else just enter protocol relative url path like //tile.com/maps/{z}/{x}/{y}.png?api_key={key} in Layer Http URL field'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" name=\"httpsurl\" ng-model=\"mapLayerCtrlr.urls.httpsUrl\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label-width=\"3\" label=\"{{::'API Key Name'|translate}}\" validation=\"true\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\" ng-dblclick=\"mapLayerCtrlr.showHttps=!mapLayerCtrlr.showHttps\"><i class=\"fa fa-key\"></i></span>\n" +
    "                        <input type=hidden name=\"selectedKey\" ng-required=\"true\" ng-model=\"mapLayerCtrlr.selectedKey\">\n" +
    "                        <ui-select ng-model=\"mapLayerCtrlr.selectedKey\" on-select=\"mapLayerCtrlr.layer.apiKeyName = mapLayerCtrlr.selectedKey.value === null ? null : mapLayerCtrlr.selectedKey.name\">\n" +
    "                            <ui-select-match theme=\"bootstrap\">\n" +
    "                                {{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"key in mapLayerCtrlr.apiKeys | filter: {name: $select.search } | orderBy:'name'\">\n" +
    "                                <span ng-bind-html=\"key.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                        <span class=\"input-group-btn\">\n" +
    "                            <button class=\"btn btn-default\" type=\"button\"\n" +
    "                                    ng-click=\"mapLayerCtrlr.editApiKey(false)\"><i class=\"icon icon_plus\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" type=\"button\" ng-click=\"mapLayerCtrlr.editApiKey(true)\"\n" +
    "                                    ng-disabled=\"mapLayerCtrlr.selectedKey.value==null\"><i class=\"icon icon_pencil\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" type=\"button\" ng-click=\"mapLayerCtrlr.deleteApiKey()\"\n" +
    "                                    ng-disabled=\"mapLayerCtrlr.selectedKey.value==null\"><i class=\"icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </span>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label-width=\"3\" label=\"{{::'API Key Value'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" readonly=\"true\" name=\"apuKeyValue\" ng-model=\"mapLayerCtrlr.selectedKey.value\">\n" +
    "                </edge-labeled-control>\n" +
    "                <h4 translate>Base Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-labeled-control style=\"clear: both\" class=\"col-sm-6\" label-width=\"6\" validation=\"true\" label=\"{{::'Minimum Zoom'|translate}}\">\n" +
    "                    <edge-number-spinner inputname=\"minZoom\" isrequired=\"true\" ng-model=\"mapLayerCtrlr.layerOptions.minZoom\" step=\"1\" minimum=\"1\" maximum=\"22\">\n" +
    "                    </edge-number-spinner>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\" label=\"{{::'Maximum Zoom'|translate}}\">\n" +
    "                    <edge-number-spinner inputname=\"maxZoom\" isrequired=\"true\" ng-model=\"mapLayerCtrlr.layerOptions.maxZoom\" step=\"1\" minimum=\"1\" maximum=\"22\">\n" +
    "                    </edge-number-spinner>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control style=\"clear: both; width\" class=\"col-sm-6\" label-width=\"6\" validation=\"true\" label=\"{{::'Alpha'|translate}}\">\n" +
    "                    <edge-number-spinner inputname=\"alpha\" isrequired=\"true\" ng-model=\"mapLayerCtrlr.layerOptions.opacity\" step=\"0.1\" minimum=\"0\" maximum=\"1\">\n" +
    "                    </edge-number-spinner>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control style=\"clear: both\" label-width=\"3\" label=\"{{::'Attribution'|translate}}\">\n" +
    "                    <input class=\"form-control\" type=\"text\" name=\"attribution\" ng-model=\"mapLayerCtrlr.layerOptions.attribution\">\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Additional Options'|translate}}\" use-form-validation=\"additionalOptions\" validate=\"mapLayerCtrlr.validateOptions()\" index=\"2\">\n" +
    "            <style>\n" +
    "                .tableListHeading label { font-size: 14px; margin: 2px 0; padding-left: 3px }\n" +
    "            </style>\n" +
    "            <form name=\"additionalOptions\" class=\"tableList\" style=\"height: 100%;\">\n" +
    "                <edge-panel>\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div class=\"tableListHeading\" style=\"width: 100%\">\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <label translate>Name</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-2\">\n" +
    "                                <label translate>Type</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-6\">\n" +
    "                                <label translate>Value</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <ul class=\"list-group eeList stringList\">\n" +
    "                            <li class=\"list-group-item\" style=\"padding: 8px 0;\"\n" +
    "                            ng-repeat=\"item in mapLayerCtrlr.additionalOptions track by $index\"\n" +
    "                            ng-class=\"{even: $even, odd: $odd, selected: panelScope.mapLayerCtrlr.selectedOption === $index}\"\n" +
    "                            ng-click=\"panelScope.mapLayerCtrlr.selectedOption = $index\">\n" +
    "                                <edge-labeled-control class=\"col-sm-4\" label-width=\"0\" validation=\"true\" style=\"padding-right: 15px\">\n" +
    "                                    <input class=\"form-control\" type=\"text\" name=\"key{{$index}}\" ng-required=\"true\" ng-model=\"item.key\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control class=\"col-sm-2\" label-width=\"0\">\n" +
    "                                    <select class=\"form-control\" name=\"type{{$index}}\" ng-model=\"item.type\" ng-change=\"mapLayerCtrlr.updateType(item)\">\n" +
    "                                        <option ng-repeat=\"option in mapLayerCtrlr.optionTypes\" value=\"{{option.value}}\">{{option.label}}</option>\n" +
    "                                    </select>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"item.oldtype === 'string'\" class=\"col-sm-6\" label-width=\"0\" validation=\"true\" style=\"padding-right: 25px\">\n" +
    "                                    <input class=\"form-control\" type=\"text\" name=\"value{{$index}}\" ng-required=\"true\" ng-model=\"item.value\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"item.oldtype === 'boolean'\" class=\"col-sm-6\" label-width=\"0\">\n" +
    "                                    <input type=\"checkbox\" name=\"value{{$index}}\" ng-model=\"item.value\" edge-boolean-switch>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"item.oldtype === 'number'\" class=\"col-sm-6\" label-width=\"0\" validation=\"true\" style=\"padding-right: 25px\">\n" +
    "                                    <edge-number-spinner inputname=\"value{{$index}}\" isrequired=\"true\" ng-model=\"item.value\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <div style=\"clear: both\"></div>\n" +
    "                            </li>\n" +
    "                        </ul>\n" +
    "                    </edge-panel-body>\n" +
    "                    <edge-panel-footer>\n" +
    "                        <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"mapLayerCtrlr.addRow()\"></button>\n" +
    "                        <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"mapLayerCtrlr.removeRow()\"\n" +
    "                                ng-disabled=\"mapLayerCtrlr.selectedOption==null\"></button>\n" +
    "                    </edge-panel-footer>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"mapLayerCtrlr.layer.layerType === 'base tile'\" label=\"{{::'Theme Options'|translate}}\" use-form-validation=\"themeOptionsForm\" validate=\"mapLayerCtrlr.validateThemeColor()\" index=\"3\">\n" +
    "            <form name=\"themeOptionsForm\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control class=\"col-sm-9\" label-width=\"5\" label=\"{{::'Toolbar Theme'|translate}}\">\n" +
    "                    <select class=\"form-control\" name=\"toolbarTheme\" ng-model=\"mapLayerCtrlr.themeOptions.toolbarTheme\">\n" +
    "                        <option ng-repeat=\"item in mapLayerCtrlr.toolbarThemes\" value=\"{{item.value}}\">{{item.label}}</option>\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control style=\"clear: both\" class=\"col-sm-9\" label-width=\"5\" label=\"{{::'Map Background Class'|translate}}\">\n" +
    "                    <select class=\"form-control\" ng-options=\"item as item for item in mapLayerCtrlr.mapBGClasses\" name=\"mapBackgroundClass\" ng-model=\"mapLayerCtrlr.themeOptions.mapBackgroundClass\"></select>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control style=\"clear: both\" class=\"col-sm-9\" label-width=\"5\" label=\"{{::'Label Background'|translate}}\">\n" +
    "                    <div>\n" +
    "                        <edge-labeled-control label=\"{{::'Color' | translate}}\" validation=\"true\" label-width=\"4\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <div class=\"input-group-addon\" style=\"padding:4px;\">\n" +
    "                                    <div class=\"edgeColorPickerPreview\" ng-style=\"{'background-color':mapLayerCtrlr.themeOptions.labelBackground.color}\"></div>\n" +
    "                                </div>\n" +
    "                                <input class=\"form-control\" type=\"text\" name=\"color\"\n" +
    "                                    colorpicker=\"hex\" ng-trim=\"true\" ng-required=\"true\"\n" +
    "                                    ng-model=\"mapLayerCtrlr.themeOptions.labelBackground.color\"\n" +
    "                                    ng-pattern=\"validateColor\">\n" +
    "                            </div>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control label=\"{{::'Alpha' | translate}}\" label-width=\"4\" validation=\"true\" required=\"true\">\n" +
    "                            <edge-number-spinner inputname=\"labelAlpha\" isrequired=\"true\" ng-model=\"mapLayerCtrlr.themeOptions.labelBackground.alpha\" step=\"0.1\" minimum=\"0\" maximum=\"1\">\n" +
    "                            </edge-number-spinner>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/add-content-bundle-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/add-content-bundle-dialog.tpl.html",
    "<div ng-controller=\"AddContentBundleDialogController as acbdCtrlr\">\n" +
    "    <form name=\"dialogForm\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{'Application Version' | translate}}\"\n" +
    "                                  label-width=\"4\"\n" +
    "                                  helptext=\"{{'Select the version of the target application. This will affect the list of applicable content bundles.' | translate}}\"\n" +
    "                                  validation=\"true\">\n" +
    "                <input type=\"hidden\" name=\"selectedVersion\" ng-model=\"acbdCtrlr.selectedVersion\" ng-required=\"true\">\n" +
    "                <ui-select ng-model=\"acbdCtrlr.selectedVersion\" append-to-body=\"true\">\n" +
    "                    <ui-select-match theme=\"bootstrap\"\n" +
    "                                     allow-clear=\"false\"\n" +
    "                                     placeholder=\"{{'Select application version...' | translate}}\">\n" +
    "                        {{$select.selected}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices\n" +
    "                            repeat=\"item as item in acbdCtrlr.appVersions | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"item | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{'Content Bundle' | translate}}\"\n" +
    "                                  label-width=\"4\"\n" +
    "                                  helptext=\"{{'Select from the available content bundles for the application version chosen above.' | translate}}\"\n" +
    "                                  validation=\"true\">\n" +
    "                <input type=\"hidden\" name=\"selectedBundle\" ng-model=\"acbdCtrlr.selectedBundle\" ng-required=\"true\">\n" +
    "                <ui-select ng-model=\"acbdCtrlr.selectedBundle\" append-to-body=\"true\">\n" +
    "                    <ui-select-match theme=\"bootstrap\"\n" +
    "                                     allow-clear=\"false\"\n" +
    "                                     placeholder=\"{{'Select bundle...' | translate}}\">\n" +
    "                        {{$select.selected.displayName}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices\n" +
    "                            repeat=\"item as item in acbdCtrlr.selectedModule.contentBundles | filter: {bundleName:$select.search, appVersion:acbdCtrlr.selectedVersion}\">\n" +
    "                        <span ng-bind-html=\"item.displayName | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{'Deployment Prefix' | translate}}\"\n" +
    "                                  label-width=\"4\"\n" +
    "                                  helptext=\"{{'Deployed configuration items require unique names, use a prefix to avoid collisions such as deploying the same content bundle multiple times.' | translate}}\"\n" +
    "                                  validation=\"true\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"prefix\" ng-model=\"acbdCtrlr.selectedBundle.bundlePrefix\" ng-required=\"false\" ng-pattern=\"/^[a-zA-Z]\\w*$/\" ng-trim=\"false\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"acbdCtrlr.handleCancel()\">\n" +
    "                <span translate>Cancel</span></button>\n" +
    "            <button edge-button-spinner\n" +
    "                    data-spinner-color=\"#AAAAAA\"\n" +
    "                    data-style=\"expand-left\"\n" +
    "                    class=\"btn btn-success\"\n" +
    "                    spin-toggle=\"acbdCtrlr.activelySaving\"\n" +
    "                    ng-click=\"acbdCtrlr.handleAdd()\">\n" +
    "                <span translate>Deploy</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/add-content-bundle-success-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/add-content-bundle-success-dialog.tpl.html",
    "<div class=\"importModule alert alert-success\" role=\"alert\">\n" +
    "    <div class=\"col-sm-2\">\n" +
    "        <i class=\"icon icon_check\"></i>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-10\">\n" +
    "        <div class=\"oneDot5emFont\" translate>Content Bundle:</div>\n" +
    "        <span class=\"text-bold oneDot5emFont\" ng-bind-html=\"::bundle.displayName\"></span>\n" +
    "        <div class=\"oneDot5emFont\" translate>Deployed Successfully</div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/import-license-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/import-license-dialog.tpl.html",
    "<form name=\"importalModuleForm\" class=\"form-horizontal\">\n" +
    "    <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\" property-def=\"::Controller.moduleFileNameDef\" property-value=\"Controller.exportNameValue\" callback=\"Controller.processFile\"></edge-property-control>\n" +
    "\n" +
    "    <textarea ng-if=\"Controller.licenseFile.length > 0\" readonly class=\"form-control\" style=\"width: 100%; height: 260px\">{{Controller.licenseFile}}\n" +
    "    </textarea>\n" +
    "\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/import-module-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/import-module-dialog.tpl.html",
    "<div class=\"row\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                <input type=\"search\" ng-change=\"Controller.refreshData()\" ng-model=\"Controller.q\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ui-grid=\"Controller.dataGridOptions\" ui-grid-selection ui-grid-resize-columns class=\"grid modulegrid availablemodulegrid\" style=\"min-height: 350px\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/import-module-prompt-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/import-module-prompt-dialog.tpl.html",
    "<div class=\"importModule alert alert-info\" role=\"alert\">\n" +
    "    <div class=\"col-sm-2\">\n" +
    "        <i class=\"icon icon_info\"></i>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-10\">\n" +
    "        <div ng-if=\"::module.installed\">\n" +
    "            <span translate-params-module-name=\"::(module.vendor + ' ' + module.name)\" translate>This will upgrade the <span class=\"text-bold\">{{moduleName}}</span> adapter from:</span>\n" +
    "            <div class=\"text-bold oneDot5emFont\" translate-params-from-version=\"::module.version\" translate-params-to-version=\"selected.version\" translate>Version {{fromVersion}} to Version {{toVersion}}</div>\n" +
    "        </div>\n" +
    "        <div ng-if=\"::!module.installed\">\n" +
    "            <span translate-params-module-name=\"::(module.vendor + ' ' + module.name)\" translate>This will install the <span class=\"text-bold\">{{moduleName}}</span> adapter:</span>\n" +
    "            <div class=\"text-bold oneDot5emFont\" translate-params-to-version=\"selected.version\" translate>Version {{toVersion}}</div>\n" +
    "        </div>\n" +
    "        <div ng-if=\"::(module.newVersions.length > 1)\" style=\"padding-top: 20px\">\n" +
    "            <span translate>Available Versions</span>\n" +
    "            <div class=\"radio\" ng-repeat=\"version in ::module.newVersions\">\n" +
    "              <label>\n" +
    "                  <input type=\"radio\" ng-model=\"selected.version\" ng-value=\"version\">{{version}}\n" +
    "              </label>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-12\" style=\"text-align: center; padding-top: 20px\" translate>\n" +
    "        No Server Restart is required for this operation.\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/import-module-success-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/import-module-success-dialog.tpl.html",
    "<div class=\"importModule alert alert-success\" role=\"alert\">\n" +
    "    <div class=\"col-sm-2\">\n" +
    "        <i class=\"icon icon_check\"></i>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-10\">\n" +
    "        <span class=\"text-bold oneDot5emFont\" ng-bind-html=\"::(module.vendorDescription + ' ' + module.name + ' ' + module.version)\"></span>\n" +
    "        <div class=\"oneDot5emFont\" translate>Installed Successfully</div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/license-viewer-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/license-viewer-dialog.tpl.html",
    "<div class=\"row\" ng-controller=\"LicenseViewerController as ctrlr\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\">\n" +
    "                    <i class=\"icon icon_search\"></i>\n" +
    "                </span> <input type=\"search\"\n" +
    "                               ng-change=\"ctrlr.refreshData()\"\n" +
    "                               ng-model=\"ctrlr.q\"\n" +
    "                               class=\"form-control\"\n" +
    "                               placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ng-if=\"!ctrlr.licenseStatus\" class=\"alert alert-warning\" role=\"alert\" style=\"border-radius: 0; margin: 0; padding:10px\">\n" +
    "        <span translate>The product is not licensed. Please update the license.</span>\n" +
    "    </div>\n" +
    "    <div ng-if=\"ctrlr.licenseStatus\" class=\"alert\" ng-class=\"ctrlr.licenseStatus.dateValid && ctrlr.licenseStatus.ipValid ? 'alert-success' : 'alert-danger'\" role=\"alert\" style=\"border-radius: 0; margin: 0; padding:10px\">\n" +
    "        <div ng-if=\"! ctrlr.licenseStatus.dateValid\" style=\"padding-bottom: 15px\" translate>The product license has expired.</div>\n" +
    "        <div ng-if=\"! ctrlr.licenseStatus.ipValid\" style=\"padding-bottom: 15px\" translate>The product license is invalid for this server's IP address.</div>\n" +
    "        <span translate-params-ip=\"ctrlr.serverIP\" translate-params-date=\"ctrlr.expirationDate\" translate-params-session=\"ctrlr.sessionMax\" translate-params-domain=\"ctrlr.domainMax\" translate>\n" +
    "            Product is licensed for IP <b>{{ip}}</b> until <b>{{date}}</b> with <b>{{session}}</b> session(s) and <b>{{domain}}</b> domain(s)\n" +
    "        </span>\n" +
    "        <br/><span translate>The following adapters are licensed:</span>\n" +
    "    </div>\n" +
    "    <div ui-grid=\"ctrlr.dataGridOptions\" ui-grid-selection ui-grid-resize-columns\n" +
    "         class=\"grid modulegrid licensegrid\" style=\"min-height: 350px\"></div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-success pull-left\" ng-click=\"::ctrlr.updateLicense()\">\n" +
    "                <span translate>Update License...</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"::handleClose()\">\n" +
    "                <span translate>Close</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/module-connections-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/module-connections-dialog.tpl.html",
    "<div class=\"row\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                <input type=\"search\" ng-change=\"Controller.refreshData()\" ng-model=\"Controller.q\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ui-grid=\"Controller.dataGridOptions\" ui-grid-selection ui-grid-resize-columns class=\"grid modulegrid connectionsgrid\" style=\"min-height: 350px\"></div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <button class=\"btn btn-default pull-left\" ng-click=\"Controller.viewPipeline()\" ng-disabled=\"Controller.selectedConnection==null\">\n" +
    "            <i class=\"glyphicon glyphicon-eye-open\"></i>\n" +
    "            <span translate>View Pipeline</span>\n" +
    "        </button>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/modules/modules.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/modules/modules.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel resize=\"Controller.panelResized\">\n" +
    "        <edge-panel-header label=\"{{::'Installed Adapters' | translate}}\">\n" +
    "            <div class=\"panel-heading-control pull-right\">\n" +
    "                <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input\n" +
    "                            type=\"search\"\n" +
    "                            ng-change=\"panelScope.Controller.refreshData()\"\n" +
    "                            ng-model=\"panelScope.Controller.q\"\n" +
    "                            class=\"form-control\"\n" +
    "                            placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <div ui-grid=\"Controller.dataGridOptions\"\n" +
    "                 ui-grid-selection\n" +
    "                 ui-grid-resize-columns\n" +
    "                 class=\"grid modulegrid installedmodulegrid\"></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button ng-disabled=\"panelScope.Controller.availableModules.length === 0\" class=\"btn btn-default\"\n" +
    "                    ng-click=\"::panelScope.Controller.addModule()\"\n" +
    "                    title=\"{{'Add' | translate}}\">\n" +
    "                <i class=\"icon icon_plus\"></i>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.editModuleConnections()\"\n" +
    "                    ng-disabled=\"panelScope.Controller.selectedModule==null\" title=\"{{'Edit' | translate}}\">\n" +
    "                <i class=\"icon icon_pencil\"></i>\n" +
    "            </button>\n" +
    "            <button ng-if=\"showDelete\" class=\"btn btn-danger\" ng-click=\"::panelScope.Controller.uninstallModule()\"\n" +
    "                ng-disabled=\"panelScope.Controller.selectedModule==null\">\n" +
    "                <i class=\"glyphicon glyphicon-trash\"></i>\n" +
    "                <span translate>Uninstall</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                ng-click=\"::panelScope.Controller.addContent()\" \n" +
    "                ng-disabled=\"!panelScope.Controller.selectedModule.contentBundles.length > 0\">\n" +
    "                <span translate>Deploy Content Bundle</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    ng-click=\"::panelScope.Controller.uploadModule()\">\n" +
    "                <span translate>Upload Adapter</span>\n" +
    "            </button>\n" +
    "            <!--\n" +
    "            <button class=\"btn btn-default\">\n" +
    "                <i class=\"glyphicon glyphicon-plus\"></i>\n" +
    "                <span translate>New Custom Adapter</span>\n" +
    "            </button>\n" +
    "            -->\n" +
    "            <div class=\"pull-right btn-toolbar\">\n" +
    "                <button class=\"btn btn-success\" ng-click=\"::panelScope.Controller.viewLicense()\">\n" +
    "                    <span translate>Manage License</span>\n" +
    "                </button>\n" +
    "                <div class=\"connections-license-info\">\n" +
    "                    <span translate>Total Active Connections:</span>\n" +
    "                    <span class=\"badge\" ng-dblclick=\"showDelete=true\">{{panelScope.Controller.activeConnectionCount}}</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/sessions/sessions.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/sessions/sessions.tpl.html",
    "<edge-view>\n" +
    "    <div class=\"row\">\n" +
    "        <edge-panel resize=\"Controller.panelResized\">\n" +
    "            <edge-panel-header label=\"{{::'Manage Sessions'|translate}}\"></edge-panel-header>\n" +
    "            <edge-panel-body style=\"overflow:hidden\">\n" +
    "                <div ui-grid=\"Controller.dataGridOptions\" ui-grid-selection class=\"grid backupgrid\"></div>\n" +
    "            </edge-panel-body>\n" +
    "            <edge-panel-footer>\n" +
    "                <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.deleteSession()\" title=\"{{::'Terminate' | translate}}\">\n" +
    "                    <i class=\"icon icon_trash\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.loadSessionList()\">\n" +
    "                    <span translate>Refresh</span>\n" +
    "                </button>\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.selectAll()\">\n" +
    "                        <span translate>Select All</span>\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-default\" ng-click=\"panelScope.Controller.clearAll()\">\n" +
    "                        <span translate>Deselect All</span>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </edge-panel-footer>\n" +
    "        </edge-panel>\n" +
    "    </div>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/system/edgeAdaptersInfo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/system/edgeAdaptersInfo.tpl.html",
    "<div>\n" +
    "    <!-- @formatter:off -->\n" +
    "    <style>\n" +
    "        table {\n" +
    "            width: 100%;\n" +
    "            max-width: 450px;\n" +
    "            border-spacing: 0;\n" +
    "        }\n" +
    "\n" +
    "        th, td {\n" +
    "            max-width: 100px;\n" +
    "            overflow: hidden;\n" +
    "            text-overflow: ellipsis;\n" +
    "            white-space: nowrap;\n" +
    "        }\n" +
    "\n" +
    "        tbody {\n" +
    "            overflow-y: auto;\n" +
    "            overflow-x: hidden;\n" +
    "        }\n" +
    "\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "    <table>\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th translate>Name</th>\n" +
    "            <th translate>Version</th>\n" +
    "            <th translate style='text-align: right'>Enabled</th>\n" +
    "            <th translate style='text-align: right'>Maximum</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr ng-repeat=\"module in installedModules\">\n" +
    "            <td>{{module.vendor}}.{{module.name}}</td>\n" +
    "            <td>{{module.version}}</td>\n" +
    "            <td style=\"text-align: right\">{{module.connections}}</td>\n" +
    "            <td style=\"text-align: right\" ng-bind-html=\"module.licensed === -1 ? '<i>unlimited</i>' : module.licensed\"></td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/system/edgeSystemInfo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/system/edgeSystemInfo.tpl.html",
    "<div>\n" +
    "    <div style=\"margin:0px 20px;white-space: nowrap;text-overflow: ellipsis;\">\n" +
    "        <div class=\"systemInfoItem row\" ng-repeat=\"item in sysInfoCtrlr.infoList1\">\n" +
    "            <div class=\"col-sm-4\" ng-if=\"item.label\">\n" +
    "                <span class=\"pull-right text-info text-bold hidden-xs\">{{item.label}}:</span>\n" +
    "                <span class=\"text-info text-bold visible-xs\">{{item.label}}:</span>\n" +
    "            </div>\n" +
    "            <div class=\"col-sm-4\" ng-if=\"!item.label\" style='font-size: xx-small'>&nbsp;</div>\n" +
    "            <div class=\"col-sm-8\" style=\"word-wrap: break-word\" ng-bind-html=\"item.value\"></div>\n" +
    "        </div>\n" +
    "        <div class=\"systemInfoItem row\">\n" +
    "            <div class=\"col-sm-4\">\n" +
    "                <span class=\"pull-right text-info text-bold hidden-xs\" translate>Adapter Information:</span>\n" +
    "                <span class=\"text-info text-bold visible-xs\" translate>Adapter Information:</span>\n" +
    "            </div>\n" +
    "            <div class=\"col-sm-8\">\n" +
    "                <edge-adapters-info installed-modules=\"sysInfoCtrlr.installedModules\"></edge-adapters-info>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"systemInfoItem row\" ng-repeat=\"item in sysInfoCtrlr.infoList2\">\n" +
    "            <div class=\"col-sm-4\" ng-if=\"item.label\">\n" +
    "                <span class=\"pull-right text-info text-bold hidden-xs\">{{item.label}}:</span>\n" +
    "                <span class=\"text-info text-bold visible-xs\">{{item.label}}:</span>\n" +
    "            </div>\n" +
    "            <div class=\"col-sm-4\" ng-if=\"!item.label\" style='font-size: xx-small'>&nbsp;</div>\n" +
    "            <div class=\"col-sm-8\" style=\"word-wrap: break-word\" ng-bind-html=\"item.value\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"row\" style=\"margin-top:10px;\">\n" +
    "        <div class=\"col-sm-4\"></div>\n" +
    "        <div class=\"col-sm-8\">\n" +
    "            <button class=\"btn btn-default\"\n" +
    "                    ngclipboard\n" +
    "                    data-clipboard-action=\"copy\"\n" +
    "                    data-clipboard-text=\"{{sysInfoCtrlr.clipboardText}}\"\n" +
    "                    style=\"margin-bottom: 10px\">\n" +
    "                <span translate>Copy To Clipboard</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/managers/system/system-info-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/managers/system/system-info-dialog.tpl.html",
    "<style>\n" +
    "    .SystemInfo .modal-body {\n" +
    "        padding:20px 0 0 0;\n" +
    "        overflow:hidden;\n" +
    "        background-color: #F7F7F7;\n" +
    "    }\n" +
    "    .branded-background-wide {\n" +
    "        height:220px;\n" +
    "    }\n" +
    "    .sys-info-logo {\n" +
    "        margin-left: 4em;\n" +
    "        text-align: left;\n" +
    "        padding-top: 2em;\n" +
    "        margin-bottom: 0em;\n" +
    "    }\n" +
    "    .sys-info-logo > img {\n" +
    "        width: 320px;\n" +
    "    }\n" +
    "</style>\n" +
    "<div class=\"branded-background-wide\">\n" +
    "    <div class=\"sys-info-logo\"><img ng-src=\"{{aboutLogo}}\"/>\n" +
    "    </div>\n" +
    "</div>\n" +
    "<edge-system-info></edge-system-info>\n" +
    "");
}]);

angular.module("edge/core/admin/page/add-folder-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/page/add-folder-dialog.tpl.html",
    "<div ng-controller=\"AddFolderDialogController as Controller\">\n" +
    "    <script type=\"text/ng-template\" id=\"nodes_renderer.html\">\n" +
    "        <div ui-tree-handle class=\"tree-icon tree-node tree-node-content\">\n" +
    "            <i data-nodrag\n" +
    "               ng-click=\"this.toggle()\"\n" +
    "               ng-class=\"{ 'tree-icon icon_toggle_collapsed': collapsed, 'tree-icon icon_toggle_expanded': !collapsed, 'invisible': !node.children }\"></i>\n" +
    "                            <span class=\"tree-node-label\" ng-mousedown=\"Controller.nodeSelected(node)\"\n" +
    "                                  ng-class=\"Controller.nodeClass(node)\">\n" +
    "                                <i class=\"tree-icon tree-node-icon\"\n" +
    "                                   ng-class=\"{'icon_folder_closed':node.folder, 'icon_page':!node.folder}\"></i>{{node.displayName ? node.displayName : node.name}}</span>\n" +
    "        </div>\n" +
    "        <ol ng-if=\"node.children\" ui-tree-nodes ng-model=\"node.children\" ng-class=\"{ 'hidden': collapsed }\">\n" +
    "            <li ng-if=\"::node.folder\" ng-repeat=\"node in node.children\" ui-tree-node ng-include=\"'nodes_renderer.html'\">\n" +
    "            </li>\n" +
    "        </ol>\n" +
    "    </script>\n" +
    "    <form name=\"dialogForm\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{::'Folder Name' | translate}}\" validation=\"true\">\n" +
    "                <input name=\"folderName\" type=\"text\" class=\"form-control\" ng-model=\"Controller.folderName\" ng-pattern=\"/^[^/]+$/\" required edge-focus>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Menu Visibility' | translate}}\" validation=\"false\">\n" +
    "                <edge-radio-group name=\"optionsRadios\"\n" +
    "                                  ng-model=\"Controller.isVisible\">\n" +
    "                    <edge-radio-button ng-value=\"true\">\n" +
    "                        <span translate>Show in Menu</span><br/><span class=\"text-muted\"\n" +
    "                                                                      translate>The folder will appear in the navigation menu, and will be accessible via actions.</span>\n" +
    "                    </edge-radio-button>\n" +
    "                    <edge-radio-button ng-value=\"false\">\n" +
    "                        <span translate>Hide from Menu</span><br/><span class=\"text-muted\"\n" +
    "                                                                        translate>The folder will be hidden in the navigation menu, but still accessible via actions.</span>\n" +
    "                    </edge-radio-button>\n" +
    "                </edge-radio-group>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Folder Location' | translate}}\" validation=\"true\"\n" +
    "                                  element-name=\"selectedNode\">\n" +
    "                <input name=\"selectedNode\" type=\"hidden\" ng-model=\"Controller.selectedContent\" required>\n" +
    "                <div ui-tree drag-enabled=\"false\" class=\"form-control\"\n" +
    "                     style=\"height:auto;max-height:150px;overflow: auto\">\n" +
    "                    <ol ui-tree-nodes ng-model=\"Controller.treeModel\" id=\"select-folder-tree-root\">\n" +
    "                        <li ng-repeat=\"node in Controller.treeModel\" ui-tree-node\n" +
    "                            ng-include=\"'nodes_renderer.html'\"></li>\n" +
    "                    </ol>\n" +
    "                </div>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-if=\"Controller.activelySaving\" edge-button-spinner data-spinner-color=\"#AAAAAA\" data-style=\"expand-left\" class=\"btn btn-danger\" spin-toggle=\"true\" translate>Wait</button>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"Controller.handleCancel()\" translate>Cancel</button>\n" +
    "            <button ng-disabled=\"Controller.activelySaving\" class=\"btn btn-success\" ng-click=\"Controller.handleSave()\" translate>Save</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/page/add-page-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/page/add-page-dialog.tpl.html",
    "<div ng-controller=\"AddPageDialogController as Controller\">\n" +
    "    <script type=\"text/ng-template\" id=\"nodes_renderer.html\">\n" +
    "        <div ui-tree-handle class=\"tree-icon tree-node tree-node-content\">\n" +
    "            <i data-nodrag\n" +
    "               ng-click=\"this.toggle()\"\n" +
    "               ng-class=\"{ 'tree-icon icon_toggle_collapsed': collapsed, 'tree-icon icon_toggle_expanded': !collapsed, 'invisible': !node.children }\"></i>\n" +
    "                            <span class=\"tree-node-label\" ng-mousedown=\"Controller.nodeSelected(node)\"\n" +
    "                                  ng-class=\"Controller.nodeClass(node)\">\n" +
    "                                <i class=\"tree-icon tree-node-icon\"\n" +
    "                                   ng-class=\"{'icon_folder_closed':node.folder, 'icon_page':!node.folder}\"></i>{{node.displayName ? node.displayName : node.name}}</span>\n" +
    "        </div>\n" +
    "        <ol ng-if=\"node.children\" ui-tree-nodes ng-model=\"node.children\" ng-class=\"{ 'hidden': collapsed }\">\n" +
    "            <li ng-if=\"::node.folder\" ng-repeat=\"node in node.children\" ui-tree-node ng-include=\"'nodes_renderer.html'\">\n" +
    "            </li>\n" +
    "        </ol>\n" +
    "    </script>\n" +
    "    <form name=\"dialogForm\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{::'Page Name' | translate}}\" validation=\"true\">\n" +
    "                <input name=\"pageName\" type=\"text\" class=\"form-control\" ng-model=\"Controller.pageName\" ng-pattern=\"/^[^/]+$/\" required edge-focus>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Menu Visibility' | translate}}\" validation=\"false\">\n" +
    "                <edge-radio-group name=\"optionsRadios\"\n" +
    "                                  ng-model=\"Controller.isVisible\">\n" +
    "                    <edge-radio-button ng-value=\"true\">\n" +
    "                        <span translate>Show in Menu</span><br/><span class=\"text-muted\"\n" +
    "                                                                      translate>The page will appear in the navigation menu, and will be accessible via actions.</span>\n" +
    "                    </edge-radio-button>\n" +
    "                    <edge-radio-button ng-value=\"false\">\n" +
    "                        <span translate>Hide from Menu</span><br/><span class=\"text-muted\"\n" +
    "                                                                        translate>The page will be hidden in the navigation menu, but still accessible via actions.</span>\n" +
    "                    </edge-radio-button>\n" +
    "                </edge-radio-group>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Page Location' | translate}}\" validation=\"true\" element-name=\"selectedNode\">\n" +
    "                <input name=\"selectedNode\" type=\"hidden\" ng-model=\"Controller.selectedContent\" required>\n" +
    "                <div ui-tree drag-enabled=\"false\" class=\"form-control\"\n" +
    "                     style=\"height:auto;max-height:150px;overflow: auto\">\n" +
    "                    <ol ui-tree-nodes ng-model=\"Controller.treeModel\" id=\"select-folder-tree-root\">\n" +
    "                        <li ng-repeat=\"node in Controller.treeModel\" ui-tree-node\n" +
    "                            ng-include=\"'nodes_renderer.html'\"></li>\n" +
    "                    </ol>\n" +
    "                </div>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button ng-if=\"Controller.activelySaving\" edge-button-spinner data-spinner-color=\"#AAAAAA\" data-style=\"expand-left\" class=\"btn btn-danger\" spin-toggle=\"true\" translate>Wait</button>\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"Controller.handleCancel()\" translate>Cancel</button>\n" +
    "            <button ng-disabled=\"Controller.activelySaving\" class=\"btn btn-success\" ng-click=\"Controller.handleSave()\" translate>Save</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/attrDefList/edgeAttrDefListChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/attrDefList/edgeAttrDefListChooser.tpl.html",
    "<input type=hidden name=\"{{propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\" on-select=\"onSelect($item)\">\n" +
    "    <ui-select-match allow-clear=\"{{propertyDef.required !== true}}\"\n" +
    "                     placeholder=\"{{'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item.name as item in attributeDefs | orderBy: 'name' | filter: $select.search.name\">\n" +
    "        <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/CloneNodeDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/CloneNodeDialog.tpl.html",
    "<div ng-controller=\"CloneNodeDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <div ng-if=\"ctrlr.errorResponse\" style=\"margin-bottom:10px\">\n" +
    "        <div class=\"alert alert-danger\">\n" +
    "            <span translate>Error cloning pipeline node.</span>\n" +
    "        </div>\n" +
    "        <edge-server-message response=\"ctrlr.errorResponse\"></edge-server-message>\n" +
    "    </div>\n" +
    "    <form name=\"suffixForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Suffix' | translate}}\"\n" +
    "                              helptext=\"{{'This suffix will be appended to any names that must be unique within the node that\\'s being cloned.' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"suffix\"\n" +
    "                   ng-model=\"ctrlr.suffix\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"suffixForm.$invalid\"\n" +
    "                    edge-button-spinner\n" +
    "                    data-spinner-color=\"#AAAAAA\"\n" +
    "                    data-style=\"expand-left\"\n" +
    "                    spin-toggle=\"ctrlr.isSaving\"\n" +
    "                    ng-click=\"ctrlr.handleClone()\"><span translate>Clone</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/pipeline/confirm-node-delete-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/confirm-node-delete-dialog.tpl.html",
    "<div ng-if=\"message\" class=\"alert alert-danger\" style=\"margin: 10px 20px 20px 20px;\">\n" +
    "    <span style=\"white-space: pre-line\" ng-bind-html=\"message\"></span>\n" +
    "</div>\n" +
    "<edge-labeled-control label=\"{{::'Delete Options' | translate}}\" label-width=\"3\">\n" +
    "    <edge-radio-group name=\"deleteOptions\"\n" +
    "                      ng-model=\"model.deletemode\" style=\"margin-top: -10px;\">\n" +
    "        <edge-radio-button ng-value=0>\n" +
    "            <span translate>Only this node:</span>&nbsp;{{::$parent.selectedNode.title}}<br/>\n" +
    "            <span class=\"text-muted\"\n" +
    "                  translate>The children of this node will remain, but may appear as \"orphans\".</span><br/>\n" +
    "        </edge-radio-button>\n" +
    "        <edge-radio-button ng-value=1>\n" +
    "            <span translate>This node and its children</span><br/>\n" +
    "            <span class=\"text-muted\"\n" +
    "                  translate>Delete this node and all downstream children.</span><br/>\n" +
    "        </edge-radio-button>\n" +
    "    </edge-radio-group>\n" +
    "</edge-labeled-control>");
}]);

angular.module("edge/core/admin/pipeline/connect/ChooseConnectionType.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/ChooseConnectionType.tpl.html",
    "<div class=\"row\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                <input type=\"search\" ng-model=\"ctrl.searchString\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ui-grid=\"ctrl.gridOptions\" ui-grid-selection ui-grid-resize-columns class=\"grid modulegrid connectiontypesgrid\" style=\"min-height: 350px\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/connect-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/connect-wizard.tpl.html",
    "<div ng-controller=\"ConnectionWizardController as ConnectWizardCtrlr\" ng-init=\"ConnectWizardCtrlr.init()\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"true\" dialog-mode=\"true\" on-save=\"ConnectWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ConnectWizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Connection Details'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"1\" validate=\"ConnectWizardCtrlr.validateConfiguration()\">\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form ng-if=\"ConnectWizardCtrlr.propertyEditorConfig\" name=\"connectionConfig\" style=\"padding-right:20px;\">\n" +
    "                <edge-property-editor config=\"ConnectWizardCtrlr.propertyEditorConfig\"></edge-property-editor>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Test Connection'|translate}}\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.testConnection()\" index=\"2\">\n" +
    "            <div block-ui=\"connectionTest\" style=\"height: 100%\">\n" +
    "                <div class=\"alert alert-success\" ng-if=\"ConnectWizardCtrlr.connectionTestSuccessful\"\n" +
    "                     translate>Connection test was successful.\n" +
    "                </div>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.connectionTestFailed\">\n" +
    "                    <div class=\"alert alert-danger\"><b translate>Connection test failed.</b><br><br>\n" +
    "                        <span translate>Server Response:</span>\n" +
    "                        <div class=\"well well-sm\">{{ConnectWizardCtrlr.serverResponse}} <br>\n" +
    "                            <a class=\"pull-right\"\n" +
    "                               ng-if=\"ConnectWizardCtrlr.extraDetail\"\n" +
    "                               ng-init=\"ConnectWizardCtrlr.showExtraDetail = false\"\n" +
    "                               ng-click=\"ConnectWizardCtrlr.showExtraDetail = !ConnectWizardCtrlr.showExtraDetail\">More Info</a>\n" +
    "                            <div class=\"clearfix\"></div>\n" +
    "                            <span ng-if=\"ConnectWizardCtrlr.showExtraDetail\"><br>{{ConnectWizardCtrlr.extraDetail}}</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/edgeConnectionEndpointDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/edgeConnectionEndpointDef.tpl.html",
    "<div class=\"with-padding\" ng-dblclick=\"showEditEndpointTemplate()\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <input type=\"checkbox\"\n" +
    "                   name=\"enabled\"\n" +
    "                   ng-model=\"config.enabled\"\n" +
    "                   edge-boolean-switch>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <input class=\"form-control\" ng-dblclick=\"$event.stopPropagation()\"\n" +
    "                   ng-model=\"config.name\"\n" +
    "                   placeholder=\"{{'UNKNOWN'}}\"></input>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-8\" ng-click=\"showEditEndpointTemplate()\">\n" +
    "            <small title=\"{{connectionInfo()}}\" style=\"overflow: hidden; white-space:nowrap; text-overflow:ellipsis; display: block; padding: 8px 5px; height: 32px;\">{{connectionInfo()}}</small>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/edit-database-endpoint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/edit-database-endpoint-dialog.tpl.html",
    "<div ng-controller=\"EndpointEditorDialogController as ctrlr\" class=\"with-padding row\">\n" +
    "    <form name=\"endpointEditForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label-width=\"4\" label=\"{{::'Enable Endpoint'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='ctrlr.config.enabled' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"4\" label=\"{{::'Endpoint Name'|translate}}\" ng-required=\"true\"\n" +
    "                              name=\"endpointName\"\n" +
    "                              helptext=\"{{::'A unique name identifying the endpoint.'|translate}}\" validation=\"true\">\n" +
    "            <input type=\"text\" class=\"form-control\" name=\"name\" required ng-model=\"ctrlr.config.name\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-property-editor config=\"ctrlr.config.editorConfig\"></edge-property-editor>\n" +
    "        <edge-dialog-footer>\n" +
    "            <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "                <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\"><span translate>Cancel</span></button>\n" +
    "                <button class=\"btn btn-success\"\n" +
    "                        ng-click=\"ctrlr.handleSave()\"\n" +
    "                        ng-disabled=\"endpointEditForm.$invalid\"><span translate>OK</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-dialog-footer>\n" +
    "    </form>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/edit-proxy-endpoint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/edit-proxy-endpoint-dialog.tpl.html",
    "<div ng-controller=\"ProxyEndpointEditorDialogController as ctrlr\" class=\"with-padding row\">\n" +
    "    <form name=\"endpointEditForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Enable Endpoint'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='ctrlr.config.enabled' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Endpoint Name'|translate}}\" ng-required=\"true\"\n" +
    "                              name=\"endpointName\"\n" +
    "                              helptext=\"{{::'A unique name identifying the endpoint.'|translate}}\" validation=\"true\">\n" +
    "            <input type=\"text\" class=\"form-control\" name=\"name\" required ng-model=\"ctrlr.config.name\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-property-control ng-repeat=\"propertyDef in ::ctrlr.normalSetting\"\n" +
    "                               class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                               property-value=\"ctrlr.config.propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "        </edge-property-control>\n" +
    "        <div ng-if=\"ctrlr.config.propertyBundle.findPropertyValueByName('ssoHandlerType').value !== 'None'\">\n" +
    "            <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                   property-def=\"::ctrlr.config.propertyBundleDef.findPropertyDefByName('ssoCredentials')\"\n" +
    "                                   property-value=\"ctrlr.config.propertyBundle.findPropertyValueByName('ssoCredentials')\"\n" +
    "                                   default-name=\"ctrlr.config.propertyBundle.findPropertyValueByName('name')\">\n" +
    "            </edge-property-control>\n" +
    "        </div>\n" +
    "        <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                               property-def=\"::ctrlr.config.propertyBundleDef.findPropertyDefByName('useProxy')\"\n" +
    "                               property-value=\"ctrlr.config.propertyBundle.findPropertyValueByName('useProxy')\">\n" +
    "        </edge-property-control>\n" +
    "        <div ng-if=\"ctrlr.config.propertyBundle.findPropertyValueByName('useProxy').value\">\n" +
    "            <edge-property-control ng-repeat=\"propertyDef in ::ctrlr.proxySetting\"\n" +
    "                                   class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                                   property-value=\"ctrlr.config.propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "            </edge-property-control>\n" +
    "\n" +
    "            <div ng-if=\"ctrlr.config.propertyBundle.findPropertyValueByName('proxySsoHandlerType').value !== 'None'\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ctrlr.config.propertyBundleDef.findPropertyDefByName('proxySsoCredentials')\"\n" +
    "                                       property-value=\"ctrlr.config.propertyBundle.findPropertyValueByName('proxySsoCredentials')\"\n" +
    "                                       default-name=\"ctrlr.config.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <edge-dialog-footer>\n" +
    "            <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "                <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\"><span translate>Cancel</span></button>\n" +
    "                <button class=\"btn btn-success\"\n" +
    "                        ng-click=\"ctrlr.handleSave()\"\n" +
    "                        ng-disabled=\"endpointEditForm.$invalid\"><span translate>OK</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-dialog-footer>\n" +
    "    </form>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/failover-connect-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/failover-connect-wizard.tpl.html",
    "<div ng-controller=\"FailoverConnectionWizardController as ConnectWizardCtrlr\" ng-init=\"ConnectWizardCtrlr.init()\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"true\" dialog-mode=\"true\" on-save=\"ConnectWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ConnectWizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Default Name'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"1\"  validate=\"ConnectWizardCtrlr.validateConfig()\">\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form name=\"connectionConfig\" class=\"form-horizontal\" style=\"padding-right:20px;\">\n" +
    "                <h4 class=\"top\" translate>Connection Details</h4>\n" +
    "                <edge-property-editor config=\"ConnectWizardCtrlr.propertyEditorConfig\"></edge-property-editor>\n" +
    "                <h4 class=\"top\" translate>Failover</h4>\n" +
    "                <edge-labeled-control label-width=\"4\" label=\"{{::'Enable Failover'|translate}}\">\n" +
    "                    <input type='checkbox' ng-model='ConnectWizardCtrlr.failoverEnabled' edge-boolean-switch>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Endpoints'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"2\" >\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form ng-if=\"ConnectWizardCtrlr.failoverEnabled === false\" name=\"connectionConfig\" style=\"padding-right:20px;\">\n" +
    "                <edge-labeled-control label-width=\"4\" label=\"{{::'Enable Endpoint'|translate}}\">\n" +
    "                    <input type='checkbox' ng-model='ConnectWizardCtrlr.endpointConfigBundles[0].enabled' edge-boolean-switch>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-property-editor config=\"ConnectWizardCtrlr.endpointConfigBundles[0].editorConfig\"></edge-property-editor>\n" +
    "            </form>\n" +
    "            <edge-panel ng-if=\"ConnectWizardCtrlr.failoverEnabled === true\">\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-2\">\n" +
    "                            <label translate style=\"padding-left:20px\">Enable</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-2\">\n" +
    "                            <label translate style=\"padding-left:20px\">Name</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-8\">\n" +
    "                            <label translate style=\"padding-left:20px\">Connection Info</label>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list selected-item=\"ConnectWizardCtrlr.endpointSelected\"\n" +
    "                               type=\"reorderable\"\n" +
    "                               items=\"ConnectWizardCtrlr.endpointConfigBundles\">\n" +
    "                        <edge-connection-endpoint-def config=\"item\"></edge-connection-endpoint-def>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <button title=\"{{'Add Entry' | translate}}\"\n" +
    "                            class=\"btn btn-default icon icon_plus\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.addEntry()\"></button>\n" +
    "                    <button class=\"btn btn-default\"\n" +
    "                            title=\"{{'Edit Selected' | translate}}\"\n" +
    "                            ng-disabled=\"!ConnectWizardCtrlr.endpointSelected\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.editEntry()\"><i class=\"btn_icon icon icon_pencil\"></i></button>\n" +
    "                    <button class=\"btn btn-default\"\n" +
    "                            title=\"{{'Clone Selected' | translate}}\"\n" +
    "                            ng-disabled=\"!ConnectWizardCtrlr.endpointSelected\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.cloneEntry()\"><i class=\"btn_icon icon icon_copy\"></i></button>\n" +
    "                    <button class=\"btn btn-danger\"\n" +
    "                            title=\"{{'Delete Selected' | translate}}\"\n" +
    "                            ng-disabled=\"ConnectWizardCtrlr.endpointSelected==null || ConnectWizardCtrlr.connection.endpoints.length==1\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.removeEntry()\"><i class=\"btn_icon icon icon_trash\"></i></button>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Test Connection'|translate}}\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.testConnect()\" index=\"3\">\n" +
    "            <div block-ui=\"connectionTest\" style=\"height: 100%\">\n" +
    "                <div class=\"alert alert-success\" ng-if=\"ConnectWizardCtrlr.isTestSuccessful() && ConnectWizardCtrlr.anyEndpointsToTest()\"\n" +
    "                     translate>Connection test was successful.\n" +
    "                </div>\n" +
    "                <div class=\"alert alert-warning\" ng-if=\"!ConnectWizardCtrlr.anyEndpointsToTest()\"\n" +
    "                     translate>No endpoint was enabled to test.\n" +
    "                </div>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.isTestFailed()\">\n" +
    "                    <div class=\"alert alert-danger\"><b translate>Connection test failed.</b><br><br>\n" +
    "                        <span translate>Server Response:</span>\n" +
    "                        <div class=\"well well-sm\">\n" +
    "                            <div ng-repeat=\"result in ConnectWizardCtrlr.testResults track by $index\">\n" +
    "                                <span ng-if='result.extraDetail != null && result.serverResponse != \"\"'>{{'endpoint '+($index+1)+' \"'+ConnectWizardCtrlr.connection.endpoints[$index].name+'\" : '+ result.serverResponse}}</span>\n" +
    "                            </div>\n" +
    "                                <a class=\"pull-right\"\n" +
    "                                   ng-if=\"ConnectWizardCtrlr.getExtraDetail()\"\n" +
    "                                   ng-init=\"ConnectWizardCtrlr.showExtraDetail = false\"\n" +
    "                                   ng-click=\"ConnectWizardCtrlr.showExtraDetail = !ConnectWizardCtrlr.showExtraDetail\">More Info</a>\n" +
    "                                <div class=\"clearfix\"></div>\n" +
    "                                <span ng-if=\"ConnectWizardCtrlr.showExtraDetail\">\n" +
    "                                <div ng-repeat=\"result in ConnectWizardCtrlr.testResults track by $index\">\n" +
    "                                    <span ng-if='result.extraDetail != null && result.extraDetail != \"\"'>{{'endpoint '+($index+1)+' \"'+ConnectWizardCtrlr.connection.endpoints[$index].name+'\" : '+ result.extraDetail}}</span>\n" +
    "                                </div>\n" +
    "                                </span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <br><span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "                <div ng-if=\"!ConnectWizardCtrlr.anyEndpointsToTest()\">\n" +
    "                    <span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/proxy-connect-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/proxy-connect-wizard.tpl.html",
    "<div ng-controller=\"ProxyConnectionWizardController as ConnectWizardCtrlr\" ng-init=\"ConnectWizardCtrlr.init()\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"true\" dialog-mode=\"true\" on-save=\"ConnectWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ConnectWizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Connection Details'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"1\" validate=\"ConnectWizardCtrlr.validateConfiguration()\">\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form ng-if=\"ConnectWizardCtrlr.configReady\" name=\"connectionConfig\" class=\"form-horizontal\">\n" +
    "                <edge-property-control ng-repeat=\"propertyDef in ::ConnectWizardCtrlr.normalSetting\"\n" +
    "                    class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                    property-value=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName('ssoHandlerType').value !== 'None'\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                        property-def=\"::ConnectWizardCtrlr.propertyBundleDef.findPropertyDefByName('ssoCredentials')\"\n" +
    "                        property-value=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName('ssoCredentials')\"\n" +
    "                        default-name=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                    property-def=\"::ConnectWizardCtrlr.propertyBundleDef.findPropertyDefByName('useProxy')\"\n" +
    "                    property-value=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName('useProxy')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName('useProxy').value\">\n" +
    "                    <edge-property-control ng-repeat=\"propertyDef in ::ConnectWizardCtrlr.proxySetting\"\n" +
    "                        class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                        property-value=\"ConnectWizardCtrlr.propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Test Connection'|translate}}\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.testConnection()\" index=\"2\">\n" +
    "            <div block-ui=\"connectionTest\" style=\"height: 100%\">\n" +
    "                <div class=\"alert alert-success\" ng-if=\"ConnectWizardCtrlr.connectionTestSuccessful\"\n" +
    "                     translate>Connection test was successful.\n" +
    "                </div>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.connectionTestFailed\">\n" +
    "                    <div class=\"alert alert-danger\"><b translate>Connection test failed.</b><br><br>\n" +
    "                        <span translate>Server Response:</span>\n" +
    "                        <div class=\"well well-sm\">{{ConnectWizardCtrlr.serverResponse}} <br>\n" +
    "                            <a class=\"pull-right\"\n" +
    "                               ng-if=\"ConnectWizardCtrlr.extraDetail\"\n" +
    "                               ng-init=\"ConnectWizardCtrlr.showExtraDetail = false\"\n" +
    "                               ng-click=\"ConnectWizardCtrlr.showExtraDetail = !ConnectWizardCtrlr.showExtraDetail\">More Info</a>\n" +
    "                            <div class=\"clearfix\"></div>\n" +
    "                            <span ng-if=\"ConnectWizardCtrlr.showExtraDetail\"><br>{{ConnectWizardCtrlr.extraDetail}}</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/connect/proxy-failover-connect-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/connect/proxy-failover-connect-wizard.tpl.html",
    "<div ng-controller=\"ProxyFailoverConnectionWizardController as ConnectWizardCtrlr\" ng-init=\"ConnectWizardCtrlr.init()\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"true\" dialog-mode=\"true\" on-save=\"ConnectWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ConnectWizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Default Name'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"1\"  validate=\"ConnectWizardCtrlr.validateConfig()\">\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form ng-if=\"ConnectWizardCtrlr.configReady\" name=\"connectionConfig\" class=\"form-horizontal\" style=\"padding-right:20px;\">\n" +
    "                <h4 class=\"top\" translate>Connection Details</h4>\n" +
    "                <edge-property-editor config=\"ConnectWizardCtrlr.propertyEditorConfig\"></edge-property-editor>\n" +
    "                <h4 class=\"top\" translate>Failover</h4>\n" +
    "                <edge-labeled-control label-width=\"4\" label=\"{{::'Enable Failover'|translate}}\">\n" +
    "                    <input type='checkbox' ng-model='ConnectWizardCtrlr.failoverEnabled' edge-boolean-switch>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Endpoints'|translate}}\" use-form-validation=\"connectionConfig\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.doNameCheck = true\"\n" +
    "                          index=\"2\" >\n" +
    "            <div ng-if=\"ConnectWizardCtrlr.wasDisabledForLicensing\" class=\"alert alert-warning\">\n" +
    "                <span translate>This connection has been disabled due to licensing.  Disable another connection of the same type, or update the product license.</span>\n" +
    "            </div>\n" +
    "            <form ng-if=\"ConnectWizardCtrlr.configReady && ConnectWizardCtrlr.failoverEnabled === false\" name=\"connectionConfig\" class=\"form-horizontal\" style=\"padding-right:20px;\">\n" +
    "                <edge-labeled-control label-width=\"3\" label=\"{{::'Enable Endpoint'|translate}}\">\n" +
    "                    <input type='checkbox' ng-model='ConnectWizardCtrlr.endpointConfigBundles[0].enabled' edge-boolean-switch>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-property-control ng-repeat=\"propertyDef in ::ConnectWizardCtrlr.normalSetting\"\n" +
    "                                       class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                                       property-value=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('ssoHandlerType').value !== 'None'\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundleDef.findPropertyDefByName('ssoCredentials')\"\n" +
    "                                           property-value=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('ssoCredentials')\"\n" +
    "                                           default-name=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('name')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundleDef.findPropertyDefByName('useProxy')\"\n" +
    "                                       property-value=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('useProxy')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('useProxy').value\">\n" +
    "                    <edge-property-control ng-repeat=\"propertyDef in ::ConnectWizardCtrlr.proxySetting\"\n" +
    "                                           class=\"col-sm-12\" validation=\"true\" label-width=\"3\" property-def=\"::propertyDef\"\n" +
    "                                           property-value=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName(propertyDef.name)\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('proxySsoHandlerType').value !== 'None'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                               property-def=\"::ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundleDef.findPropertyDefByName('proxySsoCredentials')\"\n" +
    "                                               property-value=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('proxySsoCredentials')\"\n" +
    "                                               default-name=\"ConnectWizardCtrlr.endpointConfigBundles[0].propertyBundle.findPropertyValueByName('name')\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "            <edge-panel ng-if=\"ConnectWizardCtrlr.failoverEnabled === true\">\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-2\">\n" +
    "                            <label translate style=\"padding-left:20px\">Enable</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-2\">\n" +
    "                            <label translate style=\"padding-left:20px\">Name</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-8\">\n" +
    "                            <label translate style=\"padding-left:20px\">Connection Info</label>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list selected-item=\"ConnectWizardCtrlr.endpointSelected\"\n" +
    "                               type=\"reorderable\"\n" +
    "                               items=\"ConnectWizardCtrlr.endpointConfigBundles\">\n" +
    "                        <edge-connection-endpoint-def config=\"item\"></edge-connection-endpoint-def>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <button title=\"{{'Add Entry' | translate}}\"\n" +
    "                            class=\"btn btn-default icon icon_plus\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.addEntry()\"></button>\n" +
    "                    <button class=\"btn btn-default\"\n" +
    "                            title=\"{{'Edit Selected' | translate}}\"\n" +
    "                            ng-disabled=\"!ConnectWizardCtrlr.endpointSelected\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.editEntry()\"><i class=\"btn_icon icon icon_pencil\"></i></button>\n" +
    "                    <button class=\"btn btn-default\"\n" +
    "                            title=\"{{'Clone Selected' | translate}}\"\n" +
    "                            ng-disabled=\"!ConnectWizardCtrlr.endpointSelected\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.cloneEntry()\"><i class=\"btn_icon icon icon_copy\"></i></button>\n" +
    "                    <button class=\"btn btn-danger\"\n" +
    "                            title=\"{{'Delete Selected' | translate}}\"\n" +
    "                            ng-disabled=\"ConnectWizardCtrlr.endpointSelected==null || ConnectWizardCtrlr.connection.endpoints.length==1\"\n" +
    "                            ng-click=\"ConnectWizardCtrlr.removeEntry()\"><i class=\"btn_icon icon icon_trash\"></i></button>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Test Connection'|translate}}\"\n" +
    "                          on-show=\"ConnectWizardCtrlr.testConnect()\" index=\"3\">\n" +
    "            <div block-ui=\"connectionTest\" style=\"height: 100%\">\n" +
    "                <div class=\"alert alert-success\" ng-if=\"ConnectWizardCtrlr.isTestSuccessful() && ConnectWizardCtrlr.anyEndpointsToTest()\"\n" +
    "                     translate>Connection test was successful.\n" +
    "                </div>\n" +
    "                <div class=\"alert alert-warning\" ng-if=\"!ConnectWizardCtrlr.anyEndpointsToTest()\"\n" +
    "                     translate>No endpoint was enabled to test.\n" +
    "                </div>\n" +
    "                <div ng-if=\"ConnectWizardCtrlr.isTestFailed()\">\n" +
    "                    <div class=\"alert alert-danger\"><b translate>Connection test failed.</b><br><br>\n" +
    "                        <span translate>Server Response:</span>\n" +
    "                        <div class=\"well well-sm\">\n" +
    "                            <div ng-repeat=\"result in ConnectWizardCtrlr.testResults track by $index\">\n" +
    "                                <span ng-if='result.extraDetail != null && result.serverResponse != \"\"'>{{'endpoint '+($index+1)+' \"'+ConnectWizardCtrlr.connection.endpoints[$index].name+'\" : '+ result.serverResponse}}</span>\n" +
    "                            </div>\n" +
    "                                <a class=\"pull-right\"\n" +
    "                                   ng-if=\"ConnectWizardCtrlr.getExtraDetail()\"\n" +
    "                                   ng-init=\"ConnectWizardCtrlr.showExtraDetail = false\"\n" +
    "                                   ng-click=\"ConnectWizardCtrlr.showExtraDetail = !ConnectWizardCtrlr.showExtraDetail\">More Info</a>\n" +
    "                                <div class=\"clearfix\"></div>\n" +
    "                                <span ng-if=\"ConnectWizardCtrlr.showExtraDetail\">\n" +
    "                                <div ng-repeat=\"result in ConnectWizardCtrlr.testResults track by $index\">\n" +
    "                                    <span ng-if='result.extraDetail != null && result.extraDetail != \"\"'>{{'endpoint '+($index+1)+' \"'+ConnectWizardCtrlr.connection.endpoints[$index].name+'\" : '+ result.extraDetail}}</span>\n" +
    "                                </div>\n" +
    "                                </span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <br><span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "                <div ng-if=\"!ConnectWizardCtrlr.anyEndpointsToTest()\">\n" +
    "                    <span translate>Would you like to save the connection anyway?</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/ChooseConsumerType.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/ChooseConsumerType.tpl.html",
    "<div class=\"list-group visChooser\">\n" +
    "    <a href ng-repeat=\"type in ctrlr.consumerTypes | orderBy:'displayName'\" class=\"list-group-item visChooserListItem\" ng-click=\"ctrlr.selectedType = type;dialogRef.close()\" ng-class=\"{odd:$odd}\">\n" +
    "        <table style=\"table-layout:fixed;\">\n" +
    "            <tr>\n" +
    "                <td rowspan=\"2\" valign=\"middle\" align=\"center\">\n" +
    "                    <img width=32 height=32 ng-src=\"{{ctrlr.getConsumerIcon(type)}}\">\n" +
    "                </td>\n" +
    "                <td class=\"visChooserDisplayName\">\n" +
    "                    <h5>{{type.displayName}}</h5>\n" +
    "                </td>\n" +
    "                <td rowspan=\"2\" valign=\"middle\" align=\"center\">\n" +
    "                    <span ng-if=\"type.name == ctrlr.defaultConsumerTypeName\" class=\"label label-info\" translate>default</span>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "            <tr>\n" +
    "                <td class=\"visChooserTypeDescription\">{{type.description}}</td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </a>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/consumer-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/consumer-wizard.tpl.html",
    "<div ng-controller=\"ConsumerWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!WizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\" sidebar-size=\".2\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure'|translate}}\" index=\"0\" use-form-validation=\"config\"\n" +
    "                          validate=\"WizardCtrlr.validateConfiguration()\">\n" +
    "            <form name=\"config\">\n" +
    "                <edge-property-editor ng-if=\"WizardCtrlr.propertyEditorConfig\"\n" +
    "                                      config=\"WizardCtrlr.propertyEditorConfig\"></edge-property-editor>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Attributes DB Options'|translate}}\" index=\"1\" class=\"edgeFlexColumn\">\n" +
    "            <form name=\"attributes\" ng-disabled=\"! WizardCtrlr.baseStepValidState.valid\" style=\"height: 100%\">\n" +
    "            <edge-panel class=\"tableList\">\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div style=\"width: 100%\">\n" +
    "                        <div class=\"col-sm-4\">\n" +
    "                            <label translate style=\"padding-left:15px\">Attribute</label>\n" +
    "                        </div>\n" +
    "                        <!--\n" +
    "                        <div class=\"col-sm-4\" style=\"padding-left:10px\">\n" +
    "                            <label translate>Primary Key</label>\n" +
    "                        </div>\n" +
    "                        -->\n" +
    "                        <div class=\"col-sm-4\">\n" +
    "                            <label translate>Indexing On</label>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"WizardCtrlr.selectedAttributes\">\n" +
    "                        <div class=\"row with-padding\">\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <input type=\"string\" class=\"form-control\" ng-disabled=\"true\" ng-model=\"item.attributeName\">\n" +
    "                            </div>\n" +
    "                            <!--\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <edge-check-box ng-model=\"item.primaryKey\"></edge-check-box>\n" +
    "                            </div>\n" +
    "                            -->\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <edge-check-box ng-model=\"item.indexingOn\"></edge-check-box>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "            </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Data Preview'|translate}}\" index=\"2\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"WizardCtrlr\" has-data-error=\"! WizardCtrlr.baseStepValidState.valid\"></edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"WizardCtrlr.editParameters()\" translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/datapreview/columnTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/datapreview/columnTemplate.tpl.html",
    "<div\n" +
    "        role=\"columnheader\"\n" +
    "        ng-class=\"{ 'sortable': sortable }\"\n" +
    "        class=\"edgeDataPreviewColumnHeader\"\n" +
    "        ui-grid-one-bind-aria-labelledby-grid=\"col.uid + '-header-text ' + col.uid + '-sortdir-text'\"\n" +
    "        aria-sort=\"{{col.sort.direction == asc ? 'ascending' : ( col.sort.direction == desc ? 'descending' : (!col.sort.direction ? 'none' : 'other'))}}\">\n" +
    "    <div\n" +
    "            role=\"button\"\n" +
    "            tabindex=\"0\"\n" +
    "            class=\"ui-grid-cell-contents ui-grid-header-cell-primary-focus\"\n" +
    "            col-index=\"renderIndex\"\n" +
    "            title=\"TOOLTIP\">\n" +
    "\n" +
    "        <table>\n" +
    "            <tr>\n" +
    "                <td class=\"edgeDataPreviewColumnName\" colspan=\"2\">\n" +
    "                    <span>{{ col.displayName CUSTOM_FILTERS }}</span>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "            <tr>\n" +
    "                <td style=\"width:100%;\">\n" +
    "                    <span class=\"edgeDataPreviewDataType\">{{col.colDef.dataType}}</span>\n" +
    "                </td>\n" +
    "                <td style=\"text-align:right;\">\n" +
    "                    <span ui-grid-one-bind-id-grid=\"col.uid + '-sortdir-text'\"\n" +
    "                          ui-grid-visible=\"col.sort.direction\"\n" +
    "                          aria-label=\"{{getSortDirectionAriaLabel()}}\">\n" +
    "                          <i\n" +
    "                                  ng-class=\"{ 'ui-grid-icon-up-dir': col.sort.direction == asc, 'ui-grid-icon-down-dir': col.sort.direction == desc, 'ui-grid-icon-blank': !col.sort.direction }\"\n" +
    "                                  title=\"{{isSortPriorityVisible() ? i18n.headerCell.priority + ' ' + ( col.sort.priority + 1 )  : null}}\"\n" +
    "                                  aria-hidden=\"true\">\n" +
    "                         </i>\n" +
    "                         <sub\n" +
    "                                 ui-grid-visible=\"isSortPriorityVisible()\"\n" +
    "                                 class=\"ui-grid-sort-priority-number\">\n" +
    "                           {{col.sort.priority + 1}}\n" +
    "                         </sub>\n" +
    "                    </span>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <div ui-grid-filter></div>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreview.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreview.tpl.html",
    "<div class=\"row\" style=\"height:calc(100% + 60px);margin:-30px -35px -30px -30px\">\n" +
    "    <edge-split-pane value=\"tdpCtrlr.splitValue\"\n" +
    "                     horizontal=\"false\" enable-divider=\"tdpCtrlr.splitValue > 0\"\n" +
    "                     resize-listener=\"tdpCtrlr.debouncedResizeCallback()\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <h4><span translate>Variables</span>&nbsp;\n" +
    "                <small>\n" +
    "                    <small>(<a href ng-click=\"tdpCtrlr.editParameters()\"><span translate>manage</span></a>)\n" +
    "                    </small>\n" +
    "                </small>\n" +
    "            </h4>\n" +
    "            <form name=\"params\">\n" +
    "                <edge-params-list-editor style=\"padding:10px;\" wizard-ctrlr=\"tdpCtrlr.consumerWizardController\">\n" +
    "                </edge-params-list-editor>\n" +
    "                <div ng-if=\"tdpCtrlr.consumerWizardController.constructDO.parameterAssertions.length > 0\"\n" +
    "                     style=\"padding:6px;\">\n" +
    "                    <h4 translate>Upstream Variables</h4>\n" +
    "                    <edge-param-asserts-list-editor wizard-ctrlr=\"tdpCtrlr.consumerWizardController\"></edge-param-asserts-list-editor>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "            <div class=\"btn-toolbar\" ng-if=\"tdpCtrlr.consumerWizardController.constructDO.parameters.length > 0 && hasDataError !== true\">\n" +
    "                <button class=\"btn btn-default pull-right\" style=\"margin-right:10px\" ng-click=\"tdpCtrlr.onShow(true)\">\n" +
    "                    <span translate>Apply to Preview</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view style=\"overflow: hidden\">\n" +
    "            <div ng-if=\"hasDataError !== true\" block-ui=\"consumerDataPreview\" style=\"height: 100%\">\n" +
    "                <div ng-if=\"tdpCtrlr.previewGridOptions.data.length > 0\" style=\"height: 100%\">\n" +
    "                    <div ng-show=\"tdpCtrlr.previewGridReady\" style=\"height: 100%\"\n" +
    "                         class=\"previewgrid consumergrid\"\n" +
    "                         ui-grid=\"tdpCtrlr.previewGridOptions\"\n" +
    "                         ui-grid-resize-columns></div>\n" +
    "                </div>\n" +
    "                <div ng-if=\"tdpCtrlr.noPreviewDataAvailable\" style=\"height: 100%; display: flex; align-items: center;\">\n" +
    "                    <div class=\"alert alert-warning\" style=\"margin: 0 auto\" translate>No data was returned from the server. Please check the configuration if this is unexpected.</div>\n" +
    "                </div>\n" +
    "                <div ng-if=\"tdpCtrlr.previewResultErrorMessage\" style=\"height: 100%; display: flex; align-items: center;\">\n" +
    "                    <div class=\"alert alert-danger\" style=\"margin: 0 auto\" ng-bind-html=\"tdpCtrlr.previewResultErrorMessage\"></div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-if=\"hasDataError === true\" style=\"height: 100%; display: flex; align-items: center;\">\n" +
    "                <div class=\"alert alert-warning\" style=\"margin: 0 auto\" translate>\n" +
    "                    No data preview is possible.\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreviewTable.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/datapreview/edgeTabularDataPreviewTable.tpl.html",
    "<div>\n" +
    "    <style>\n" +
    "        .dataPreviewGrid .ui-grid-render-container {\n" +
    "            border: 0px;\n" +
    "        }\n" +
    "    </style>\n" +
    "    <div class=\"dataPreviewGrid\" ui-grid=\"previewGridOptions\" ui-grid-resize-columns></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeFileChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeFileChooser.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-if=\"files.length > 0\" ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match placeholder=\"{{'Choose a file...'|translate}}\">{{$select.selected}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item in files | orderBy:'+' | filter: $select.search\">\n" +
    "        <div class=\"row\" ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "<div ng-if=\"files.length === 0\" class=\"alert alert-warning\" style=\"margin-top: 0px\">\n" +
    "    <span translate>No files have been found given the connection details defined on this pipeline.</span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeParamAssertsListEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeParamAssertsListEditor.tpl.html",
    "<div class=\"form-group\" ng-repeat=\"assert in wizardCtrlr.constructDO.parameterAssertions\">\n" +
    "    <label for=\"{{assert.id}}\">{{assert.producerName+assert.upstreamParameterName}}</label>\n" +
    "    <input class=\"form-control\" type=\"text\" id=\"{{assert.id}}\" ng-model=\"assert.value\">\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeParamControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeParamControl.tpl.html",
    "<div class=\"form-group\">\n" +
    "    <div class=\"row\" ng-if=\"readonly !== true\">\n" +
    "        <label>{{param.parameterName}}</label><a ng-if=\"::$root.isAdmin\" href class=\"pull-right\"\n" +
    "                                                 ng-click=\"modifyParam(param)\"><i class=\"icon icon_wrench text-warning\"></i></a>\n" +
    "        <a ng-if=\"::$root.isAdmin\" href class=\"pull-right\" title=\"{{::'Delete Variable' | translate}}\"\n" +
    "           ng-click=\"deleteParameter(param)\"><i class=\"icon icon_trash text-danger\"></i></a>\n" +
    "    </div>\n" +
    "    <div ng-if=\"! hide\" class=\"row\" ng-switch=\"inputInfo.type\">\n" +
    "        <div ng-switch-when=\"Number\">\n" +
    "            <edge-labeled-control label-width=\"0\" validation=\"true\" style=\"margin-bottom: 0\" element-name=\"{{::param.id}}\">\n" +
    "                <!-- dummy input to prevent edge label control error when adding a new number parameter\n" +
    "            constraint -->\n" +
    "                <input type=\"hidden\" name=\"sp{{param.id}}\" ng-model=\"param.defaultValue\" ng-required=\"true\">\n" +
    "                <edge-number-spinner inputname=\"{{::param.id}}\" ng-model=\"param.defaultValue\" isrequired=\"true\"\n" +
    "                    placeholder=\"{{inputInfo.spinner.placeholder}}\"\n" +
    "                    reload=\"inputInfo.spinner.reload\"\n" +
    "                    step=\"inputInfo.spinner.interval\" minimum=\"inputInfo.spinner.min\"\n" +
    "                    maximum=\"inputInfo.spinner.max\" >\n" +
    "                </edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"Combo\">\n" +
    "            <edge-labeled-control label-width=\"0\" validation=\"true\" style=\"margin-bottom: 0\">\n" +
    "                <input type=\"hidden\" name=\"cm{{param.id}}\" ng-model=\"param.defaultValue\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"param.defaultValue\" theme=\"bootstrap\">\n" +
    "                    <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item.value as item in inputInfo.choices | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"::item.label | highlightHtmlSafe: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"Buttons\">\n" +
    "            <div class=\"btn-group\" role=\"group\">\n" +
    "                <button type=\"button\" ng-repeat=\"item in inputInfo.choices\" class=\"btn btn-default\" ng-class=\"{'btn-primary':param.defaultValue == item.value}\" ng-click=\"param.defaultValue = item.value\">{{item.label}}</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-switch-default>\n" +
    "            <edge-labeled-control label-width=\"0\" validation=\"true\" style=\"margin-bottom: 0\">\n" +
    "                <input type=\"text\" name=\"st{{param.id}}\" class=\"form-control\" ng-model=\"param.defaultValue\" ng-trim=\"false\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeParamsListEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeParamsListEditor.tpl.html",
    "<edge-param-control ng-repeat=\"param in wizardCtrlr.constructDO.parameters\">\n" +
    "</edge-param-control>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeProducersChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeProducersChooser.tpl.html",
    "<style>\n" +
    ".{{::className}} {\n" +
    "    background-color: transparent;\n" +
    "}\n" +
    "</style>\n" +
    "<div class=\"input-group\">\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\" ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <ui-select ng-if=\"::vm.multiple\" multiple ng-model=\"vm.values\" theme=\"bootstrap\">\n" +
    "        <ui-select-match>{{$item.name}}\n" +
    "        </ui-select-match>\n" +
    "        <ui-select-choices repeat=\"producer in producers | orderBy:'name' | filter: {name: $select.search} track by producer.id\">\n" +
    "            <span ng-bind-html=\"producer.name | highlight: $select.search\"></span>\n" +
    "            <small class=\"pull-right\" ng-bind-html=\"producer.typeName\"></small>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "    <span class=\"input-group-addon btn btn-default {{::className}}\" ng-click=\"insertProducer()\" translate>Add Dataset</span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/edgeSecVarsChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/edgeSecVarsChooser.tpl.html",
    "<style>\n" +
    ".{{::className}} {\n" +
    "    background-color: transparent;\n" +
    "}\n" +
    "</style>\n" +
    "<div class=\"input-group\">\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\" ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <ui-select ng-if=\"::vm.multiple\" multiple ng-model=\"vm.values\" theme=\"bootstrap\">\n" +
    "        <ui-select-match>{{$item.parameterName}}\n" +
    "        </ui-select-match>\n" +
    "        <ui-select-choices repeat=\"secVar in globalSecVars | orderBy:'parameterName' | filter: {parameterName: $select.search} track by secVar.parameterName\">\n" +
    "            <span ng-bind-html=\"secVar.parameterName | highlight: $select.search\"></span>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "    <span class=\"input-group-addon btn btn-default {{::className}}\" ng-click=\"insertSecVar()\" translate>Add Secured Variable</span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/flowmodel/edgeRmMetaAttributeEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/flowmodel/edgeRmMetaAttributeEditor.tpl.html",
    "<div>\n" +
    "    <div class=\"col-sm-4\">\n" +
    "        <select class=\"form-control\"\n" +
    "                ng-model=\"metaAttribute.aggregation\"\n" +
    "                ng-options=\"aggr.value as aggr.label for aggr in aggregationTypes\"></select>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-8\" ng-if=\"metaAttribute.aggregation != 'COUNT'\">\n" +
    "        <ui-select ng-if=\"attributes.length > 0\"\n" +
    "            ng-model=\"metaAttribute.attributeName\" theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "            <ui-select-match placeholder=\"{{::'Choose a column...'|translate}}\">{{$select.selected.name}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item.name as item in ::attributes | orderBy: 'name' | filter: $select.search\">\n" +
    "                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "        <div ng-if=\"attributes.length === 0\" class=\"alert alert-warning\">\n" +
    "            <span translate>Parent data producer does not have any columns with numeric data.</span>\n" +
    "        </div>\n" +
    "        <div ng-if=\"attributes === undefined\" class=\"form-control\" ng-bind-html=\"metaAttribute.attributeName\"></div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/flowmodel/edit-node-value-aggregation-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/flowmodel/edit-node-value-aggregation-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\">\n" +
    "    <form name=\"addLinkDefForm\" style=\"padding:10px\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\">\n" +
    "                <span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\" ng-disabled=\"addLinkDefForm.$invalid\" ng-click=\"ctrlr.handleSave()\">\n" +
    "                <span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/flowmodel/flowmodel-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/flowmodel/flowmodel-wizard.tpl.html",
    "<div ng-controller=\"FlowModelWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!WizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\" index=\"0\" use-form-validation=\"nodeconfig\" validate=\"WizardCtrlr.validateConfigureStep()\" style=\"height:100%\">\n" +
    "            <form name=\"nodeconfig\" class=\"form-horizontal\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                    property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "            <form class=\"form-horizontal\" ng-disabled=\"! WizardCtrlr.hasData\" style=\"height:calc(100% - 50px)\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-heading\">\n" +
    "                            <label translate>Column</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-body\">\n" +
    "                            <edge-list items=\"WizardCtrlr.columnDefs\"\n" +
    "                                selected-item=\"WizardCtrlr.selectedColumnDef\" type=\"reorderable\" unique-property=\"id\">\n" +
    "                                <div ng-if=\"listScope.WizardCtrlr.hasData\" class=\"col-sm-12 with-padding\">\n" +
    "                                    <ui-select ng-model=\"item.idAttrName\" theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "                                        <ui-select-match allow-clear=\"false\"\n" +
    "                                                         placeholder=\"{{::'Choose a column...'|translate}}\">{{$select.selected.name}}\n" +
    "                                        </ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"item.name as item in ::listScope.WizardCtrlr.dataAttributes | orderBy: 'name' | filter: $select.search\">\n" +
    "                                            <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                            <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                </div>\n" +
    "                                <div ng-if=\"! listScope.WizardCtrlr.hasData\" class=\"col-sm-12 with-padding\">\n" +
    "                                    <div class=\"form-control\" ng-bind-html=\"item.idAttrName\"></div>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <div class=\"btn-group\">\n" +
    "                                <button class=\"btn btn-success\" ng-click=\"WizardCtrlr.addColumnDef()\">\n" +
    "                                    <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                                </button>\n" +
    "                                <button class=\"btn btn-danger\" ng-click=\"WizardCtrlr.removeColumnDef()\"\n" +
    "                                    ng-disabled=\"!WizardCtrlr.selectedColumnDef || WizardCtrlr.columnDefs.length < 3\">\n" +
    "                                    <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-heading\">\n" +
    "                            <label translate>Link Value Aggregation</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-body\">\n" +
    "                            <edge-list items=\"WizardCtrlr.linkMetaAttrs\"\n" +
    "                                       selected-item=\"WizardCtrlr.selectedLinkMetaAttr\">\n" +
    "                                <div class=\"row\">\n" +
    "                                    <div class=\"col-sm-12 with-padding\">\n" +
    "                                        <edge-rm-meta-attribute-editor meta-attribute=\"item\" attributes=\"::listScope.WizardCtrlr.numericDataAttributes\"></edge-rm-meta-attribute-editor>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <div class=\"btn-group\">\n" +
    "                                <button class=\"btn btn-success\" ng-click=\"WizardCtrlr.addLinkMetaAttr()\">\n" +
    "                                    <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                                </button>\n" +
    "                                <button class=\"btn btn-danger\" ng-click=\"WizardCtrlr.removeLinkMetaAttr()\"\n" +
    "                                    ng-disabled=\"!WizardCtrlr.selectedLinkMetaAttr || WizardCtrlr.linkMetaAttrs.length < 2\">\n" +
    "                                    <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Variables' | translate}}\"\n" +
    "                          index=\"2\"\n" +
    "                          use-form-validation=\"params\"\n" +
    "                          on-show=\"WizardCtrlr.fetchTestData()\">\n" +
    "            <div class=\"row\" style=\"height:100%\">\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <h4><span translate>Variables</span>&nbsp;\n" +
    "                        <small>\n" +
    "                            <small>(<a href ng-click=\"WizardCtrlr.editParameters()\"><span translate>manage</span></a>)\n" +
    "                            </small>\n" +
    "                        </small>\n" +
    "                    </h4>\n" +
    "                    <form name=\"params\">\n" +
    "                        <edge-params-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-params-list-editor>\n" +
    "                        <div ng-if=\"WizardCtrlr.constructDO.parameterAssertions.length > 0\">\n" +
    "                            <h4 translate>Upstream Variables</h4>\n" +
    "                            <edge-param-asserts-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-param-asserts-list-editor>\n" +
    "                        </div>\n" +
    "                    </form>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length > 0\">\n" +
    "                        <button class=\"btn btn-default pull-right\" ng-click=\"WizardCtrlr.fetchTestData()\">\n" +
    "                            <span translate>Apply to Preview</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length == 0\">\n" +
    "                        <div class=\"alert alert-info\">\n" +
    "                            <span translate>There are no variables on this pipeline at this time.</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-9\" style=\"padding-left: 20px;\">\n" +
    "                    <h4 translate>Model Preview</h4>\n" +
    "                    <edge-preview-graph style=\"height:95%\"\n" +
    "                                        nodes=\"WizardCtrlr.previewGraphNodes\"\n" +
    "                                        links=\"WizardCtrlr.previewGraphLinks\"\n" +
    "                                        digraph=\"true\">\n" +
    "                    </edge-preview-graph>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/date2LongTypeEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/date2LongTypeEditor.tpl.html",
    "<form name=\"dateParserForm\" class=\"form-horizontal\">\n" +
    "    <edge-labeled-control style=\"clear: both;\" label=\"{{::'Long Format'|translate}}\" label-width=\"3\">\n" +
    "        <ui-select theme=\"bootstrap\" ng-model=\"Controller.attribute.optionalModifier\">\n" +
    "            <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "            <ui-select-choices repeat=\"field.value as field in (Controller.formats | filter: {label: $select.search})\">\n" +
    "                <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/edgeGUISelectTypeEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/edgeGUISelectTypeEditor.tpl.html",
    "<form name=\"dateParserForm\" class=\"form-horizontal\">\n" +
    "    <edge-labeled-control label-width=\"3\" label=\"{{::'Sample Record'|translate}}\">\n" +
    "        <input type=\"text\" class=\"form-control\" disabled ng-value=\"::Controller.attribute.sampleData\">\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label-width=\"3\" label=\"{{::'Parsed Result'|translate}}\" ng-class=\"Controller.parseTest()\">\n" +
    "        <input type=\"text\" class=\"form-control\" disabled ng-value=\"Controller.epochTimeResult\">\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"! Controller.timeSignature.isEpochTime || Controller.isCustomFormat()\" label=\"{{::'Time Zone'|translate}}\" label-width=\"3\" helptext=\"{{::'Select a timezone where the date is in. If no value is entered, GMT will be assumed.'|translate}}\">\n" +
    "        <ui-select theme=\"bootstrap\" ng-model=\"Controller.elucidator.timezone\">\n" +
    "            <ui-select-match allow-clear=\"true\">{{$select.selected.value}}</ui-select-match>\n" +
    "            <ui-select-choices group-by=\"::'groupBy'\" repeat=\"field.value as field in (Controller.tz | filter: {label: $select.search})\">\n" +
    "                <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Date Format'|translate}}\" label-width=\"3\" helptext=\"{{::'Format syntax and examples can be found at <a href=\\'http://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html\\' target=\\'javaDateFormat\\'>DateTime Format</a>'|translate}}\">\n" +
    "        <ui-select theme=\"bootstrap\" ng-model=\"Controller.format\" on-select=\"Controller.formatSelected()\">\n" +
    "            <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "            <ui-select-choices repeat=\"field.value as field in (Controller.formats | filter: {label: $select.search})\">\n" +
    "                <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"Controller.isCustomFormat()\" style=\"margin-bottom: 0;\" label=\"{{::'Custom Format'|translate}}\" label-width=\"3\" helptext=\"{{::'Please enter a format for your date; syntax and examples can be found at <a href=\\'http://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html\\' target=\\'javaDateFormat\\'>DateTime Format</a>'|translate}}\">\n" +
    "        <input class=\"form-control\" type=\"text\" name=\"customFormat\" ng-model=\"Controller.elucidator.format\">\n" +
    "    </edge-labeled-control>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeConfig.tpl.html",
    "<div style=\"height:100%;\">\n" +
    "    <div ng-if=\"!Controller.skippedAttributesHandled\" style=\"height:100%;\" class=\"edgeFlexColumn\">\n" +
    "        <div class=\"alert alert-info\">\n" +
    "            <span translate>The following attributes were not auto added to this filter as they did not have valid values in the first record of the dataset.  Would you like to add any of them now?</span>\n" +
    "        </div>\n" +
    "        <edge-panel style=\"height:calc(100%)\">\n" +
    "            <edge-panel-header hide-label=\"true\">\n" +
    "                <div class=\"panel-heading-control pull-right\">\n" +
    "                    <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                        <input type=\"search\"\n" +
    "                               ng-model=\"Controller.q\"\n" +
    "                               class=\"form-control\"\n" +
    "                               placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-panel-header>\n" +
    "            <edge-panel-body>\n" +
    "                <edge-list items=\"Controller.skippedDataAttributes\"\n" +
    "                           q=\"{'name':Controller.q}\"\n" +
    "                           multiple=\"true\"\n" +
    "                           selected-items=\"Controller.selectedSkippedDataAttributes\">\n" +
    "                    <div style=\"padding:5px;\">{{item.name}}</div>\n" +
    "                </edge-list>\n" +
    "            </edge-panel-body>\n" +
    "            <edge-panel-footer>\n" +
    "                <button class=\"btn btn-default\" ng-click=\"Controller.skippedAttributesHandled = true\">\n" +
    "                    <span translate>No Thanks</span></button>\n" +
    "                <button class=\"btn btn-default\" ng-click=\"Controller.addAllSkippedAttributes()\">\n" +
    "                    <span translate>Add All</span></button>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-click=\"Controller.addSelectedSkippedAttributes()\"><span translate>Add Selected</span>\n" +
    "                </button>\n" +
    "            </edge-panel-footer>\n" +
    "        </edge-panel>\n" +
    "    </div>\n" +
    "    <edge-panel ng-if=\"Controller.skippedAttributesHandled\">\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <label translate style=\"padding-left:15px\">Original Attribute</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-2\">\n" +
    "                    <label translate style=\"padding-left:20px\">Sample</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <label translate style=\"padding-left:10px\">New Attribute Name</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-2\" style=\"padding-left:10px\">\n" +
    "                    <label translate>Data Type</label>\n" +
    "                </div>\n" +
    "                <!--\n" +
    "                <div class=\"col-sm-1\">\n" +
    "                    <label translate>Primary Key</label>\n" +
    "                </div>\n" +
    "                -->\n" +
    "                <div class=\"col-sm-1\">\n" +
    "                    <label translate>Indexing On</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body>\n" +
    "            <edge-list selected-items=\"Controller.selectedItems\"\n" +
    "                       multiple=\"true\"\n" +
    "                       type=\"reorderable\"\n" +
    "                       items=\"Controller.attributes.selectedAttributeList\">\n" +
    "                <edge-select-attribute-def config=\"item\"\n" +
    "                                           controller=\"::listScope.Controller\"></edge-select-attribute-def>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button type=\"button\"\n" +
    "                    class=\"btn btn-default icon icon_plus\"\n" +
    "                    ng-click=\"Controller.addRow()\"\n" +
    "                    ng-attr-title=\"{{::'Add attribute' | translate}}\"></button>\n" +
    "            <button type=\"button\"\n" +
    "                    class=\"btn btn-default icon icon_minus\"\n" +
    "                    ng-click=\"Controller.removeSelectedRows()\"\n" +
    "                    ng-disabled=\"Controller.selectedItems.length == 0\"\n" +
    "                    ng-attr-title=\"{{::'Remove selected attributes' | translate}}\"></button>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/edgeSelectAttributeDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div ng-if=\"! controller.readonlyView\" class=\"row\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <ui-select ng-model=\"config.attributeName\" append-to-body=\"true\" class=\"small-select-font\"\n" +
    "                       on-select=\"controller.attributeSelected(config, $item)\" theme=\"bootstrap\">\n" +
    "                <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                <ui-select-choices style=\"width:200%;\"\n" +
    "                        repeat=\"dataAttribute.name as dataAttribute in controller.dataAttributes | filter: $select.search\">\n" +
    "                    <div>\n" +
    "                        <small class=\"pull-right\" ng-bind-html=\"::dataAttribute.typeAsString\"></small>\n" +
    "                        <span style=\"font-weight: bold;\" ng-bind-html=\"::dataAttribute.name | highlight: $select.search\"></span>\n" +
    "                    </div>\n" +
    "                    <small ng-if=\"::dataAttribute.sampleData\" style=\"font-style: italic; padding-left: 10px;\"><span translate>sample</span>: {{::dataAttribute.sampleData}}</small>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <div class=\"text\" title=\"{{config.sampleData}}\">{{config.sampleData}}</div>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <edge-labeled-control class=\"col-sm-12\" label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                <input class=\"form-control\" name=\"{{::inputName}}\" ng-model=\"config.newAttributeName\" ng-pattern=\"/^\\w*$/\" placeholder=\"{{config.defaultDBColumnName()}}\"></input>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <ui-select ng-model=\"config.attributeType\" append-to-body=\"true\" on-select=\"controller.typeSelected(config)\" class=\"small-select-font\" theme=\"bootstrap\">\n" +
    "                    <ui-select-match>{{$select.selected.label.toLowerCase()}}</ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"type.value as type in controller.types[config.originalAttributeType] | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"type.label.toLowerCase() | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "                <span ng-if=\"allowEditDate()\" class=\"input-group-btn\" style=\"padding-left:5px;vertical-align: bottom;\">\n" +
    "                   <button type=\"button\" class=\"form-control btn btn-default icon icon_pencil\"\n" +
    "                           ng-click=\"controller.editAttributeTypeDialog(config)\"></button>\n" +
    "                </span>\n" +
    "                <span ng-if=\"allowEditLong()\" class=\"input-group-btn\" style=\"padding-left:5px;vertical-align: bottom;\">\n" +
    "                   <button type=\"button\" class=\"form-control btn btn-default icon icon_pencil\"\n" +
    "                           ng-click=\"controller.editLongTypeDialog(config)\"></button>\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <!--\n" +
    "        <div class=\"col-sm-1\">\n" +
    "            <edge-check-box ng-model=\"config.primaryKey\"></edge-check-box>\n" +
    "        </div>\n" +
    "        -->\n" +
    "        <div class=\"col-sm-1\">\n" +
    "            <edge-check-box ng-model=\"config.indexingOn\"></edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div ng-if=\"controller.readonlyView\" class=\"row\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <input class=\"form-control\" ng-model=\"::config.attributeName\">\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <div class=\"text\"></div>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <input class=\"form-control\" ng-value=\"::config.defaultDBColumnName()\">\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <input class=\"form-control\" ng-model=\"::config.typeAsString\">\n" +
    "        </div>\n" +
    "        <!--\n" +
    "        <div class=\"col-sm-1\">\n" +
    "            <edge-check-box ng-model=\"config.primaryKey\"></edge-check-box>\n" +
    "        </div>\n" +
    "        -->\n" +
    "        <div class=\"col-sm-1\">\n" +
    "            <edge-check-box ng-model=\"::config.indexingOn\"></edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortConfig.tpl.html",
    "<div style=\"height:300px\">\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <label translate style=\"padding-left:15px\">Attribute Name</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <label translate style=\"padding-left:5px\">Sort</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body>\n" +
    "            <edge-list selected-item=\"Controller.selectedItem\" type=\"reorderable\" items=\"Controller.sort.sortedAttributeList\">\n" +
    "                <edge-select-sort-def config=\"item\" controller=\"listScope.Controller\"></edge-select-sort-def>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"Controller.addRow()\"></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"Controller.removeRow()\"\n" +
    "                    ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/edgeSelectSortDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <ui-select ng-model=\"config.attributeName\" append-to-body=\"true\" on-select=\"controller.attributeSelected(config, $item)\" class=\"small-select-font\">\n" +
    "                <ui-select-match>{{$select.selected.attributeName}}</ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"attribute.attributeName as attribute in controller.attributes | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"::attribute.attributeName | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <ui-select ng-model=\"config.sortScheme\" append-to-body=\"true\" class=\"small-select-font\">\n" +
    "                <ui-select-match>{{$select.selected.schemeDescription}}</ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"sortScheme in controller.getSortSchemes(config.type) | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"::sortScheme.schemeDescription | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/guiSelectConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/guiSelectConfigWizard.tpl.html",
    "<div ng-controller=\"GuiSelectWizardController as GuiSelectWizardWizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!GuiSelectWizardWizardCtrlr.isEdit\" dialog-mode=\"true\" sidebar-size=\".2\"\n" +
    "                 on-save=\"GuiSelectWizardWizardCtrlr.handleSave\" on-cancel=\"GuiSelectWizardWizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Config'|translate}}\" use-form-validation=\"config\" index=\"0\" validate=\"GuiSelectWizardWizardCtrlr.validateConfiguration()\">\n" +
    "            <form name=\"config\">\n" +
    "                <div class=\"form-horizontal\">\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GuiSelectWizardWizardCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                           property-value=\"GuiSelectWizardWizardCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                                           property-def=\"::GuiSelectWizardWizardCtrlr.propertyBundleDef.findPropertyDefByName('serverSubscribe')\"\n" +
    "                                           property-value=\"GuiSelectWizardWizardCtrlr.propertyBundle.findPropertyValueByName('serverSubscribe')\"></edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Attributes'|translate}}\" use-form-validation=\"select\"\n" +
    "                          validate=\"GuiSelectWizardWizardCtrlr.validateSelectConfig()\"\n" +
    "                          index=\"1\" class=\"edgeFlexColumn\">\n" +
    "            <form name=\"select\" class=\"form-horizontal tableList edgeFlexColumn\" style=\"height: 100%;\" ng-disabled=\"! GuiSelectWizardWizardCtrlr.hasData\">\n" +
    "                <edge-select-attribute-config></edge-select-attribute-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Filter'|translate}}\" use-form-validation=\"filter\" index=\"2\">\n" +
    "            <form name=\"filter\" class=\"form-horizontal\" ng-disabled=\"! GuiSelectWizardWizardCtrlr.hasData\">\n" +
    "                <edge-expression-builder\n" +
    "                                         group=\"GuiSelectWizardWizardCtrlr.expression.value\"\n" +
    "                                         data-sources=\"::GuiSelectWizardWizardCtrlr.dataAttributes\"></edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Row Limit and Sort'|translate}}\" use-form-validation=\"sort\" index=\"3\">\n" +
    "            <form name=\"sort\" class=\"form-horizontal tableList\" style=\"height: 100%;\" ng-disabled=\"! GuiSelectWizardWizardCtrlr.hasData\">\n" +
    "                <edge-labeled-control label-width=\"3\" label=\"{{::'Row Limit?'|translate}}\" style=\"margin-bottom: 15px;\"\n" +
    "                    helptext=\"{{::GuiSelectWizardWizardCtrlr.propertyBundleDef.findPropertyDefByName('limit').helpText}}\" element-name=\"setRowLimit\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch name=\"setRowLimit\" ng-model=\"GuiSelectWizardWizardCtrlr.setRowLimit\">\n" +
    "                </edge-labeled-control>\n" +
    "                <div ng-if=\"GuiSelectWizardWizardCtrlr.propertyBundle.findPropertyValueByName('limit').value !== 0\">\n" +
    "                    <div class=\"col-sm-3\"></div>\n" +
    "                    <edge-property-control validation=\"true\" class=\"col-sm-9\" label-width=\"0\" style=\"margin-bottom: 20px;\"\n" +
    "                        property-def=\"::GuiSelectWizardWizardCtrlr.propertyBundleDef.findPropertyDefByName('limit')\"\n" +
    "                        property-value=\"GuiSelectWizardWizardCtrlr.propertyBundle.findPropertyValueByName('limit')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <edge-select-sort-config ng-if=\"GuiSelectWizardWizardCtrlr.attributes.value.selectedAttributeList.length > 0\"></edge-select-sort-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" index=\"4\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"GuiSelectWizardWizardCtrlr\" has-data-error=\"! GuiSelectWizardWizardCtrlr.hasData\">\n" +
    "            </edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-click=\"GuiSelectWizardWizardCtrlr.editParameters()\"\n" +
    "                        translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\" ng-if=\"GuiSelectWizardWizardCtrlr.$scope.WizardCtrlr.selectedStepIndex == 4\">\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-click=\"GuiSelectWizardWizardCtrlr.showSql()\"\n" +
    "                        ng-disabled=\"! GuiSelectWizardWizardCtrlr.hasData\"\n" +
    "                        translate>View SQL</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/guiselect/preview-sql-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/guiselect/preview-sql-dialog.tpl.html",
    "<div class=\"querystatement\">\n" +
    "    <textarea edge-codemirror options=\"{lineWrapping:true, backdrop:'text/x-mysql',mode:'edgeParsed',readOnly:true}\" ng-model=\"query\"></textarea>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/pipeline/consumer/json/edgeJsonAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/json/edgeJsonAttributeDef.tpl.html",
    "<div class=\"with-padding tableList\">\n" +
    "    <div ng-if=\"::(partial !== 'true')\" class=\"row\">\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <input class=\"form-control\" ng-disabled=\"true\" ng-model=\"attributeDef.attributeName\" title=\"{{attributeDef.attributeName}}\"></input>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <edge-labeled-control label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                <input class=\"form-control\" ng-model=\"attributeDef.newAttributeName\" name=\"{{newAttrName}}\" title=\"{{attributeDef.columnName}}\" placeholder=\"{{attributeDef.defaultDBColumnName()}}\" ng-pattern=\"/^[a-zA-Z0-9_]*$/\"></input>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <div class=\"text\" ng-bind=\"attributeDef.typeAsString\"></div>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <edge-check-box ng-model=\"attributeDef.indexingOn\"></edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div ng-if=\"::(partial === 'true')\" class=\"row\">\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <input class=\"form-control\" ng-disabled=\"true\" ng-model=\"attributeDef.attributeName\"></input>\n" +
    "        </div>\n" +
    "        <!--\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <edge-check-box ng-model=\"attributeDef.primaryKey\"></edge-check-box>\n" +
    "        </div>\n" +
    "        -->\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <edge-check-box ng-model=\"attributeDef.indexingOn\"></edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/json/edgeJsonPreview.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/json/edgeJsonPreview.tpl.html",
    "<div class=\"edgeJSONPreview\">\n" +
    "    <div ng-if=\"jsonPrevCtrlr.largeDataDetected\" class=\"alert alert-warning edgeJSONPreviewInfo\">\n" +
    "        <span translate>Syntax highlighting turned off due to large dataset</span>\n" +
    "    </div>\n" +
    "    <div ng-if=\"!jsonPrevCtrlr.largeDataDetected\" class=\"edgeJsonPreviewToolbar\">\n" +
    "        <label class=\"checkbox-inline\">\n" +
    "            <input type=\"checkbox\" ng-model=\"jsonPrevCtrlr.showTree\" ng-change=\"jsonPrevCtrlr.updateTreeShownState()\">\n" +
    "            <span translate>Show As Tree</span>\n" +
    "        </label>\n" +
    "    </div>\n" +
    "    <json-formatter ng-if=\"jsonPrevCtrlr.showTree || jsonPrevCtrlr.treeShown\" ng-show=\"jsonPrevCtrlr.showTree\" open=\"2\" json=\"jsonPrevCtrlr.jsonObject\" class=\"json-formatter\"></json-formatter>\n" +
    "    <pre ng-show=\"!jsonPrevCtrlr.showTree\" class=\"jsonPretty\"></pre>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/json/edgeJsonTreenode.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/json/edgeJsonTreenode.tpl.html",
    "<span style=\"display: flex\">\n" +
    "    <span ng-if=\"::selectable\" class=\"tree-check tree-icon\" ng-class=\"treeCtrlr.checkClass(columnKey)\" ng-click=\"treeCtrlr.updateCheckboxState($event, columnKey)\"></span>\n" +
    "    <span ng-if=\"::(! selectable && level === 1 && isExpandable)\" class=\"tree-check tree-icon locked\" ng-class=\"treeCtrlr.readonlyCheckClass(value)\"></span>\n" +
    "    <span ng-if=\"::(!isExpandable)\" style=\"display: flex; flex-basis: 100%;\">\n" +
    "        <span class=\"key\">{{::key}}</span>\n" +
    "        <span class=\"leaf-value\">{{::value}}</span>\n" +
    "    </span>\n" +
    "    <span ng-if=\"::isExpandable\" ng-click=\"toggleExpanded()\" style=\"display: flex; flex-basis: 100%; min-width: 0;\">\n" +
    "        <span class=\"key expandable\" ng-class=\"{'expanded':isExpanded}\">{{::key}}</span>\n" +
    "        <span ng-show=\"!isExpanded\" class=\"branch-preview\">{{::preview}}</span>\n" +
    "    </span>\n" +
    "</span>\n" +
    "<ul ng-if=\"isExpandable && shouldRender\" ng-show=\"isExpanded\" class=\"branch-value\">\n" +
    "    <li ng-repeat=\"valueKey in ::keys\">\n" +
    "        <json-node key=\"::valueKey\" value=\"::value[valueKey]\" object-sorted-keys=\"::objectSortedKeys\"></json-node>\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/json/json-feed-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/json/json-feed-wizard.tpl.html",
    "<div ng-controller=\"JSONFeedWizardController as JSONWizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!JSONWizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"JSONWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"JSONWizardCtrlr.handleCancel\" class=\"edge-performance-boost\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Configuration'|translate}}\" use-form-validation=\"parserConfig\"\n" +
    "                          validate=\"JSONWizardCtrlr.validateConfiguration()\" index=\"0\">\n" +
    "            <form name=\"parserConfig\" class=\"form-horizontal\" set-form-controller='JSONWizardCtrlr.setParserController'>\n" +
    "                <edge-streamer-wizard-step-config controller=\"JSONWizardCtrlr\"\n" +
    "                                                  streamer-type=\"JSONWizardCtrlr.streamerType\"></edge-streamer-wizard-step-config>\n" +
    "                <h4 translate>Data Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::JSONWizardCtrlr.propertyBundleDef.findPropertyDefByName('autoTyping')\"\n" +
    "                    property-value=\"JSONWizardCtrlr.propertyBundle.findPropertyValueByName('autoTyping')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'JSON Parser'|translate}}\" use-form-validation=\"parser\"\n" +
    "                          index=\"1\" validate=\"JSONWizardCtrlr.validateParser()\"\n" +
    "                          on-show=\"JSONWizardCtrlr.onShowParser()\">\n" +
    "            <form name=\"parser\" class=\"form-horizontal\" style=\"height:100%;\">\n" +
    "                <edge-labeled-control validation=\"true\" show-feedback-icon=\"false\"\n" +
    "                                      top-label=\"true\" label=\"{{::'JSON Path' | translate}}\"\n" +
    "                                      helptext=\"{{::JSONWizardCtrlr.getJsonPathHelpText()}}\">\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-body\" style=\"flex-basis: auto;\">\n" +
    "                            <textarea ng-required=\"true\"\n" +
    "                                      name=\"jsonPath\"\n" +
    "                                      ng-model=\"JSONWizardCtrlr.jsonPathProperty.value\"\n" +
    "                                      ng-pattern=\"JSONWizardCtrlr.jsonPathRegex\"\n" +
    "                                      class=\"form-control\"\n" +
    "                                      ng-change=\"JSONWizardCtrlr.needReparse = true\"\n" +
    "                                      style=\"border-width: 0;\"></textarea>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-click=\"JSONWizardCtrlr.handleTestBtn()\"\n" +
    "                                    ng-class=\"{'pulse':JSONWizardCtrlr.needReparse}\">\n" +
    "                                <span ng-if=\"JSONWizardCtrlr.needReparse\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"></span> <span translate>Test</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "\n" +
    "                <edge-labeled-control top-label=\"true\" label=\"{{::'JSON Data' | translate}}\"\n" +
    "                                      class=\"hundred-percent-height-label\" style=\"height: calc(100% - 150px);\">\n" +
    "                    <edge-panel on-init=\"JSONWizardCtrlr.previewPanelCreated()\" id=\"JSONPreviewPanel\">\n" +
    "                        <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                                <li class=\"active\">\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#raw\" id=\"rawTab\" style=\"margin-left: 10px; padding:7px 15px\">\n" +
    "                                        <span translate>Raw Data</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#query\" id=\"queryTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>JSON Path Results</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#flatten\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>Exposed Values</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <button class=\"btn btn-default btn-sm pull-right\"\n" +
    "                                        style=\"padding: 4px 10px; margin-right: 5px\"\n" +
    "                                        ng-if=\"!JSONWizardCtrlr.noRawDataAvailable\"\n" +
    "                                        ng-click=\"JSONWizardCtrlr.downloadRaw()\">\n" +
    "                                    <span class=\"icon icon_cloud_download\"></span> &nbsp;<span translate>Download Raw</span>\n" +
    "                                </button>\n" +
    "                            </ul>\n" +
    "                            <div ng-if=\"!JSONWizardCtrlr.noPreviewDataAvailable && JSONWizardCtrlr.activeTab === '#flatten'\"\n" +
    "                                 class=\"tableList\" style=\"padding: 3px 0 0 0;\">\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:5px\">New Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto;\">Type</label>\n" +
    "                                </div>\n" +
    "                                <!--\n" +
    "                                <div class=\"col-sm-1\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto; margin-left: -8px;\">Primary Key</label>\n" +
    "                                </div>\n" +
    "                                -->\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto; margin-left: -10px;\">Indexing On</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <div class=\"tab-content\" style=\"height:100%\">\n" +
    "                                <div id=\"raw\" class=\"tab-pane fade in active\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"JSONWizardCtrlr.showBusy && JSONWizardCtrlr.activeTab === '#raw'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"JSONWizardCtrlr.noRawDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!JSONWizardCtrlr.noRawDataAvailable\" style=\"height: 100%\">\n" +
    "                                        <edge-json-preview ugly-json-string=\"JSONWizardCtrlr.uglyRawDataString\"></edge-json-preview>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"query\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"JSONWizardCtrlr.showBusy && JSONWizardCtrlr.activeTab === '#query'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"JSONWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!JSONWizardCtrlr.noPreviewDataAvailable\" style=\"height: 100%\">\n" +
    "                                        <json-tree object=\"JSONWizardCtrlr.uglyPreviewDataString\" root-name=\"JSONWizardCtrlr.rootNodeTitle\" start-expanded=\"true\" all-columns=\"JSONWizardCtrlr.allAttributes\" shown-columns=\"JSONWizardCtrlr.shownAttributes\" first-level-columns=\"JSONWizardCtrlr.firstLevelAttributes\"></json-tree>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"flatten\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"JSONWizardCtrlr.showBusy && JSONWizardCtrlr.activeTab === '#flatten'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"JSONWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"!JSONWizardCtrlr.noPreviewDataAvailable\" style=\"height:100%\">\n" +
    "                                        <edge-list items=\"JSONWizardCtrlr.shownAttributes\">\n" +
    "                                            <edge-json-attribute-def attribute-def=\"item\"></edge-json-attribute-def>\n" +
    "                                        </edge-list>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-body>\n" +
    "                    </edge-panel>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Tabular Data Preview'|translate}}\" index=\"2\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"JSONWizardCtrlr\"></edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"JSONWizardCtrlr.editParameters()\" translate>\n" +
    "                    Manage Variables\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/relmodel/add-linkdef-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/relmodel/add-linkdef-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\" ng-controller=\"AddLinkDefDialogController as ctrlr\">\n" +
    "    <form name=\"addLinkDefForm\" style=\"padding:10px\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-5\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-labeled-control label=\"{{::'Source Data Set'|translate}}\"\n" +
    "                                              top-label=\"true\"\n" +
    "                                              validation=\"true\"\n" +
    "                                              element-name=\"selectedSourceProducer\">\n" +
    "                   <span class=\"input-group-btn\">\n" +
    "                     <button type=\"button\" class=\"btn btn-default form-control\" ng-disabled=\"true\"\n" +
    "                             ng-click=\"ctrlr.showSourceProducerChooserDialog()\">\n" +
    "                         <span class=\"pull-left\">{{ctrlr.selectedSourceProducer.title}}</span>\n" +
    "                         <span class=\"icon icon_caret_right pull-right\"></span>\n" +
    "                     </button>\n" +
    "                       <input type=\"hidden\"\n" +
    "                              name=\"selectedSourceProducer\"\n" +
    "                              ng-model=\"ctrlr.selectedSourceProducer\"\n" +
    "                              ng-required=\"true\">\n" +
    "                   </span>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-labeled-control label-width=\"0\" validation=\"true\"\n" +
    "                                              element-name=\"selectedSourceProducerAttr\">\n" +
    "                            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                            <input type=hidden\n" +
    "                                   name=\"selectedSourceProducerAttr\"\n" +
    "                                   ng-model=\"ctrlr.selectedSourceProducerAttr\"\n" +
    "                                   ng-required=\"true\">\n" +
    "                            <ui-select ng-diabled=\"!ctrlr.selectedSourceProducer\"\n" +
    "                                       ng-model=\"ctrlr.selectedSourceProducerAttr\"\n" +
    "                                       theme=\"bootstrap\">\n" +
    "                                <ui-select-match allow-clear=\"true\"\n" +
    "                                                 placeholder=\"{{'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item.name as item in ctrlr.sourceAttributeDefs | orderBy: 'name' | filter: {name: $select.search}\">\n" +
    "                                    <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                    <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-2\">\n" +
    "                    <div style=\"text-align:center; position:relative; top: 72px;\">\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"ctrlr.toggleDirection()\">\n" +
    "                            <i ng-class=\"ctrlr.directionalIcon\" class=\"icon\"></i>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-5\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-labeled-control label=\"{{::'Target Data Set'|translate}}\"\n" +
    "                                              top-label=\"true\"\n" +
    "                                              validation=\"true\"\n" +
    "                                              element-name=\"selectedTargetProducer\">\n" +
    "                   <span class=\"input-group-btn\">\n" +
    "                     <button type=\"button\" class=\"btn btn-default form-control\" ng-disabled=\"ctrlr.lockTargetProducer\"\n" +
    "                             ng-click=\"ctrlr.showTargetProducerChooserDialog()\">\n" +
    "                         <span class=\"pull-left\">{{ctrlr.selectedTargetProducer.title}}</span>\n" +
    "                         <span class=\"icon icon_caret_right pull-right\"></span>\n" +
    "                     </button>\n" +
    "                      <input type=\"hidden\"\n" +
    "                             name=\"selectedTargetProducer\"\n" +
    "                             ng-model=\"ctrlr.selectedTargetProducer\"\n" +
    "                             ng-required=\"true\">\n" +
    "\n" +
    "                   </span>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-labeled-control label-width=\"0\" validation=\"true\"\n" +
    "                                              element-name=\"selectedTargetProducerAttr\">\n" +
    "                            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                            <input type=hidden\n" +
    "                                   name=\"selectedTargetProducerAttr\"\n" +
    "                                   ng-model=\"ctrlr.selectedTargetProducerAttr\"\n" +
    "                                   ng-required=\"true\">\n" +
    "                            <ui-select ng-diabled=\"!ctrlr.selectedTargetProducer\"\n" +
    "                                       ng-model=\"ctrlr.selectedTargetProducerAttr\"\n" +
    "                                       theme=\"bootstrap\">\n" +
    "                                <ui-select-match allow-clear=\"true\"\n" +
    "                                                 placeholder=\"{{'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item.name as item in ctrlr.targetAttributeDefs | orderBy: 'name' | filter: {name: $select.search}\">\n" +
    "                                    <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                    <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\">\n" +
    "                <span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\" ng-disabled=\"addLinkDefForm.$invalid\" ng-click=\"ctrlr.handleSave()\">\n" +
    "                <span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/relmodel/relmodel-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/relmodel/relmodel-wizard.tpl.html",
    "<div ng-controller=\"RelModelWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!WizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\"\n" +
    "                          index=\"0\"\n" +
    "                          use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%;\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                    property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "                <div class=\"panel panel-default\" style=\"height:calc(100% - 40px)\">\n" +
    "                    <div class=\"panel-heading\">\n" +
    "                        <div class=\"panel-title\" translate>Link Definitions</div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-body\">\n" +
    "                        <edge-pipes options=\"WizardCtrlr.pipesOptions\" selected-node=\"WizardCtrlr.selectedNode\" style=\"overflow: hidden;\"></edge-pipes>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-footer\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <!--\n" +
    "                            <button class=\"btn btn-success\" ng-click=\"WizardCtrlr.addLinkDef()\">\n" +
    "                                <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                            </button>\n" +
    "                            -->\n" +
    "                            <button class=\"btn btn-warning\" ng-click=\"WizardCtrlr.handleEdit()\"\n" +
    "                                ng-disabled=\"!WizardCtrlr.selectedLinkDef\">\n" +
    "                                <i class=\"btn_icon icon icon_pencil\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-danger\" ng-click=\"WizardCtrlr.handleDelete()\"\n" +
    "                                ng-disabled=\"!WizardCtrlr.selectedLinkDef && !WizardCtrlr.selectedNodeDef\">\n" +
    "                                <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Reachability Options' | translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          use-form-validation=\"reachoptions\">\n" +
    "            <form class=\"form-horizontal\" name=\"reachoptions\">\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                                           property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('limitReachability')\"\n" +
    "                                           property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('limitReachability')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"WizardCtrlr.limitReachability\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-property-control label-width=\"4\"\n" +
    "                                               property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('linealNodes')\"\n" +
    "                                               property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('linealNodes')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div class=\"row\" ng-if=\"!WizardCtrlr.useUpDown\">\n" +
    "                        <edge-property-control label-width=\"4\"\n" +
    "                                               property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('hopsTotal')\"\n" +
    "                                               property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('hopsTotal')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-property-control label-width=\"4\"\n" +
    "                                               property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('useUpDown')\"\n" +
    "                                               property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('useUpDown')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"WizardCtrlr.useUpDown\">\n" +
    "                        <div class=\"row\">\n" +
    "                            <edge-property-control label-width=\"4\"\n" +
    "                                                   property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('hopsUp')\"\n" +
    "                                                   property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('hopsUp')\"></edge-property-control>\n" +
    "                        </div>\n" +
    "                        <div class=\"row\">\n" +
    "                            <edge-property-control label-width=\"4\"\n" +
    "                                                   property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('hopsDown')\"\n" +
    "                                                   property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('hopsDown')\"></edge-property-control>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Variables' | translate}}\"\n" +
    "                          index=\"2\"\n" +
    "                          use-form-validation=\"params\"\n" +
    "                          on-show=\"WizardCtrlr.fetchTestData()\">\n" +
    "            <div class=\"row\" style=\"height:100%\">\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <h4><span translate>Variables</span>&nbsp;\n" +
    "                        <small>\n" +
    "                            <small>(<a href ng-click=\"WizardCtrlr.editParameters()\"><span translate>manage</span></a>)\n" +
    "                            </small>\n" +
    "                        </small>\n" +
    "                    </h4>\n" +
    "                    <form name=\"params\">\n" +
    "                        <edge-params-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-params-list-editor>\n" +
    "                        <div ng-if=\"WizardCtrlr.constructDO.parameterAssertions.length > 0\">\n" +
    "                            <h4 translate>Upstream Variables</h4>\n" +
    "                            <edge-param-asserts-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-param-asserts-list-editor>\n" +
    "                        </div>\n" +
    "                    </form>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length > 0\">\n" +
    "                        <button class=\"btn btn-default pull-right\" ng-click=\"WizardCtrlr.fetchTestData()\">\n" +
    "                            <span translate>Apply to Preview</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length == 0\">\n" +
    "                        <div class=\"alert alert-info\">\n" +
    "                            <span translate>There are no variables on this pipeline at this time.</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-9\" style=\"padding-left: 20px;\">\n" +
    "                    <h4 translate>Model Preview</h4>\n" +
    "                    <edge-preview-graph style=\"height:95%\"\n" +
    "                                        nodes=\"WizardCtrlr.previewGraphNodes\"\n" +
    "                                        links=\"WizardCtrlr.previewGraphLinks\">\n" +
    "                    </edge-preview-graph>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/streamers/file-streamer-config.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/streamers/file-streamer-config.tpl.html",
    "<div class=\"form-horizontal\">\n" +
    "    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "    <edge-labeled-control label=\"{{::controller.propertyBundleDef.findPropertyDefByName('file').displayName}}\"\n" +
    "                          validation=\"true\"\n" +
    "                          label-width=\"4\">\n" +
    "        <edge-file-chooser property-def=\"::controller.propertyBundleDef.findPropertyDefByName('file')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('file')\"></edge-file-chooser>\n" +
    "    </edge-labeled-control>\n" +
    "    <h4 translate>Refresh Details</h4>\n" +
    "    <hr>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('poll')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('poll')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('serverSubscribe')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('serverSubscribe')\"></edge-property-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/streamers/shell-streamer-config.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/streamers/shell-streamer-config.tpl.html",
    "<div class=\"form-horizontal\">\n" +
    "    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "    <edge-labeled-control label=\"{{::controller.propertyBundleDef.findPropertyDefByName('file').displayName}}\"\n" +
    "                          validation=\"true\"\n" +
    "                          label-width=\"4\">\n" +
    "        <edge-file-chooser property-def=\"::controller.propertyBundleDef.findPropertyDefByName('file')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('file')\"></edge-file-chooser>\n" +
    "    </edge-labeled-control>\n" +
    "    <h4 translate>Base Configuration</h4>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('params')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('params')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('stderrOption')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('stderrOption')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('environmentVars')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('environmentVars')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('useServerEnv')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('useServerEnv')\"></edge-property-control>\n" +
    "    <h4 translate>Refresh Details</h4>\n" +
    "    <hr>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('poll')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('poll')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('serverSubscribe')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('serverSubscribe')\"></edge-property-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/streamers/webdata-streamer-config.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/streamers/webdata-streamer-config.tpl.html",
    "<div class=\"form-horizontal\">\n" +
    "    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('start')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('start')\"></edge-property-control>\n" +
    "    <h4 translate>Base Configuration</h4>\n" +
    "    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('method')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('method')\"></edge-property-control>\n" +
    "    <edge-property-control validation=\"true\"\n" +
    "                           label-width=\"4\"\n" +
    "                           ng-if=\"['POST', 'PUT', 'PATCH'].indexOf(controller.propertyBundle.findPropertyValueByName('method').value) >= 0\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('postBody')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('postBody')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('headers')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('headers')\"></edge-property-control>\n" +
    "    <edge-labeled-control label=\"{{::controller.propertyBundleDef.findPropertyDefByName('rule').displayName}}\"\n" +
    "                          validation=\"true\"\n" +
    "                          label-width=\"4\">\n" +
    "        <edge-proxy-rule-chooser property-def=\"::controller.propertyBundleDef.findPropertyDefByName('rule')\"\n" +
    "                                 property-value=\"controller.propertyBundle.findPropertyValueByName('rule')\"></edge-proxy-rule-chooser>\n" +
    "    </edge-labeled-control>\n" +
    "    <!--<edge-property-control label-width=\"4\"-->\n" +
    "                           <!--property-def=\"::controller.propertyBundleDef.findPropertyDefByName('ssoScope')\"-->\n" +
    "                           <!--property-value=\"controller.propertyBundle.findPropertyValueByName('ssoScope')\"></edge-property-control>-->\n" +
    "    <!--<edge-property-control label-width=\"4\"-->\n" +
    "                           <!--ng-if=\"controller.propertyBundle.findPropertyValueByName('ssoScope').value == 'Feed'\"-->\n" +
    "                           <!--property-def=\"::controller.propertyBundleDef.findPropertyDefByName('ssoSpecifyCredentials')\"-->\n" +
    "                           <!--property-value=\"controller.propertyBundle.findPropertyValueByName('ssoSpecifyCredentials')\"></edge-property-control>-->\n" +
    "    <!--<edge-property-control label-width=\"4\"-->\n" +
    "                           <!--ng-if=\"controller.propertyBundle.findPropertyValueByName('ssoScope').value == 'Feed' && controller.propertyBundle.findPropertyValueByName('ssoSpecifyCredentials').value == true\"-->\n" +
    "                           <!--property-def=\"::controller.propertyBundleDef.findPropertyDefByName('ssoCredentials')\"-->\n" +
    "                           <!--property-value=\"controller.propertyBundle.findPropertyValueByName('ssoCredentials')\"></edge-property-control>-->\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('logging')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('logging')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           ng-if=\"controller.propertyBundle.findPropertyValueByName('logging').value == 'Debug'\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('verboselogging')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('verboselogging')\"></edge-property-control>\n" +
    "    <h4 translate>Refresh Details</h4>\n" +
    "    <hr>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('poll')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('poll')\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"4\"\n" +
    "                           property-def=\"::controller.propertyBundleDef.findPropertyDefByName('serverSubscribe')\"\n" +
    "                           property-value=\"controller.propertyBundle.findPropertyValueByName('serverSubscribe')\"></edge-property-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/treemapmodel/treemapmodel-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/treemapmodel/treemapmodel-wizard.tpl.html",
    "<div ng-controller=\"TreeMapModelWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!WizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\" index=\"0\" use-form-validation=\"nodeconfig\"\n" +
    "                          validate=\"WizardCtrlr.validateConfigureStep()\" style=\"height:100%\">\n" +
    "            <form name=\"nodeconfig\" class=\"form-horizontal\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::WizardCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"WizardCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "            <form class=\"form-horizontal\" ng-disabled=\"! WizardCtrlr.hasData\" style=\"height:calc(100% - 50px)\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-heading\">\n" +
    "                            <label translate>Tree Map Levels</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-body\">\n" +
    "                            <edge-list items=\"WizardCtrlr.columnDefs\"\n" +
    "                                       selected-item=\"WizardCtrlr.selectedColumnDef\" type=\"reorderable\">\n" +
    "                                <div class=\"with-padding\">\n" +
    "                                    <edge-labeled-control ng-if=\"listScope.WizardCtrlr.hasData\"\n" +
    "                                                          style=\"margin-bottom:0;\"\n" +
    "                                                          label=\"{{::'Label Field' | translate}}\" validation=\"false\">\n" +
    "                                        <ui-select ng-model=\"item.idAttrName\"\n" +
    "                                                   theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "                                            <ui-select-match allow-clear=\"false\"\n" +
    "                                                             placeholder=\"{{::'Choose a column...'|translate}}\">\n" +
    "                                                {{$select.selected.name}}\n" +
    "                                            </ui-select-match>\n" +
    "                                            <ui-select-choices\n" +
    "                                                    repeat=\"item.name as item in ::listScope.WizardCtrlr.dataAttributes | orderBy: 'name' | filter: $select.search\">\n" +
    "                                                <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                            </ui-select-choices>\n" +
    "                                        </ui-select>\n" +
    "                                    </edge-labeled-control>\n" +
    "                                    <div ng-if=\"! listScope.WizardCtrlr.hasData\" class=\"form-control\"\n" +
    "                                         ng-bind-html=\"item.idAttrName\"></div>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <div class=\"btn-group\">\n" +
    "                                <button class=\"btn btn-success\"\n" +
    "                                        ng-click=\"WizardCtrlr.addColumnDef()\"\n" +
    "                                        title=\"{{::'Add TreeMap Level' | translate}}\">\n" +
    "                                    <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                                </button>\n" +
    "                                <button class=\"btn btn-danger\" ng-click=\"WizardCtrlr.removeColumnDef()\"\n" +
    "                                        title=\"{{::'Remove Selected TreeMap Level' | translate}}\"\n" +
    "                                        ng-disabled=\"!WizardCtrlr.selectedColumnDef || WizardCtrlr.columnDefs.length < 3\">\n" +
    "                                    <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-heading\">\n" +
    "                            <label translate>Aggregated Values</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-body\">\n" +
    "                            <edge-list items=\"WizardCtrlr.selectedColumnDef.metaAttrs\"\n" +
    "                                       selected-item=\"WizardCtrlr.selectedMetaAttr\">\n" +
    "                                <div class=\"with-padding\">\n" +
    "                                    <edge-rm-meta-attribute-editor meta-attribute=\"item\"\n" +
    "                                                                   attributes=\"::listScope.WizardCtrlr.numericDataAttributes\">\n" +
    "                                    </edge-rm-meta-attribute-editor>\n" +
    "                                    <div class=\"clearfix\"></div>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <div class=\"btn-group\">\n" +
    "                                <button class=\"btn btn-success\"\n" +
    "                                        title=\"{{::'Add Aggregated Value' | translate}}\"\n" +
    "                                        ng-disabled=\"!WizardCtrlr.selectedColumnDef\"\n" +
    "                                        ng-click=\"WizardCtrlr.addMetaAttr()\">\n" +
    "                                    <i class=\"btn_icon icon icon_plus\"></i>\n" +
    "                                </button>\n" +
    "                                <button class=\"btn btn-danger\"\n" +
    "                                        ng-click=\"WizardCtrlr.removeMetaAttr()\"\n" +
    "                                        title=\"{{::'Remove Selected Aggregated Value' | translate}}\"\n" +
    "                                        ng-disabled=\"!WizardCtrlr.selectedMetaAttr || WizardCtrlr.selectedColumnDef.metaAttrs.length == 1\">\n" +
    "                                    <i class=\"btn_icon icon icon_trash\"></i>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "\n" +
    "                    </div>\n" +
    "\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Variables' | translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          use-form-validation=\"params\"\n" +
    "                          on-show=\"WizardCtrlr.fetchTestData()\">\n" +
    "            <div class=\"row\" style=\"height:100%\">\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <h4><span translate>Variables</span>&nbsp;\n" +
    "                        <small>\n" +
    "                            <small>(<a href ng-click=\"WizardCtrlr.editParameters()\"><span translate>manage</span></a>)\n" +
    "                            </small>\n" +
    "                        </small>\n" +
    "                    </h4>\n" +
    "                    <form name=\"params\">\n" +
    "                        <edge-params-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-params-list-editor>\n" +
    "                        <div ng-if=\"WizardCtrlr.constructDO.parameterAssertions.length > 0\">\n" +
    "                            <h4 translate>Upstream Variables</h4>\n" +
    "                            <edge-param-asserts-list-editor wizard-ctrlr=\"WizardCtrlr\"></edge-param-asserts-list-editor>\n" +
    "                        </div>\n" +
    "                    </form>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length > 0\">\n" +
    "                        <button class=\"btn btn-default pull-right\" ng-click=\"WizardCtrlr.fetchTestData()\">\n" +
    "                            <span translate>Apply to Preview</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-toolbar\" ng-if=\"WizardCtrlr.constructDO.parameters.length == 0\">\n" +
    "                        <div class=\"alert alert-info\">\n" +
    "                            <span translate>There are no variables on this pipeline at this time.</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-9\" style=\"padding-left: 20px;\">\n" +
    "                    <h4 translate>Model Preview</h4>\n" +
    "                    <edge-preview-graph style=\"height:95%\"\n" +
    "                                        nodes=\"WizardCtrlr.previewGraphNodes\"\n" +
    "                                        links=\"WizardCtrlr.previewGraphLinks\"\n" +
    "                                        digraph=\"true\">\n" +
    "                    </edge-preview-graph>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/xls/xls-feed-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/xls/xls-feed-wizard.tpl.html",
    "<div ng-controller=\"XLSFeedWizardController as XLSWizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!XLSWizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"XLSWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"XLSWizardCtrlr.handleCancel\" class=\"edge-performance-boost\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Configuration'|translate}}\" use-form-validation=\"config\" validate=\"XLSWizardCtrlr.validateConfiguration()\" index=\"0\">\n" +
    "            <form name=\"config\" set-form-controller='XLSWizardCtrlr.setParserController'>\n" +
    "                <edge-streamer-wizard-step-config controller=\"XLSWizardCtrlr\"\n" +
    "                                                  streamer-type=\"XLSWizardCtrlr.streamerType\"></edge-streamer-wizard-step-config>\n" +
    "                <div class=\"form-horizontal\">\n" +
    "                    <h4 translate>Data Options</h4>\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                                           property-def=\"::XLSWizardCtrlr.propertyBundleDef.findPropertyDefByName('evaluate')\"\n" +
    "                                           property-value=\"XLSWizardCtrlr.propertyBundle.findPropertyValueByName('evaluate')\"></edge-property-control>\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                                           property-def=\"::XLSWizardCtrlr.propertyBundleDef.findPropertyDefByName('types')\"\n" +
    "                                           property-value=\"XLSWizardCtrlr.propertyBundle.findPropertyValueByName('types')\"></edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Select XLS Sheet'|translate}}\"\n" +
    "                          index=\"1\" on-show=\"XLSWizardCtrlr.onShowParser()\">\n" +
    "            <form name=\"parser\" class=\"form-horizontal\" style=\"display: flex; flex-direction: column; height:100%;\">\n" +
    "                <edge-labeled-control style=\"flex-grow: 0;\" validation=\"true\" show-feedback-icon=\"false\"\n" +
    "                                      top-label=\"true\" label=\"{{::'Sheet Name' | translate}}\"\n" +
    "                                      helptext=\"{{::XLSWizardCtrlr.getXLSHelpText()}}\"\n" +
    "                                      element-name=\"xlsSheetSelect\">\n" +
    "                    <ui-select ng-model=\"XLSWizardCtrlr.sheetNameProperty.value\" theme=\"bootstrap\" on-select=\"XLSWizardCtrlr.updateAttributesList()\">\n" +
    "                        <ui-select-match placeholder=\"{{::'Sheet Name...'|translate}}\">{{$select.selected}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item in XLSWizardCtrlr.sheetList | orderBy:'+' | filter: $select.search\">\n" +
    "                            <div class=\"row\" ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-panel class=\"tableList\" style=\"flex-grow: 1;\">\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div style=\"width: 100%\">\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <label translate style=\"padding-left:15px\">Attribute</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <label translate>Indexing On</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <edge-list items=\"XLSWizardCtrlr.selectedAttributes\">\n" +
    "                            <div class=\"row with-padding\">\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <input type=\"string\" class=\"form-control\" ng-disabled=\"true\" ng-model=\"item.attributeName\">\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <edge-check-box ng-model=\"item.indexingOn\"></edge-check-box>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </edge-panel-body>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Tabular Data Preview'|translate}}\" index=\"2\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"XLSWizardCtrlr\"></edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"XLSWizardCtrlr.editParameters()\" translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/xml/edgeXmlTreenode.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/xml/edgeXmlTreenode.tpl.html",
    "<span style=\"display: flex\">\n" +
    "    <span ng-if=\"::selectable\" class=\"tree-check tree-icon\" ng-class=\"treeCtrlr.checkClass(columnKey, level, bypass)\" ng-click=\"treeCtrlr.updateCheckboxState($event, columnKey)\"></span>\n" +
    "    <span ng-if=\"::(! selectable && level > 0 && isExpandable)\" class=\"tree-check tree-icon locked\" ng-class=\"treeCtrlr.checkClass(columnKey, level, bypass)\"></span>\n" +
    "    <span ng-if=\"::(!isExpandable && !isAttribute)\" style=\"display: flex; flex-basis: 100%;\">\n" +
    "        <span class=\"key\">{{::value.nodeName}}</span>\n" +
    "        <span class=\"leaf-value\">{{::value.textContent}}</span>\n" +
    "    </span>\n" +
    "    <span ng-if=\"::(!isExpandable && isAttribute)\" style=\"display: flex; flex-basis: 100%;\">\n" +
    "        <span class=\"key\">@{{::value.nodeName}}</span>\n" +
    "        <span class=\"leaf-value\">{{::value.textContent}}</span>\n" +
    "    </span>\n" +
    "    <span ng-if=\"::isExpandable\" ng-click=\"toggleExpanded()\" style=\"display: flex; flex-basis: 100%; min-width: 0;\">\n" +
    "        <span class=\"key expandable\" ng-class=\"{'expanded':isExpanded}\">{{::(value.nodeName === \"_aaa_\" ? (\"Parsed Result\"|translate) : value.nodeName)}}</span>\n" +
    "    </span>\n" +
    "</span>\n" +
    "<ul ng-if=\"isExpandable && shouldRender\" ng-show=\"isExpanded\" class=\"branch-value\">\n" +
    "    <li ng-repeat=\"attribute in ::value.attributes\">\n" +
    "        <xml-node value=\"::attribute\" is-attribute=\"true\"></xml-node>\n" +
    "    </li>\n" +
    "    <li ng-repeat=\"node in ::nodes\">\n" +
    "        <xml-node value=\"::node\" is-attribute=\"false\"></xml-node>\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/xml/xml-feed-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/xml/xml-feed-wizard.tpl.html",
    "<div ng-controller=\"XMLFeedWizardController as XMLWizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!XMLWizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"XMLWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"XMLWizardCtrlr.handleCancel\" class=\"edge-performance-boost\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Configuration'|translate}}\" use-form-validation=\"config\" validate=\"XMLWizardCtrlr.validateConfiguration()\" index=\"0\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" set-form-controller='XMLWizardCtrlr.setParserController'>\n" +
    "                <edge-streamer-wizard-step-config controller=\"XMLWizardCtrlr\"\n" +
    "                                                  streamer-type=\"XMLWizardCtrlr.streamerType\"></edge-streamer-wizard-step-config>\n" +
    "                <h4 translate>Data Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::XMLWizardCtrlr.propertyBundleDef.findPropertyDefByName('autoTyping')\"\n" +
    "                    property-value=\"XMLWizardCtrlr.propertyBundle.findPropertyValueByName('autoTyping')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'XML XPath Parser'|translate}}\" use-form-validation=\"parser\"\n" +
    "                          index=\"1\" validate=\"XMLWizardCtrlr.validateParser()\"\n" +
    "                          on-show=\"XMLWizardCtrlr.onShowParser()\">\n" +
    "            <form name=\"parser\" class=\"form-horizontal\" style=\"height:100%;\">\n" +
    "                <edge-labeled-control validation=\"true\" show-feedback-icon=\"false\"\n" +
    "                                      top-label=\"true\" label=\"{{::'XPath' | translate}}\"\n" +
    "                                      helptext=\"{{::XMLWizardCtrlr.getXPathHelpText()}}\"\n" +
    "                                      >\n" +
    "                    <div class=\"panel panel-default\">\n" +
    "                        <div class=\"panel-body\" style=\"flex-basis: auto;\">\n" +
    "                            <textarea ng-required=\"true\"\n" +
    "                                      name=\"xpath\"\n" +
    "                                      ng-model=\"XMLWizardCtrlr.xpathProperty.value\"\n" +
    "                                      class=\"form-control\"\n" +
    "                                      ng-change=\"XMLWizardCtrlr.needReparse = true\"\n" +
    "                                      style=\"border-width: 0;\"></textarea>\n" +
    "                        </div>\n" +
    "                        <div class=\"panel-footer\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-click=\"XMLWizardCtrlr.handleTestBtn()\"\n" +
    "                                    ng-class=\"{'pulse':XMLWizardCtrlr.needReparse}\">\n" +
    "                                <span ng-if=\"XMLWizardCtrlr.needReparse\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"></span> <span translate>Test</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "\n" +
    "                <edge-labeled-control top-label=\"true\" label=\"{{::'XML Data' | translate}}\"\n" +
    "                                      class=\"hundred-percent-height-label\" style=\"height: calc(100% - 150px);\">\n" +
    "                    <edge-panel on-init=\"XMLWizardCtrlr.previewPanelCreated()\" id=\"XMLPreviewPanel\">\n" +
    "                        <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                                <li class=\"active\">\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#raw\" id=\"rawTab\" style=\"margin-left: 10px; padding:7px 15px\">\n" +
    "                                        <span translate>Raw Data</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#query\" id=\"queryTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>XPath Results</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#flatten\" id=\"flattenTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>Exposed Values</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <button class=\"btn btn-default btn-sm pull-right\" style=\"padding: 4px 10px; margin-right: 5px\" ng-if=\"!XMLWizardCtrlr.noRawDataAvailable\" ng-click=\"XMLWizardCtrlr.downloadRaw()\">\n" +
    "                                    <span class=\"icon icon_cloud_download\"></span> &nbsp;<span translate>Download Raw</span>\n" +
    "                                </button>\n" +
    "                            </ul>\n" +
    "                            <div ng-if=\"!XMLWizardCtrlr.noPreviewDataAvailable && XMLWizardCtrlr.activeTab === '#flatten'\" class=\"tableList\" style=\"padding: 3px 0 0 0\">\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:5px\">New Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto;\">Type</label>\n" +
    "                                </div>\n" +
    "                                <!--\n" +
    "                                <div class=\"col-sm-1\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto; margin-left: -8px;\">Primary Key</label>\n" +
    "                                </div>\n" +
    "                                -->\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto; margin-left: -10px;\">Indexing On</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <div class=\"tab-content\" style=\"height:100%\">\n" +
    "                                <div id=\"raw\" class=\"tab-pane fade in active\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLWizardCtrlr.showBusy && XMLWizardCtrlr.activeTab === '#raw'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLWizardCtrlr.noRawDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                        <div ng-bind-html=\"XMLWizardCtrlr.parsingError\"></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!XMLWizardCtrlr.noRawDataAvailable\" style=\"height:100%\">\n" +
    "                                        <textarea style=\"height:100%\" edge-codemirror options=\"{mode:'application/xml', readOnly:true, autoHeight:true}\" ng-model=\"XMLWizardCtrlr.uglyRawDataString\"></textarea>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"query\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLWizardCtrlr.showBusy && XMLWizardCtrlr.activeTab === '#query'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!XMLWizardCtrlr.noPreviewDataAvailable\" style=\"height:100%\">\n" +
    "                                        <xml-tree object=\"XMLWizardCtrlr.uglyPreviewDataString\" root-name=\"XMLWizardCtrlr.rootNodeTitle\" start-expanded=\"true\" all-columns=\"XMLWizardCtrlr.allAttributes\" shown-columns=\"XMLWizardCtrlr.shownAttributes\" first-level-columns=\"XMLWizardCtrlr.firstLevelAttributes\"></xml-tree>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"flatten\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLWizardCtrlr.showBusy && XMLWizardCtrlr.activeTab === '#flatten'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"!XMLWizardCtrlr.noPreviewDataAvailable\" style=\"height:100%\">\n" +
    "                                        <edge-list items=\"XMLWizardCtrlr.shownAttributes\">\n" +
    "                                            <edge-json-attribute-def attribute-def=\"item\"></edge-json-attribute-def>\n" +
    "                                        </edge-list>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-body>\n" +
    "                    </edge-panel>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Tabular Data Preview'|translate}}\" index=\"2\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"XMLWizardCtrlr\"></edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"XMLWizardCtrlr.editParameters()\" translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/consumer/xml/xslt/xml-xslt-feed-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/consumer/xml/xslt/xml-xslt-feed-wizard.tpl.html",
    "<div ng-controller=\"XMLXSLTFeedWizardController as XMLXSLTWizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!XMLXSLTWizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"XMLXSLTWizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"XMLXSLTWizardCtrlr.handleCancel\" class=\"edge-performance-boost\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Configuration'|translate}}\" use-form-validation=\"config\" validate=\"XMLXSLTWizardCtrlr.validateConfiguration()\" index=\"0\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" set-form-controller='XMLXSLTWizardCtrlr.setParserController'>\n" +
    "                <edge-streamer-wizard-step-config controller=\"XMLXSLTWizardCtrlr\"\n" +
    "                                                  streamer-type=\"XMLXSLTWizardCtrlr.streamerType\"></edge-streamer-wizard-step-config>\n" +
    "                <h4 translate>Data Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::XMLXSLTWizardCtrlr.propertyBundleDef.findPropertyDefByName('autoTyping')\"\n" +
    "                    property-value=\"XMLXSLTWizardCtrlr.propertyBundle.findPropertyValueByName('autoTyping')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'XML XSLT Parser'|translate}}\" use-form-validation=\"parser\"\n" +
    "                         validate=\"XMLXSLTWizardCtrlr.validateParser()\"\n" +
    "                          index=\"1\" on-show=\"XMLXSLTWizardCtrlr.onShowParser()\">\n" +
    "            <form name=\"parser\" class=\"form-horizontal\" style=\"height:100%;\">\n" +
    "                <edge-labeled-control validation=\"true\" show-feedback-icon=\"false\" style=\"height: 100%;\"\n" +
    "                                      top-label=\"true\" label=\"{{::'XML Data' | translate}}\"\n" +
    "                                      helptext=\"{{::XMLXSLTWizardCtrlr.getXSLTHelpText()}}\"\n" +
    "                                      class=\"hundred-percent-height-label\" element-name=\"xslt\">\n" +
    "                    <edge-panel on-init=\"XMLXSLTWizardCtrlr.previewPanelCreated()\" id=\"XMLPreviewPanel\">\n" +
    "                        <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                                <li class=\"active\">\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#raw\" style=\"margin-left: 10px; padding:7px 15px\">\n" +
    "                                        <span translate>Raw Data</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#xsltCode\" id=\"xsltCodeTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>XSLT</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#query\" id=\"queryTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>XSLT Results</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <li>\n" +
    "                                    <a data-toggle=\"tab\" data-target=\"#flatten\" id=\"flattenTab\" style=\"padding:7px 15px\">\n" +
    "                                        <span translate>Indexing</span>\n" +
    "                                    </a>\n" +
    "                                </li>\n" +
    "                                <button class=\"btn btn-default btn-sm pull-right\" style=\"padding: 4px 10px; margin-right: 5px\" ng-if=\"!XMLXSLTWizardCtrlr.noRawDataAvailable\" ng-click=\"XMLXSLTWizardCtrlr.downloadRaw()\">\n" +
    "                                    <span class=\"icon icon_cloud_download\"></span> &nbsp;<span translate>Download Raw</span>\n" +
    "                                </button>\n" +
    "                            </ul>\n" +
    "                            <div ng-if=\"!XMLXSLTWizardCtrlr.noPreviewDataAvailable && XMLXSLTWizardCtrlr.activeTab === '#flatten'\" class=\"tableList\" style=\"padding: 3px 0 0 0\">\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <!--\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto; margin-left: -8px;\">Primary Key</label>\n" +
    "                                </div>\n" +
    "                                -->\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate class=\"text\" style=\"padding:0; height: auto;\">Indexing On</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <div class=\"tab-content\" style=\"height:100%\">\n" +
    "                                <div id=\"raw\" class=\"tab-pane fade in active\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLXSLTWizardCtrlr.showBusy && XMLXSLTWizardCtrlr.activeTab === '#raw'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLXSLTWizardCtrlr.noRawDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                        <div ng-bind-html=\"XMLXSLTWizardCtrlr.rawParsingError\"></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!XMLXSLTWizardCtrlr.noRawDataAvailable\" style=\"height:100%\">\n" +
    "                                        <textarea style=\"height:100%\" edge-codemirror options=\"{mode:'application/xml', readOnly:true, autoHeight:true}\" ng-model=\"XMLXSLTWizardCtrlr.uglyRawDataString\"></textarea>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"xsltCode\" class=\"tab-pane fade\">\n" +
    "                                    <textarea style=\"height:100%\" edge-codemirror options=\"{mode:'application/xml', lineNumbers:true, autoHeight:true}\" ng-model=\"XMLXSLTWizardCtrlr.xsltProperty.value\" ng-required=\"true\" name=\"xslt\" ng-change=\"XMLXSLTWizardCtrlr.needReparse = true\"></textarea>\n" +
    "                                </div>\n" +
    "                                <div id=\"query\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLXSLTWizardCtrlr.showBusy && XMLXSLTWizardCtrlr.activeTab === '#query'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLXSLTWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                        <div ng-bind-html=\"XMLXSLTWizardCtrlr.parsingError\"></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!XMLXSLTWizardCtrlr.noPreviewDataAvailable\" style=\"height:100%\">\n" +
    "                                        <textarea edge-codemirror options=\"{mode:'application/xml', readOnly:true, autoHeight:true}\" ng-model=\"XMLXSLTWizardCtrlr.uglyPreviewDataString\"></textarea>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div id=\"flatten\" class=\"tab-pane fade\">\n" +
    "                                    <div class=\"edgeJSONPreviewBusyOverlay\" ng-if=\"XMLXSLTWizardCtrlr.showBusy && XMLXSLTWizardCtrlr.activeTab === '#flatten'\">\n" +
    "                                        <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                                            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "                                    </div>\n" +
    "                                    <div ng-if=\"XMLXSLTWizardCtrlr.noPreviewDataAvailable\"\n" +
    "                                         class=\"alert alert-danger\"\n" +
    "                                         style=\"margin-bottom: 0px;border-radius: 0px;\">\n" +
    "                                        <span translate>No data was returned from the server. Please check the configuration if this is unexpected.</span>\n" +
    "                                    </div>\n" +
    "                                    <div ng-show=\"!XMLXSLTWizardCtrlr.noPreviewDataAvailable\" style=\"height:100%\">\n" +
    "                                        <edge-list items=\"XMLXSLTWizardCtrlr.shownAttributes\">\n" +
    "                                            <edge-json-attribute-def attribute-def=\"item\" partial=\"true\"></edge-json-attribute-def>\n" +
    "                                        </edge-list>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer ng-if=\"XMLXSLTWizardCtrlr.activeTab === '#xsltCode'\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-click=\"XMLXSLTWizardCtrlr.handleTestBtn()\"\n" +
    "                                    ng-class=\"{'pulse':XMLXSLTWizardCtrlr.needReparse}\">\n" +
    "                                <span ng-if=\"XMLXSLTWizardCtrlr.needReparse\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"></span> <span translate>Test</span>\n" +
    "                            </button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Tabular Data Preview'|translate}}\" index=\"2\">\n" +
    "            <edge-tabular-data-preview consumer-wizard-controller=\"XMLXSLTWizardCtrlr\"></edge-tabular-data-preview>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"XMLXSLTWizardCtrlr.editParameters()\" translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/dialogs/CredentialsNeeded.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/dialogs/CredentialsNeeded.tpl.html",
    "<div class=\"alert alert-danger\" translate>The pipeline node could not be created or edited due to missing credentials.</div>\n" +
    "<h5 translate>The following credentials are missing:</h5>\n" +
    "<div class=\"well well-sm\">\n" +
    "    <div ng-repeat=\"(key, value) in error.result.MISSING_CREDENTIAL_NAMES\">\n" +
    "        {{value}}\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/dialogs/DataRetrievalError.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/dialogs/DataRetrievalError.tpl.html",
    "<div class=\"alert alert-danger\" translate>The pipeline node could not be created or edited due to an error retrieving data from the upstream pipeline.</div>\n" +
    "<div class=\"well well-sm\">\n" +
    "    <span translate>This problem may be a result of:</span>\n" +
    "    <ul>\n" +
    "        <li translate>Dependent server or connection is down</li>\n" +
    "        <li translate>Misconfigured parent connection, feed, or transform</li>\n" +
    "        <li translate>Invalid data or communication errors</li>\n" +
    "    </ul>\n" +
    "</div>");
}]);

angular.module("edge/core/admin/pipeline/dialogs/SaveFailed.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/dialogs/SaveFailed.tpl.html",
    "<div class=\"alert alert-danger\">\n" +
    "    <span translate>The</span> {{nodeType}} <span translate>could not be saved.</span>\n" +
    "    <br>\n" +
    "</div>\n" +
    "<span translate>Server Response:</span>\n" +
    "<div class=\"well well-sm\" ng-init=\"vm.showInfo = false\">{{serverResponse}}\n" +
    "    <br>\n" +
    "    <a class=\"pull-right\" ng-show=\"vm.showInfo == false\" ng-if=\"extraDetail || result\" ng-click=\"vm.showInfo = !vm.showInfo\" translate>More Info</a>\n" +
    "    <div class=\"clearfix\"></div>\n" +
    "    <span ng-if=\"vm.showInfo\"><br>{{extraDetail}}</span>\n" +
    "    <span ng-if=\"vm.showInfo\"><br>\n" +
    "        <span ng-repeat=\"(key, value) in result\">\n" +
    "            {{key}}:&nbsp;{{value}}\n" +
    "        </span>\n" +
    "    </span>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/dialogs/SecParamNeeded.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/dialogs/SecParamNeeded.tpl.html",
    "T<div class=\"alert alert-danger\" translate>The pipeline node could not be created or edited due to missing secured variables.</div>\n" +
    "<h5 translate>The following variables are missing:</h5>\n" +
    "<div class=\"well well-sm\">\n" +
    "    <div ng-repeat=\"(key, value) in error.result.MISSING_SECPARAM_NAMES\">\n" +
    "        {{value}}\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/edit-pipeline-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/edit-pipeline-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\" ng-controller=\"PipelineConfigController as ctrlr\">\n" +
    "    <edge-split-pane value=\".20\">\n" +
    "        <edge-split-pane-view resize-callback=\"ctrlr.handlePipesPaneResize\">\n" +
    "            <edge-pipes ng-if=\"ctrlr.initialized\" options=\"ctrlr.pipesOptions\"\n" +
    "                selected-node=\"ctrlr.selectedPipelineNode\" change-select-to=\"ctrlr.selectInstanceId\"></edge-pipes>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <div id=\"edgePipelineConfigArea\" style=\"height:100%\"></div>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "</div>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <button ng-if=\"WizardCtrlr.activelyValidating || activelySaving\" edge-button-spinner data-spinner-color=\"#AAAAAA\" data-style=\"expand-left\" class=\"btn btn-danger\" spin-toggle=\"true\" translate>\n" +
    "            Wait\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-danger\" ng-click=\"handleCancel()\" translate>\n" +
    "            Cancel and Close\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default\" ng-if=\"!WizardCtrlr.onFirstStep()\" ng-disabled=\"WizardCtrlr.activelyValidating\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating  || activelySaving\"\n" +
    "                ng-click=\"WizardCtrlr.handleBack()\" translate>Back\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default\" ng-if=\"!WizardCtrlr.onLastStep()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating  || activelySaving\"\n" +
    "                ng-click=\"WizardCtrlr.handleNext()\" translate>Next\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-success\" ng-if=\"WizardCtrlr.allowSaveButton()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating  || activelySaving\"\n" +
    "                ng-click=\"handleSave()\" translate>Save\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-success\" ng-if=\"WizardCtrlr.allowSaveButton()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                ng-click=\"handleSaveAndClose()\" translate>Save and Close\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/jobstatus/jobs.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/jobstatus/jobs.tpl.html",
    "<edge-view class=\"jobsView\">\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button ng-if=\"ctrlr.powerUser\" ng-disabled=\"ctrlr.selectedTaskId && ctrlr.showGraph\" class=\"edgeSmallToggleButton btn btn-default\" ng-class=\"{'toggledOn': ctrlr.showGraph && ! ctrlr.selectedTaskId}\"\n" +
    "                        ng-click=\"ctrlr.showTopologyGraph(true)\" title=\"{{::'Show Topology for all active jobs' | translate}}\">\n" +
    "                        <i class=\"icon icon_vis_topology\"></i>&nbsp;<span translate>Topology - Active Jobs</span>\n" +
    "                    </button>\n" +
    "                    <button ng-disabled=\"! ctrlr.selectedTaskId\" class=\"edgeSmallToggleButton btn btn-default\"\n" +
    "                        ng-class=\"{'toggledOn': ctrlr.showGraph}\" ng-click=\"ctrlr.showTopologyGraph(false)\"\n" +
    "                        title=\"{{::'Show selected job\\'s history topology' | translate}}\">\n" +
    "                        <i class=\"icon icon_vis_topology\"></i>&nbsp;<span translate>Topology - Job History</span>\n" +
    "                    </button>\n" +
    "                    <div class=\"btn-group table-control\" role=\"group\">\n" +
    "                        <button class=\"edgeSmallToggleButton btn btn-default\" ng-class=\"{'toggledOn': !ctrlr.showGraph}\"\n" +
    "                            ng-click=\"ctrlr.goBack()\" title=\"{{::'Show Status Table' | translate}}\">\n" +
    "                            <i class=\"icon icon_vis_table\"></i>&nbsp;<span translate>Table</span>\n" +
    "                        </button>\n" +
    "                        <button ng-disabled=\"ctrlr.showGraph\" class=\"edgeSmallToggleButton btn btn-default dropdown-toggle\" ng-class=\"{'toggledOn': !ctrlr.showGraph}\"\n" +
    "                            data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"\n" +
    "                            title=\"{{::'Toggle Column Visibility' | translate}}\">\n" +
    "                            <span class=\"caret\"></span>\n" +
    "                        </button>\n" +
    "                        <div class=\"dropdown-menu\" ng-click=\"$event.stopPropagation();\">\n" +
    "                            <form class=\"form-horizontal\" style=\"padding:0px 10px 10px 10px\">\n" +
    "                                <div ng-repeat=\"columnDef in ctrlr.dataGridOptions.columnDefs\">\n" +
    "                                    <label>\n" +
    "                                        <input type=\"checkbox\" style=\"margin-right: 4px;\" ng-model=\"columnDef.visible\">{{columnDef.displayName}}\n" +
    "                                    </label>\n" +
    "                                </div>\n" +
    "                            </form>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "\n" +
    "                <div ng-if=\"!ctrlr.showGraph\" class=\"pull-right\" style=\"max-width:200px\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_search\" ng-dblclick=\"ctrlr.$location.search('powerUser', true)\"></i></span>\n" +
    "                        <input class=\"form-control\" placeholder=\"{{::'filter'|translate}}\" ng-model=\"ctrlr.search\">\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <edge-jobs-graph nodes=\"ctrlr.nodes\" links=\"ctrlr.links\" ng-if=\"ctrlr.showGraph\"></edge-jobs-graph>\n" +
    "            <div ng-if=\"ctrlr.showGraph && ctrlr.nodes.length === 0\"\n" +
    "                 style='position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%)'>\n" +
    "                <div class=\"alert alert-warning\" style='margin: 0; padding: 8px 2em; white-space: nowrap'>\n" +
    "                    <i class=\"icon icon_info_circle\" style='vertical-align: middle'></i>\n" +
    "                    <span translate>There is no job history at this time. It has expired. Please refresh the job status table.</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <!-- force display block, so that in Firefox, browser back or going back from graph to table,\n" +
    "                the table's scroll positon will be retained, IE and chrome does it by default without the forced display block -->\n" +
    "            <div ng-show=\"!ctrlr.showGraph\" class=\"grid modulegrid jobsgrid\" style=\"height: 100%; display: block !important;\"\n" +
    "                 ui-grid=\"ctrlr.dataGridOptions\" ui-grid-selection\n" +
    "                 ui-grid-resize-columns ui-grid-move-columns></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"ctrlr.refreshPipeline()\"\n" +
    "                    title=\"{{::'Refresh Job Status' | translate}}\">\n" +
    "                <i class=\"icon icon_refresh\"></i>\n" +
    "            </button>\n" +
    "            <div ng-if=\"!ctrlr.showGraph\" class=\"edgeClientFilterButtonBar btn-group\">\n" +
    "                <button class=\"btn btn-default edgeClientFilterButton\" ng-repeat=\"filterDef in ctrlr.statusFilterDefs\"\n" +
    "                    ng-click=\"ctrlr.toggleFilterDef(filterDef)\" ng-class=\"{'filterOn':filterDef.on}\">\n" +
    "                    <span>{{filterDef.label}}</span>\n" +
    "                </button>\n" +
    "                <button ng-if=\"ctrlr.powerUser\" class=\"btn btn-default edgeClientFilterButton\" ng-repeat=\"filterDef in ctrlr.hiddenStatusFilterDefs\"\n" +
    "                    ng-click=\"ctrlr.toggleFilterDef(filterDef)\" ng-class=\"{'filterOn':filterDef.on}\">\n" +
    "                    <span>{{filterDef.label}}</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div ng-if=\"!ctrlr.showGraph\" class=\"pull-right\">\n" +
    "                <button ng-if=\"ctrlr.powerUser\" class=\"btn btn-default btn-xs\" ng-click=\"ctrlr.showJobsHistoryForAllNodes()\" ng-disabled=\"ctrlr.viewAllJobs\"\n" +
    "                    title=\"{{::'Show job history for all nodes.' | translate}}\" translate>\n" +
    "                    View All Jobs\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default btn-xs\" ng-click=\"ctrlr.saveJobStatus()\" ng-disabled=\"ctrlr.dataGridOptions.data.length === 0\"\n" +
    "                    title=\"{{::'Save Job Status Table as CSV' | translate}}\">\n" +
    "                    <span translate>Save as CSV</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/proxy/edgeProxyAppChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/proxy/edgeProxyAppChooser.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match placeholder=\"{{'Choose an application...'|translate}}\">{{$select.selected}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item in appNames | orderBy:'+' | filter: $select.search\">\n" +
    "        <div class=\"row\" ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/proxy/edgeProxyAppVersionChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/proxy/edgeProxyAppVersionChooser.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match placeholder=\"{{'Choose a version...'|translate}}\">{{$select.selected}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item in appVersions | orderBy:'+' | filter: $select.search\">\n" +
    "        <div class=\"row\" ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/proxy/edgeProxyRuleChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/proxy/edgeProxyRuleChooser.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match placeholder=\"{{'Choose a rule...'|translate}}\">{{$select.selected}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item in rules | filter: $select.search\">\n" +
    "        <div class=\"row\" ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/proxy/edgeSsoHandlerChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/proxy/edgeSsoHandlerChooser.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match placeholder=\"{{'Choose an SSO handler...'|translate}}\">{{$select.selected}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item in handlerDefs | filter: $select.search track by $index\">\n" +
    "        <div ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/proxy/proxy-feed-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/proxy/proxy-feed-wizard.tpl.html",
    "<div ng-controller=\"ProxyFeedWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!WizardCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{'Configure'|translate}}\" index=\"0\" use-form-validation=\"config\"\n" +
    "                          validate=\"WizardCtrlr.validateConfiguration()\">\n" +
    "            <form name=\"config\">\n" +
    "                <edge-property-editor ng-if=\"WizardCtrlr.propertyEditorConfig\"\n" +
    "                                      config=\"WizardCtrlr.propertyEditorConfig\"></edge-property-editor>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          on-show=\"WizardCtrlr.showPreview()\"\n" +
    "                          on-hide=\"WizardCtrlr.hidePreview()\">\n" +
    "            <div ng-if=\"WizardCtrlr.previewReady === false\">\n" +
    "                <h3 translate>Loading Preview... </h3>\n" +
    "                <div style='display:inline-block; position:relative; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                    <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "            </div>\n" +
    "            <div class=\"edgePreviewWidget\"\n" +
    "                 ng-if=\"WizardCtrlr.previewReady === true && WizardCtrlr.proxyURL != null && WizardCtrlr.statusCheck('CURRENT')\">\n" +
    "                <iframe name=\"edgeWebTop-preview\" style=\"width: 100%; height: 100%\" ng-src=\"{{WizardCtrlr.proxyURL}}\"/>\n" +
    "            </div>\n" +
    "            <div ng-if=\"WizardCtrlr.previewReady === true && WizardCtrlr.proxyURL == null\n" +
    "                && WizardCtrlr.statusCheck('BAD_CREDENTIALS') && WizardCtrlr.statusCheck('REQUIRE_CREDENTIALS')\"\n" +
    "            class=\"alert alert-danger\">\n" +
    "                <span translate>Unable to show preview due to configuration issue.</span>\n" +
    "            </div>\n" +
    "            <div ng-if=\"WizardCtrlr.previewReady === true && WizardCtrlr.statusCheck('BAD_CREDENTIALS')\"\n" +
    "                 class=\"alert alert-danger\">\n" +
    "                <span translate>Unable to show preview due to bad credentials.</span>\n" +
    "            </div>\n" +
    "            <div ng-if=\"WizardCtrlr.previewReady === true && WizardCtrlr.statusCheck('REQUIRE_CREDENTIALS')\"\n" +
    "                 class=\"alert alert-danger\">\n" +
    "                <span translate>Unable to show preview due to missing credentials.</span>\n" +
    "            </div>\n" +
    "\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/select-pipe-node.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/select-pipe-node.tpl.html",
    "<div style=\"height: 100%;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"pipelineSelect\">\n" +
    "            <edge-pipeline-search ng-if=\"::SelectNodeController.showSearch\" show-pages=\"::false\" seed-search-choice=\"::SelectNodeController.seedSearchChoice\"></edge-pipeline-search>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-pipes options=\"SelectNodeController.pipesOptions\" selected-node=\"SelectNodeController.selectedNode\">\n" +
    "    </edge-pipes>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/serveraction/server-action-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/serveraction/server-action-wizard.tpl.html",
    "<div ng-controller=\"ServerActionWizardController as Controller\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!Controller.isEdit\" dialog-mode=\"true\" on-save=\"Controller.handleSave\"\n" +
    "                 on-cancel=\"Controller.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure'|translate}}\" index=\"0\" use-form-validation=\"config\" validate=\"Controller.validateData()\">\n" +
    "            <form name=\"config\">\n" +
    "                <edge-property-editor ng-if=\"Controller.propertyEditorConfig\"\n" +
    "                                      config=\"Controller.propertyEditorConfig\"></edge-property-editor>\n" +
    "            </form>\n" +
    "            <form name=\"runServerAction\" ng-if=\"Controller.isExecutable\">\n" +
    "                <div class=\"form-horizontal\">\n" +
    "                    <edge-labeled-control label=\"{{::'Run Server Action' | translate}}\" helptext=\"{{::'Manually execute server action' | translate}}\" validation=\"false\" required=\"false\">\n" +
    "                        <button class=\"btn btn-default\" ng-disabled=\"Controller.executionInProgress\" ng-click=\"Controller.executeAction()\">\n" +
    "                            <span ng-if=\"Controller.executionInProgress\">{{::'Testing...' | translate}}</span>\n" +
    "                            <span ng-if=\"!Controller.executionInProgress\">{{::'Test Server Action' | translate}}</span>\n" +
    "                        </button>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <edge-panel ng-if=\"Controller.responseDetails\">\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div class=\"col-sm-12\">\n" +
    "                            <label translate>Server Action Response Details</label>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body style=\"padding: 0.5em\">\n" +
    "                        <div ng-repeat=\"(key, value) in Controller.responseDetails\">\n" +
    "                            <label>{{key}}:</label>\n" +
    "                            <pre style=\"white-space: pre-wrap\">{{value}}</pre>\n" +
    "                        </div>\n" +
    "                    </edge-panel-body>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Refresh'|translate}}\" use-form-validation=\"feed\" index=\"2\">\n" +
    "            <form name=\"feed\" class=\"form-horizontal tableList\" style=\"height: 100%;\">\n" +
    "                <div style=\"height: 100%\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div class=\"col-sm-12\">\n" +
    "                                <label translate>List of Feeds that will be refreshed once this action is executed.</label>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"Controller.selectedItem\" items=\"Controller.dependencies\" type=\"simple\">\n" +
    "                                <div class=\"with-padding\">\n" +
    "                                <div class=\"input-group\">\n" +
    "                                    <input name=\"feedid{{item.uid}}\" class=\"form-control\" type=\"hidden\" ng-model=\"item.name\" required>\n" +
    "                                    <ui-select ng-model=\"item.name\" theme=\"bootstrap\" on-select=\"listScope.Controller.updateSelectedItem($item)\">\n" +
    "                                        <ui-select-match placeholder=\"{{::'Choose a feed...' | translate}}\">{{$select.selected.name}}\n" +
    "                                        </ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"feed.name as feed in (listScope.Controller.feeds | filter: {name: $select.search})\">\n" +
    "                                            <div ng-bind-html=\"feed.name | highlight: $select.search\"></div>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                    <span class=\"input-group-btn\">\n" +
    "                                        <button class=\"btn btn-default\" type=\"button\"\n" +
    "                                            ng-click=\"listScope.Controller.pickFeed()\"><i class=\"icon icon_feed\"></i>\n" +
    "                                        </button>\n" +
    "                                    </span>\n" +
    "                                </div>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"Controller.addRow()\"></button>\n" +
    "                            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"Controller.removeRow()\"\n" +
    "                                    ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-toolbar>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"Controller.editParameters()\" translate>Manage Variables</button>\n" +
    "            </div>\n" +
    "        </edge-wizard-toolbar>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/view-pipes.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/view-pipes.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div id=\"edge-pipes-view-mode\" class=\"btn-group\">\n" +
    "                    <button class=\"edgeSmallToggleButton btn btn-default btn-sm\" ng-class=\"{'toggledOn' : ctrlr.viewMode == 'topo'}\"\n" +
    "                            ng-click=\"ctrlr.showTopo();\" translate>Topology</button>\n" +
    "                    <button class=\"edgeSmallToggleButton btn btn-default btn-sm\" ng-class=\"{'toggledOn' : ctrlr.viewMode == 'table'}\"\n" +
    "                            ng-click=\"ctrlr.showTable();\" translate>Table</button>\n" +
    "                    <button class=\"edgeSmallToggleButton btn btn-default btn-sm\" ng-class=\"{'toggledOn' : ctrlr.viewMode == 'treetable'}\"\n" +
    "                            ng-click=\"ctrlr.showTreeTable();\" translate>Tree Table</button>\n" +
    "                </div>\n" +
    "                <button type=\"button\" id=\"edge-pipes-settings\" class=\"btn btn-default pull-right\" ng-click=\"ctrlr.showSettings()\"><i class=\"icon icon_cog\"></i></button>\n" +
    "                <div class=\"pull-right panel-heading-control\">\n" +
    "                    <edge-pipeline-search></edge-pipeline-search>\n" +
    "                </div>\n" +
    "                <div class=\"pull-right\" style=\"max-width:200px;\" ng-if=\"ctrlr.viewMode.indexOf('table') != -1\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_filter\"></i></span>\n" +
    "                        <input type=\"search\" ng-model=\"ctrlr.searchString\" class=\"form-control\"\n" +
    "                               placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body class=\"edge-pipes-container\" style=\"overflow:hidden;\">\n" +
    "            <edge-pipes ng-if=\"panelScope.ctrlr.pipesOptions.nodes\" ng-class=\"{'edge-offscreen' : panelScope.ctrlr.viewMode !== 'topo' || panelScope.ctrlr.mode !== 'showPipes'}\"\n" +
    "                        options=\"panelScope.ctrlr.pipesOptions\"\n" +
    "                        selected-node=\"panelScope.ctrlr.selectedNode\"\n" +
    "                        change-select-to=\"panelScope.ctrlr.viewMode === 'topo' && panelScope.ctrlr.mode === 'showPipes'\"\n" +
    "                        ng-mouseleave=\"panelScope.ctrlr.appTooltipService.hideTooltip();\">\n" +
    "            </edge-pipes>\n" +
    "            <edge-pipes-table ng-if=\"panelScope.ctrlr.tableViewOption\" ng-class=\"{'edge-offscreen' : panelScope.ctrlr.viewMode !== 'table' || panelScope.ctrlr.mode !== 'showPipes'}\"\n" +
    "                nodes=\"panelScope.ctrlr.tableViewOption.nodes\"\n" +
    "                pipes-controller=\"panelScope.ctrlr\"\n" +
    "                selected-node=\"panelScope.ctrlr.selectedNode\"\n" +
    "                change-select-to=\"panelScope.ctrlr.viewMode === 'table' && panelScope.ctrlr.mode === 'showPipes'\"\n" +
    "                ng-mouseleave=\"panelScope.ctrlr.appTooltipService.hideTooltip();\">\n" +
    "            </edge-pipes-table>\n" +
    "            <edge-pipes-tree-table ng-if=\"panelScope.ctrlr.treetableViewOption\" ng-class=\"{'edge-offscreen' : panelScope.ctrlr.viewMode !== 'treetable' || panelScope.ctrlr.mode !== 'showPipes'}\"\n" +
    "                nodes=\"panelScope.ctrlr.treetableViewOption.nodes\"\n" +
    "                links=\"panelScope.ctrlr.treetableViewOption.links\"\n" +
    "                pipes-controller=\"panelScope.ctrlr\"\n" +
    "                selected-node=\"panelScope.ctrlr.selectedNode\"\n" +
    "                change-select-to=\"panelScope.ctrlr.viewMode === 'treetable' && panelScope.ctrlr.mode === 'showPipes'\"\n" +
    "                ng-mouseleave=\"panelScope.ctrlr.appTooltipService.hideTooltip();\">\n" +
    "            </edge-pipes-tree-table>\n" +
    "            <div ng-if=\"panelScope.ctrlr.mode === 'showSelectMessage'\"\n" +
    "                 class=\"alert alert-info\" translate>\n" +
    "                Please choose a pipeline to edit.\n" +
    "            </div>\n" +
    "            <div ng-if=\"panelScope.ctrlr.mode === 'showWaitForServer'\"\n" +
    "                 class=\"alert alert-info\">\n" +
    "                <span style=\"width: 10px;height: 5px;display: inline-block;\"\n" +
    "                      us-spinner=\"{hwaccel:'true',radius:4,width:2,length:3,top:'0',left:'0',position:'relative'}\"></span>\n" +
    "                <span translate>Retrieving pipeline from the server.</span>\n" +
    "            </div>\n" +
    "            <div ng-if=\"panelScope.ctrlr.mode === 'showInstructions'\"\n" +
    "                 style='position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%)'>\n" +
    "                <div class=\"alert alert-warning\" style='margin: 0; padding: 8px 2em; white-space: nowrap'>\n" +
    "                    <i class=\"icon icon_info_circle\" style='vertical-align: middle'></i>\n" +
    "                    <span translate>Add a connection to get started!</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <!-- Do not delete the following block of code, it's for the context menu on the pipeline-->\n" +
    "            <li style=\"cursor:pointer;list-style-type:none;\">\n" +
    "                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\"></a>\n" +
    "                <ul id=\"contextMenu\" class=\"dropdown-menu\"></ul>\n" +
    "            </li>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button type=\"button\" class=\"btn btn-success\"\n" +
    "                            ng-class=\"{'pulse':panelScope.ctrlr.mode == 'showInstructions'}\"\n" +
    "                            ng-click=\"panelScope.ctrlr.addConnection()\"\n" +
    "                            title=\"{{::'Add Connection' | translate}}\">\n" +
    "                        <span><i class=\"icon icon_plus btn_icon\"></i></span>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-warning\"\n" +
    "                            ng-disabled=\"panelScope.ctrlr.cannotEdit()\"\n" +
    "                            ng-click=\"panelScope.ctrlr.editNode()\"\n" +
    "                            title=\"{{::'Edit Selected' | translate}}\">\n" +
    "                        <span><i class=\"icon icon_pencil btn_icon\"></i></span>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-warning\"\n" +
    "                            ng-disabled=\"panelScope.ctrlr.selectedNode === undefined || panelScope.ctrlr.selectedNode.invalid\"\n" +
    "                            ng-click=\"panelScope.ctrlr.cloneNode()\"\n" +
    "                            title=\"{{::'Duplicate Selected' | translate}}\">\n" +
    "                        <span><i class=\"icon icon_copy btn_icon\"></i></span>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\" class=\"btn btn-danger\"\n" +
    "                            ng-disabled=\"panelScope.ctrlr.selectedNode === undefined\"\n" +
    "                            ng-click=\"panelScope.ctrlr.deleteNode()\"\n" +
    "                            title=\"{{::'Delete Selected' | translate}}\">\n" +
    "                        <span><i class=\"icon icon_trash btn_icon\"></i></span>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "                <div class=\"btn-group pull-right\" style=\"margin-right:5px;\">\n" +
    "                    <button class=\"edgeSmallToggleButton btn btn-default btn-sm\"\n" +
    "                            ng-class=\"{'toggledOn' : ctrlr.selectedViewType.name == 'data'}\"\n" +
    "                            ng-click=\"ctrlr.showData();\" translate>Data</button>\n" +
    "                    <button class=\"edgeSmallToggleButton btn btn-default btn-sm\"\n" +
    "                            ng-class=\"{'toggledOn' : ctrlr.selectedViewType.name == 'action'}\"\n" +
    "                            ng-click=\"ctrlr.showActions();\" translate>Actions</button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/pipeline/visualization/ChooseVisualizationType.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/pipeline/visualization/ChooseVisualizationType.tpl.html",
    "<div class=\"edge-vis-chooser-container\">\n" +
    "    <span ng-repeat=\"visInfo in ::ctrlr.visualizationTypes | orderBy:'type.displayName'\"\n" +
    "          uib-tooltip-html=\"'<h5>{{::visInfo.type.displayName}}</h5> {{::visInfo.type.description}} {{::visInfo.extraDetail}}'\"\n" +
    "          tooltip-append-to-body=\"true\"\n" +
    "          tooltip-class=\"edge-vis-chooser-tooltip\"\n" +
    "          tooltip-popup-delay=\"500\"\n" +
    "          tooltip-placement=\"auto top\">\n" +
    "        <button ng-disabled=\"::(visInfo.compatible !== true)\"\n" +
    "                class=\"btn btn-default edge-vis-chooser-btn\"\n" +
    "                ng-click=\"ctrlr.selectedType = visInfo.type;dialogRef.close()\">\n" +
    "            <img width=48 height=48 ng-src=\"{{::ctrlr.getVisualizationIcon(visInfo.type)}}\">\n" +
    "            <h5>{{::visInfo.type.displayName}}</h5>\n" +
    "        </button>\n" +
    "    </span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/defaults/provision-defaults.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/defaults/provision-defaults.tpl.html",
    "<edge-view class=\"edgeProvisionView\">\n" +
    "    <div class=\"col-sm-3 input-group\" style=\"padding-left:0px;padding-right:0px; margin-bottom: 15px; height:auto\">\n" +
    "        <span class=\"input-group-addon\" translate>Manage By</span>\n" +
    "        <ui-select ng-model=\"ctrlr.selectedManageBy\" theme=\"bootstrap\" on-select=\"ctrlr.handleManageBy($item)\">\n" +
    "            <ui-select-match placeholder=\"{{'Choose...' | translate}}\">{{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item in ctrlr.manageBy | filter: $select.search\">\n" +
    "                <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <edge-panel style=\"height:calc(100% - 47px);overflow:hidden; clear: both;\">\n" +
    "        <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                    <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#variables\" style=\"padding:7px 15px\"><span\n" +
    "                            translate>Secured Variables</span></a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#credentials\" style=\"padding:7px 15px\"><span\n" +
    "                            translate>Credentials</span></a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#preferences\" style=\"padding:7px 15px\"><span\n" +
    "                            translate>Preferences</span></a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#passwordPolicy\" style=\"padding:7px 15px\"><span\n" +
    "                            translate>Password Policy</span></a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body>\n" +
    "            <div class=\"tab-content\" style=\"height: 100%\">\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane fade in active\" id=\"variables\">\n" +
    "                    <edge-list items=\"ctrlr.globalVariables\" selected-item=\"ctrlr.selectedGlobalVariable\"\n" +
    "                               sort=\"param.parameterName\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editGlobalVariable(false)\">\n" +
    "                            <i class=\"icon icon_var list-icon pull-left\"></i> {{item.parameterName}}\n" +
    "                            <code class=\"pull-right\">\n" +
    "                                <i class=\"glyphicon glyphicon-globe\"></i>\n" +
    "                                {{listScope.ctrlr.getGlobalDisplayValue(item)}}\n" +
    "                            </code>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"credentials\">\n" +
    "                    <edge-list items=\"ctrlr.globalCredentials\" selected-item=\"ctrlr.selectedGlobalCredential\"\n" +
    "                               sort=\"parameterName\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editGlobalCredential(false)\">\n" +
    "                            <i class=\"fa fa-key\"></i> {{item.parameterName}}\n" +
    "                            <code class=\"pull-right\">\n" +
    "                                <i class=\"glyphicon glyphicon-globe\"></i>\n" +
    "                                {{listScope.ctrlr.getGlobalCredentialDisplayValue(item)}}\n" +
    "                            </code>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"preferences\" style=\"padding: 20px 35px 20px 20px;\">\n" +
    "                    <form name=\"prefsForm\" class=\"form-horizontal\">\n" +
    "                        <edge-labeled-control class=\"col-sm-6\" label-width=\"4\" label=\"{{::'Session Timeout'|translate}}\"\n" +
    "                                              helptext=\"{{::'Default session timeout setting in minutes'|translate}}\">\n" +
    "                            <input class=\"form-control\"\n" +
    "                                   readonly=\"true\"\n" +
    "                                   name=\"sessionTimeout\"\n" +
    "                                   ng-model=\"ctrlr.sessionTimeout.value\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" label-width=\"2\" label=\"{{::'Custom Login Page'|translate}}\"\n" +
    "                            helptext=\"{{::'Specify a directory containing an alternative login page (must be in the static-web/ directory)'|translate}}\"\n" +
    "                            validation=\"true\">\n" +
    "                            <input type=\"text\" class=\"form-control\" name=\"customlogin\"\n" +
    "                                   ng-model=\"ctrlr.preferences[ctrlr.PrefsService.PREF_LOGIN_CUSTOM_PATH]\"\n" +
    "                                   ng-pattern=\"/^static-web\\/.+$/\"\n" +
    "                                   ng-change=\"ctrlr.prefsChanged()\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "                            helptext=\"{{::'Default system Add To Home Screen mobile touch icon; override it by placing an apple-touch-icon.png file in static-web/lookandfeel/ directory.'|translate}}\"\n" +
    "                            label=\"{{::'Touch Icon' | translate}}\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\">\n" +
    "                                    <img class=\"icon\" ng-src=\"/apple-touch-icon.png\" style=\"width: 16px; height: 16px\">\n" +
    "                                </span>\n" +
    "                                <input type=\"text\" class=\"form-control\" name=\"touchicon\" readonly value=\"/apple-touch-icon.png\">\n" +
    "                            </div>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <h4 style=\"clear: both; margin-bottom: 5px; padding-top: 10px;\" translate>Look And Feel</h4>\n" +
    "                        <hr style=\"margin-top: 0;\">\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\" label=\"{{::'Name' | translate}}\" validation=\"true\">\n" +
    "                            <input name=\"laf\" class=\"form-control\" type=\"hidden\" ng-model=\"ctrlr.selectedLaf\"\n" +
    "                                   required>\n" +
    "                            <ui-select ng-model=\"ctrlr.selectedLaf\" theme=\"bootstrap\"\n" +
    "                                       ng-change=\"ctrlr.lafChanged()\">\n" +
    "                                <ui-select-match placeholder=\"{{::'Choose a LAF...' | translate}}\">{{$select.selected.displayName}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item in (ctrlr.lafs | filter: {displayName: $select.search})\">\n" +
    "                                    <div ng-bind-html=\"item.displayName | highlight: $select.search\"></div>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "                            helptext=\"{{::'Base theme to use; this is overridden with optional override.css file.'|translate}}\"\n" +
    "                            label=\"{{::'Theme' | translate}}\">\n" +
    "                            <input type=\"text\" class=\"form-control\" name=\"theme\" readonly ng-model=\"ctrlr.selectedLaf.themeName\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "                            helptext=\"{{::'This title prefix appears in browser\\'s tab. This value is prepended to the current page name. For example: CompanyA:'|translate}}\"\n" +
    "                            label=\"{{::'Title Prefix' | translate}}\">\n" +
    "                            <input type=\"text\" class=\"form-control\" name=\"titlePrefix\" readonly\n" +
    "                                   ng-model=\"ctrlr.selectedLaf.titlePrefix\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-8\" label-width=\"3\" label=\"{{::'Banner Logo'|translate}}\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\">\n" +
    "                                    <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.bannerLogo}}\" style=\"height: 16px\">\n" +
    "                                </span>\n" +
    "                                <input class=\"form-control\" name=\"bannerlogo\" readonly\n" +
    "                                    ng-model=\"ctrlr.selectedLaf.bannerLogo\">\n" +
    "                            </div>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-8\" label-width=\"3\" label=\"{{::'About logo'|translate}}\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\">\n" +
    "                                    <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.aboutLogo}}\" style=\"height: 16px\">\n" +
    "                                </span>\n" +
    "                                <input class=\"form-control\" name=\"aboutlogo\" readonly\n" +
    "                                    ng-model=\"ctrlr.selectedLaf.aboutLogo\">\n" +
    "                            </div>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "                            label=\"{{::'Favicon' | translate}}\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\">\n" +
    "                                    <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.favicon}}\" style=\"width: 16px; height: 16px\">\n" +
    "                                </span>\n" +
    "                                <input type=\"text\" class=\"form-control\" name=\"favicon\" readonly ng-model=\"ctrlr.selectedLaf.favicon\">\n" +
    "                            </div>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </form>\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"passwordPolicy\" style=\"padding: 20px 35px 20px 20px;\">\n" +
    "                    <edge-password-policy password-policy=\"ctrlr.passwordPolicyModel.provisionedPolicy\"\n" +
    "                                          pre-defined-syntax=\"::ctrlr.preDefinedSyntax\"></edge-password-policy>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-group\" ng-if=\"ctrlr.activeTab === '#variables'\">\n" +
    "                <button class=\"btn btn-success\" ng-click=\"ctrlr.editGlobalVariable(true)\">\n" +
    "                    <i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedGlobalVariable\"\n" +
    "                        ng-click=\"ctrlr.editGlobalVariable(false)\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-danger\" ng-disabled=\"! ctrlr.selectedGlobalVariable\"\n" +
    "                        ng-click=\"ctrlr.deleteGlobalVariable()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\" ng-if=\"ctrlr.activeTab === '#credentials'\">\n" +
    "                <button class=\"btn btn-success\" ng-click=\"ctrlr.editGlobalCredential(true)\">\n" +
    "                    <i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedGlobalCredential\"\n" +
    "                        ng-click=\"ctrlr.editGlobalCredential(false)\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                <button class=\"btn btn-danger\" ng-disabled=\"! ctrlr.selectedGlobalCredential\"\n" +
    "                        ng-click=\"ctrlr.deleteGlobalCredential()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#preferences'\">\n" +
    "                <button class=\"btn btn-success\" ng-click=\"ctrlr.updatePrefs()\" ng-class=\"{'pulse':ctrlr.unsavedPrefs}\">\n" +
    "                    <span ng-if=\"ctrlr.unsavedPrefs\" class=\"icon icon_exclamation_triangle\"></span>\n" +
    "                    <span translate>Save</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#passwordPolicy'\">\n" +
    "                <button class=\"btn btn-primary\"\n" +
    "                        ng-class=\"{'pulse':ctrlr.passwordPolicyModel.changesPending}\"\n" +
    "                        ng-click=\"ctrlr.updatePPolicy()\">\n" +
    "                        <span ng-if=\"ctrlr.passwordPolicyModel.changesPending\"\n" +
    "                              class=\"icon icon_exclamation_triangle\"\n" +
    "                              title=\"{{::'Unsaved Changes' | translate}}\"></span><span translate>Save</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/global-security-variable-edit.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/global-security-variable-edit.tpl.html",
    "<form name=\"variableForm\" class=\"form-horizontal\">\n" +
    "    <div class=\"col-sm-12\" style=\"padding-right: 20px\">\n" +
    "        <edge-labeled-control ng-if=\"::Controller.isNew\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              label=\"{{::'Name'|translate}}\">\n" +
    "            <input name=\"name\"\n" +
    "                   type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   ng-model=\"Controller.variable.param.parameterName\"\n" +
    "                   ng-required=\"true\"\n" +
    "                   ng-pattern=\"/^[a-zA-Z]\\w*$/\"\n" +
    "                   edge-focus>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"4\" label=\"{{::'Validation Value'|translate}}\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <div class=\"btn-group btn-group-justified\">\n" +
    "                        <select ng-model=\"Controller.type\"\n" +
    "                                class=\"form-control\"\n" +
    "                                ng-change=\"Controller.handleTypeChange()\">\n" +
    "                            <option value=\"static\" translate>Static</option>\n" +
    "                            <option value=\"expression\" translate>Expression</option>\n" +
    "                        </select>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-8\">\n" +
    "                    <div ng-if=\"Controller.type === 'expression'\" class=\"input-group\" style=\"width:100%\">\n" +
    "                        <ui-select ng-model=\"Controller.defaultValue\" append-to-body=\"true\">\n" +
    "                            <ui-select-match theme=\"bootstrap\">{{$select.selected}}</ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item in Controller.getExpressions($select.search)\">\n" +
    "                                <span ng-bind-html=\"item| highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </div>\n" +
    "                    <input name=\"value\"\n" +
    "                           type=\"text\"\n" +
    "                           class=\"form-control\"\n" +
    "                           ng-model=\"Controller.defaultValue\"\n" +
    "                           ng-trim=\"false\"\n" +
    "                           ng-if=\"Controller.type === 'static'\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control  label-width=\"4\" label=\"{{::'Value Usage'|translate}}\">\n" +
    "            <edge-radio-group name=\"selectionMode\"\n" +
    "                              ng-model=\"Controller.inheritedValue\">\n" +
    "                <edge-radio-button value=\"{{::Controller.DEFAULT_IS_NULL}}\">\n" +
    "                    <span translate>Use for validation only</span><br/>\n" +
    "                    <span class=\"text-muted\" translate>This value will only be used to validate endpoints.</span><br/>\n" +
    "                    <span class=\"text-muted\" translate>A value for the secured variable must be set for the domain or user.</span>\n" +
    "                </edge-radio-button>\n" +
    "                <edge-radio-button value=\"{{::Controller.USE_VALIDATION}}\">\n" +
    "                    <span translate>Use as a default value</span><br/>\n" +
    "                    <span class=\"text-muted\" translate>This value will be used as a default for all users.</span><br/>\n" +
    "                    <span class=\"text-muted\" translate>The value can be overwritten by a secured variable set for the domain or user.</span>\n" +
    "                </edge-radio-button>\n" +
    "            </edge-radio-group>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/domains/ChooseDomainType.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/domains/ChooseDomainType.tpl.html",
    "<div class=\"list-group visChooser\">\n" +
    "    <a href=\"javascript:void(0)\" ng-repeat=\"type in types | orderBy:'displayName'\" class=\"list-group-item visChooserListItem\" ng-click=\"dialogRef.selectedType = type;dialogRef.close()\" ng-class=\"{odd:$odd}\">\n" +
    "        <table style=\"table-layout:fixed;\">\n" +
    "            <tr>\n" +
    "                <td rowspan=\"2\" valign=\"middle\" align=\"center\">\n" +
    "                    <img width=32 height=32 ng-src=\"{{::getDomainTypeIcon(type.icon)}}\">\n" +
    "                </td>\n" +
    "                <td class=\"visChooserDisplayName\">\n" +
    "                    <h5>{{::type.getBaseDisplayName()}}</h5>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "            <tr>\n" +
    "                <td class=\"visChooserTypeDescription\">{{::type.description}}</td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </a>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/domains/ldapAdapterWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/domains/ldapAdapterWizard.tpl.html",
    "<div ng-controller=\"LdapAdapterController as LdapAdapterCtrlr\" style=\"height:100%\" block-ui=\"connectionTest\">\n" +
    "    <edge-wizard force-progression=\"!LdapAdapterCtrlr.isEdit\"\n" +
    "                 dialog-mode=\"true\" on-save=\"LdapAdapterCtrlr.handleSave\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config'|translate}}\" use-form-validation=\"usersForm\" index=\"1\"\n" +
    "            validate=\"LdapAdapterCtrlr.validateConfiguration()\" on-show=\"LdapAdapterCtrlr.reloadUsers = true\">\n" +
    "            <style>\n" +
    "                form.ui-select-jointed-group .input-group>.ui-select-bootstrap>input.ui-select-search.form-control {\n" +
    "                    border-radius: 0;\n" +
    "                }\n" +
    "\n" +
    "                form[name=\"usersForm\"] .ui-select-match-text {\n" +
    "                    width: 100%;\n" +
    "                }\n" +
    "            </style>\n" +
    "            <form name=\"usersForm\" class=\"form-horizontal ui-select-jointed-group\">\n" +
    "                <div ng-if=\"LdapAdapterCtrlr.connectionTestFailed\">\n" +
    "                    <div class=\"alert alert-danger\"><b translate>Connection test failed.</b><br><br>\n" +
    "                        <span translate>Server Response:</span>\n" +
    "                        <div class=\"well well-sm\">{{LdapAdapterCtrlr.serverResponse}} <br>\n" +
    "                            <a class=\"pull-right\"\n" +
    "                               ng-if=\"LdapAdapterCtrlr.extraDetail\"\n" +
    "                               ng-init=\"LdapAdapterCtrlr.showExtraDetail = false\"\n" +
    "                               ng-click=\"LdapAdapterCtrlr.showExtraDetail = !LdapAdapterCtrlr.showExtraDetail\">More Info</a>\n" +
    "                            <div class=\"clearfix\"></div>\n" +
    "                            <span ng-if=\"LdapAdapterCtrlr.showExtraDetail\"><br>{{LdapAdapterCtrlr.extraDetail}}</span>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-property-control ng-if=\"!LdapAdapterCtrlr.isEdit\" validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapAdapterCtrlr.typesDef\"\n" +
    "                    property-value=\"LdapAdapterCtrlr.ldapType\" items=\"::LdapAdapterCtrlr.ldapTypes\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapAdapterCtrlr.nameDef\"\n" +
    "                    property-value=\"LdapAdapterCtrlr.adapter.properties.findPropertyValueByName('domainName')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-labeled-control label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{'LDAP'|translate}}\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_globe_west\"></i></span>\n" +
    "                        <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                        <input type=hidden name=\"ldap\" ng-model=\"LdapAdapterCtrlr.adapter.sharedConfig\" ng-required=\"true\">\n" +
    "                        <ui-select ng-model=\"LdapAdapterCtrlr.adapter.sharedConfig\">\n" +
    "                            <ui-select-match theme=\"bootstrap\">\n" +
    "                                {{$select.selected.name}}\n" +
    "                                <span class=\"pull-right\" ng-bind-html=\"$select.selected.url\"></span>\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"ldap.sharedConfig as ldap in LdapAdapterCtrlr.ldaps | filter: {url: $select.search } | orderBy:'name'\">\n" +
    "                                <span ng-bind-html=\"ldap.name | highlight: $select.search\"></span>\n" +
    "                                <span class=\"pull-right\" ng-bind-html=\"ldap.url | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                        <span class=\"input-group-btn\">\n" +
    "                            <button class=\"btn btn-default\" type=\"button\"\n" +
    "                                    ng-click=\"LdapAdapterCtrlr.showEditLDAPDialog(false)\"><i class=\"icon icon_plus\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" type=\"button\" ng-click=\"LdapAdapterCtrlr.showEditLDAPDialog(true)\"\n" +
    "                                    ng-disabled=\"LdapAdapterCtrlr.adapter.sharedConfig==null\"><i class=\"icon icon_pencil\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" type=\"button\" ng-click=\"LdapAdapterCtrlr.deleteLdapConnection()\"\n" +
    "                                    ng-disabled=\"LdapAdapterCtrlr.adapter.sharedConfig==null || LdapAdapterCtrlr.isSharedConfigInUse()\"><i class=\"icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </span>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "                <div ng-repeat=\"propertyDef in LdapAdapterCtrlr.extraPropertyDefs\">\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                        property-def=\"propertyDef\"\n" +
    "                        property-value=\"LdapAdapterCtrlr.adapter.properties.findPropertyValueByName(propertyDef.name)\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview User Search'|translate}}\" index=\"2\" on-show=\"LdapAdapterCtrlr.getSampleUsers()\">\n" +
    "            <div block-ui=\"retrieveUsers\" style=\"height: 100%\">\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list ng-if=\"LdapAdapterCtrlr.users\" items=\"LdapAdapterCtrlr.users\" sort=\"userName\" empty-message=\"{{'No users found. Please check your search base and filter.'|translate}}\">\n" +
    "                        <div class=\"with-padding\">\n" +
    "                            <i class=\"icon icon_user list-icon pull-left\"></i> <span ng-mouseenter=\"listScope.LdapAdapterCtrlr.services.showTooltip(item)\" ng-mouseleave=\"listScope.LdapAdapterCtrlr.services.hideTooltip()\">{{item.userName+'@'+item.domainName}}</span>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <span translate>Maximum of 50 users will be retrieved.</span>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"LdapAdapterCtrlr.adapter.sharedConfig.properties.findPropertyValueByName('useGroup').value === true\" label=\"{{::'Group to Role Mapping'|translate}}\" use-form-validation=\"roles\" index=\"3\">\n" +
    "            <style>\n" +
    "                .tableListHeading label { font-size: 14px; margin: 2px 0; padding-left: 3px }\n" +
    "            </style>\n" +
    "            <form name=\"roles\" class=\"tableList\" style=\"height: 100%;\">\n" +
    "                <edge-panel>\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div class=\"row tableListHeading\">\n" +
    "                            <div class=\"col-sm-6\">\n" +
    "                                <label translate>LDAP Group</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-6\">\n" +
    "                                <label translate>Role</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <ul class=\"list-group eeList stringList\">\n" +
    "                            <li class=\"list-group-item\" style=\"padding: 8px 0;\"\n" +
    "                            ng-repeat=\"item in panelScope.LdapAdapterCtrlr.adapter.roleMappings track by $index\"\n" +
    "                            ng-class=\"{even: $even, odd: $odd, selected: panelScope.LdapAdapterCtrlr.selectedMapping === $index}\"\n" +
    "                            ng-click=\"panelScope.LdapAdapterCtrlr.selectedMapping = $index\">\n" +
    "                                <edge-labeled-control class=\"col-sm-6\" label-width=\"0\" validation=\"true\" style=\"padding-right: 15px\">\n" +
    "                                    <input type=hidden name=\"{{'group'+$index}}\" ng-model=\"item.mappedRole\" ng-required=\"true\">\n" +
    "                                    <ui-select ng-model=\"item.mappedRole\" append-to-body=\"true\" class=\"small-select-font\" theme=\"bootstrap\">\n" +
    "                                        <ui-select-match>{{panelScope.LdapAdapterCtrlr.groupDisplayName($select.selected.name)}}</ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"group in panelScope.LdapAdapterCtrlr.ldapGroups | orderBy:'name' | filter: $select.search\">\n" +
    "                                            <span ng-bind-html=\"panelScope.LdapAdapterCtrlr.groupDisplayName(group.name) | highlight: $select.search\"></span>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control class=\"col-sm-6\" label-width=\"0\" validation=\"true\" style=\"padding-right: 25px\">\n" +
    "                                    <input type=hidden name=\"{{'role'+$index}}\" ng-model=\"item.parentRole\" ng-required=\"true\">\n" +
    "                                    <div class=\"input-group\">\n" +
    "                                        <ui-select ng-model=\"item.parentRole\" append-to-body=\"true\" class=\"small-select-font\" theme=\"bootstrap\">\n" +
    "                                            <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                                            <ui-select-choices repeat=\"role in panelScope.LdapAdapterCtrlr.allRoles | orderBy:'name' | filter: $select.search\">\n" +
    "                                                <span ng-bind-html=\"role.name | highlight: $select.search\"></span>\n" +
    "                                            </ui-select-choices>\n" +
    "                                        </ui-select>\n" +
    "                                        <span class=\"input-group-btn\">\n" +
    "                                            <button class=\"btn btn-default\" type=\"button\"\n" +
    "                                                    ng-click=\"panelScope.LdapAdapterCtrlr.addNewRole()\"><i class=\"icon icon_plus\"></i>\n" +
    "                                            </button>\n" +
    "                                        </span>\n" +
    "                                    </div>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <div style=\"clear: both\"></div>\n" +
    "                            </li>\n" +
    "                        </ul>\n" +
    "                    </edge-panel-body>\n" +
    "                    <edge-panel-footer>\n" +
    "                        <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"LdapAdapterCtrlr.addRow()\"></button>\n" +
    "                        <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"LdapAdapterCtrlr.removeRow()\"\n" +
    "                                ng-disabled=\"LdapAdapterCtrlr.selectedMapping==null\"></button>\n" +
    "                    </edge-panel-footer>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/domains/ldapCleanupResult.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/domains/ldapCleanupResult.tpl.html",
    "<div class=\"list-group visChooser\">\n" +
    "    <div ng-if=\"::(users.length === 0 && roles.length === 0)\">\n" +
    "        <a href=\"javascript:void(0)\" class=\"list-group-item visChooserListItem\" style=\"background-color: transparent\">\n" +
    "            <div class=\"with-padding\" translate>No obsolete users or roles found</div>\n" +
    "        </a>\n" +
    "    </div>\n" +
    "    <div ng-if=\"::(users.length > 0 || roles.length > 0)\">\n" +
    "        <a href=\"javascript:void(0)\" ng-repeat=\"item in ::users | orderBy:'userName'\" class=\"list-group-item visChooserListItem\" ng-class=\"{odd:$odd}\">\n" +
    "            <div class=\"with-padding\">\n" +
    "                <i class=\"icon icon_user list-icon pull-left\"></i> {{::(item.userName+'@'+item.adapterName)}}\n" +
    "            </div>\n" +
    "        </a>\n" +
    "        <a href=\"javascript:void(0)\" ng-repeat=\"item in ::roles | orderBy:'name'\" class=\"list-group-item visChooserListItem\" ng-class=\"{odd:users.length % 2 ? $even : $odd}\">\n" +
    "            <div class=\"with-padding\">\n" +
    "                <i class=\"icon icon_folder_o list-icon pull-left\"></i> {{::item.name}}\n" +
    "            </div>\n" +
    "        </a>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/domains/ldapConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/domains/ldapConfigWizard.tpl.html",
    "<div ng-controller=\"LdapConfigController as LdapConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!LdapConfigCtrlr.isEdit\"\n" +
    "                 dialog-mode=\"true\"\n" +
    "                 on-save=\"LdapConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"LdapConfigCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config'|translate}}\" use-form-validation=\"config\" index=\"0\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" ng-if=\"::LdapConfigCtrlr.hasConfig\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.typeDef\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('type')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('host')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('host')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('port')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('port')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('useSsl')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('useSsl')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('credentials')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('credentials')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Groups Queries'|translate}}\" use-form-validation=\"groups\" index=\"1\">\n" +
    "            <form name=\"groups\" class=\"form-horizontal\" style=\"height: 100%;\" ng-if=\"::LdapConfigCtrlr.hasConfig\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                    property-def=\"::LdapConfigCtrlr.propertyBundleDef.findPropertyDefByName('useGroup')\"\n" +
    "                    property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('useGroup')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName('useGroup').value === true\" ng-repeat=\"propertyDef in LdapConfigCtrlr.extraPropertyDefs\">\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                        property-def=\"propertyDef\"\n" +
    "                        property-value=\"LdapConfigCtrlr.ldap.properties.findPropertyValueByName(propertyDef.name)\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/edgePasswordPolicy.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/edgePasswordPolicy.tpl.html",
    "<form name=\"passwordPolicyForm\" class=\"form-horizontal\">\n" +
    "    <div ng-if=\"embedded\">\n" +
    "        <h4 class=\"top\" translate>User Password Change</h4>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'User must change password after reset'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='passwordPolicy.passwordExpiresAfterReset' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'User must change password if last change date cannot be determined'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='passwordPolicy.expirePasswordIfLastChangeUnknown' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Throttle password change'|translate}}\"\n" +
    "            helptext=\"{{::'Limit how often user can change password. Default is no limit.'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.mayChange' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"option.mayChange\" label-width=\"6\" label=\"{{::'Password age (seconds)'|translate}}\"\n" +
    "                              helptext=\"{{::'Password can be changed again after number of seconds has elapsed since the last change'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"passwordHistory\" isrequired=\"true\" ng-model=\"option.minAge\"\n" +
    "                                 step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Keep password history'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.needHistory' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"option.needHistory\" label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Passwords to remember'|translate}}\"\n" +
    "            helptext=\"{{::'Number of Passwords to be tracked by the system when changing passwords'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"passwordHistory\" isrequired=\"true\" ng-model=\"option.history\"\n" +
    "                                 step=\"1\" minimum=\"1\" maximum=\"64\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <hr>\n" +
    "        <h4 class=\"top\" translate>Password Expiration</h4>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Password Never Expires'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.neverExpire' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <div ng-if=\"! option.neverExpire\">\n" +
    "            <edge-labeled-control label-width=\"6\" validation=\"true\"\n" +
    "                label=\"{{::'Number of days before password expires'|translate}}\">\n" +
    "                <edge-number-spinner inputname=\"passwordExpiryDays\" isrequired=\"true\" ng-model=\"option.expiration\"\n" +
    "                                     step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "            <div ng-if=\"false\">\n" +
    "            <edge-labeled-control label-width=\"6\" label=\"{{::'Override default handler for reporting expiration to the user'|translate}}\">\n" +
    "                <input type='checkbox' ng-model='option.needExpiredHandler' edge-boolean-switch>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"option.needExpiredHandler\" label-width=\"6\" label=\"{{::'Custom handler'|translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"pwExpiredHandler\" ng-model=\"option.pwExpiredHandler\">\n" +
    "            </edge-labeled-control>\n" +
    "            </div>\n" +
    "            <edge-labeled-control label-width=\"6\" label=\"{{::'Send warning before a password expires'|translate}}\">\n" +
    "                <input type='checkbox' ng-model='option.needWarning' edge-boolean-switch>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"option.needWarning\" label-width=\"6\" validation=\"true\"\n" +
    "                label=\"{{::'Number of days warning before password expires'|translate}}\">\n" +
    "                <edge-number-spinner inputname=\"warningDays\" isrequired=\"true\" ng-model=\"option.warning\"\n" +
    "                                     step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "            <div ng-if=\"false\">\n" +
    "            <edge-labeled-control label-width=\"6\" label=\"{{::'Override default handler for password expiration warning to the user'|translate}}\">\n" +
    "                <input type='checkbox' ng-model='option.needWarningHandler' edge-boolean-switch>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"option.needWarningHandler\" label-width=\"6\" label=\"{{::'Custom handler'|translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"pwWarningHandler\" ng-model=\"option.pwWarningHandler\">\n" +
    "            </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <hr>\n" +
    "        <h4 class=\"top\" translate>Password Length</h4>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Password must have a minimum number of characters'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.needMinLength' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"option.needMinLength\" label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Minimum number of characters'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"minLength\" isrequired=\"true\" ng-model=\"option.minLength\"\n" +
    "                                 step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Password must have a maximum number of characters'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.needMaxLength' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"option.needMaxLength\" label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Maximum number of characters'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"maxLength\" isrequired=\"true\" ng-model=\"option.maxLength\"\n" +
    "                                 step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <hr>\n" +
    "        <h4 class=\"top\" translate>Password Syntax</h4>\n" +
    "        <div ng-repeat=\"rule in preDefinedSyntax.rules track by $index\">\n" +
    "            <edge-labeled-control label-width=\"6\" label=\"{{::rule.description}}\">\n" +
    "                <input type='checkbox' ng-model='option.rules[$index]' edge-boolean-switch>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Custom Rule'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.needCustomRule' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <div ng-if=\"option.needCustomRule\">\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Expression'|translate}}\"\n" +
    "                              helptext=\"{{::'Regular Expression, for example a password needs a equal sign, plus sign, or ampersand sign: .*[=+&].*'|translate}}\" validation=\"true\">\n" +
    "            <input type=\"text\" class=\"form-control\" name=\"regularExpr\" required ng-model=\"option.customRule.regularExpr\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Match'|translate}}\"\n" +
    "                              helptext=\"{{::'If Yes, then the expression will be matched, else the negation of the expression will be matched'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.customRule.match' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Description'|translate}}\"\n" +
    "                              helptext=\"{{::'Help text shown to the user in the password form'|translate}}\" validation=\"true\">\n" +
    "            <input type=\"text\" class=\"form-control\" name=\"description\" required ng-model=\"option.customRule.description\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Message to the User'|translate}}\"\n" +
    "                              helptext=\"{{::'Error message to display to the user when password change failed the match'|translate}}\" validation=\"true\">\n" +
    "            <input type=\"text\" class=\"form-control\" name=\"message\" required ng-model=\"option.customRule.message\">\n" +
    "        </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <hr>\n" +
    "    </div>\n" +
    "\n" +
    "    <h4 class=\"top\" translate>Inactive Account</h4>\n" +
    "    <edge-labeled-control label-width=\"6\" label=\"{{::'Lock accounts due to inactivity'|translate}}\">\n" +
    "        <input type='checkbox' ng-model='option.needInactiveLockoutPeriod' edge-boolean-switch>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"option.needInactiveLockoutPeriod\" label-width=\"6\" validation=\"true\"\n" +
    "        label=\"{{::'Number of days of inactivity before locking accounts'|translate}}\">\n" +
    "        <edge-number-spinner inputname=\"inactiveLockoutPeriod\" isrequired=\"true\" ng-model=\"option.inactiveLockoutPeriod\"\n" +
    "                             step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "    </edge-labeled-control>\n" +
    "    <hr>\n" +
    "    <h4 class=\"top\" translate>Failure Attempts</h4>\n" +
    "    <edge-labeled-control label-width=\"6\" label=\"{{::'Lock accounts due to login failures'|translate}}\">\n" +
    "        <input type='checkbox' ng-model='option.needLockOut' edge-boolean-switch>\n" +
    "    </edge-labeled-control>\n" +
    "    <div ng-if=\"option.needLockOut\">\n" +
    "        <edge-labeled-control label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Number of consecutive failed login attempts before accounts locked'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"maxFailure\" isrequired=\"true\" ng-model=\"option.maxFailure\"\n" +
    "                                 step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Number of seconds to reset failure count'|translate}}\"\n" +
    "            helptext=\"{{::'Number of seconds elapsed before failed login count is cleared from the system. 0 means the count will not be reset.'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"resetFailureCount\" isrequired=\"true\" ng-model=\"option.resetFailureCount\"\n" +
    "                                 step=\"1\" minimum=\"0\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"6\" label=\"{{::'Lock accounts indefinitely'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='option.lockForever' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"!option.lockForever\" label-width=\"6\" validation=\"true\"\n" +
    "            label=\"{{::'Number of minutes before account is unlocked'|translate}}\"\n" +
    "            helptext=\"{{::'Once an account is locked, this is the number of minutes before the account is automatically unlocked'|translate}}\">\n" +
    "            <edge-number-spinner inputname=\"lockoutDuration\" isrequired=\"true\" ng-model=\"option.lockoutDuration\"\n" +
    "                                 step=\"1\" minimum=\"1\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/edit-domain-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/edit-domain-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\" ng-controller=\"EditDomainDialogController as ctrlr\">\n" +
    "    <div class=\"alert alert-warning\">\n" +
    "        <span translate>Users belonging to this domain will need to log in as:<br> username@&lt;Domain Name&gt;.</span>\n" +
    "    </div>\n" +
    "    <form name=\"userForm\" style=\"padding-right:10px;\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{::'Domain Name' | translate}}\" required=\"true\"\n" +
    "                                  validation=\"true\" show-feedback-icon=\"true\"\n" +
    "                                  helptext=\"{{::'Please enter the name of this domain' | translate}}\">\n" +
    "                <input type=\"text\" name=\"domainName\" class=\"form-control\" ng-model=\"ctrlr.domain.name\"\n" +
    "                       ng-required=\"true\" ng-trim=\"true\" ng-pattern=\"/^[^@]+$/\" edge-focus>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-click=\"ctrlr.handleCancelAndClose()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"userForm.$invalid\"\n" +
    "                    ng-click=\"ctrlr.handleSaveAndClose()\"><span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/edit-role-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/edit-role-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\" ng-controller=\"EditRoleDialogController as ctrlr\">\n" +
    "    <form name=\"userForm\" style=\"padding-right: 10px\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{::'Name' | translate}}\" required=\"true\"\n" +
    "                                  validation=\"true\" helptext=\"{{::'Please enter the name of this role' | translate}}\">\n" +
    "                <input type=\"text\" name=\"roleName\" class=\"form-control\" ng-model=\"ctrlr.role.name\"\n" +
    "                       ng-required=\"true\" ng-trim=\"true\" ng-pattern=\"/^.+$/\" edge-focus>\n" +
    "\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-click=\"ctrlr.handleCancelAndClose()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"userForm.$invalid\"\n" +
    "                    ng-click=\"ctrlr.handleSaveAndClose()\"><span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/provision-domains.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/provision-domains.tpl.html",
    "<edge-view class=\"edgeProvisionView\">\n" +
    "    <div class=\"col-sm-3 input-group\" style=\"padding-left:0px;padding-right:0px; margin-bottom: 15px; height:auto\">\n" +
    "        <span class=\"input-group-addon\" translate>Manage By</span>\n" +
    "        <ui-select ng-model=\"ctrlr.selectedManageBy\" theme=\"bootstrap\" on-select=\"ctrlr.handleManageBy($item)\">\n" +
    "            <ui-select-match placeholder=\"{{::'Choose...' | translate}}\">{{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item in ctrlr.manageBy | filter: $select.search\">\n" +
    "                <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <edge-split-pane value=\".4\" horizontal=\"false\" style=\"height:calc(100% - 47px)\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header label=\"{{::'Domains' | translate}}\">\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = false\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active':ctrlr.reverse == true }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = true\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_desc\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                            <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"ctrlr.domains\"\n" +
    "                               selected-item=\"ctrlr.selectedDomain\"\n" +
    "                               q=\"{name: ctrlr.q}\"\n" +
    "                               sort=\"name\"\n" +
    "                               reverse=\"ctrlr.reverse\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editSelectedDomain()\">\n" +
    "                            <i class=\"icon list-icon pull-left\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i> <span ng-bind-html=\"item.name | highlightHtmlSafe:listScope.ctrlr.q\"></span>\n" +
    "                            <div  class=\"pull-right\">\n" +
    "                                <i class=\"icon icon_user\"></i>&nbsp;<span ng-bind-html=\"item.userCount\"></span>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-success\" ng-click=\"ctrlr.addNewDomain()\">\n" +
    "                            <i class=\"icon btn_icon icon_plus\"></i>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-warning\" ng-disabled=\"ctrlr.selectedDomain == null || ! ctrlr.selectedDomain.adapter.adapterTypeHelper.canReEdit\" ng-click=\"ctrlr.editSelectedDomain()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                        <button class=\"btn btn-danger\"\n" +
    "                                ng-disabled=\"ctrlr.selectedDomain == null\"\n" +
    "                                ng-click=\"ctrlr.removeSelectedGroup()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group pull-right\">\n" +
    "                        <button class=\"btn btn-success\" ng-if=\"ctrlr.selectedDomain != null && ctrlr.selectedDomain.adapter.adapterTypeHelper.isLdap\" ng-click=\"ctrlr.ldapCleanup()\"><i class=\"icon btn_icon icon_refresh\"></i></button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "            </div>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <div ng-if=\"!ctrlr.selectedDomain\" class=\"alert alert-info\" translate>Select a Domain to Edit</div>\n" +
    "            <edge-panel ng-if=\"ctrlr.selectedDomain\">\n" +
    "                <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                    <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                        <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#content\" style=\"padding:7px 15px\"> <span\n" +
    "                                    ng-if=\"ctrlr.treeModel.changesPending\"\n" +
    "                                    class=\"text-warning icon icon_exclamation_triangle\"\n" +
    "                                    title=\"{{::'Unsaved Changes' | translate}}\"></span> <span translate>Content</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#users\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Users</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#variables\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Secured Variables</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#credentials\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Credentials</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#passwordPolicy\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Password Policy</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#preferences\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Preferences</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#kiosk\" style=\"padding:7px 15px\">\n" +
    "                                <span ng-if=\"ctrlr.kioskMode.hasUnsavedChanges\"\n" +
    "                                    class=\"text-warning icon icon_exclamation_triangle\"\n" +
    "                                    title=\"{{::'Unsaved Changes' | translate}}\"></span>\n" +
    "                                <span translate>Kiosk</span>\n" +
    "                            </a>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div style='position:absolute;left:50%;top: 50%;margin: -25px 0 0 -25px;background:rgba(255,255,255,0.5);border-radius:7px;width:50px;height:50px' \n" +
    "                        ng-if=\"ctrlr.showBusyOverlay\">\n" +
    "                        <span us-spinner=\"{hwaccel: 'true'}\"></span>\n" +
    "                    </div>\n" +
    "                    <div class=\"tab-content\" style=\"height: 100%\" ng-class=\"{'edgeBusyHide' : ctrlr.showBusyOverlay}\">\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade in active\" id=\"content\">\n" +
    "                            <edge-provision-tree tree-model=\"ctrlr.treeModel.rootFolder\"\n" +
    "                                class=\"provision-tree\" selected-node=\"ctrlr.selectedTreeNode\">\n" +
    "                            </edge-provision-tree>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"users\">\n" +
    "                            <edge-list items=\"ctrlr.users\" selected-item=\"ctrlr.selectedUser\" sort=\"userName\"\n" +
    "                                empty-message=\"{{::'There are no users in the currently selected domain.' | translate}}\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editSelectedUser()\">\n" +
    "                                    <i class=\"icon {{item.isLocked()==true ? 'icon_locked' : 'icon_user'}} list-icon pull-left\"></i>\n" +
    "                                    <span style=\"color: {{item.isLocked()==true ? 'red' : 'auto'}}\" ng-bind-html=\"item.userName+'@'+item.domainName | highlightHtmlSafe: listScope.ctrlr.q\" ng-mouseenter=\"listScope.ctrlr.showTooltip(item)\" ng-mouseleave=\"listScope.ctrlr.hideTooltip()\"></span>\n" +
    "                                    <code class=\"pull-right\">{{listScope.ctrlr.selectedDomain.adapter.adapterTypeHelper.displayName}}</code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"variables\">\n" +
    "                            <edge-list items=\"ctrlr.variables\" selected-item=\"ctrlr.selectedVariable\"\n" +
    "                                sort=\"param.parameterName\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editVariable(false)\">\n" +
    "                                    <i class=\"icon icon_var list-icon pull-left\"></i> {{item.param.parameterName}}\n" +
    "                                    <code class=\"pull-right\">\n" +
    "                                        <i class=\"{{item.iconClass}}\"></i>\n" +
    "                                        {{listScope.ctrlr.getDisplayValue(item)}}\n" +
    "                                    </code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"credentials\">\n" +
    "                            <edge-list items=\"ctrlr.credentials\" selected-item=\"ctrlr.selectedCredential\"\n" +
    "                                sort=\"param.parameterName\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editCredential()\">\n" +
    "                                    <i class=\"fa fa-key\"></i> {{item.param.parameterName}}\n" +
    "                                    <code class=\"pull-right\">\n" +
    "                                        <i class=\"{{item.iconClass}}\"></i>\n" +
    "                                        {{listScope.ctrlr.getCredentialDisplayValue(item)}}\n" +
    "                                    </code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade form-horizontal\" id=\"passwordPolicy\" style=\"padding: 20px 35px 20px 20px;\">\n" +
    "                            <h4 class=\"top\" translate>Domain Password Policy</h4>\n" +
    "                            <edge-labeled-control label-width=\"6\" label=\"{{::'Inherit Password Policy from Default'|translate}}\">\n" +
    "                                <input type='checkbox' ng-model='ctrlr.passwordPolicyModel.isInherited' edge-boolean-switch>\n" +
    "                            </edge-labeled-control>\n" +
    "                            <div ng-if=\"! ctrlr.passwordPolicyModel.isInherited\">\n" +
    "                            <hr>\n" +
    "                            <edge-password-policy password-policy=\"ctrlr.passwordPolicyModel.provisionedPolicy\"\n" +
    "                                                  pre-defined-syntax=\"::ctrlr.preDefinedSyntax\" embedded=\"ctrlr.selectedDomain.adapter.adapterTypeHelper.name === 'Embedded'\"></edge-password-policy>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"preferences\" style=\"padding: 20px;\">\n" +
    "                            <form name=\"prefsForm\" class=\"form-horizontal\">\n" +
    "                                <edge-labeled-control label=\"{{::'Inherit Session Timeout?'|translate}}\"\n" +
    "                                    helptext=\"{{::'Inherit value from Default'|translate}}\">\n" +
    "                                    <input type='checkbox' ng-model=\"ctrlr.sessionTimeout.inherited\" edge-boolean-switch ng-change=\"ctrlr.prefsDirty = true\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"ctrlr.sessionTimeout.inherited\" class=\"col-sm-8\" label-width=\"6\" label=\"{{::'Default Timeout'|translate}}\"\n" +
    "                                    helptext=\"{{::'Default system value in minutes'|translate}}\">\n" +
    "                                    <input type=\"text\" class=\"form-control\" name=\"defaultTimeout\" readonly value=\"{{::ctrlr.defaultSessionTimeout}}\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"!ctrlr.sessionTimeout.inherited\" class=\"col-sm-8\"\n" +
    "                                    label-width=\"6\" label=\"{{::'Timeout Override'|translate}}\" validation=\"true\"\n" +
    "                                    helptext=\"{{::'Domain session timeout setting in minutes. Enter a value greater than 0 or -1 for no timeout.'|translate}}\">\n" +
    "                                    <edge-number-spinner inputname=\"domainTimeout\" isrequired=\"true\"\n" +
    "                                        ng-model=\"ctrlr.sessionTimeout.value\" ng-change=\"ctrlr.prefsDirty = true\"\n" +
    "                                        inputname=\"domainTimeout\" step=\"1\" minimum=\"-1\" maximum=\"2147483647\">\n" +
    "                                    </edge-number-spinner>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <h4 style=\"clear: both; margin-bottom: 5px; padding-top: 10px;\" translate>Look And Feel</h4>\n" +
    "                                <hr style=\"margin-top: 0;\">\n" +
    "                                <edge-labeled-control style=\"clear: both\" label=\"{{::'Inherit?'|translate}}\"\n" +
    "                                                      helptext=\"{{::'Inherit value from Default'|translate}}\">\n" +
    "                                    <input type='checkbox' ng-model=\"ctrlr.inheritLaf\" edge-boolean-switch ng-change=\"ctrlr.toggleInheritLaf()\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"ctrlr.inheritLaf\" class=\"col-sm-8\" label-width=\"6\"\n" +
    "                                    label=\"{{::'Default LAF' | translate}}\">\n" +
    "                                    <input type=\"text\" class=\"form-control\" name=\"defaultLAF\" readonly\n" +
    "                                        value=\"{{::ctrlr.defaultLaf.displayName}}\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control ng-if=\"! ctrlr.inheritLaf\" style=\"clear: both;\" class=\"col-sm-8\" label-width=\"6\" label=\"{{::'LAF Override' | translate}}\" validation=\"true\">\n" +
    "                                    <input name=\"laf\" class=\"form-control\" type=\"hidden\" ng-model=\"ctrlr.selectedLaf.name\" required>\n" +
    "                                    <ui-select ng-model=\"ctrlr.selectedLaf\" theme=\"bootstrap\"\n" +
    "                                               ng-change=\"ctrlr.prefsDirty = true\">\n" +
    "                                        <ui-select-match placeholder=\"{{::'Choose a LAF...' | translate}}\">{{$select.selected.displayName}}\n" +
    "                                        </ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"item in (ctrlr.lafs | filter: {displayName: $select.search})\">\n" +
    "                                            <div ng-bind-html=\"item.displayName | highlight: $select.search\"></div>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control style=\"clear: both;\" class=\"col-sm-8\" label-width=\"6\"\n" +
    "                                    helptext=\"{{::'Base theme to use; this is overridden with optional override.css file.'|translate}}\"\n" +
    "                                    label=\"{{::'Theme' | translate}}\">\n" +
    "                                    <input type=\"text\" class=\"form-control\" name=\"theme\" readonly ng-model=\"ctrlr.selectedLaf.themeName\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control style=\"clear: both;\" class=\"col-sm-8\" label-width=\"6\"\n" +
    "                                    helptext=\"{{::'This title prefix appears in browser\\'s tab. This value is prepended to the current page name. For example: CompanyA:'|translate}}\"\n" +
    "                                    label=\"{{::'Title Prefix' | translate}}\">\n" +
    "                                    <input type=\"text\" class=\"form-control\" name=\"titlePrefix\" readonly\n" +
    "                                           ng-model=\"ctrlr.selectedLaf.titlePrefix\">\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control style=\"clear: both;\" label-width=\"4\" label=\"{{::'Banner Logo'|translate}}\">\n" +
    "                                    <div class=\"input-group\">\n" +
    "                                        <span class=\"input-group-addon\">\n" +
    "                                            <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.bannerLogoSafe}}\" style=\"height: 16px\">\n" +
    "                                        </span>\n" +
    "                                        <input class=\"form-control\" name=\"bannerlogo\" readonly\n" +
    "                                            ng-model=\"ctrlr.selectedLaf.bannerLogo\">\n" +
    "                                    </div>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control style=\"clear: both;\" label-width=\"4\" label=\"{{::'About Logo'|translate}}\">\n" +
    "                                    <div class=\"input-group\">\n" +
    "                                        <span class=\"input-group-addon\">\n" +
    "                                            <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.aboutLogoSafe}}\" style=\"height: 16px\">\n" +
    "                                        </span>\n" +
    "                                        <input class=\"form-control\" name=\"aboutlogo\" readonly\n" +
    "                                            ng-model=\"ctrlr.selectedLaf.aboutLogo\">\n" +
    "                                    </div>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control style=\"clear: both;\" label-width=\"4\"\n" +
    "                                    label=\"{{::'Favicon' | translate}}\">\n" +
    "                                    <div class=\"input-group\">\n" +
    "                                        <span class=\"input-group-addon\">\n" +
    "                                            <img class=\"icon\" ng-src=\"{{ctrlr.selectedLaf.faviconSafe}}\" style=\"width: 16px; height: 16px\">\n" +
    "                                        </span>\n" +
    "                                        <input type=\"text\" class=\"form-control\" name=\"favicon\" readonly ng-model=\"ctrlr.selectedLaf.favicon\">\n" +
    "                                    </div>\n" +
    "                                </edge-labeled-control>\n" +
    "                            </form>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"kiosk\" style=\"height: 100%; padding: 20px;\">\n" +
    "                            <edge-kiosk-pages-editor active=\"ctrlr.activeTab === '#kiosk'\" kiosk-mode=\"ctrlr.kioskMode\" available-pages=\"ctrlr.pages\"></edge-kiosk-pages-editor>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer ng-if=\"ctrlr.activeTab !== '#users' || ctrlr.selectedDomain.adapter.adapterTypeHelper.allowUserAction\">\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#content'\">\n" +
    "                        <div class=\"btn-group dropup\">\n" +
    "                            <edge-split-button items=\"ctrlr.treeActions\"\n" +
    "                                               label-field=\"label\"\n" +
    "                                               on-selection=\"ctrlr.treeActionClick(selectedItem)\"\n" +
    "                                               selected-item=\"ctrlr.selectedAction\">\n" +
    "                                {{item.label}}\n" +
    "                            </edge-split-button>\n" +
    "                        </div>\n" +
    "                        <div style=\"float: right; display: inline\">\n" +
    "                            <button class=\"btn btn-primary pull-right\"\n" +
    "                                    ng-class=\"{'pulse':ctrlr.treeModel.changesPending}\"\n" +
    "                                    ng-click=\"ctrlr.saveProvisionContent()\">\n" +
    "                                <span ng-if=\"ctrlr.treeModel.changesPending\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"\n" +
    "                                      title=\"{{::'Unsaved Changes' | translate}}\"></span> <span translate>Save</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#users'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-success\"\n" +
    "                                ng-click=\"ctrlr.addUserToGroup()\">\n" +
    "                                <i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                            <button class=\"btn btn-warning\"\n" +
    "                                    ng-disabled=\"ctrlr.selectedUser == null\"\n" +
    "                                    ng-click=\"ctrlr.editSelectedUser()\"><i class=\"icon btn_icon icon_pencil\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-danger\"\n" +
    "                                    ng-disabled=\"ctrlr.selectedUser == null\"\n" +
    "                                    ng-click=\"ctrlr.removeSelectedUser()\"><i class=\"icon btn_icon icon_trash\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#variables'\">\n" +
    "                        <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedVariable\"\n" +
    "                                ng-click=\"ctrlr.editVariable()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#credentials'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedCredential\"\n" +
    "                                    ng-click=\"ctrlr.editCredential()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#passwordPolicy'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                        <div style=\"float: right; display: inline\">\n" +
    "                            <button class=\"btn btn-primary\"\n" +
    "                                    ng-class=\"{'pulse':ctrlr.passwordPolicyModel.changesPending}\"\n" +
    "                                    ng-click=\"ctrlr.savePasswordPolicy()\">\n" +
    "                                    <span ng-if=\"ctrlr.passwordPolicyModel.changesPending\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"\n" +
    "                                      title=\"{{::'Unsaved Changes' | translate}}\"></span><span translate>Save</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#kiosk'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                        <div style=\"float: right; display: inline\">\n" +
    "                            <button class=\"btn btn-primary\"\n" +
    "                                    ng-class=\"{'pulse':ctrlr.kioskMode.hasUnsavedChanges}\"\n" +
    "                                    ng-click=\"ctrlr.saveKioskMode()\">\n" +
    "                                    <span ng-if=\"ctrlr.kioskMode.hasUnsavedChanges\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"\n" +
    "                                      title=\"{{::'Unsaved Changes' | translate}}\"></span><span translate>Save</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#preferences'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <div style=\"float: right; display: inline\">\n" +
    "                                <button class=\"btn btn-primary\"\n" +
    "                                        ng-class=\"{'pulse':ctrlr.prefsDirty}\"\n" +
    "                                        ng-click=\"ctrlr.savePreferences()\">\n" +
    "                                    <span ng-if=\"ctrlr.prefsDirty\"\n" +
    "                                          class=\"icon icon_exclamation_triangle\"\n" +
    "                                          title=\"{{::'Unsaved Changes' | translate}}\"></span><span translate>Save</span>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/groups/provision-roles.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/groups/provision-roles.tpl.html",
    "<edge-view class=\"edgeProvisionView\">\n" +
    "    <div class=\"col-sm-3 input-group\" style=\"padding-left:0px;padding-right:0px; margin-bottom: 15px; height:auto\">\n" +
    "        <span class=\"input-group-addon\" translate>Manage By</span>\n" +
    "        <ui-select ng-model=\"ctrlr.selectedManageBy\" theme=\"bootstrap\" on-select=\"ctrlr.handleManageBy($item)\">\n" +
    "            <ui-select-match placeholder=\"{{::'Choose...' | translate}}\">{{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item in ctrlr.manageBy | filter: $select.search\">\n" +
    "                <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <edge-split-pane value=\".4\" horizontal=\"false\" style=\"height:calc(100% - 47px)\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header label=\"{{::'Roles' | translate}}\">\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = false\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active':ctrlr.reverse == true }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = true\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_desc\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                            <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"ctrlr.roles\"\n" +
    "                               selected-item=\"ctrlr.selectedRole\"\n" +
    "                               q=\"{name: ctrlr.q}\"\n" +
    "                               reverse=\"ctrlr.reverse\">\n" +
    "                        <div class=\"with-padding\">\n" +
    "                            <i ng-if=\"listScope.ctrlr.isDomain(item)\" class=\"icon icon_user_group\"></i>\n" +
    "                            <i ng-if=\"!listScope.ctrlr.isDomain(item)\" class=\"icon icon_folder_o\"></i>\n" +
    "                            &nbsp;<span ng-bind-html=\"item.name | highlightHtmlSafe:listScope.ctrlr.q\"></span>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-success\" ng-click=\"ctrlr.addNewRole()\"><i class=\"icon btn_icon icon_plus\"></i>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-danger\"\n" +
    "                                ng-disabled=\"ctrlr.selectedRole == null\"\n" +
    "                                ng-click=\"ctrlr.removeSelectedRole()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "            </div>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <div ng-if=\"!ctrlr.selectedRole\" class=\"alert alert-info\" translate>Select a Role to Edit</div>\n" +
    "            <edge-panel ng-if=\"ctrlr.selectedRole\">\n" +
    "                <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                    <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                        <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#content\" style=\"padding:7px 15px\"> <span\n" +
    "                                    ng-if=\"ctrlr.treeModel.changesPending\"\n" +
    "                                    class=\"text-warning icon icon_exclamation_triangle\"\n" +
    "                                    title=\"{{::'Unsaved Changes' | translate}}\"></span> <span translate>Content</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#users\" style=\"padding:7px 15px\"><span\n" +
    "                                    translate>Users</span></a>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div style='position:absolute;left:50%;top: 50%;margin: -25px 0 0 -25px;background:rgba(255,255,255,0.5);border-radius:7px;width:50px;height:50px' \n" +
    "                        ng-if=\"ctrlr.showBusyOverlay\">\n" +
    "                        <span us-spinner=\"{hwaccel: 'true'}\"></span>\n" +
    "                    </div>\n" +
    "                    <div class=\"tab-content\" style=\"height: 100%\" ng-class=\"{'edgeBusyHide' : ctrlr.showBusyOverlay}\">\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade in active\" id=\"content\">\n" +
    "                            <edge-provision-tree tree-model=\"ctrlr.treeModel.rootFolder\"\n" +
    "                                class=\"provision-tree\" selected-node=\"ctrlr.selectedTreeNode\">\n" +
    "                            <edge-provision-tree/>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"users\">\n" +
    "                            <edge-list items=\"ctrlr.users\" selected-item=\"ctrlr.selectedUser\" sort=\"userName\"\n" +
    "                                empty-message=\"{{::'There are no users in the currently selected role.' | translate}}\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editSelectedUser()\">\n" +
    "                                    <i class=\"icon icon_user list-icon pull-left\"></i> <span ng-bind-html=\"item.userName+'@'+item.domainName | highlightHtmlSafe: listScope.ctrlr.q\" ng-mouseenter=\"listScope.ctrlr.showTooltip(item)\" ng-mouseleave=\"listScope.ctrlr.hideTooltip()\"></span>\n" +
    "                                    <code class=\"pull-right\">{{item.adapter.adapterTypeHelper.displayName}}</code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#content'\">\n" +
    "                        <div class=\"btn-group dropup\">\n" +
    "                            <edge-split-button items=\"ctrlr.treeActions\"\n" +
    "                                               label-field=\"label\"\n" +
    "                                               on-selection=\"ctrlr.treeActionClick(selectedItem)\"\n" +
    "                                               selected-item=\"ctrlr.selectedAction\">\n" +
    "                                {{item.label}}\n" +
    "                            </edge-split-button>\n" +
    "                        </div>\n" +
    "                        <div style=\"float: right; display: inline\">\n" +
    "                            <button class=\"btn btn-primary pull-right\"\n" +
    "                                    ng-class=\"{'pulse':ctrlr.treeModel.changesPending}\"\n" +
    "                                    ng-click=\"ctrlr.saveProvisionContent()\">\n" +
    "                                <span ng-if=\"ctrlr.treeModel.changesPending\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"\n" +
    "                                      title=\"{{::'Unsaved Changes' | translate}}\"></span> <span translate>Save</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#users'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-success\" ng-click=\"ctrlr.addUserToGroup()\">\n" +
    "                                <i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                            <button class=\"btn btn-warning\"\n" +
    "                                    ng-disabled=\"ctrlr.selectedUser == null || ! ctrlr.selectedUser.adapter.adapterTypeHelper.allowUserAction\"\n" +
    "                                    ng-click=\"ctrlr.editSelectedUser()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                            <button class=\"btn btn-danger\"\n" +
    "                                    ng-disabled=\"ctrlr.selectedUser == nul\"\n" +
    "                                    ng-click=\"ctrlr.removeSelectedUser()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/kiosk/edgeKioskPagesEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/kiosk/edgeKioskPagesEditor.tpl.html",
    "<form name=\"kioskForm\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "    <edge-labeled-control style=\"margin-right: 20px;\" label=\"{{::'Enable Kiosk Mode'|translate}}\">\n" +
    "        <input type='checkbox' ng-model='kioskMode.on' edge-boolean-switch>\n" +
    "    </edge-labeled-control>\n" +
    "    <div ng-if=\"kioskMode.on\">\n" +
    "        <edge-labeled-control style=\"margin-right: 20px;\" label=\"{{::'Page Duration'|translate}}\" validation=\"true\" helptext=\"{{::'How many seconds to display for each page. Minimum is 5 seconds'|translate}}\">\n" +
    "            <edge-number-spinner class=\"col-sm-6\" inputname=\"perPageTime\" isrequired=\"true\" ng-model=\"kioskMode.perPageTime\" step=\"1\" minimum=\"5\">\n" +
    "            </edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control style=\"margin-right: 20px;\" label=\"{{::'Hide Header'|translate}}\" helptext=\"{{::'Hide page header bar and breadcrumb bar. If hide header is on, then the Kiosk control will be hidden as well.'|translate}}\">\n" +
    "            <input type='checkbox' ng-model='kioskMode.hideHeader' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control style=\"margin-right: 20px;\" label=\"{{::'Reload Time'|translate}}\" validation=\"true\" helptext=\"{{::'How many minutes before the application reloads itself. This prevents memory leaks in the browser window. If Kiosk mode is paused by the user, then refresh will be stopped as well. The minimum value is 1 minute.'|translate}}\">\n" +
    "            <edge-number-spinner class=\"col-sm-6\" inputname=\"reloadTime\" isrequired=\"true\" ng-model=\"kioskMode.reloadTime\" step=\"1\" minimum=\"1\">\n" +
    "            </edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "        <div class=\"alert alert-danger\" ng-if=\"availablePages.length < 1\" translate>\n" +
    "            There is no page provisioned, please provision some pages first.\n" +
    "        </div>\n" +
    "        <!-- placeholder div for set height during window resize event and tab visible event, it use to\n" +
    "            guarantee that the dom element will exist as panel has conditional statement on it -->\n" +
    "        <div class=\"edgeKisokPagesPanelContainer\">\n" +
    "            <edge-panel ng-if=\"availablePages.length > 0\" style=\"height: 100%\">\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-5\">\n" +
    "                            <label translate style=\"padding-left:15px\">Page</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-7\">\n" +
    "                            <label translate style=\"padding-left:5px\">Page Vars with override</label>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list selected-item=\"Controller.selectedItem\" type=\"reorderable\" items=\"kioskMode.getPagesConfig()\" empty-message=\"{{::' '}}\">\n" +
    "                        <div class=\"row with-padding\" ng-dblclick=\"listScope.Controller.editPage()\">\n" +
    "                            <div class=\"col-sm-5\">\n" +
    "                                <div class=\"input-group\">\n" +
    "                                    <ui-select ng-if=\"listScope.Controller.count % 2 === 1\" ng-model=\"item.id\" append-to-body=\"true\" class=\"small-select-font\" theme=\"bootstrap\" on-select=\"listScope.Controller.clearPageVars($select.selected)\">\n" +
    "                                        <ui-select-match><span ng-bind-html=\"listScope.Controller.getSelectedPath($select.selected, item.id)\"></span></ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"page.id as page in listScope.availablePages | filter: {menuPath: $select.search}\" style=\"width: 150%\">\n" +
    "                                            <span ng-bind-html=\"page.menuPath | highlight: $select.search\"></span>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "\n" +
    "                                    <ui-select ng-if=\"listScope.Controller.count % 2 === 0\" ng-model=\"item.id\" append-to-body=\"true\" class=\"small-select-font\" theme=\"bootstrap\" on-select=\"listScope.Controller.clearPageVars($select.selected)\">\n" +
    "                                        <ui-select-match><span ng-bind-html=\"listScope.Controller.getSelectedPath($select.selected, item.id)\"></span></ui-select-match>\n" +
    "                                        <ui-select-choices repeat=\"page.id as page in listScope.availablePages | filter: {menuPath: $select.search}\" style=\"width: 150%\">\n" +
    "                                            <span ng-bind-html=\"page.menuPath | highlight: $select.search\"></span>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-7\">\n" +
    "                                <div class=\"form-control small-select-font\" disabled style=\"white-space: nowrap; text-overflow: ellipsis; overflow: hidden;\" title=\"{{item.pageVarsTitleString}}\" ng-bind-html=\"item.pageVarsString\"></div>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button type=\"button\" class=\"btn btn-success icon icon_plus\" ng-click=\"Controller.addRow(false)\"></button>\n" +
    "                        <button type=\"button\" class=\"btn btn-warning icon icon_pencil\" ng-click=\"Controller.editPage()\" ng-disabled=\"Controller.selectedItem==null || Controller.selectedItem.index < 0\"></button>\n" +
    "                        <button type=\"button\" class=\"btn btn-success icon icon_copy\" ng-click=\"Controller.addRow(true)\" ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "                        <button type=\"button\" class=\"btn btn-danger icon icon_trash\" ng-click=\"Controller.removeRow()\"\n" +
    "                            ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/kiosk/edgeKioskPagevarControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/kiosk/edgeKioskPagevarControl.tpl.html",
    "<div class=\"form-group\" style=\"padding:2px\">\n" +
    "    <div class=\"row\" ng-switch=\"inputInfo.type\">\n" +
    "        <div class=\"col-sm-12\">\n" +
    "            <div ng-switch-when=\"Number\">\n" +
    "                <edge-number-spinner inputname=\"{{pageVar.id}}\" ng-model=\"shadowPageVars[pageVar.name].value\"\n" +
    "                                     placeholder=\"{{inputInfo.spinner.placeholder}}\"\n" +
    "                                     reload=\"inputInfo.spinner.reload\"\n" +
    "                                     step=\"inputInfo.spinner.interval\" minimum=\"inputInfo.spinner.min\"\n" +
    "                                     maximum=\"inputInfo.spinner.max\">\n" +
    "                </edge-number-spinner>\n" +
    "            </div>\n" +
    "            <div ng-switch-when=\"Combo\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"shadowPageVars[pageVar.name].value\" append-to-body=\"true\" theme=\"bootstrap\">\n" +
    "                    <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item.value as item in inputInfo.choices | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"item.label | highlightHtmlSafe: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </div>\n" +
    "            <div ng-switch-when=\"Buttons\">\n" +
    "                <div class=\"btn-group\" role=\"group\">\n" +
    "                    <button type=\"button\" ng-repeat=\"item in inputInfo.choices\" class=\"btn btn-default\" ng-class=\"{'btn-primary':shadowPageVars[pageVar.name].value == item.value}\" ng-click=\"updatePageVarValue4ButtonGroup(shadowPageVars[pageVar.name], item)\">{{item.label}}</button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-switch-default>\n" +
    "                <input type=\"text\" class=\"form-control\" ng-model=\"shadowPageVars[pageVar.name].value\" ng-trim=\"false\">\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/kiosk/edit-page-setting-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/kiosk/edit-page-setting-dialog.tpl.html",
    "<form name=\"pageVarsOverrideForm\" class=\"form-horizontal\">\n" +
    "    <edge-labeled-control label=\"{{::'Page Duration'|translate}}\" validation=\"true\" helptext=\"{{::'How many seconds to display for this page. Minimum is 5 seconds'|translate}}\">\n" +
    "        <edge-number-spinner class=\"col-sm-6\" inputname=\"pageTime\" ng-model=\"duration.value\" step=\"1\" minimum=\"5\">\n" +
    "        </edge-number-spinner>\n" +
    "    </edge-labeled-control>\n" +
    "    <hr ng-if=\"pageVars.length > 0\">\n" +
    "    <edge-labeled-control ng-repeat=\"pageVar in pageVars track by $index\" label=\"{{::pageVar.name}}\" style=\"margin-bottom: 0\">\n" +
    "        <edge-kiosk-pagevar-control style=\"margin-left: 3px; margin-right: 10px;\"></edge-kiosk-pagevar-control>\n" +
    "    </edge-labeled-control>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/security-credential-edit.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/security-credential-edit.tpl.html",
    "<form name=\"ssoTokenForm\" class=\"form-horizontal\">\n" +
    "    <style>\n" +
    "        form[name=ssoTokenForm] .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n" +
    "            border-radius: 0;\n" +
    "        }\n" +
    "        form[name=ssoTokenForm] .input-group .form-control.ui-select-toggle, form[name=ssoTokenForm] > .ui-select-bootstrap > input.ui-select-search.form-control {\n" +
    "        border-top-right-radius: 3px;\n" +
    "        border-bottom-right-radius: 3px;\n" +
    "        border-top-left-radius: 0;\n" +
    "        border-bottom-left-radius: 0;\n" +
    "    }\n" +
    "    </style>\n" +
    "    <div class=\"col-sm-12\">\n" +
    "        <edge-labeled-control label-width=\"4\" label=\"{{::'Inherited?'|translate}}\">\n" +
    "            <input type=\"checkbox\" ng-model=\"Controller.inherited\" edge-boolean-switch data-on-text=\"{{::'Yes'|translate}}\" data-off-text=\"{{::'No'|translate}}\" ng-change=\"Controller.inheritedToggled()\">\n" +
    "        </edge-labeled-control>\n" +
    "        <div ng-if=\"Controller.inherited\">\n" +
    "            <edge-labeled-control ng-if=\"::!Controller.credential.hasInheritedValue\" label-width=\"4\" label=\"{{::Controller.getInheritedLabel()}}\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <div class=\"input-group-addon\">\n" +
    "                        <i class=\"glyphicon glyphicon-globe\"></i>\n" +
    "                    </div>\n" +
    "                    <input type=\"text\" class=\"form-control\" ng-value=\"::'undefined'|translate\" disabled>\n" +
    "                </div>\n" +
    "            </edge-labeled-control>\n" +
    "            <div ng-if=\"::Controller.credential.hasInheritedValue\">\n" +
    "                <label class=\"col-sm-4 control-label\">{{::Controller.getInheritedLabel()}}</label>\n" +
    "                <div class=\"col-sm-8\" style=\"margin-bottom: -15px\">\n" +
    "                    <edge-credential-set viewonly=\"true\" ng-model=\"Controller.credential.inheritedValue\" expressions=\"Controller.expressions\"></edge-credential-set>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-if=\"Controller.credentialSet.credentials.length > 0\">\n" +
    "            <label class=\"col-sm-4 control-label\" translate>Credential</label>\n" +
    "            <div class=\"col-sm-8\" style=\"margin-bottom: -15px\">\n" +
    "                <edge-credential-set ng-model=\"Controller.credentialSet\" expressions=\"Controller.expressions\"></edge-credential-set>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/security-variable-edit.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/security-variable-edit.tpl.html",
    "<form name=\"variableForm\" class=\"form-horizontal\">\n" +
    "    <div class=\"col-sm-12\">\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Inherited?'|translate}}\">\n" +
    "            <input type=\"checkbox\" ng-model=\"Controller.inherited\" edge-boolean-switch data-on-text=\"{{::'Yes'|translate}}\" data-off-text=\"{{::'No'|translate}}\" ng-change=\"Controller.inheritedToggled()\">\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label-width=\"3\" label=\"{{::'Default Value'|translate}}\" ng-show=\"Controller.inherited && Controller.variable.canBeInherited\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <div class=\"input-group-addon\">\n" +
    "                    <i ng-class=\"Controller.variable.inheritedIconClass\"></i>\n" +
    "                </div>\n" +
    "                <input type=\"text\" ng-trim=\"false\" class=\"form-control\" ng-value=\"::Controller.variable.inheritedValue.toSummaryString()\" disabled>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "        <div class=\"row\" ng-if=\"Controller.inherited && ! Controller.variable.canBeInherited\">\n" +
    "            <div class=\"col-sm-3\"></div>\n" +
    "            <div class=\"col-sm-9\">\n" +
    "                <div class=\"alert alert-warning\">\n" +
    "                    <span translate>A default value does not exist for System Default or Domain.  Setting this variable to inherited may produce unintended problems.</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <edge-labeled-control ng-if=\"! Controller.inherited\" label-width=\"3\" label=\"{{::'Value'|translate}}\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-4\">\n" +
    "                    <div class=\"btn-group btn-group-justified\">\n" +
    "                        <select ng-model=\"Controller.type\"\n" +
    "                                class=\"form-control\"\n" +
    "                                ng-change=\"Controller.handleTypeChange()\">\n" +
    "                            <option value=\"static\" translate>Static</option>\n" +
    "                            <option value=\"expression\" translate>Expression</option>\n" +
    "                        </select>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-8\">\n" +
    "                    <div ng-if=\"Controller.type === 'expression'\" class=\"input-group\" style=\"width:100%\">\n" +
    "                        <ui-select ng-model=\"Controller.variable.value.expression\" append-to-body=\"true\">\n" +
    "                            <ui-select-match theme=\"bootstrap\">{{$select.selected}}</ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item in Controller.getExpressions($select.search)\">\n" +
    "                                <span ng-bind-html=\"item| highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </div>\n" +
    "                    <input name=\"value\"\n" +
    "                           type=\"text\"\n" +
    "                           class=\"form-control\"\n" +
    "                           ng-model=\"Controller.variable.value.primitiveValue\"\n" +
    "                           ng-trim=\"false\"\n" +
    "                           ng-if=\"Controller.type === 'static'\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/users/add-existing-user-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/users/add-existing-user-dialog.tpl.html",
    "<div ng-controller=\"AddExistingUserDialogController as ctrlr\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"form-group\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                    <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\"\n" +
    "                        placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                        ng-click=\"ctrlr.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                        title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                    <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-class=\"{ 'active' :ctrlr.reverse == true }\"\n" +
    "                        ng-click=\"ctrlr.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                        title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                    <i class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-click=\"ctrlr.toggleSelectAll(false)\"\n" +
    "                        title=\"{{::'Unselect All' | translate}}\">\n" +
    "                    <i class=\"icon icon_select_box\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-click=\"ctrlr.toggleSelectAll(true)\"\n" +
    "                        title=\"{{::'Select All' | translate}}\">\n" +
    "                    <i class=\"icon icon_select_checked\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-list selected-items=\"ctrlr.selectedUsers\" change-selected-items=\"ctrlr.filteredUsers\" style=\"min-height: 40em\"\n" +
    "               multiple=\"true\" items=\"ctrlr.availableUsers\" sort=\"userName\" q=\"ctrlr.filterUsers\" reverse=\"ctrlr.reverse\">\n" +
    "        <div class=\"with-padding\" style=\"padding-right: 20px\">\n" +
    "            <i class=\"icon icon_user list-icon pull-left\"></i> <span ng-bind-html=\"item.userName+'@'+item.domainName | highlightHtmlSafe: listScope.ctrlr.q\" ng-mouseenter=\"listScope.ctrlr.services.showTooltip(item)\" ng-mouseleave=\"listScope.ctrlr.services.hideTooltip()\"></span>\n" +
    "            <code class=\"pull-right\" ng-bind-html=\"item.adapter.adapterTypeHelper.displayName\"></code>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-click=\"ctrlr.handleCancelAndClose()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-click=\"ctrlr.handleSaveAndClose()\"><span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/users/add-role-to-user-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/users/add-role-to-user-dialog.tpl.html",
    "<div ng-controller=\"AddRoleToUserDialogController as ctrlr\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"form-group\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                    <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\"\n" +
    "                        placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"btn-group\">\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                        ng-click=\"ctrlr.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                        title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                    <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-sm btn-default\" ng-class=\"{ 'active' :ctrlr.reverse == true }\"\n" +
    "                        ng-click=\"ctrlr.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                        title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                    <i class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-list selected-items=\"ctrlr.selectedRoles\" multiple=\"true\" items=\"ctrlr.filteredRoles\"\n" +
    "               sort=\"name\" q=\"ctrlr.filterRoles\" reverse=\"ctrlr.reverse\" style=\"min-height: 40em\"\n" +
    "               empty-message=\"{{::'There are no more roles available to add this user to...' | translate}}\">\n" +
    "        <div class=\"with-padding\" style=\"padding-right: 20px\">\n" +
    "            <i class=\"icon icon_folder_o list-icon pull-left\"></i> &nbsp;<span ng-bind-html=\"item.name | highlight:listScope.ctrlr.q\"></span>\n" +
    "            <span class=\"pull-right\">\n" +
    "                <i class=\"icon icon_user\"></i>&nbsp;<span ng-bind-html=\"item.userCount\"></span>\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-click=\"ctrlr.handleCancelAndClose()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"ctrlr.selectedRoles.length < 1\"\n" +
    "                    ng-click=\"ctrlr.addSelectedRolesToUser()\"><span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/users/edit-user-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/users/edit-user-dialog.tpl.html",
    "<div style=\"width:100%;height:100%\" ng-controller=\"EditUserDialogController as ctrlr\">\n" +
    "    <form name=\"userForm\" style=\"padding-right: 10px;\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control ng-if=\"ctrlr.showDomain\" label=\"{{::'Domain' | translate}}\"\n" +
    "                                  validation=\"true\" required=\"true\"\n" +
    "                                  helptext=\"{{::'Please select a domain this new user will belong to' | translate}}\">\n" +
    "                <input type=hidden name=\"domainSuffix\" ng-model=\"ctrlr.domainSuffix\" ng-required=\"true\">\n" +
    "                <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"ctrlr.domainSuffix\" focus-on='edgeFocusOnUISelect'>\n" +
    "                    <ui-select-match theme=\"bootstrap\" placeholder=\"{{::'Choose a domain...'|translate}}\">\n" +
    "                        {{$select.selected.name}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item.domainSuffix as item in (ctrlr.domains | filter: $select.search)\">\n" +
    "                        <span ng-bind-html=\"item.name | highlightHtmlSafe: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"!ctrlr.showDomain\" label=\"{{::'Domain' | translate}}\"\n" +
    "                                 >\n" +
    "                <input type=\"text\" class=\"form-control\" ng-model=\"ctrlr.domainSuffix\" disabled>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'First Name' | translate}}\" required=\"false\"\n" +
    "                                  helptext=\"{{::'Please enter the first name of this user' | translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" ng-model=\"ctrlr.user.firstName\">\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Last Name' | translate}}\" required=\"false\"\n" +
    "                                  helptext=\"{{'Please enter the last name of this user' | translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" ng-model=\"ctrlr.user.lastName\">\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'User Name' | translate}}\" validation=\"true\" required=\"true\"\n" +
    "                                  helptext=\"{{::'Please enter the user name to be prefixed to the @domain to be used when signing in.' | translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"userName\" ng-model=\"ctrlr.user.userName\"\n" +
    "                       ng-required=\"true\" ng-trim=\"true\" ng-pattern=\"/^.+$/\" ng-disabled=\"ctrlr.isEdit\" edge-focus-on>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Password' | translate}}\"\n" +
    "                                  required=\"!ctrlr.isEdit\" validation=\"true\"\n" +
    "                                  helptext=\"{{::'Please enter the user password to be used when logging in' | translate}}\">\n" +
    "                <input type=\"password\" name=\"password\" class=\"form-control\" ng-model=\"ctrlr.user.password\"\n" +
    "                    ng-model-options=\"{allowInvalid: true}\"\n" +
    "                    ng-required=\"!ctrlr.isEdit\" ng-change=\"ctrlr.setupValidator('password')\">\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Confirm Password' | translate}}\"\n" +
    "                                  required=\"!ctrlr.isEdit\" validation=\"true\"\n" +
    "                                  helptext=\"{{::'Please enter the same password' | translate}}\">\n" +
    "                <input type=\"password\" class=\"form-control\" name=\"confirmPassword\" ng-model=\"ctrlr.confirmPassword\"\n" +
    "                    ng-model-options=\"{allowInvalid: true}\"\n" +
    "                    ng-required=\"!ctrlr.isEdit\" ng-change=\"ctrlr.setupValidator('confirmPassword')\">\n" +
    "            </edge-labeled-control>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-4\"></div>\n" +
    "                <div class=\"col-sm-8\">\n" +
    "                    <div ng-if=\"ctrlr.pwdPolicy.rules.length > 0 || ctrlr.pwdPolicy.minLength > 0 || ctrlr.pwdPolicy.maxLength > 0\"\n" +
    "                         class=\"alert alert-info\">\n" +
    "                        <label>{{::'Password Policy' | translate}}</label>\n" +
    "                        <label ng-if=\"ctrlr.pwdPolicy.minLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"ctrlr.passwordModelValue && ctrlr.passwordModelValue.length >= ctrlr.pwdPolicy.minLength\"> <span translate translate-params-min=\"ctrlr.pwdPolicy.minLength\">Minimum password length is {{min}}</span></label>\n" +
    "                        <label ng-if=\"ctrlr.pwdPolicy.maxLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"ctrlr.passwordModelValue && ctrlr.passwordModelValue.length <= ctrlr.pwdPolicy.maxLength\"> <span translate translate-params-max=\"ctrlr.pwdPolicy.maxLength\">Maximum password length is {{max}}</span></label>\n" +
    "                        <label ng-repeat=\"rule in ctrlr.pwdPolicy.rules\">\n" +
    "                            <input type=\"checkbox\" disabled ng-checked=\"ctrlr.passwordModelValue && rule.satisfy(ctrlr.passwordModelValue)\"> {{rule.description}}\n" +
    "                        </label>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <edge-labeled-control label=\"{{::'User Locked'|translate}}\" required=\"false\">\n" +
    "                <input type='checkbox' ng-model=\"ctrlr.isLocked\" edge-boolean-switch>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"ctrlr.isLocked\" label=\"{{::'Lock Reason'|translate}}\"  required=\"false\"\n" +
    "                                  helptext=\"{{::'Lock Reason'|translate}}\">\n" +
    "                <input type=\"text\" class=\"form-control\" name=\"lockReason\" ng-model=\"ctrlr.user.accountUserMeta.lockReason\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-click=\"ctrlr.handleCancel()\"><span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"userForm.$invalid\"\n" +
    "                    ng-click=\"ctrlr.handleSave()\"><span translate>Save</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/admin/provision/users/provision-users.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/admin/provision/users/provision-users.tpl.html",
    "<edge-view class=\"edgeProvisionView\">\n" +
    "    <div class=\"col-sm-3 input-group\" style=\"padding-left:0px;padding-right:0px; margin-bottom: 15px; height:auto\">\n" +
    "        <span class=\"input-group-addon\" translate>Manage By</span>\n" +
    "        <ui-select ng-model=\"ctrlr.selectedManageBy\" theme=\"bootstrap\" on-select=\"ctrlr.handleManageBy($item)\">\n" +
    "            <ui-select-match placeholder=\"{{::'Choose...' | translate}}\">{{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item in ctrlr.manageBy | filter: $select.search\">\n" +
    "                <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <edge-split-pane value=\".5\" horizontal=\"false\" style=\"height:calc(100% - 47px)\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"panel-heading-control pull-left\" style=\"margin-left: -6px\">\n" +
    "                        <div class=\"col-sm-5\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\"><i class=\"icon icon_user_group\"></i></span>\n" +
    "                                <ui-select ng-model=\"ctrlr.selectedDomain\">\n" +
    "                                    <ui-select-match theme=\"bootstrap\" placeholder=\"{{::'All Domains' | translate}}\" allow-clear=\"true\">\n" +
    "                                        {{$select.selected.name}}\n" +
    "                                    </ui-select-match>\n" +
    "                                    <ui-select-choices repeat=\"domain in ctrlr.domains | filter: {name: $select.search } | orderBy:'name'\">\n" +
    "                                        <span ng-bind-html=\"domain.name | highlight: $select.search\"></span>\n" +
    "                                    </ui-select-choices>\n" +
    "                                </ui-select>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-5\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                                <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\" placeholder=\"{{::'All Users' | translate}}\"/>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-2\">\n" +
    "                            <div class=\"btn-group\">\n" +
    "                                <button class=\"btn btn-sm btn-default\" data-toggle=\"tooltip\"\n" +
    "                                        ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                                        ng-click=\"ctrlr.reverse = false\"\n" +
    "                                        title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                                    <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                                </button>\n" +
    "                                <button class=\"btn btn-sm btn-default\" data-toggle=\"tooltip\"\n" +
    "                                        ng-class=\"{ 'active':ctrlr.reverse == true }\"\n" +
    "                                        ng-click=\"ctrlr.reverse = true\"\n" +
    "                                        title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                                    <i class=\"icon icon_sort_amount_desc\"></i>\n" +
    "                                </button>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"ctrlr.users\" selected-item=\"ctrlr.selectedUser\" sort=\"userName\"\n" +
    "                               q=\"ctrlr.filterUsers\" reverse=\"ctrlr.reverse\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editSelectedUser()\">\n" +
    "                            <i class=\"icon {{item.isLocked()==true ? 'icon_locked' : 'icon_user'}} list-icon pull-left\"></i>\n" +
    "                            <span style=\"color: {{item.isLocked()==true ? 'red' : 'auto'}}\" ng-bind-html=\"item.userName+'@'+item.domainName | highlightHtmlSafe: listScope.ctrlr.q\" ng-mouseenter=\"listScope.ctrlr.showTooltip(item)\" ng-mouseleave=\"listScope.ctrlr.hideTooltip()\"></span>\n" +
    "                            <code class=\"pull-right\" ng-bind-html=\"item.adapter.adapterTypeHelper.displayName | highlightHtmlSafe: listScope.ctrlr.q\"></code>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-success\" ng-click=\"ctrlr.addNewUser()\"><i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                        <button class=\"btn btn-warning\" ng-disabled=\"ctrlr.selectedUser == null || ! ctrlr.selectedUser.adapter.adapterTypeHelper.allowUserAction\" ng-click=\"ctrlr.editSelectedUser()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                        <button class=\"btn btn-danger\" ng-disabled=\"ctrlr.selectedUser == null || ! ctrlr.selectedUser.adapter.adapterTypeHelper.allowUserAction\" ng-click=\"ctrlr.removeSelectedUser()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <div ng-if=\"!ctrlr.selectedUser\" class=\"alert alert-info\" translate>Select a User to Edit</div>\n" +
    "            <edge-panel ng-if=\"ctrlr.selectedUser\">\n" +
    "                <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                    <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                        <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#roles\" style=\"padding:7px 15px\"><span translate>Roles</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#variables\" style=\"padding:7px 15px\"><span translate>Secured Variables</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#credentials\" style=\"padding:7px 15px\"><span translate>Credentials</span></a>\n" +
    "                        </li>\n" +
    "                        <li role=\"presentation\">\n" +
    "                            <a href role=\"tab\" data-toggle=\"tab\" data-target=\"#kiosk\" style=\"padding:7px 15px\">\n" +
    "                                <span ng-if=\"ctrlr.kioskMode.hasUnsavedChanges\"\n" +
    "                                    class=\"text-warning icon icon_exclamation_triangle\"\n" +
    "                                    title=\"{{::'Unsaved Changes' | translate}}\"></span>\n" +
    "                                <span translate>Kiosk</span>\n" +
    "                            </a>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div style='position:absolute;left:50%;top: 50%;margin: -25px 0 0 -25px;background:rgba(255,255,255,0.5);border-radius:7px;width:50px;height:50px' \n" +
    "                        ng-if=\"ctrlr.showBusyOverlay\">\n" +
    "                        <span us-spinner=\"{hwaccel: 'true'}\"></span>\n" +
    "                    </div>\n" +
    "                    <div class=\"tab-content\" style=\"height: 100%\" ng-class=\"{'edgeBusyHide' : ctrlr.showBusyOverlay}\">\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade in active\" id=\"roles\">\n" +
    "                            <edge-list items=\"ctrlr.userGroups\" selected-item=\"ctrlr.selectedGroup\">\n" +
    "                                <div class=\"with-padding\">\n" +
    "                                    <i class=\"icon icon_folder_o list-icon pull-left\"></i>\n" +
    "                                    &nbsp;<span ng-bind-html=\"item.name\"></span>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"variables\">\n" +
    "                            <edge-list items=\"ctrlr.variables\" selected-item=\"ctrlr.selectedVariable\"\n" +
    "                                sort=\"param.parameterName\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editVariable()\">\n" +
    "                                    <i class=\"icon icon_var list-icon pull-left\"></i> {{item.param.parameterName}}\n" +
    "                                    <code class=\"pull-right\">\n" +
    "                                        <i class=\"{{item.iconClass}}\"></i>\n" +
    "                                        {{listScope.ctrlr.getDisplayValue(item)}}\n" +
    "                                    </code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"credentials\">\n" +
    "                            <edge-list items=\"ctrlr.credentials\" selected-item=\"ctrlr.selectedCredential\"\n" +
    "                                sort=\"param.parameterName\">\n" +
    "                                <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editCredential()\">\n" +
    "                                    <i class=\"fa fa-key\"></i> {{item.param.parameterName}}\n" +
    "                                    <code class=\"pull-right\">\n" +
    "                                        <i class=\"{{item.iconClass}}\"></i>\n" +
    "                                        {{listScope.ctrlr.getCredentialDisplayValue(item)}}\n" +
    "                                    </code>\n" +
    "                                </div>\n" +
    "                            </edge-list>\n" +
    "                        </div>\n" +
    "                        <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"kiosk\" style=\"height: 100%; padding: 20px;\">\n" +
    "                            <edge-kiosk-pages-editor active=\"ctrlr.activeTab === '#kiosk'\" kiosk-mode=\"ctrlr.kioskMode\" available-pages=\"ctrlr.pages\"></edge-kiosk-pages-editor>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#roles'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-success\" ng-click=\"ctrlr.addRolesToUser()\"><i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                            <button class=\"btn btn-danger\" ng-disabled=\"ctrlr.selectedGroup == null\" ng-click=\"ctrlr.removeSelectedRole()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#variables'\">\n" +
    "                        <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedVariable\"\n" +
    "                                ng-click=\"ctrlr.editVariable()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ctrlr.activeTab === '#credentials'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-warning\" ng-disabled=\"! ctrlr.selectedCredential\"\n" +
    "                                    ng-click=\"ctrlr.editCredential()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group pull-right\" ng-if=\"ctrlr.activeTab === '#kiosk'\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                        <div style=\"float: right; display: inline\">\n" +
    "                            <button class=\"btn btn-primary\"\n" +
    "                                    ng-class=\"{'pulse':ctrlr.kioskMode.hasUnsavedChanges}\"\n" +
    "                                    ng-click=\"ctrlr.saveKioskMode()\">\n" +
    "                                    <span ng-if=\"ctrlr.kioskMode.hasUnsavedChanges\"\n" +
    "                                      class=\"icon icon_exclamation_triangle\"\n" +
    "                                      title=\"{{::'Unsaved Changes' | translate}}\"></span><span translate>Save</span>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/base/defaultpage/default.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/defaultpage/default.tpl.html",
    "<div class=\"container edge-no-provisioned-content\"\n" +
    "     ng-if=\"dpCtrlr.showNoProvisionedContentMessage\">\n" +
    "    <div class=\"centered-wide-div\">\n" +
    "        <i class=\"icon icon_minus_circle text-warning\"></i></br>\n" +
    "        <span translate>Content has not been provisioned for this user.  Please contact your system administrator.</span>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/core/base/error/error.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/error/error.tpl.html",
    "<div class=\"container\"  style=\"text-align: center; style=position:relative; height:100%; width:100%\">\n" +
    "    <div class=\"with-padding\" ng-switch=\"::errorCode\" style=\"position: absolute; top: 50%; transform: translateY(-50%); width:100%\">\n" +
    "        <div ng-switch-when=\"404\" class=\"alert alert-error\" style=\"padding:20px\">\n" +
    "            <i style=\"font-size: 4em\" class=\"icon icon_question_circle text-danger\"></i></br>\n" +
    "            <span style=\"font-size: 2em\">{{errorCode}}&nbsp;<span translate>Error</span></span></br>\n" +
    "            <span translate>The requested URL can not be found.</span>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <div ng-switch-when=\"403|401|550\" ng-switch-when-separator=\"|\" class=\"alert alert-error\" style=\"padding:20px\">\n" +
    "                <i style=\"font-size: 4em\" class=\"icon icon_shield text-danger\"></i></br>\n" +
    "                <span style=\"font-size: 2em\">{{errorCode}}&nbsp;<span translate>Error</span></span></br>\n" +
    "                    <span translate>You do not have all the permissions necessary to view the last URL requested.</span>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <div ng-switch-default class=\"alert alert-error\" style=\"padding:20px\">\n" +
    "            <span style=\"font-size: 5em\">:-(</span><br>\n" +
    "            <span style=\"font-size: large\" translate>something went wrong</span><br><br>\n" +
    "            <span translate>We're sorry, but the server was unable to complete your request.</span>\n" +
    "            <br><br>\n" +
    "            <span style=\"font-size: 2em\">\n" +
    "                {{errorCode}}&nbsp;<span translate>Error</span>&nbsp;\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/base/notification/modal/modalNotification.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/notification/modal/modalNotification.tpl.html",
    "<!-- Copyright 2014 Edge Technologies -->\n" +
    "<div class=\"modal-header\">\n" +
    "    <h4 class=\"modal-title\">Important Message</h4>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "    <div ng-class=\"{'alert alert-info': vm.notification.severity == 'INFO', 'alert alert-warning': vm.notification.severity == 'WARNING', 'alert alert-danger': vm.notification.severity == 'ERROR'}\"\n" +
    "         role=\"alert\">\n" +
    "        {{vm.component}}: {{vm.notification.message}}\n" +
    "    </div>\n" +
    "</div>\n" +
    "<div class=\"modal-footer\">\n" +
    "    <button type=\"button\" class=\"btn btn-default pull-right\" ng-click=\"vm.close()\">Close</button>\n" +
    "</div>");
}]);

angular.module("edge/core/base/notification/toaster/edgeToasterNotification.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/notification/toaster/edgeToasterNotification.tpl.html",
    "<!-- Copyright 2014 Edge Technologies -->\n" +
    "<div class=\"panel panel-default\" ng-if=\"unreadToasterNotifications()\">\n" +
    "    <div class=\"panel-body\">\n" +
    "        <div ng-repeat=\"notification in notifications | filter:unreadToaster | orderBy:'dateCreated':true\"\n" +
    "             ng-class=\"{'alert alert-success': notification.severity == 'DEBUG',\n" +
    "                        'alert alert-info': notification.severity == 'INFO',\n" +
    "                        'alert alert-warning': notification.severity == 'WARNING',\n" +
    "                        'alert alert-danger': notification.severity == 'ERROR'}\"\n" +
    "             ng-click=\"dismissToaster(notification.ID)\" style=\"cursor: pointer\">\n" +
    "            {{notification.componentName}}: {{notification.message}}\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/core/base/serviceability/about/aboutDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/serviceability/about/aboutDialog.tpl.html",
    "<div ng-controller=\"AboutController as Controller\" style=\"overflow: hidden\">\n" +
    "\n" +
    "\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-12\">\n" +
    "            <div class=\"branded-background\">\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-12\">\n" +
    "                        <center class=\"about-logo\">\n" +
    "                            <img ng-src=\"{{Controller.aboutLogo}}\"/>\n" +
    "                        </center>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "\n" +
    "    <div class=\"about-info\">\n" +
    "        <div class=\"about-center\">\n" +
    "            <div class=\"about-tagline\">Access. Integrate. Visualize. Understand.</div>\n" +
    "        </div>\n" +
    "        <div>\n" +
    "            <div class=\"about-version-current\">\n" +
    "                <div class=\"row \">\n" +
    "                    <div class=\"col-sm-12\">\n" +
    "                        <span class=\"version-label\">edgeSuite Version:</span>\n" +
    "                        <span class=\"version-number\">{{::Controller.version}}</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"row\" id=\"about-update-btn\">\n" +
    "                    <div class=\"col-sm-12\">\n" +
    "                        <button class=\"btn btn-branded\">Update Available</button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "\n" +
    "                <!--\n" +
    "                <div class=\"row \">\n" +
    "                    <div class=\"col-sm-12\">\n" +
    "                        <span class=\"version-current\">Up to date</span>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                -->\n" +
    "            </div>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <div class=\"about-copyright\">Copyright 2016, 2017 Edge Technologies Inc. All rights reserved.</div>\n" +
    "    </div>\n" +
    "\n" +
    "\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/base/serviceability/messages/messages-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/serviceability/messages/messages-dialog.tpl.html",
    "<div ng-controller=\"MessageCenterController as mcc\" style=\"height: 100%;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                <input type=\"search\" ng-model=\"mcc.searchString\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ui-grid=\"mcc.dataGridOptions\"\n" +
    "         ui-grid-selection\n" +
    "         ui-grid-auto-resize\n" +
    "         ui-grid-resize-columns\n" +
    "         style=\"height: 100%;\"\n" +
    "         class=\"grid modulegrid messagegrid\"></div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <span class=\"pull-left\" translate translate-n=\"mcc.dataGridOptions.data.length\" translate-plural=\"{{$count}} Messages\">1 Message</span>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"mcc.clearMessages()\">\n" +
    "                <span translate>Clear All Messages</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"mcc.saveMessages()\">\n" +
    "                <span translate>Save to File</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"mcc.close()\">\n" +
    "                <span translate>Close</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>");
}]);

angular.module("edge/core/base/serviceability/messages/stack-trace-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/serviceability/messages/stack-trace-dialog.tpl.html",
    "<h4 translate style=\"margin-top: 0px;\">An exception has occurred on the client:</h4>\n" +
    "<pre>{{stack}}</pre>");
}]);

angular.module("edge/core/base/services/popup/edgeVerticalPopupMenuItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/services/popup/edgeVerticalPopupMenuItem.tpl.html",
    "<li>\n" +
    "    <a ng-if=\"menuItem.folder\" class=\"edge-popupmenu-right-caret\" ng-click=\"expand($event)\"><span\n" +
    "            class=\"edge-menubar-label-span\"><i class=\"verticalPopupMenuIcon icon\" ng-class=\"menuItem.iconClass\"></i>{{menuItem.label}}</span></a>\n" +
    "    <ul ng-if=\"menuItem.folder\" class=\"dropdown-menu edge-menubar-sub-menu\">\n" +
    "        <edge-vertical-popup-menu-item ng-repeat=\"item in menuItem.children\"\n" +
    "                                       menu-item=\"item\"></edge-vertical-popup-menu-item>\n" +
    "    </ul>\n" +
    "    <a ng-if=\"!menuItem.folder && !menuItem.isSeparator\" ng-disabled=\"menuItem.disabled\"\n" +
    "       ng-click=\"itemClick($event, menuItem)\"><i class=\"verticalPopupMenuIcon icon\" ng-class=\"menuItem.iconClass\"></i>{{menuItem.label}}</a>\n" +
    "    <div ng-if=\"menuItem.isSeparator\" class=\"dropdown-divider\"></div>\n" +
    "</li>\n" +
    "");
}]);

angular.module("edge/core/base/services/upload/upload-file-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/services/upload/upload-file-dialog.tpl.html",
    "<div>\n" +
    "    <form id=\"fileupload\"\n" +
    "          action=\"/upload/static-web\"\n" +
    "          method=\"POST\"\n" +
    "          enctype=\"multipart/form-data\"\n" +
    "          file-upload=\"ctrlr.uploadOptions\"\n" +
    "          ng-class=\"{'fileupload-processing': processing() || loadingFiles}\">\n" +
    "        <div class=\"alert alert-info\">\n" +
    "            <span translate>Drag and drop backup files to this dialog, or use the 'Add Files' button below to choose files to upload to the server.</span><br>\n" +
    "            <span translate>Maximum file size is 1 GB.</span></div>\n" +
    "        <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->\n" +
    "        <div class=\"row fileupload-buttonbar\">\n" +
    "            <div class=\"col-lg-7\">\n" +
    "                <!-- The fileinput-button span is used to style the file input field as button -->\n" +
    "                <span class=\"btn btn-default fileinput-button\" ng-class=\"{disabled: disabled}\">\n" +
    "                    <i class=\"glyphicon glyphicon-plus\"></i>\n" +
    "                    <span translate>Add files...</span>\n" +
    "                    <input type=\"file\" name=\"file\" multiple ng-disabled=\"disabled\" ng-attr-accept=\"{{ctrlr.inputAccept}}\">\n" +
    "                </span>\n" +
    "                <button type=\"button\" class=\"btn btn-success start\" ng-click=\"submit()\" ng-disabled=\"!ctrlr.filesNeedUpload(queue)\">\n" +
    "                    <i class=\"glyphicon glyphicon-upload\"></i>\n" +
    "                    <span translate>Upload All</span>\n" +
    "                </button>\n" +
    "                <button type=\"button\"\n" +
    "                        class=\"btn btn-warning cancel\"\n" +
    "                        ng-click=\"cancel()\"\n" +
    "                        ng-disabled=\"!ctrlr.filesCanBeCanceled(queue)\">\n" +
    "                    <i class=\"glyphicon glyphicon-ban-circle\"></i>\n" +
    "                    <span translate>Cancel All</span>\n" +
    "                </button>\n" +
    "                <!-- The global file processing state -->\n" +
    "                <span class=\"fileupload-process\"></span>\n" +
    "            </div>\n" +
    "            <!-- The global progress state -->\n" +
    "            <div class=\"col-lg-5 fade\" ng-class=\"{in: active()}\">\n" +
    "                <!-- The global progress bar -->\n" +
    "                <div class=\"progress progress-striped active\" file-upload-progress=\"progress()\">\n" +
    "                    <div class=\"progress-bar progress-bar-success\" ng-style=\"{width: num + '%'}\"></div>\n" +
    "                </div>\n" +
    "                <!-- The extended global progress state -->\n" +
    "                <div class=\"progress-extended\">&nbsp;</div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <!-- The table listing the files available for upload/download -->\n" +
    "        <table class=\"table table-striped files\">\n" +
    "            <tr ng-repeat=\"file in queue\" ng-class=\"{'processing': file.$processing()}\">\n" +
    "                <td>\n" +
    "                    <p class=\"name\" ng-switch on=\"!!file.url\">\n" +
    "                        <span ng-switch-when=\"true\">\n" +
    "                            <a ng-href=\"{{file.url}}\" title=\"{{file.name}}\" download=\"{{file.name}}\">{{file.name}}</a>\n" +
    "                        </span>\n" +
    "                        <span ng-switch-default>{{file.name}}</span>\n" +
    "                    </p>\n" +
    "                    <strong ng-show=\"file.error\" class=\"error text-danger\">{{file.error}}</strong>\n" +
    "                </td>\n" +
    "                <td>\n" +
    "                    <p ng-if=\"file.$state() != 'pending'\" class=\"size\">{{file.size | formatFileSize}}</p>\n" +
    "                    <div ng-if=\"file.$state() == 'pending'\"\n" +
    "                         class=\"progress progress-striped active fade\"\n" +
    "                         ng-class=\"{pending: 'in'}[file.$state()]\"\n" +
    "                         file-upload-progress=\"file.$progress()\">\n" +
    "                        <div class=\"progress-bar progress-bar-success\" ng-style=\"{width: num + '%'}\"></div>\n" +
    "                    </div>\n" +
    "                </td>\n" +
    "                <td>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-success start\"\n" +
    "                            ng-click=\"file.$submit()\"\n" +
    "                            ng-hide=\"!file.$submit || options.autoUpload\"\n" +
    "                            ng-disabled=\"file.$state() == 'pending' || file.$state() == 'rejected'\">\n" +
    "                        <i class=\"glyphicon glyphicon-upload\"></i>\n" +
    "                        <span translate>Upload</span>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-warning cancel\"\n" +
    "                            ng-click=\"file.$cancel()\"\n" +
    "                            ng-hide=\"!file.$cancel\">\n" +
    "                        <i class=\"glyphicon glyphicon-ban-circle\"></i>\n" +
    "                        <span translate>Cancel</span>\n" +
    "                    </button>\n" +
    "                    <!--\n" +
    "                    <button ng-controller=\"FileDestroyController\" type=\"button\" class=\"btn btn-danger destroy\" ng-click=\"file.$destroy()\" ng-hide=\"!file.$destroy\">\n" +
    "                        <i class=\"glyphicon glyphicon-trash\"></i>\n" +
    "                        <span>Delete</span>\n" +
    "                    </button> -->\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </form>\n" +
    "\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"dialogRef.close()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/base/tools/edgeServerMessage.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/base/tools/edgeServerMessage.tpl.html",
    "<div>\n" +
    "    <span translate>Server Response</span>:\n" +
    "    <div class=\"well well-sm\">{{response.message}}\n" +
    "        <br>\n" +
    "        <span ng-if=\"response.reference\">{{response.reference}}</span>\n" +
    "        <a class=\"pull-right\"\n" +
    "           ng-if=\"response.result && showInfo === false\"\n" +
    "           ng-click=\"toggleShowInfo()\"\n" +
    "           translate>More Info</a>\n" +
    "        <div class=\"clearfix\"></div>\n" +
    "        <div ng-if=\"showInfo\"><br>\n" +
    "            <div ng-repeat=\"(key, value) in response.result\">\n" +
    "                <b>{{key}}</b> : {{value[0]}}\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/core/communication/change-password.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/communication/change-password.tpl.html",
    "<div ng-controller=\"ForceChangePasswordController as fcpCtrlr\">\n" +
    "    <form class=\"form-horizontal\" name=\"changePasswordForm\" style=\"padding-right: 10px\">\n" +
    "        <span translate>Your password has expired and you must change it now in order to continue.</span><br><br>\n" +
    "        <div ng-if=\"fcpCtrlr.error != undefined\" class=\"alert alert-danger\">\n" +
    "            {{fcpCtrlr.error}}\n" +
    "        </div>\n" +
    "        <div class=\"form-group\">\n" +
    "            <edge-labeled-control label=\"{{::'Current Password' | translate}}\" labelWidth=\"4\" required=\"true\" validation=\"true\">\n" +
    "                <input class=\"form-control\" name=\"currentPassword\" ng-model=\"fcpCtrlr.currentPassword\" type=\"password\" ng-required=\"true\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"form-group\">\n" +
    "            <edge-labeled-control label=\"{{::'New Password' | translate}}\" labelWidth=\"4\" required=\"true\" validation=\"true\">\n" +
    "                <input class=\"form-control\" name=\"newPassword\" ng-model=\"fcpCtrlr.newPassword\" ng-model-options=\"{allowInvalid: true}\" type=\"password\" ng-required=\"true\" ng-change=\"fcpCtrlr.validateConfirm()\"\n" +
    "                       ng-minlength=\"fcpCtrlr.pwdPolicy.minLength\" ng-maxlength=\"fcpCtrlr.pwdPolicy.maxLength > 0 ? fcpCtrlr.pwdPolicy.maxLength : null\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"form-group\">\n" +
    "            <edge-labeled-control label=\"{{::'Confirm Password' | translate}}\" helptext=\"{{::'Please enter the same password'|translate}}\" labelWidth=\"4\" required=\"true\" validation=\"true\">\n" +
    "                <input class=\"form-control\" name=\"confirmPassword\" ng-model=\"fcpCtrlr.confirmPassword\" type=\"password\" ng-required=\"true\" ng-model-options=\"{allowInvalid: true}\" ng-change=\"fcpCtrlr.validateConfirm()\">\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-4\"></div>\n" +
    "            <div class=\"col-sm-8\">\n" +
    "                <div ng-if=\"fcpCtrlr.pwdPolicy.rules.length > 0 || fcpCtrlr.pwdPolicy.minLength > 0 || fcpCtrlr.pwdPolicy.maxLength > 0\"\n" +
    "                     class=\"alert {{fcpCtrlr.isPasswordValid() ? 'alert-info' : 'alert-danger'}}\">\n" +
    "                    <label>{{::'Password Policy' | translate}}</label>\n" +
    "                    <label ng-if=\" fcpCtrlr.pwdPolicy.minLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"fcpCtrlr.newPassword.length >= fcpCtrlr.pwdPolicy.minLength\"> Minimum password length is {{::fcpCtrlr.pwdPolicy.minLength}}</label>\n" +
    "                    <label ng-if=\" fcpCtrlr.pwdPolicy.maxLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"fcpCtrlr.newPassword.length <= fcpCtrlr.pwdPolicy.maxLength\"> Maximum password length is {{::fcpCtrlr.pwdPolicy.maxLength}}</label>\n" +
    "                    <label ng-repeat=\"rule in fcpCtrlr.pwdPolicy.rules\">\n" +
    "                        <input type=\"checkbox\" disabled ng-checked=\"fcpCtrlr.newPassword && rule.satisfy(fcpCtrlr.newPassword)\"> {{::rule.description}}\n" +
    "                    </label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <!--\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\">\n" +
    "                <span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            -->\n" +
    "            <button class=\"btn btn-success\" ng-disabled=\"changePasswordForm.$invalid || !fcpCtrlr.isPasswordValid()\" ng-click=\"fcpCtrlr.handleSave()\">\n" +
    "                <span translate>Change Password</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/connect/admin/view/view-connections.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/connect/admin/view/view-connections.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel collapsible=\"false\" collapsed=\"false\">\n" +
    "        <edge-panel-header label=\"{{::'Connections' | translate}}\">\n" +
    "            <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                    <input type=\"search\" ng-model=\"Controller.searchString\" class=\"form-control\" placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <div ui-grid=\"Controller.dataGridOptions\" ui-grid-selection ui-grid-resize-columns class=\"grid modulegrid connectiongrid\" style=\"height: 100%\"></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-success\"\n" +
    "                            ng-click=\"Controller.addConnection()\"\n" +
    "                            title=\"{{::'Add' | translate}}\">\n" +
    "                        <i class=\"icon icon_plus\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-warning\"\n" +
    "                            ng-click=\"Controller.editSelectedConnection()\"\n" +
    "                            ng-disabled=\"! Controller.selectedConnection\"\n" +
    "                            title=\"{{::'Edit' | translate}}\">\n" +
    "                        <i class=\"icon icon_pencil\"></i>\n" +
    "                    </button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-danger\"\n" +
    "                            ng-click=\"Controller.deleteSelectedConnection()\"\n" +
    "                            ng-disabled=\"! Controller.selectedConnection\"\n" +
    "                            title=\"{{::'Delete' | translate}}\">\n" +
    "                        <i class=\"icon icon_trash\"></i>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "                <button class=\"btn btn-default pull-left\" ui-sref=\"admin.pipes({search: '0_'+Controller.selectedConnection.instanceId})\" ng-disabled=\"! Controller.selectedConnection\">\n" +
    "                    <i class=\"glyphicon glyphicon-eye-open\"></i>\n" +
    "                    <span translate>View Pipeline</span>\n" +
    "                </button>\n" +
    "                <div class=\"pull-right connections-license-info\">\n" +
    "                    <span class=\"text-muted\" translate>Total Connections:</span>\n" +
    "                    <span>{{Controller.dataGridOptions.data.length}}</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/nav/banner/edgeBanner.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/banner/edgeBanner.tpl.html",
    "<nav class=\"edge-navbar navbar navbar-inverse\" role=\"navigation\">\n" +
    "    <div id=\"edgeBannerContainer\">\n" +
    "        <div id=\"edgeBannerLogo\">\n" +
    "            <img ui-sref=\"default\" ng-src=\"{{::bctrlr.currentLaf.bannerLogo}}\" class=\"navbar-brand-logo\">\n" +
    "        </div>\n" +
    "        <div id=\"edgeBannerUserID\">\n" +
    "            {{bctrlr.userID}}\n" +
    "        </div>\n" +
    "        <div id=\"edgeBannerMenu\">\n" +
    "            <edge-menu-bar class=\"hidden-xs\"></edge-menu-bar>\n" +
    "        </div>\n" +
    "        <div class=\"edgeBannerButton visible-xs\">\n" +
    "            <a href id=\"pageMenuBtn\"\n" +
    "               ng-click=\"bctrlr.togglePageMenu();\"\n" +
    "               ng-class=\"{'open':bctrlr.bannerService.pageMenuOpen}\"> <i class=\"icon icon_visualization\"></i> </a>\n" +
    "        </div>\n" +
    "        <div class=\"hidden-xs edgeBannerButton\">\n" +
    "            <a href id=\"pageSearchBtn\"\n" +
    "               ng-click=\"bctrlr.toggleSearch()\"\n" +
    "               ng-class=\"{'open':bctrlr.bannerService.searchOpen}\"> <i class=\"icon icon_search\"></i>\n" +
    "                <edge-quick-search ng-show=\"bctrlr.bannerService.searchOpen\"></edge-quick-search>\n" +
    "            </a>\n" +
    "        </div>\n" +
    "\n" +
    "        <div id=\"pageSearchInputDiv\" class=\"hidden-xs\">\n" +
    "            <input id=\"pageSearchInput\"\n" +
    "                   ng-show=\"bctrlr.bannerService.searchOpen\"\n" +
    "                   ng-model=\"bctrlr.bannerService.search\"\n" +
    "                   placeholder=\"search...\"\n" +
    "                   edge-on-enter=\"bctrlr.bannerService.onSearchEnterPress()\">\n" +
    "        </div>\n" +
    "        <div class=\"edgeBannerButton\">\n" +
    "            <a href id=\"systemMenuBtn\"\n" +
    "               ng-click=\"bctrlr.toggleSystemMenu();\"\n" +
    "               ng-class=\"{'open':$root.showSystemMenu && !bctrlr.bannerService.pageMenuOpen}\">\n" +
    "                <i class=\"icon icon_menu_bars\"></i><span ng-if=\"bctrlr.getUnreadMessageCount() > 0\" class=\"messageBubble\">{{bctrlr.getUnreadMessageCount()}}</span></a>\n" +
    "        </div>\n" +
    "        <div ng-if=\"! (bctrlr.currentLaf.isSystem || bctrlr.isSmallDevice)\"><img ng-src=\"{{::bctrlr.currentLaf.powerByEdgeLogo}}\"/></div>\n" +
    "        <div ng-if=\"bctrlr.bannerService.displayLicenseWarning\" class=\"edgeWarning\" ng-class=\"{'edgeWarningAltClass': bctrlr.bannerService.licenseWarningAltClass}\">\n" +
    "            <i class=\"icon icon_exclamation_triangle\"></i>\n" +
    "            <a href ng-click=\"bctrlr.launchLicenseAction()\" class='edgeWarningText'><span>{{bctrlr.bannerService.licenseWarningText}}</span></a>\n" +
    "            <a href ng-click=\"bctrlr.bannerService.displayLicenseWarning = false\" style=\"float: right;\"> <i class=\"icon icon_close\"></i> </a>\n" +
    "        </div>\n" +
    "        <div ng-if=\"bctrlr.bannerService.displayPasswordWarning\" class=\"edgeWarning\" ng-class=\"{'edgeWarningAltClass': bctrlr.bannerService.passwordWarningAltClass}\">\n" +
    "            <i class=\"icon icon_exclamation_triangle\"></i>\n" +
    "            <a href ng-click=\"bctrlr.launchPasswordChangeAction()\" class='edgeWarningText'><span>{{bctrlr.bannerService.passwordWarningText}}</span></a>\n" +
    "            <a href ng-click=\"bctrlr.bannerService.displayPasswordWarning = false\" style=\"float: right;\"> <i class=\"icon icon_close\"></i> </a>\n" +
    "        </div>\n" +
    "        <div ng-if=\"bctrlr.bannerService.displayClusterWarning\" class=\"edgeWarning\" ng-class=\"{'edgeWarningAltClass': bctrlr.bannerService.clusterWarningAltClass}\">\n" +
    "            <i class=\"icon icon_exclamation_triangle\"></i>\n" +
    "            <a href class=\"edgeWarningText\" ng-click=\"bctrlr.bannerService.clusterAdminLogin()\"><span>{{bctrlr.bannerService.clusterWarningText}}</span></a>\n" +
    "            <a href ng-click=\"bctrlr.bannerService.displayClusterWarning = false\" style=\"float: right;\"> <i class=\"icon icon_close\"></i> </a>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</nav>\n" +
    "");
}]);

angular.module("edge/core/nav/breadcrumb/edgeRouterBreadcrumbBar.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/breadcrumb/edgeRouterBreadcrumbBar.tpl.html",
    "<ol class=\"breadcrumb edgeBreadcrumbBar\">\n" +
    "    <li class=\"alt-separator breadcrumb-btn\" \n" +
    "        ng-if=\"pageBreadcrumbService.paletteButton\" \n" +
    "        ng-class=\"{active: pageBreadcrumbService.paletteVisible}\" \n" +
    "        ng-click=\"pageBreadcrumbService.togglePalette()\" \n" +
    "        title=\"{{pageBreadcrumbService.toggleText}}\"><span class=\"icon icon_sliders\"></span></li>\n" +
    "    <li ng-repeat=\"crumb in breadcrumbs\"\n" +
    "        ng-class=\"{ active: $last }\"><a ui-sref=\"{{ crumb.route }}\" ng-if=\"!$last\">{{ crumb.displayName\n" +
    "        }}</a><span ng-show=\"$last\">{{ crumb.displayName }}</span>&nbsp;\n" +
    "    </li>\n" +
    "</ol>\n" +
    "");
}]);

angular.module("edge/core/nav/hamburger/edgeHamburgerMenu.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/hamburger/edgeHamburgerMenu.tpl.html",
    "<ul id=\"hamburger_menu\" class=\"nav navbar-nav navbar-right\" style=\"margin-right: 0px;\">\n" +
    "</ul>\n" +
    "");
}]);

angular.module("edge/core/nav/menubar/edgeMenuBar.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/menubar/edgeMenuBar.tpl.html",
    "<div>\n" +
    "    <div ng-if=\"! mbCtrlr.contentService.isKioskMode\" class=\"edgeMenuBar\">\n" +
    "        <div ng-show=\"mbCtrlr.showLeftScrollBtn\" ng-click=\"mbCtrlr.scrollLeft()\" class=\"edgeMenuBarLeftScroll\">\n" +
    "            <i class=\"icon icon_chevron_left\"></i>\n" +
    "        </div>\n" +
    "        <div class=\"edgeMenuBarTabs\">\n" +
    "            <div class=\"edgeMenuBarTabsScoller\" ng-style=\"{'left':mbCtrlr.scrollerPosX + 'px'}\">\n" +
    "                <edge-menu-bar-tab ng-repeat=\"menuItem in mbCtrlr.rootMenuItems track by $index\"\n" +
    "                                   menu-item=\"menuItem\" on-repeat-done=\"mbCtrlr.initialized()\"></edge-menu-bar-tab>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-show=\"mbCtrlr.showRightScrollBtn\" ng-click=\"mbCtrlr.scrollRight()\" class=\"edgeMenuBarRightScroll\">\n" +
    "            <i class=\"icon icon_chevron_right\"></i>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div ng-if=\"mbCtrlr.contentService.isKioskMode && mbCtrlr.kioskPages.length > 1\" class=\"edgeMenuBar edgeKioskPlayer\">\n" +
    "        <div class=\"btn-group btn-group-xs\">\n" +
    "            <button type=\"button\" class=\"btn icon icon_fast_backward\" ng-click='mbCtrlr.kioskBack(0)'>\n" +
    "            </button>\n" +
    "\n" +
    "            <button type=\"button\" class=\"btn icon icon_step_backward\" ng-click='mbCtrlr.kioskBack((mbCtrlr.nextKioskPage - 2 + mbCtrlr.kioskPages.length) % mbCtrlr.kioskPages.length)'>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "\n" +
    "        <button type=\"button\" id=\"edgeKioskPlayButton\" class=\"btn icon icon_pause\" ng-click='mbCtrlr.togglePlay()'>\n" +
    "        </button>\n" +
    "\n" +
    "        <div class=\"btn-group btn-group-xs\">\n" +
    "            <button type=\"button\" class=\"btn icon icon_step_forward\" ng-click='mbCtrlr.kioskForward(mbCtrlr.nextKioskPage)'>\n" +
    "            </button>\n" +
    "\n" +
    "            <button type=\"button\" class=\"btn icon icon_fast_forward\" ng-click='mbCtrlr.kioskForward(mbCtrlr.kioskPages.length-1)'>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/nav/menubar/edgeMenuBarTab.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/menubar/edgeMenuBarTab.tpl.html",
    "<div class=\"edgeMenuBarTab\">\n" +
    "    <div ng-if=\"menuItem.folder\" uib-dropdown dropdown-append-to-body keyboard-nav on-toggle=\"mbCtrlr.onToggle(open)\">\n" +
    "        <a uib-dropdown-toggle>\n" +
    "            <div class=\"edgeMenuBarTabLabel\">\n" +
    "                {{menuItem.displayName}}\n" +
    "            </div>\n" +
    "            <div class=\"edgeMenuBarTabCaret\">\n" +
    "                <span class=\"caret\" style=\"margin-left: 5px;\"></span>\n" +
    "            </div>\n" +
    "        </a>\n" +
    "        <ul uib-dropdown-menu class=\"edge-menubar-root-sub-menu dropdown-menu\" ng-show=\"menuItem.children.length > 0\">\n" +
    "            <edge-popup-menu-item ng-repeat=\"item in menuItem.children\" menu-item=\"item\"></edge-popup-menu-item>\n" +
    "        </ul>\n" +
    "    </div>\n" +
    "    <a ng-if=\"!menuItem.folder\" ng-href=\"{{mbCtrlr.getMenuItemHref(menuItem)}}\">\n" +
    "        <div class=\"edgeMenuBarTabLabel\">\n" +
    "            {{menuItem.displayName}}\n" +
    "        </div>\n" +
    "    </a>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/nav/menubar/edgePopupMenuItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/menubar/edgePopupMenuItem.tpl.html",
    "<li>\n" +
    "    <a  ng-if=\"menuItem.folder\" class=\"edge-menubar-right-caret\" ng-click=\"expand($event)\"><span class=\"edge-menubar-label-span\">{{menuItem.displayName}}</span></a>\n" +
    "    <ul ng-if=\"menuItem.folder\" class=\"dropdown-menu edge-menubar-sub-menu\">\n" +
    "        <edge-popup-menu-item ng-repeat=\"item in menuItem.children\" menu-item=\"item\"></edge-popup-menu-item>\n" +
    "    </ul>\n" +
    "    <a ng-if=\"!menuItem.folder\" ng-href=\"{{getHref()}}\">{{menuItem.displayName}}</a>\n" +
    "</li>");
}]);

angular.module("edge/core/nav/quicksearch/edgeQuickSearch.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/quicksearch/edgeQuickSearch.tpl.html",
    "<div id=\"edgeQuickSearch\">\n" +
    "    <edge-list items=\"ctrlr.contentNodes\" q=\"{displayName:ctrlr.bannerService.search}\" selected-item=\"ctrlr.selectedContent\"\n" +
    "               type=\"simple\" class=\"quick-search-list\">\n" +
    "        <a href class=\"quick-search-item\"\n" +
    "           ng-bind-html=\"item.displayName | highlightHtmlSafe:listScope.ctrlr.bannerService.search\"></a>\n" +
    "    </edge-list>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/nav/systemmenu/edgeSystemMenu.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/systemmenu/edgeSystemMenu.tpl.html",
    "<div class=\"edgeSystemMenu\">\n" +
    "    <edge-system-menu-item-renderer class=\"edgePageMenuItemRenderer\"\n" +
    "                                  ng-repeat=\"item in smCtrlr.activeMenu.children\"\n" +
    "                                  item=\"item\"></edge-system-menu-item-renderer>\n" +
    "</div>");
}]);

angular.module("edge/core/nav/systemmenu/edgeSystemMenuItemRenderer.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/nav/systemmenu/edgeSystemMenuItemRenderer.tpl.html",
    "<div>\n" +
    "    <div ng-if=\"!item.folder && item.visible\" class=\"edgePageMenuItem\" ng-click=\"smCtrlr.handleItemClick(item);$event.stopPropagation();\">\n" +
    "        <a href class=\"no-select\">{{item.displayName}}</a>\n" +
    "    </div>\n" +
    "    <div ng-if=\"item.folder\" class=\"edgePageMenuFolder\">\n" +
    "        <h5 ng-if=\"item.visible\" class=\"no-select\">{{item.displayName}}</h5>\n" +
    "        <div ng-if=\"item.id != seedItem.id\" class=\"edgePageMenuReturn\" ng-click=\"handleReturnClick();$event.stopPropagation();\">\n" +
    "            <a href class=\"no-select\"><i class=\"icon icon_caret_left\"></i>{{item.parent.displayName}}</a>\n" +
    "        </div>\n" +
    "        <div class=\"edgePageMenuItem\"\n" +
    "             ng-repeat=\"child in item.children | filter:{visible:true}\"\n" +
    "             ng-click=\"handleItemClick(child);$event.stopPropagation();\"\n" +
    "             ng-attr-title=\"{{child.displayName}}\">\n" +
    "            <a href class=\"no-select\">{{child.displayName}} <i ng-if=\"child.folder\" class=\"icon icon_caret_right\"></i>\n" +
    "                <span ng-if=\"isMessageCenter(child)\" class=\"messageCenterCount\">{{msgService.unReadMessageCount}}</span>\n" +
    "            </a>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/core/page/breadcrumb/edgePageBreadcrumbBar.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/breadcrumb/edgePageBreadcrumbBar.tpl.html",
    "<ol class=\"breadcrumb edgePageBreadcrumbBar\">\n" +
    "    <li class=\"alt-separator breadcrumb-btn\"\n" +
    "        ng-if=\"controller.pageBreadcrumbService.paletteButton\"\n" +
    "        ng-class=\"{active: controller.pageBreadcrumbService.paletteVisible}\"\n" +
    "        ng-click=\"controller.pageBreadcrumbService.togglePalette()\"\n" +
    "        title=\"{{controller.pageBreadcrumbService.toggleText}}\"><span class=\"icon icon_sliders\"></span></li>\n" +
    "    <li class=\"alt-separator\"><a href=\"/#\"><span class=\"icon icon_home\"></span></a></li>\n" +
    "    <li ng-repeat=\"crumb in controller.breadcrumbs track by $index\"\n" +
    "        ng-class=\"{active: $last}\"><a href=\"{{crumb.url}}\"\n" +
    "                                      ng-click=\"controller.crumbClicked($index); $event.preventDefault()\">{{crumb.displayName}}</a>&nbsp;\n" +
    "    </li>\n" +
    "    <div class=\"btn-group pull-right\" ng-if=\"::$root.isAdmin\" style=\"margin-top:-2px;\">\n" +
    "        <button class=\"edgeSmallToggleButton btn btn-default btn-sm toggledOn\"><span translate>View</span></button>\n" +
    "        <button class=\"edgeSmallToggleButton btn btn-default btn-sm\"\n" +
    "                ng-click=\"controller.editPage();\"><span translate>Edit</span></button>\n" +
    "    </div>\n" +
    "    <a href\n" +
    "       ng-click=\"pageController.showPageHelp()\"\n" +
    "       ng-attr-title=\"{{::'Page Help' | translate}}\"\n" +
    "       ng-if=\"::pageController.pageConfig.isHelpSet()\"><i class=\"icon icon_question pull-right\"></i></a>\n" +
    "</ol>\n" +
    "");
}]);

angular.module("edge/core/page/dialogs/PageNotFound.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/dialogs/PageNotFound.tpl.html",
    "<span translate>A page can not be found at the given URL:</span> /page/{{path}}\n" +
    "");
}]);

angular.module("edge/core/page/layout/cell/edgePageLayoutCell.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/layout/cell/edgePageLayoutCell.tpl.html",
    "<div>\n" +
    "    <div ng-if=\"layoutCell.contentType === 'content'\" class=\"layout-cell\" style=\"height: 100%;\">\n" +
    "        <edge-widget-container ng-if=\"::ready\" layout=\"layoutCell\" page-controller=\"config.pageController\">\n" +
    "        </edge-widget-container>\n" +
    "        <span ng-show=\"layoutCell.canResizeColumn()\" class=\"resizer vert\"></span>\n" +
    "        <div ng-show=\"isSwapping()\" ng-class=\"swapClass()\" ng-click=\"swap()\"></div>\n" +
    "    </div>\n" +
    "    <div ng-if=\"layoutCell.contentType === 'rowContainer'\" class=\"layout-cell\" id=\"{{layoutCell.id}}\" style=\"padding: 0 0 0 5px; position: relative; width: calc(100% + 5px); height: 100%;\">\n" +
    "        <edge-page-layout-internal-row ng-repeat=\"layoutRow in layoutCell.getCells() track by layoutRow.id\" layout-row=\"layoutRow\" config=\"config\" id=\"{{layoutRow.id}}\" style=\"width: 100%;\" ng-style=\"{height: layoutRow.getInternalRowHeight($index)}\"></edge-page-layout-internal-row>\n" +
    "        <span ng-show=\"layoutCell.canResizeColumn()\" class=\"resizer vert\"></span>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/layout/edgePageLayout.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/layout/edgePageLayout.tpl.html",
    "<div class=\"page-layout\">\n" +
    "    <edge-page-layout-row ng-if=\"config.layoutType === 'report'\" ng-repeat=\"layoutRow in config.getRows() track by layoutRow.id\" layout-row=\"layoutRow\" id=\"{{layoutRow.id}}\" config=\"config\" ng-style=\"{height: layoutRow.height+'px'}\"></edge-page-layout-row>\n" +
    "    <div ng-if=\"config.layoutType === 'dashboard'\" id=\"{{config.dashboardRow.id}}\" style=\"height: 100%\">\n" +
    "        <edge-page-layout-internal-row ng-repeat=\"layoutRow in config.dashboardRow.getCells() track by layoutRow.id\" layout-row=\"layoutRow\" config=\"config\" id=\"{{layoutRow.id}}\" style=\"width: 100%; margin-left: 0\" ng-style=\"{height: layoutRow.getInternalRowHeight($index)}\"></edge-page-layout-internal-row>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/layout/row/edgePageLayoutInternalRow.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/layout/row/edgePageLayoutInternalRow.tpl.html",
    "<div class=\"row\">\n" +
    "    <edge-page-layout-cell ng-if=\"layoutRow.getCells().length > 0\" ng-repeat=\"layoutCell in layoutRow.getCells() track by layoutCell.id\"\n" +
    "    layout-cell=\"layoutCell\" config=\"config\" id=\"{{layoutCell.id}}\" class=\"page-layout-cell\" ng-style=\"{width: layoutCell.width+'%', padding: layoutCell.getInternalColumnPadding($index)}\"></edge-page-layout-cell>\n" +
    "    <edge-page-layout-cell ng-if=\"layoutRow.getCells().length === 0\"\n" +
    "                           layout-cell=\"layoutRow\" config=\"config\" id=\"{{layoutRow.id}}\" class=\"page-layout-cell\" style=\"padding: 0; width: 100%;\"></edge-page-layout-cell>\n" +
    "    <div ng-show=\"layoutRow.canResizeRow()\" class=\"resizer horz\" style=\"clear: both\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/layout/row/edgePageLayoutRow.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/layout/row/edgePageLayoutRow.tpl.html",
    "<div class=\"row\">\n" +
    "    <edge-page-layout-cell ng-repeat=\"layoutCell in layoutRow.getCells() track by layoutCell.id\"\n" +
    "                           layout-cell=\"layoutCell\" config=\"config\" id=\"{{layoutCell.id}}\" class=\"page-layout-cell\" style=\"padding: 0 5px;\" ng-style=\"{width: layoutCell.width+'%'}\"></edge-page-layout-cell>\n" +
    "    <div ng-show=\"layoutRow.config.swapper == null\" class=\"resizer horz\" style=\"clear: both\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/delete-pagevar-confirm-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/delete-pagevar-confirm-dialog.tpl.html",
    "<span translate>Are you sure you want to delete the selected Page Variable?</span>");
}]);

angular.module("edge/core/page/pagevars/edgePagevarControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/edgePagevarControl.tpl.html",
    "<div class=\"form-group pagevar-control\"\n" +
    "     style=\"padding:2px 12px 8px 12px;margin:0px;\"\n" +
    "     ng-mouseenter=\"mouseEnter(pageVar, $event)\"\n" +
    "     ng-mouseleave=\"mouseLeave(pageVar, $event)\">\n" +
    "    <label title=\"{{($root.isAdmin) ? 'pageVar.' + pageVar.name : ''}}\">{{pageVar.getDisplayName()}}</label>\n" +
    "    <a ng-if=\"::$root.isAdmin && showMappings\" href class=\"pull-right\"\n" +
    "       ng-click=\"modifyPageVar(pageVar)\"><i class=\"icon icon_wrench text-warning\"></i></a>\n" +
    "    <a ng-if=\"::$root.isAdmin && showMappings\" href class=\"pull-right\" title=\"{{::'Delete Variable'|translate}}\"\n" +
    "       ng-click=\"deletePageVar(pageVar)\"><i class=\"icon icon_trash text-danger\"></i></a>\n" +
    "    <div ng-if=\"! hide\" class=\"row\" ng-switch=\"inputInfo.type\">\n" +
    "        <div ng-switch-when=\"Number\">\n" +
    "            <edge-number-spinner inputname=\"{{pageVar.id}}\" ng-model=\"pageVar.value\"\n" +
    "                                 placeholder=\"{{inputInfo.spinner.placeholder}}\"\n" +
    "                                 reload=\"inputInfo.spinner.reload\"\n" +
    "                                 step=\"inputInfo.spinner.interval\" minimum=\"inputInfo.spinner.min\"\n" +
    "                                 maximum=\"inputInfo.spinner.max\">\n" +
    "            </edge-number-spinner>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"Combo\">\n" +
    "            <ui-select ng-required=\"true\" ng-model=\"pageVar.value\" append-to-body=\"true\" theme=\"bootstrap\">\n" +
    "                <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item.value as item in inputInfo.choices | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"item.label | highlightHtmlSafe: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"Buttons\">\n" +
    "            <div class=\"btn-group\" role=\"group\">\n" +
    "                <button type=\"button\"\n" +
    "                        ng-repeat=\"item in inputInfo.choices\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        ng-class=\"{'btn-primary':pageVar.value == item.value}\"\n" +
    "                        ng-click=\"pageController.updateInputType(pageVar, item)\">{{item.label}}\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-switch-default>\n" +
    "            <input type=\"text\" class=\"form-control\" ng-model=\"pageVar.value\" ng-trim=\"false\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/edgePageVarEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/edgePageVarEditor.tpl.html",
    "<div>\n" +
    "    <form id=\"form\" name=\"form\">\n" +
    "        <edge-list ng-if=\"$root.isAdmin && showMappings && ctrlr.pageVars.length> 0\"\n" +
    "                   items=\"ctrlr.pageVars\"\n" +
    "                   selectable=\"false\"\n" +
    "                   type=\"reorderable\"\n" +
    "                   class=\"pagevar-list\">\n" +
    "            <edge-pagevar-control page-controller=\"listScope.ctrlr.pageCtrlr\"\n" +
    "                                  page-var=\"item\"\n" +
    "                                  show-mappings=\"listScope.ctrlr.$scope.showMappings\"\n" +
    "                                  ng-class=\"{'hide-pagevar': item.hide}\"></edge-pagevar-control>\n" +
    "        </edge-list>\n" +
    "        <edge-pagevar-control ng-if=\"::!($root.isAdmin && showMappings)\"\n" +
    "                              ng-repeat=\"pageVar in ctrlr.pageVars\"\n" +
    "                              page-controller=\"ctrlr.pageCtrlr\"\n" +
    "                              page-var=\"pageVar\"\n" +
    "                              show-mappings=\"ctrlr.$scope.showMappings\"></edge-pagevar-control>\n" +
    "        <div ng-if=\"showMappings && ctrlr.PageVarManager.pageVarMappings.length > 0\">\n" +
    "            <div class=\"sidebar-headline\" translate>Variable Mappings</div>\n" +
    "            <edge-page-var-mapping-list mappings=\"ctrlr.PageVarManager.pageVarMappings\"\n" +
    "                                        page-controller=\"ctrlr.pageCtrlr\"></edge-page-var-mapping-list>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/edgePageVarMappingControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/edgePageVarMappingControl.tpl.html",
    "<div class=\"form-group\" style=\"padding: 0 12px 0 5px;\" ng-class=\"{'has-error': hasSyntaxError}\">\n" +
    "    <label style=\"font-weight: normal\">{{pageVarMapping.producerParam.parameterName}}</label>\n" +
    "    <input type=\"text\" class=\"form-control\" title=\"{{title}}\" ng-model=\"pageVarMapping.producerParam.value\" ng-blur=\"validate()\" ng-trim=\"false\">\n" +
    "    <div ng-if=\"hasSyntaxError\" class=\"edge-error-messages ng-active\">\n" +
    "        <div translate>Invalid syntax</div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/edgePageVarMappingList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/edgePageVarMappingList.tpl.html",
    "<div>\n" +
    "    <div class=\"pageVarMapping\" ng-repeat=\"producerID in uniqueProducers\"\n" +
    "         ng-mouseenter=\"mouseEnter(producerID, $event)\"\n" +
    "         ng-mouseleave=\"mouseLeave(producerID, $event)\">\n" +
    "        <label style=\"padding:0px 5px;\">{{pageController.getProducerInstanceTitle(producerID)}}</label>\n" +
    "        <edge-page-var-mapping-control ng-repeat=\"pageVarMapping in mappings | filter:{producerID: producerID}\"></edge-page-var-mapping-control>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/edit-pagevar-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/edit-pagevar-dialog.tpl.html",
    "<form name=\"pageVarForm\" class=\"form-horizontal\">\n" +
    "    <style>\n" +
    "        form[name=pageVarForm] .input-group>.ui-select-bootstrap>input.ui-select-search.form-control {\n" +
    "            border-radius: 0;\n" +
    "        }\n" +
    "    </style>\n" +
    "    <div ng-if=\"Controller.isDuplicateName\" class=\"alert alert-danger\" translate>A page variable of the same name already exists, please enter a different name</div>\n" +
    "    <edge-property-control label-width=\"3\" validation=\"true\" property-def=\"::Controller.nameDef\" property-value=\"Controller.name\"></edge-property-control>\n" +
    "    <edge-property-control label-width=\"3\" validation=\"true\" property-def=\"::Controller.labelDef\" property-value=\"Controller.label\" ></edge-property-control>\n" +
    "    <edge-property-control label-width=\"3\" property-def=\"::Controller.hideDef\" property-value=\"Controller.hide\"></edge-property-control>\n" +
    "    <edge-labeled-control label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Variable Constraint'|translate}}\">\n" +
    "        <div class=\"input-group\">\n" +
    "            <span class=\"input-group-addon\"><i class=\"icon icon_database\"></i></span>\n" +
    "            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "            <input type=hidden name=\"dummy123\" ng-model=\"Controller.selectedConstraint\" ng-required=\"true\">\n" +
    "            <ui-select ng-required=\"true\" ng-model=\"Controller.selectedConstraint\" on-select=\"Controller.selectConstraint($item)\" append-to-body=\"true\">\n" +
    "                <ui-select-match theme=\"bootstrap\">\n" +
    "                    {{$select.selected.name}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item in Controller.constraints | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                    <small class=\"pull-right\" ng-bind-html=\"item.propertyTypeName\"></small>\n" +
    "                    <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "            <span class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\"\n" +
    "                        ng-click=\"Controller.showEditConstraintDialog(false)\"><i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"Controller.showEditConstraintDialog(true)\"\n" +
    "                        ng-disabled=\"Controller.selectedConstraint==null || Controller.selectedConstraint.id.indexOf('DEFAULT_') == 0\"><i class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </edge-labeled-control>\n" +
    "    <div ng-if=\"Controller.selectedConstraint.isString() || Controller.selectedConstraint.isDatetime()\">\n" +
    "        <edge-property-control ng-if=\"Controller.selectedConstraint.choices.length === 0\" label-width=\"3\" validation=\"true\" property-def=\"::Controller.unboundedDefaultValueDef\" property-value=\"Controller.defaultValue\"></edge-property-control>\n" +
    "        <edge-labeled-control ng-if=\"Controller.selectedConstraint.choices.length > 0\" label-width=\"3\" validation=\"true\" label=\"{{::'Default Value'|translate}}\">\n" +
    "             <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "            <input type=hidden name=\"defaulValue123\" ng-model=\"Controller.defaultValue.label\" ng-required=\"true\">\n" +
    "            <ui-select ng-required=\"true\" ng-model=\"Controller.defaultValue\" append-to-body=\"true\" theme=\"bootstrap\">\n" +
    "                <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item in Controller.selectedConstraint.choices | filter: {label: $select.search} track by item.value\">\n" +
    "                    <span ng-bind-html=\"item.label | highlightHtmlSafe: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"Controller.selectedConstraint.choices.length > 0\" label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Input Control'|translate}}\">\n" +
    "            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "            <input type=hidden name=\"hint123\" ng-model=\"Controller.selectedConstraint.inputType\" ng-required=\"true\">\n" +
    "            <ui-select ng-required=\"true\" ng-model=\"Controller.selectedConstraint.inputType\" append-to-body=\"true\">\n" +
    "                <ui-select-match theme=\"bootstrap\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item.value as item in Controller.inputTypes\">\n" +
    "                    <span>{{item.label}}</span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div ng-if=\"Controller.showNumberSpinner\">\n" +
    "        <edge-labeled-control label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Default Value'|translate}}\" element-name=\"defaulValue123\">\n" +
    "            <edge-number-spinner inputname=\"defaulValue123\" isrequired=\"true\"\n" +
    "                     ng-model=\"Controller.defaultValue.value\"\n" +
    "                     placeholder=\"{{Controller.selectedConstraint.spinner.placeholder}}\"\n" +
    "                     reload=\"Controller.selectedConstraint.spinner.reload\"\n" +
    "                     step=\"Controller.selectedConstraint.spinner.interval\" minimum=\"Controller.selectedConstraint.spinner.min\"\n" +
    "                     maximum=\"Controller.selectedConstraint.spinner.max\">\n" +
    "            </edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/page/pagevars/pagevar-manager-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/pagevars/pagevar-manager-dialog.tpl.html",
    "<div ng-controller=\"PageVarManageDialogController as ctrlr\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"pull-right\" style=\"margin-right:5px;\">\n" +
    "            <nav class=\"toolbar navbar navbar-default\" role=\"navigation\">\n" +
    "                <form class=\"navbar-form navbar-left\" role=\"search\">\n" +
    "                    <div class=\"form-inline\">\n" +
    "                        <div class=\"form-group\">\n" +
    "                            <div class=\"input-group\">\n" +
    "                                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                                <input type=\"search\" ng-model=\"ctrlr.q\" class=\"form-control\"\n" +
    "                                       placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == false }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{'Sort Alphabetically' | translate}}\"><i\n" +
    "                                    class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\" ng-class=\"{ 'active' : ctrlr.reverse == true }\"\n" +
    "                                    ng-click=\"ctrlr.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{'Sort Reverse Alphabetical' | translate}}\"><i\n" +
    "                                    class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </form>\n" +
    "            </nav>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-panel>\n" +
    "        <edge-list selected-item=\"ctrlr.selectedPageVar\"\n" +
    "                   items=\"ctrlr.pageVars\"\n" +
    "                   sort=\"name\" q=\"{name:ctrlr.q}\" reverse=\"ctrlr.reverse\" style=\"min-height: 40em\">\n" +
    "            <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editPageVar(false)\">\n" +
    "                <span ng-bind-html=\"item.name | highlight: listScope.ctrlr.q\"></span>\n" +
    "                <span class=\"pull-right\"><em>{{item.defaultValue}}</em></span>\n" +
    "            </div>\n" +
    "        </edge-list>\n" +
    "    </edge-panel>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"pull-left btn-group\" role=\"group\">\n" +
    "                <button type=\"button\" class=\"btn btn-default\" ng-click=\"ctrlr.editPageVar(true)\">\n" +
    "                    <i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button type=\"button\" class=\"btn btn-default\" ng-click=\"ctrlr.editPageVar(false)\"\n" +
    "                        ng-disabled=\"ctrlr.selectedPageVar == null\">\n" +
    "                    <i class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "                <button type=\"button\" class=\"btn btn-default\" ng-click=\"ctrlr.deletePageVar()\"\n" +
    "                        ng-disabled=\"ctrlr.selectedPageVar == null\">\n" +
    "                    <i class=\"icon icon_trash\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"ctrlr.handleClose()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/page/parameters/edit-param-property.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/parameters/edit-param-property.tpl.html",
    "<form name=\"paramPropertyForm\" class=\"with-padding form-horizontal\" style=\"height: 100%;\">\n" +
    "    <style>\n" +
    "        form[name=paramPropertyForm] .input-group>.ui-select-bootstrap>input.ui-select-search.form-control {\n" +
    "            border-radius: 0;\n" +
    "        }\n" +
    "    </style>\n" +
    "    <div ng-if=\"Controller.isDuplicateName\" class=\"alert alert-danger\"><span translate>A variable of the same name already exists, please enter a different name</span></div>\n" +
    "    <div class=\"col-sm-7\" style=\"padding-right: 25px\">\n" +
    "        <edge-property-control label-width=\"3\" validation=\"true\" property-def=\"::Controller.nameDef\" property-value=\"Controller.name\" ></edge-property-control>\n" +
    "        <edge-labeled-control label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Variable Constraint'|translate}}\">\n" +
    "            <div class=\"input-group\" style=\"width:100%\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_database\"></i></span>\n" +
    "                <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <input type=hidden name=\"dummy123\" ng-model=\"Controller.selectedConstraint\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"Controller.selectedConstraint\" on-select=\"Controller.selectConstraint($item)\" append-to-body=\"true\">\n" +
    "                    <ui-select-match theme=\"bootstrap\">\n" +
    "                        {{$select.selected.name}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in Controller.constraints | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                        <small class=\"pull-right\" ng-bind-html=\"item.propertyTypeName\"></small>\n" +
    "                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                    <button class=\"btn btn-default\" type=\"button\"\n" +
    "                            ng-click=\"Controller.showEditConstraintDialog(false)\"><i class=\"icon icon_plus\"></i>\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-default\" type=\"button\" ng-click=\"Controller.showEditConstraintDialog(true)\"\n" +
    "                            ng-disabled=\"Controller.selectedConstraint==null || Controller.selectedConstraint.id.indexOf('DEFAULT_') == 0\"><i class=\"icon icon_pencil\"></i>\n" +
    "                    </button>\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "        <div ng-if=\"Controller.selectedConstraint.isString() || Controller.selectedConstraint.isDatetime()\">\n" +
    "            <edge-property-control ng-if=\"Controller.selectedConstraint.choices.length === 0\" label-width=\"3\" validation=\"true\" property-def=\"::Controller.unboundedDefaultValueDef\" property-value=\"Controller.defaultValue\"></edge-property-control>\n" +
    "            <edge-labeled-control ng-if=\"Controller.selectedConstraint.choices.length > 0\" label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Default Value'|translate}}\">\n" +
    "                 <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <input type=hidden name=\"defaulValue123\" ng-model=\"Controller.defaultValue.label\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"Controller.defaultValue\" append-to-body=\"true\" theme=\"bootstrap\">\n" +
    "                    <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in Controller.selectedConstraint.choices | filter: {label: $select.search} track by item.value\">\n" +
    "                        <span ng-bind-html=\"item.label | highlightHtmlSafe: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"Controller.selectedConstraint.choices.length > 0\" label-width=\"3\" validation=\"true\" required=\"true\" label=\"{{::'Input Control'|translate}}\">\n" +
    "                <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <input type=hidden name=\"hint123\" ng-model=\"Controller.selectedConstraint.inputType\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"Controller.selectedConstraint.inputType\">\n" +
    "                    <ui-select-match theme=\"bootstrap\">\n" +
    "                        {{$select.selected.label}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item.value as item in Controller.inputTypes\">\n" +
    "                        <span>{{item.label}}</span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div ng-if=\"Controller.showNumberSpinner\">\n" +
    "            <edge-labeled-control label-width=\"3\" validation=\"true\" label=\"{{::'Default Value'|translate}}\" element-name=\"defaulValue123\">\n" +
    "                <edge-number-spinner inputname=\"defaulValue123\" isrequired=\"true\"\n" +
    "                         ng-model=\"Controller.defaultValue.value\"\n" +
    "                         placeholder=\"{{Controller.selectedConstraint.spinner.placeholder}}\"\n" +
    "                         reload=\"Controller.selectedConstraint.spinner.reload\"\n" +
    "                         step=\"Controller.selectedConstraint.spinner.interval\" minimum=\"Controller.selectedConstraint.spinner.min\"\n" +
    "                         maximum=\"Controller.selectedConstraint.spinner.max\">\n" +
    "                </edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-5\">\n" +
    "        <edge-panel ng-if=\"Controller.selectedConstraint.isString()\" id=\"{{Controller.panelId}}\" style=\"height: 100%;\">\n" +
    "            <edge-panel-header label=\"{{::'Allowable Values'|translate}}\">\n" +
    "                <div class=\"panel-heading-control pull-right\">\n" +
    "                    <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input\n" +
    "                                type=\"search\"\n" +
    "                                ng-model=\"panelScope.Controller.q\"\n" +
    "                                class=\"form-control\"\n" +
    "                                placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-panel-header>\n" +
    "            <edge-panel-body style=\"min-height:250px\">\n" +
    "                <edge-list items=\"Controller.selectedConstraint.choices\" selected-item=\"Controller.selectedValue\" q=\"panelScope.Controller.q\">\n" +
    "                    <div class=\"row\" style=\"padding: 15px\">\n" +
    "                        <span ng-bind-html=\"item.label | highlight:listScope.panelScope.Controller.q\"></span>\n" +
    "                        <span class=\"text-italic pull-right\" ng-bind-html=\"item.value\" ng-if=\"listScope.panelScope.Controller.selectedConstraint.attributeLabel\"></span>\n" +
    "                    </div>\n" +
    "                </edge-list>\n" +
    "            </edge-panel-body>\n" +
    "            <edge-panel-footer>\n" +
    "                <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                    <span class=\"badge pull-right\"\n" +
    "                          translate translate-params-count=\"(panelScope.Controller.selectedConstraint.choices|filter:panelScope.Controller.q).length\"\n" +
    "                          translate-params-total=\"panelScope.Controller.selectedConstraint.choices.length\">\n" +
    "                      {{count}} of {{total}} Values\n" +
    "                    </span>\n" +
    "                </div>\n" +
    "            </edge-panel-footer>\n" +
    "        </edge-panel>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/page/parameters/edit-secparam-property.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/parameters/edit-secparam-property.tpl.html",
    "<form name=\"secParamPropertyForm\" class=\"form-horizontal\">\n" +
    "    <style>\n" +
    "        form[name=secParamPropertyForm] .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n" +
    "            border-radius: 0;\n" +
    "        }\n" +
    "    </style>\n" +
    "    <div ng-if=\"Controller.isDuplicateName\" class=\"alert alert-danger\" translate>A credential of the same name already exists, please enter a different name.\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-12\">\n" +
    "        <edge-labeled-control label-width=\"4\" label=\"{{::'Name' | translate}}\" validation=\"true\">\n" +
    "            <input name=\"paramName\" type=\"text\" class=\"form-control\" ng-model=\"Controller.name\" required edge-focus>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"::Controller.isNew\" label-width=\"4\" validation=\"true\"\n" +
    "                              required=\"true\" label=\"{{::'Type'|translate}}\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_database\"></i></span>\n" +
    "                <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                <input type=hidden name=\"dummy123\" ng-model=\"Controller.selectedCredentialTemplate\" ng-required=\"true\">\n" +
    "                <ui-select ng-required=\"true\" ng-model=\"Controller.selectedCredentialTemplate\"\n" +
    "                           on-select=\"Controller.selectCredentialTemplate($item)\">\n" +
    "                    <ui-select-match theme=\"bootstrap\">\n" +
    "                        {{$select.selected.name}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in Controller.credentialTemplates | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </div>\n" +
    "        </edge-labeled-control>\n" +
    "        <div ng-if=\"! Controller.isNew || Controller.selectedCredentialTemplate\">\n" +
    "            <div>\n" +
    "                <label class=\"col-sm-4 control-label\" translate>Credential</label>\n" +
    "                <div class=\"col-sm-8\" style=\"margin-bottom: -15px\">\n" +
    "                    <edge-credential-set ng-model=\"Controller.defaultCredential\"></edge-credential-set>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <edge-labeled-control style=\"margin-top: 10px;\" label-width=\"4\" label=\"{{::'Credential Usage'|translate}}\">\n" +
    "                <label style=\"margin-top: 10px;\">\n" +
    "                    <input type=\"radio\" ng-model=\"Controller.inheritedValue\" value=\"{{::Controller.DEFAULT_IS_NULL}}\">\n" +
    "                    <span translate>Use for validation only</span><br/>\n" +
    "                    <span style=\"font-weight: normal\" translate>Credentials will only be used to validate endpoints.</span><br/>\n" +
    "                    <span style=\"font-weight: normal\" translate>Users will be prompted to enter their information.</span>\n" +
    "                </label><br/>\n" +
    "                <label>\n" +
    "                    <input type=\"radio\" ng-model=\"Controller.inheritedValue\" value=\"{{::Controller.USE_VALIDATION}}\">\n" +
    "                    <span translate>Use as a default value</span><br/>\n" +
    "                    <span style=\"font-weight: normal\" translate>Credentials will be used as a default value for all users.</span><br/>\n" +
    "                    <span style=\"font-weight: normal\" translate>Users will not be prompted to enter their information.</span>\n" +
    "                </label>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/page/parameters/parameter-chooser-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/parameters/parameter-chooser-dialog.tpl.html",
    "<edge-dialog-header>\n" +
    "    <div class=\"pull-right\" style=\"margin-right:5px;\">\n" +
    "        <nav class=\"toolbar navbar navbar-default\" role=\"navigation\">\n" +
    "            <form class=\"navbar-form navbar-left\" role=\"search\">\n" +
    "                <div class=\"form-inline\">\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                            <input type=\"search\" ng-model=\"dialogController.q\" class=\"form-control\"\n" +
    "                                   placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-default\" ng-class=\"{ 'active' : dialogController.reverse == false }\"\n" +
    "                                ng-click=\"dialogController.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                                title=\"{{'Sort Alphabetically' | translate}}\"><i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-default\" ng-class=\"{ 'active' : dialogController.reverse == true }\"\n" +
    "                                ng-click=\"dialogController.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                                title=\"{{'Sort Reverse Alphabetical' | translate}}\"><i\n" +
    "                                class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i></button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </nav>\n" +
    "    </div>\n" +
    "</edge-dialog-header>\n" +
    "<edge-panel>\n" +
    "    <edge-list selected-item=\"dialogController.selectedParam\"\n" +
    "               items=\"dialogController.parameters\"\n" +
    "               sort=\"parameterName\" q=\"{parameterName:dialogController.q}\" reverse=\"dialogController.reverse\"\n" +
    "               style=\"min-height: 40em\">\n" +
    "        <div class=\"with-padding\" ng-dblclick=\"listScope.dialogController.editParameter(false)\">\n" +
    "            <span\n" +
    "                ng-bind-html=\"item.parameterName | highlight: listScope.dialogController.q\"></span><span\n" +
    "                class=\"pull-right\"><em>{{item.label}}</em></span>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "</edge-panel>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <div class=\"pull-left btn-group\" role=\"group\">\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.editParameter(true)\">\n" +
    "                <i class=\"icon icon_plus\"></i>\n" +
    "            </button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.editParameter(false)\"\n" +
    "                    ng-disabled=\"dialogController.selectedParam == null\">\n" +
    "                <i class=\"icon icon_pencil\"></i>\n" +
    "            </button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.deleteParameter()\"\n" +
    "                    ng-disabled=\"dialogController.selectedParam == null\">\n" +
    "                <i class=\"icon icon_trash\"></i>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "        <button class=\"btn btn-default\" ng-click=\"handleCancel()\" translate>\n" +
    "            Close\n" +
    "        </button>\n" +
    "        <button ng-if=\"::!dialogController.manageMode\" class=\"btn btn-success\" ng-disabled=\"dialogController.selectedParam == null\"\n" +
    "                ng-click=\"handleInsert(true)\" translate>Insert Variable\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>\n" +
    "");
}]);

angular.module("edge/core/page/parameters/secparam-chooser-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/page/parameters/secparam-chooser-dialog.tpl.html",
    "<edge-dialog-header>\n" +
    "    <div class=\"pull-right\" style=\"margin-right:5px;\">\n" +
    "        <nav class=\"toolbar navbar navbar-default\" role=\"navigation\">\n" +
    "            <form class=\"navbar-form navbar-left\" role=\"search\">\n" +
    "                <div class=\"form-inline\">\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input type=\"search\"\n" +
    "                                                                                                           ng-model=\"dialogController.q\"\n" +
    "                                                                                                           class=\"form-control\"\n" +
    "                                                                                                           placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-default\" ng-class=\"{ 'active' : dialogController.reverse == false }\"\n" +
    "                                ng-click=\"dialogController.reverse = false\" data-toggle=\"tooltip\"\n" +
    "                                title=\"{{'Sort Alphabetically' | translate}}\"><i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-default\" ng-class=\"{ 'active' : dialogController.reverse == true }\"\n" +
    "                                ng-click=\"dialogController.reverse = true\" data-toggle=\"tooltip\"\n" +
    "                                title=\"{{'Sort Reverse Alphabetical' | translate}}\"><i\n" +
    "                                class=\"glyphicon glyphicon-sort-by-attributes-alt\"></i></button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </nav>\n" +
    "    </div>\n" +
    "</edge-dialog-header>\n" +
    "<edge-panel>\n" +
    "    <edge-list selected-item=\"dialogController.selectedParam\"\n" +
    "               items=\"dialogController.securityParameters\"\n" +
    "               sort=\"parameterName\" q=\"{parameterName:dialogController.q}\" reverse=\"dialogController.reverse\"\n" +
    "               style=\"min-height: 40em\">\n" +
    "        <div class=\"with-padding\" ng-dblclick=\"listScope.dialogController.editParameter(false)\">\n" +
    "            <span ng-bind-html=\"item.parameterName | highlight: listScope.dialogController.q\"></span>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "</edge-panel>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <div class=\"pull-left btn-group\" role=\"group\">\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.editParameter(true)\">\n" +
    "                <i class=\"icon icon_plus\"></i>\n" +
    "            </button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.editParameter(false)\"\n" +
    "                    ng-disabled=\"dialogController.selectedParam == null\">\n" +
    "                <i class=\"icon icon_pencil\"></i>\n" +
    "            </button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"dialogController.deleteParameter()\"\n" +
    "                    ng-disabled=\"dialogController.selectedParam == null\">\n" +
    "                <i class=\"icon icon_trash\"></i>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "        <button class=\"btn btn-default\" ng-click=\"handleCancel()\" translate>\n" +
    "            Close\n" +
    "        </button>\n" +
    "        <button ng-if=\"::!dialogController.manageMode\"\n" +
    "                class=\"btn btn-success\"\n" +
    "                ng-disabled=\"dialogController.selectedParam == null\"\n" +
    "                ng-click=\"handleInsert()\"\n" +
    "                translate>Insert Secured Variable\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>\n" +
    "");
}]);

angular.module("edge/core/pipes/edgePipes.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/edgePipes.tpl.html",
    "<div class='pipes'>\n" +
    "    <div class='pipesTopology'></div>\n" +
    "    <div ng-show='diagram.showOverview' class='pipesOverview'></div>\n" +
    "    <div class=\"edgeWidgetOverlay\" ng-if=\"options.showControls\">\n" +
    "        <ul>\n" +
    "            <li>\n" +
    "                <a rel=\"tooltip\"\n" +
    "                   title=\"{{::'Zoom in' | translate}}\"\n" +
    "                   ng-click=\"diagram.commandHandler.increaseZoom()\"><i class=\"icon icon_plus btn_icon\"></i></a>\n" +
    "            </li>\n" +
    "            <li>\n" +
    "                <a rel=\"tooltip\" title=\"{{::'Zoom out' | translate}}\" ng-click=\"diagram.commandHandler.decreaseZoom()\"><i\n" +
    "                        class=\"icon icon_minus btn_icon \"></i></a>\n" +
    "            </li>\n" +
    "            <li><a rel=\"tooltip\" title=\"{{::'Fit to View' | translate}}\" ng-click=\"diagram.commandHandler.zoomToFit()\"><i\n" +
    "                    class=\"icon icon_fit_to_zoom\"></i></a></li>\n" +
    "        </ul>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/pipes/edgePipesTable.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/edgePipesTable.tpl.html",
    "<div style=\"height: 100%;\">\n" +
    "    <div ui-grid=\"eptCtrlr.dataGridOptions\"\n" +
    "         ui-grid-selection\n" +
    "         ui-grid-auto-resize\n" +
    "         ui-grid-resize-columns\n" +
    "         style=\"height: 100%;\"\n" +
    "         class=\"grid modulegrid edge-pipes-table\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/pipes/edgePipesTreeTable.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/edgePipesTreeTable.tpl.html",
    "<div style=\"height: 100%;\">\n" +
    "    <div ui-grid=\"eptCtrlr.dataGridOptions\"\n" +
    "         ui-grid-selection\n" +
    "         ui-grid-auto-resize\n" +
    "         ui-grid-resize-columns\n" +
    "         ui-grid-tree-view\n" +
    "         style=\"height: 100%;\"\n" +
    "         class=\"grid modulegrid edge-pipes-table\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/pipes/pipes-settings-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/pipes-settings-dialog.tpl.html",
    "<div ng-controller=\"PipesSettingsDialogController as Ctrlr\">\n" +
    "    <form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "        <div class=\"alert alert-info\" translate>Hold down <kbd>ALT</kbd> (or optionally <kbd>CTRL</kbd> on Windows) to use the alternate action on 'Double Click' and 'Mouse Wheel'.</div>\n" +
    "\n" +
    "        <edge-labeled-control label=\"{{::'Default View Mode' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"defaultView\" ng-model=\"Ctrlr.defaultView\" class=\"form-control\" ng-required=\"true\">\n" +
    "                <option value=\"topo\" translate>Topology</option>\n" +
    "                <option value=\"table\" translate>Table</option>\n" +
    "                <option value=\"treetable\" translate>Tree Table</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Double Click Action' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"dblClickAction\" ng-model=\"Ctrlr.dblClickAction\" class=\"form-control\"\n" +
    "                    ng-required=\"true\">\n" +
    "                <option value=\"edit\" translate>Edit</option>\n" +
    "                <option value=\"filter\" translate>Filter</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Popup Menu Style' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"popupMenuStyle\" ng-model=\"Ctrlr.popupMenuStyle\" class=\"form-control\"\n" +
    "                    ng-required=\"true\">\n" +
    "                <option value=\"radial\" translate>Radial</option>\n" +
    "                <option value=\"vertical\" translate>Vertical</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Mouse Wheel Action' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"mouseWheelAction\" ng-model=\"Ctrlr.mouseWheelAction\" class=\"form-control\"\n" +
    "                    ng-required=\"true\">\n" +
    "                <option value=\"pan\" translate>Pan</option>\n" +
    "                <option value=\"zoom\" translate>Zoom</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Link Style' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"linkStyle\" ng-model=\"Ctrlr.linkStyle\" class=\"form-control\" ng-required=\"true\">\n" +
    "                <option value=\"bezier\" translate>Bezier</option>\n" +
    "                <option value=\"ortho\" translate>Orthogonal</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Layout Direction' | translate}}\" validation=\"true\">\n" +
    "            <select name=\"layoutDirection\" ng-model=\"Ctrlr.layoutDirection\" class=\"form-control\"\n" +
    "                    ng-required=\"true\">\n" +
    "                <option value=\"right\" translate>Right</option>\n" +
    "                <option value=\"down\" translate>Down</option>\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control label=\"{{::'Show Overview Window' | translate}}\" style=\"margin-bottom: 0;\">\n" +
    "            <input type='checkbox' name=\"showOverview\" ng-model='Ctrlr.showOverview' edge-boolean-switch>\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"Ctrlr.handleCancel()\" translate>Cancel and Close</button>\n" +
    "            <button class=\"btn btn-success\" ng-click=\"Ctrlr.handleSave()\" translate>Save</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/pipes/reparent-node-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/reparent-node-dialog.tpl.html",
    "<div ng-controller=\"ReparentNodeDialogController as rndCtrlr\" style=\"height:100%; overflow: hidden;\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"pull-right\" style=\"margin-top: 2px; margin-right 5px;\">\n" +
    "            <edge-pipeline-search show-pages=\"::false\" seed-search-choice=\"::searchChoice\"></edge-pipeline-search>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <edge-pipes ng-if=\"rndCtrlr.viewMode == 'topo'\" options=\"rndCtrlr.pipesOptions\" selected-node=\"rndCtrlr.selectedNode\">\n" +
    "    </edge-pipes>\n" +
    "    <edge-pipes-table ng-if=\"rndCtrlr.viewMode == 'table'\" pipes-controller=\"rndCtrlr\" read-only=\"true\"\n" +
    "        nodes=\"rndCtrlr.compatibleNodes\" selected-node=\"rndCtrlr.selectedNode\">\n" +
    "    </edge-pipes-table>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <div class=\"btn-group pull-left\">\n" +
    "                <button class=\"edgeSmallToggleButton btn btn-default btn-sm\"\n" +
    "                        ng-class=\"{'toggledOn' : rndCtrlr.viewMode === 'topo'}\"\n" +
    "                        ng-click=\"rndCtrlr.viewMode = 'topo'\">\n" +
    "                    <span translate>Topology</span>\n" +
    "                </button>\n" +
    "                <button class=\"edgeSmallToggleButton btn btn-default btn-sm\"\n" +
    "                        ng-class=\"{'toggledOn' : rndCtrlr.viewMode === 'table'}\"\n" +
    "                        ng-click=\"rndCtrlr.viewMode = 'table'\">\n" +
    "                    <span translate>Table</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"dialogRef.close()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-default\" ng-disabled=\"!rndCtrlr.selectedNode\" ng-click=\"rndCtrlr.reparent()\">\n" +
    "                <span translate>Reparent</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/pipes/search/edgePipelineSearch.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/pipes/search/edgePipelineSearch.tpl.html",
    "<div class=\"input-group dropdown pipeline-search edge-pipe\" ng-disabled=\"ctrlr.loading\">\n" +
    "    <span class=\"input-group-addon\"\n" +
    "          ng-attr-title=\"Search on {{ctrlr.searchContext.displayName}}\"\n" +
    "          data-toggle=\"dropdown\"\n" +
    "          aria-haspopup=\"true\"\n" +
    "          aria-expanded=\"false\"\n" +
    "          style=\"height:24px;line-height:7px;font-size:10px;padding:0px 4px;cursor:pointer;\">\n" +
    "        <i class=\"icon icon_search\"></i><span class=\"caret\"></span>\n" +
    "    </span>\n" +
    "    <div class=\"dropdown-menu\" ng-click=\"$event.stopPropagation();\">\n" +
    "        <form class=\"form-horizontal\" style=\"padding:0px 10px 10px 10px\">\n" +
    "            <div class=\"radio\" ng-repeat=\"context in ctrlr.contexts\">\n" +
    "                <label>\n" +
    "                    <input type=\"radio\"\n" +
    "                           ng-value=\"context\"\n" +
    "                           ng-model=\"ctrlr.searchContext\">{{context.displayName}}</label>\n" +
    "            </div>\n" +
    "            <div ng-if=\"ctrlr.searchContext.type !== ctrlr.byPage\">\n" +
    "                <hr>\n" +
    "                <div class=\"checkbox\">\n" +
    "                    <label>\n" +
    "                        <input type=\"checkbox\" ng-value=\"grouped\" ng-model=\"ctrlr.groupResults\" ng-change=\"ctrlr.updateDropdown()\">\n" +
    "                        <span translate>Group By Category</span>\n" +
    "                    </label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </form>\n" +
    "    </div>\n" +
    "    <ui-select ng-model=\"ctrlr.selectedChoice\"\n" +
    "               theme=\"bootstrap\"\n" +
    "               on-select=\"ctrlr.selectionChanged($item)\">\n" +
    "        <ui-select-match placeholder=\"{{::'Search...' | translate}}\">\n" +
    "            <span ng-if=\"ctrlr.loading\" us-spinner=\"{hwaccel:'true',radius:4,width:2,length:3}\"></span>\n" +
    "            <div ng-if=\"$select.selected\"\n" +
    "                 class=\"icon edge-ui-select-choice-icon\"\n" +
    "                 ng-class=\"ctrlr.getIconClass($select.selected)\"\n" +
    "                 title=\"{{$select.selected.displayName}}\"\n" +
    "                 ng-bind-html=\"$select.selected.displayName\">\n" +
    "            </div>\n" +
    "        </ui-select-match>\n" +
    "        <ui-select-choices use-vs-repeat=\"true\" group-by=\"ctrlr.getGroupBy()\" group-filter=\"ctrlr.sortGroup\" repeat=\"item in ctrlr.choices | filter: {displayName: $select.search}\">\n" +
    "            <div class=\"edge-ui-select-choice-icon\" title=\"{{item.displayName}}\"\n" +
    "                 ng-bind-html=\"item.displayName | highlight: $select.search\"></div>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "    <style>\n" +
    "        .pipeline-search .edge-ui-select-choice-icon.icon:before {\n" +
    "            padding-right: 5px;\n" +
    "        }\n" +
    "    </style>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/prefs/preferences.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/prefs/preferences.tpl.html",
    "<div ng-controller=\"UserPrefsController as ctrlr\">\n" +
    "    <form name=\"userPrefs\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{::'Locale' | translate}}\" validation=\"true\">\n" +
    "                <input type=\"hidden\" name=\"locale\" ng-model=\"ctrlr.prefs['client.locale']\" ng-trim=\"false\" required>\n" +
    "                <ui-select ng-model=\"ctrlr.prefs['client.locale']\" theme=\"bootstrap\">\n" +
    "                    <ui-select-match placeholder=\"{{::'Choose a locale...' | translate}}\">{{$select.selected}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in (ctrlr.locales | filter: $select.search)\">\n" +
    "                        <div ng-bind-html=\"item | highlight: $select.search\"></div>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control label=\"{{::'Time Zone' | translate}}\"\n" +
    "                                  helptext=\"{{::'If the value is not set then your browser\\'s default will be used.'|translate}}\">\n" +
    "                <ui-select theme=\"bootstrap\" ng-model=\"ctrlr.prefs['client.timezone']\">\n" +
    "                    <ui-select-match allow-clear=\"true\">{{$select.selected.value}}</ui-select-match>\n" +
    "                    <ui-select-choices group-by=\"::'groupBy'\"\n" +
    "                                       repeat=\"field.value as field in (ctrlr.tz | filter:$select.search)\">\n" +
    "                        <span ng-bind-html=\"::field.label\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-default\" ng-click=\"ctrlr.handleClose()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\" ng-click=\"ctrlr.savePrefs()\" translate>Save</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/prefs/user-password-changer.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/prefs/user-password-changer.tpl.html",
    "<form name=\"passwordForm\" class=\"form-horizontal\">\n" +
    "    <div ng-if=\"Controller.error\" class=\"alert alert-danger\" style=\"margin: 0 0 20px 0;\">\n" +
    "        <span style=\"white-space: pre-line\" ng-bind-html=\"Controller.error\"></span>\n" +
    "    </div>\n" +
    "    <edge-property-control class=\"col-sm-12\" label-width=\"4\" validation=\"true\" property-def=\"::Controller.passwordDef\" property-value=\"Controller.currentPassword\"></edge-property-control>\n" +
    "    <edge-labeled-control validation=\"true\" required=\"true\" label-width=\"4\" style=\"padding: 0 5px\"label=\"{{::'New Password'|translate}}\">\n" +
    "        <input class=\"form-control\" name=\"newPassword\" id=\"newPassword\" type=\"password\" ng-model=\"Controller.newPassword\" ng-change=\"Controller.validateConfirm()\" ng-required=\"true\" ng-model-options=\"{allowInvalid: true}\"\n" +
    "               ng-minlength=\"Controller.pwdPolicy.minLength\" ng-maxlength=\"Controller.pwdPolicy.maxLength > 0 ? Controller.pwdPolicy.maxLength : null\" >\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control validation=\"true\" required=\"true\" label-width=\"4\" style=\"padding: 0 5px\" label=\"{{::'Confirm Password'|translate}}\" helptext=\"{{::'Please enter the same password'|translate}}\">\n" +
    "        <input class=\"form-control\" name=\"confirmPassword\" id=\"confirmPassword\" type=\"password\" ng-model=\"Controller.confirmPassword\" ng-model-options=\"{allowInvalid: true}\" ng-change=\"Controller.validateConfirm()\" ng-required=\"true\">\n" +
    "    </edge-labeled-control>\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-4\"></div>\n" +
    "        <div class=\"col-sm-8\">\n" +
    "            <div ng-if=\"Controller.pwdPolicy.rules.length > 0 || Controller.pwdPolicy.minLength > 0 || Controller.pwdPolicy.maxLength > 0\"\n" +
    "                 class=\"alert {{Controller.isPasswordValid() ? 'alert-info' : 'alert-danger'}}\">\n" +
    "                <label>{{::'Password Policy' | translate}}</label>\n" +
    "                <label ng-if=\"Controller.pwdPolicy.minLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"Controller.newPassword.length >= Controller.pwdPolicy.minLength\"> <span translate translate-params-min=\"::Controller.pwdPolicy.minLength\">Minimum password length is {{min}}</label>\n" +
    "                <label ng-if=\"Controller.pwdPolicy.maxLength > 0\"><input type=\"checkbox\" disabled ng-checked=\"Controller.newPassword.length <= Controller.pwdPolicy.maxLength\"> <span translate translate-params-max=\"::Controller.pwdPolicy.maxLength\">Maximum password length is {{max}}</label>\n" +
    "                <label ng-repeat=\"rule in Controller.pwdPolicy.rules\">\n" +
    "                    <input type=\"checkbox\" disabled ng-checked=\"Controller.newPassword && rule.satisfy(Controller.newPassword)\"> {{::rule.description}}\n" +
    "                </label>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/present/admin/pages/dialogs/AddVisualizationDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/present/admin/pages/dialogs/AddVisualizationDialog.tpl.html",
    "<edge-dialog-header>\n" +
    "    <div class=\"pipelineSelect\">\n" +
    "        <edge-pipeline-search ng-if=\"::SelectNodeController.showSearch\" show-pages=\"::false\" seed-search-choice=\"::SelectNodeController.seedSearchChoice\"></edge-pipeline-search>\n" +
    "    </div>\n" +
    "</edge-dialog-header>\n" +
    "<div style=\"height: 100%; overflow: hidden\">\n" +
    "    <edge-pipes options=\"SelectNodeController.pipesOptions\" selected-node=\"SelectNodeController.selectedNode\">\n" +
    "    </edge-pipes>\n" +
    "</div>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <button class=\"btn btn-danger\" ng-click=\"handleClose()\" translate>Cancel</button>\n" +
    "        <button class=\"btn btn-default\"\n" +
    "                ng-disabled=\"selectedVisualization === null\"\n" +
    "                ng-click=\"selectVisualization()\" translate>Add Visualization\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>\n" +
    "");
}]);

angular.module("edge/core/present/admin/pages/dialogs/edit-visualization-instances-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/present/admin/pages/dialogs/edit-visualization-instances-dialog.tpl.html",
    "<div ng-controller=\"EditVisualizationInstancesController as ctrlr\" class=\"edgeViewContents\">\n" +
    "    <div class=\"col-sm-3 input-group\" style=\"float: left; padding-right:20px; margin-bottom: 14px; height:auto\">\n" +
    "        <span class=\"input-group-addon\" translate>Stacking Mode</span>\n" +
    "        <ui-select ng-model=\"ctrlr.stackType\" theme=\"bootstrap\" on-select=\"ctrlr.stackingModeChanged()\">\n" +
    "            <ui-select-match>\n" +
    "                {{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item.value as item in ctrlr.widgetServiceLocator.stackSwitchTypes | filter: $select.search\">\n" +
    "                <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <div ng-if=\"ctrlr.stackType === 'interactive'\" class=\"col-sm-3\" style=\"margin-bottom: 14px; height:auto\">\n" +
    "        <div class=\"input-group\">\n" +
    "            <span class=\"input-group-addon\" translate>Auto Cycle?</span>\n" +
    "            <span class=\"input-group-addon\" style=\"border-left-width: 0;\" ng-style=\"ctrlr.autoCycle ? {'border-right-width': 0} : {'border-bottom-right-radius': '4px', 'border-top-right-radius': '4px'}\"><input type=\"checkbox\" ng-model=\"ctrlr.autoCycle\" ng-change=\"ctrlr.autoCycleChanged()\"></span>\n" +
    "            <edge-number-spinner ng-style=\"! ctrlr.autoCycle ? {'visibility': 'hidden'} : {}\" inputname=\"cycletime\" isrequired=\"true\" unit-metric=\"{{::'Seconds'|translate}}\"\n" +
    "                ng-model=\"ctrlr.cycleTime\" step=\"1\" minimum=\"5\" ng-change=\"ctrlr.cycleTimeChanged()\">\n" +
    "            </edge-number-spinner>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"form-inline pull-right col-sm-6\" style=\" height:auto\">\n" +
    "        <div class=\"input-group\">\n" +
    "            <span class=\"input-group-addon\" translate>Container Type</span>\n" +
    "            <ui-select ng-model=\"ctrlr.layoutCell.containerType\" theme=\"bootstrap\" on-select=\"ctrlr.markChanged()\">\n" +
    "                <ui-select-match>\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item.value as item in ctrlr.widgetServiceLocator.containerTypes | filter: $select.search\">\n" +
    "                    <div ng-bind-html=\"item.label | highlight: $select.search\"></div>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <edge-split-pane value=\".3\" horizontal=\"false\" style=\"height:calc(100% - 47px)\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list ng-if=\"::ctrlr.ready\" items=\"ctrlr.stackInstances\" type=\"reorderable\" selected-item=\"ctrlr.selectedVisInstance\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.ctrlr.editVis()\">\n" +
    "                            <span ng-bind-html=\"item.producer.name+' - '+item.instance.name\"></span>\n" +
    "                            <code ng-if=\"! item.visualization\" class=\"pull-right\">Missing</code>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-success\" ng-click=\"ctrlr.addNewVis()\"><i class=\"icon btn_icon icon_plus\"></i></button>\n" +
    "                        <button class=\"btn btn-warning\" ng-disabled=\"ctrlr.selectedVisInstance === null || ! ctrlr.selectedVisInstance.visualization\" ng-click=\"ctrlr.editVis()\"><i class=\"icon btn_icon icon_pencil\"></i></button>\n" +
    "                        <button class=\"btn btn-danger\" ng-disabled=\"ctrlr.selectedVisInstance === null\" ng-click=\"ctrlr.deleteVis()\"><i class=\"icon btn_icon icon_trash\"></i></button>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-body>\n" +
    "                    <div ng-if=\"!ctrlr.selectedVisInstance\" class=\"alert alert-info\" translate>Select a Visualization Instance to Edit</div>\n" +
    "                    <form ng-if=\"ctrlr.selectedVisInstance && ctrlr.selectedVisInstance.visualization\" name=\"visInstanceForm\" class=\"form-horizontal\" style=\"padding: 20px 35px 20px 20px;\">\n" +
    "                        <edge-labeled-control label=\"{{::'Visualization Label' | translate}}\" validation=\"true\">\n" +
    "                            <input name=\"visInstanceName\" class=\"form-control\" ng-required=\"true\" ng-model=\"ctrlr.name\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control label=\"{{::'Allow users to download data set?' | translate}}\">\n" +
    "                            <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.allowDownload\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control label=\"{{::'Restrict help to this page instance?' | translate}}\"\n" +
    "                            helptext=\"{{::'Setting this option to false will set this help to be available on any page that shows this visualizaion.' | translate}}\">\n" +
    "                            <input type=\"checkbox\" edge-boolean-switch ng-model=\"ctrlr.hasInstanceHelp\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control label=\"{{::'Default Help' | translate}}\">\n" +
    "                            <textarea rows=\"5\" class=\"form-control\" ng-model=\"ctrlr.visualizationHelp\" ng-disabled=\"ctrlr.hasInstanceHelp\"></textarea>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control ng-if=\"ctrlr.hasInstanceHelp\" label=\"{{::'Instance Help' | translate}}\" validation=\"true\">\n" +
    "                            <input type=\"hidden\" class=\"form-control\" name=\"help\" ng-model=\"ctrlr.help\" required>\n" +
    "                            <textarea rows=\"5\" class=\"form-control\" ng-model=\"ctrlr.help\" ng-required=\"true\"></textarea>\n" +
    "                        </edge-labeled-control>\n" +
    "                    </form>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer ng-if=\"ctrlr.selectedVisInstance && ctrlr.selectedVisInstance.visualization\">\n" +
    "                    <button class=\"btn btn-primary pull-right\" ng-class=\"{'pulse':ctrlr.hasUnsavedInstanceChanges}\"\n" +
    "                        ng-click=\"ctrlr.saveVisInstance()\" ng-disabled=\"! ctrlr.hasUnsavedInstanceChanges\">\n" +
    "                        <span ng-if=\"ctrlr.hasUnsavedInstanceChanges\" class=\"icon icon_exclamation_triangle\"\n" +
    "                            title=\"{{::'Unsaved Changes' | translate}}\"></span>\n" +
    "                        &nbsp;<span translate>Save</span>\n" +
    "                    </button>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"dialogRef.close()\" translate>Close</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/present/admin/pages/dialogs/page-options-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/present/admin/pages/dialogs/page-options-dialog.tpl.html",
    "<form class=\"form-horizontal\" name=\"pageOptions\">\n" +
    "    <edge-labeled-control label=\"{{::'Layout Type' | translate}}\">\n" +
    "        <select class=\"form-control\"\n" +
    "                ng-model=\"pageController.layoutType\"\n" +
    "                ng-disabled=\"pageConfig == null\">\n" +
    "            <option value=\"report\" translate>Report</option>\n" +
    "            <option value=\"dashboard\" translate>Dashboard</option>\n" +
    "        </select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{'Page Help' | translate}}\" validation=\"false\">\n" +
    "        <textarea rows=\"5\"\n" +
    "                  class=\"form-control\"\n" +
    "                  ng-model=\"pageConfig.help\"\n" +
    "                  ng-change=\"pageController.unsavedChanges = true;\"></textarea>\n" +
    "    </edge-labeled-control>\n" +
    "</form>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <button class=\"btn btn-danger\" ng-click=\"dialogRef.close();\">\n" +
    "            <span translate>Close</span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>");
}]);

angular.module("edge/core/present/admin/pages/dialogs/SelectProducerDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/present/admin/pages/dialogs/SelectProducerDialog.tpl.html",
    "<div ng-controller=\"SelectProducerDialogController as ctrlr\">\n" +
    "    <edge-dialog-header>\n" +
    "        <div class=\"navbar-form navbar-right\" role=\"search\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <div class=\"input-group-btn\">\n" +
    "                        <div class=\"input-group-addon\" data-toggle=\"dropdown\" style=\"padding: 4px;\">\n" +
    "                            <i class=\"icon icon_search\"></i> {{ctrlr.searchColumn.displayName}} <i class=\"caret\"></i>\n" +
    "                        </div>\n" +
    "                        <ul class=\"dropdown-menu\">\n" +
    "                            <li ng-repeat=\"columnDef in ctrlr.gridOptions.columnDefs\"\n" +
    "                                ng-click=\"ctrlr.searchColumn=columnDef\">\n" +
    "                                <a href>{{columnDef.displayName}}</a>\n" +
    "                            </li>\n" +
    "                        </ul>\n" +
    "                    </div>\n" +
    "                    <input type=\"search\" ng-model=\"ctrlr.searchString\" class=\"form-control\"\n" +
    "                           placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-header>\n" +
    "    <div ng-if=\"message\" style=\"border-radius: 0; margin: 0; padding:10px\" class=\"alert alert-info\">{{message}}</div>\n" +
    "    <div style=\"overflow: hidden\">\n" +
    "        <div ui-grid=\"ctrlr.gridOptions\" ui-grid-edit ui-grid-auto-resize ui-grid-selection class=\"grid modulegrid\"\n" +
    "             style=\"height:300px\"></div>\n" +
    "    </div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"handleClose()\">\n" +
    "                <span translate>Cancel</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-disabled=\"ctrlr.selectedProducer == null\" ng-click=\"selectProducer(ctrlr.selectedProducer)\">\n" +
    "                <span translate>Select Data Set</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/present/admin/pages/manage-pages.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/present/admin/pages/manage-pages.tpl.html",
    "<div class=\"managePagesHeader btn-toolbar\">\n" +
    "    <div class=\"pageSelectorContainer\">\n" +
    "        <div class=\"alt-separator breadcrumb-btn\"\n" +
    "             ng-class=\"{active: pageController.pageBreadcrumbService.paletteVisible}\"\n" +
    "             ng-click=\"pageController.pageBreadcrumbService.togglePalette()\"\n" +
    "             title=\"{{pageController.pageBreadcrumbService.toggleText}}\">\n" +
    "            <span class=\"icon icon_var\"></span>\n" +
    "        </div>\n" +
    "        <span class=\"btn-separator\"></span>\n" +
    "        <div class=\"pageselector\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_visualization\"></i></span>\n" +
    "                <ui-select id=\"pageSelector\"\n" +
    "                           ng-model=\"pageController.selectedPage\"\n" +
    "                           theme=\"bootstrap\" class=\"ui-select-small\">\n" +
    "                    <ui-select-match placeholder=\"{{::'Choose a page...' | translate}}\">{{$select.selected.displayName}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"item in pageController.allPages| orderBy:'displayName' | filter:{displayName:$select.search}\">\n" +
    "                        <div class=\"row\"\n" +
    "                             style=\"padding:0px;\"\n" +
    "                             ng-bind-html=\"item.displayName | highlightHtmlSafe: $select.search\"></div>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "                <div class=\"input-group-btn\">\n" +
    "                    <button class=\"btn btn-default\"\n" +
    "                            ng-click=\"pageController.addPage()\"\n" +
    "                            title=\"{{::'Add Page' | translate}}\">\n" +
    "                        <i class=\"icon icon_page_new\"></i>\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"btn-group pull-right\">\n" +
    "        <button ng-click=\"pageController.viewPage()\"\n" +
    "                class=\"edgeSmallToggleButton btn btn-default\"><span translate>View</span>\n" +
    "        </button>\n" +
    "        <button class=\"edgeSmallToggleButton btn btn-default btn-sm toggledOn\"><span translate>Edit</span></button>\n" +
    "    </div>\n" +
    "    <a href\n" +
    "       id=\"manage-page-show-help\"\n" +
    "       ng-click=\"pageController.showPageHelp()\"\n" +
    "       ng-attr-title=\"{{::'Page Help' | translate}}\"\n" +
    "       class=\"pull-right\"\n" +
    "       ng-if=\"pageController.pageConfig.isHelpSet()\">\n" +
    "        <i class=\"icon icon_question\"></i>\n" +
    "    </a>\n" +
    "</div>\n" +
    "<div style=\"height: calc(100% - 37px)\">\n" +
    "    <edge-view show-sidebar=\"true\" sidebar-name=\"palette\" mobile-sidebar=\"true\"\n" +
    "               sidebar-hidden=\"::(! pageController.pageBreadcrumbService.paletteVisible)\">\n" +
    "        <edge-view-sidebar style=\"display: none;padding:0px;\">\n" +
    "            <edge-view-sidebar-content page-controller=\"pageController\"></edge-view-sidebar-content>\n" +
    "        </edge-view-sidebar>\n" +
    "        <div ng-if=\"pageController.pageConfig == null\" class=\"alert alert-info\">\n" +
    "            <span translate>Select a page you'd like to edit.</span>\n" +
    "        </div>\n" +
    "        <div ng-if=\"pageController.layoutConfig\" style=\"height: 100%\">\n" +
    "            <edge-page-layout page-controller=\"pageController\" edit-mode=\"true\"></edge-page-layout>\n" +
    "        </div>\n" +
    "        <edge-view-footer ng-if=\"pageController.showFooter\">\n" +
    "            <!-- Responsive Toolbar Bar -->\n" +
    "\n" +
    "            <div class=\"btn-toolbar\">\n" +
    "                <button class=\"btn btn-default\" ng-click=\"pageController.addRow()\"\n" +
    "                        ng-disabled=\"pageController.pageConfig == null\">\n" +
    "                    <span translate>Add Row</span>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\"\n" +
    "                        ng-attr-title=\"{{::'Page Options' | translate}}\"\n" +
    "                        ng-click=\"pageController.showPageOptions()\"\n" +
    "                        ng-disabled=\"pageController.pageConfig == null\">\n" +
    "                    <i class=\"icon icon_sliders icon-btn\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-primary pull-right\" ng-class=\"{'pulse':pageController.unsavedChanges}\"\n" +
    "                        ng-click=\"pageController.savePageBtnClicked()\"\n" +
    "                        ng-disabled=\"pageController.pageConfig == null\"><span\n" +
    "                        ng-if=\"pageController.unsavedChanges\" class=\"icon icon_exclamation_triangle\"></span> <span\n" +
    "                        translate>Save Page</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-view-footer>\n" +
    "    </edge-view>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/dialogs/clone-ruleset-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/dialogs/clone-ruleset-dialog.tpl.html",
    "<div ng-controller=\"CloneRulesetDialogController as ctrlr\" style=\"height: 100%;\">\n" +
    "    <form name=\"suffixForm\" class=\"form-horizontal\">\n" +
    "        <edge-labeled-control label=\"{{'Suffix' | translate}}\"\n" +
    "                              helptext=\"{{'This suffix will be appended to to the name.' | translate}}\"\n" +
    "                              label-width=\"4\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"suffix\"\n" +
    "                   ng-model=\"ctrlr.suffix\"\n" +
    "                   ng-required=\"true\">\n" +
    "        </edge-labeled-control>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"suffixForm.$invalid\"\n" +
    "                    edge-button-spinner\n" +
    "                    data-spinner-color=\"#AAAAAA\"\n" +
    "                    data-style=\"expand-left\"\n" +
    "                    spin-toggle=\"ctrlr.isSaving\"\n" +
    "                    ng-click=\"ctrlr.handleClone()\"><span translate>Clone</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/dialogs/edit-formatter-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/dialogs/edit-formatter-dialog.tpl.html",
    "<div ng-controller=\"EditFormatterDialogController as ctrlr\">\n" +
    "    <form name=\"formatterConfig\" class=\"form-horizontal\" ng-switch=\"ctrlr.formatter.type\">\n" +
    "        <div class=\"col-sm-12 rule-property\">\n" +
    "            <span translate>{{ruleName}}</span>\n" +
    "        </div>\n" +
    "        <edge-icon-formatter ng-switch-when=\"0\" formatter=\"ctrlr.formatter\" options=\"options\"></edge-icon-formatter>\n" +
    "        <edge-font-formatter ng-switch-when=\"1\" formatter=\"ctrlr.formatter\" options=\"options\"></edge-font-formatter>\n" +
    "        <edge-color-formatter ng-switch-when=\"2\" formatter=\"ctrlr.formatter\" options=\"options\"></edge-color-formatter>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleCancel()\" translate>Cancel</button>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-disabled=\"propertyForm.$invalid\"\n" +
    "                    ng-click=\"ctrlr.handleApply()\"><span translate>Apply</span>\n" +
    "            </button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/dialogs/edit-ruleset-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/dialogs/edit-ruleset-dialog.tpl.html",
    "<div ng-controller=\"EditRuleSetDialogController as ctrlr\" style=\"height:100%;\">\n" +
    "    <edge-wizard force-progression=\"::(! isEdit)\"\n" +
    "                 dialog-mode=\"true\"\n" +
    "                 on-save=\"ctrlr.handleSave\"\n" +
    "                 on-cancel=\"ctrlr.handleCancel\"\n" +
    "                 sidebar-size=\"0.15\">\n" +
    "        <edge-wizard-step label=\"{{::'Name' | translate}}\"\n" +
    "                          index=\"0\"\n" +
    "                          use-form-validation=\"configuration\">\n" +
    "            <form name=\"configuration\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{'Name' | translate}}\" validation=\"true\">\n" +
    "                    <input class=\"form-control\" name=\"rulesetName\" ng-model=\"ctrlr.ruleSet.name\" ng-required=\"true\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{'Description' | translate}}\" validation=\"false\">\n" +
    "                    <textarea class=\"form-control\" name=\"description\" ng-model=\"ctrlr.ruleSet.description\"></textarea>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{'Rule Expression Type' | translate}}\" validation=\"false\">\n" +
    "                    <select class=\"form-control\" name=\"ruleExpressionType\" ng-model=\"ctrlr.ruleSet.expressionType\"\n" +
    "                            ng-change=\"ctrlr.expressionTypeChanged()\">\n" +
    "                        <option ng-value=\"0\" translate>Graphical</option>\n" +
    "                        <option ng-value=\"1\" translate>Javascript (Advanced)</option>\n" +
    "                    </select>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Variables' | translate}}\" index=\"1\" style=\"padding:10px;\"\n" +
    "                          validate=\"ctrlr.validateVariables()\"\n" +
    "                          use-form-validation=\"variables\">\n" +
    "            <div class=\"panel panel-default\" style=\"height:50%;flex-grow:0\">\n" +
    "                <div class=\"panel-body\">\n" +
    "                    <form name=\"variables\">\n" +
    "                        <edge-list items=\"ctrlr.ruleSet.variables\" selected-item=\"ctrlr.selectedVariable\">\n" +
    "                            <div class=\"with-padding\">\n" +
    "                                <div class=\"col-sm-4\" style=\"width:250px;\">\n" +
    "                                    <edge-labeled-control validation=\"true\" show-feedback-icon=\"false\" label-width=\"0\">\n" +
    "                                        <div class=\"input-group\">\n" +
    "                                            <div class=\"input-group-addon\">Name</div>\n" +
    "                                            <input class=\"form-control\" name=\"var{{$index}}\"\n" +
    "                                                   ng-pattern=\"/^[a-zA-Z][\\w_]*$/\"\n" +
    "                                                   ng-model=\"item.variable\" ng-required=\"true\">\n" +
    "                                        </div>\n" +
    "                                    </edge-labeled-control>\n" +
    "                                </div>\n" +
    "                                <div style=\"display:inline-block;width:200px;\">\n" +
    "                                    <div class=\"input-group\" style=\"height:32px;\">\n" +
    "                                        <div class=\"input-group-addon\">Type</div>\n" +
    "                                        <select class=\"form-control\" ng-model=\"item.dataType\" ng-required=\"true\" ng-options=\"option.value as option.label for option in listScope.ctrlr.variableTypes\">\n" +
    "                                        </select>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </form>\n" +
    "                </div>\n" +
    "                <div class=\"panel-footer\">\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"ctrlr.addVariable()\">\n" +
    "                            <i class=\"icon icon_plus icon_btn\"></i>\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-default\"\n" +
    "                                ng-disabled=\"ctrlr.selectedVariable === undefined || ctrlr.ruleSet.variables.length < 2\"\n" +
    "                                ng-click=\"ctrlr.removeVariable()\">\n" +
    "                            <i class=\"icon icon_trash\"></i></button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-if=\"::isEdit\" class=\"alert alert-warning\" translate>Altering a variable in any way could break existing rules within the current ruleset, as well as existing visualizaitons that are already using this ruleset.</div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Rules' | translate}}\" index=\"2\" style=\"padding:10px;\"\n" +
    "                          validate=\"ctrlr.validateRules()\"\n" +
    "                          use-form-validation=\"rules\">\n" +
    "            <form name=\"rules\" novalidate style=\"height:100%;\">\n" +
    "                <div class=\"panel panel-default\">\n" +
    "                    <div id=\"rulesList\" class=\"panel-body\">\n" +
    "                        <edge-list items=\"ctrlr.ruleSet.rules\"\n" +
    "                                   class=\"edgeRuleBuilderList\"\n" +
    "                                   type=\"reorderable\"\n" +
    "                                   selected-item=\"ctrlr.selectedRule\">\n" +
    "                            <div class=\"edgeRuleSelectionBorder\">\n" +
    "                                <edge-rule-builder rule=\"item\" index=\"$index\"\n" +
    "                                                   rule-set=\"listScope.ctrlr.ruleSet\" ng-class=\"{'has-rule-error': listScope.ctrlr.ruleErrors[$index]}\"></edge-rule-builder>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-footer\">\n" +
    "                        <div class=\"edgeDefaultRuleBuilder\">\n" +
    "                            <span translate>If nothing matches use this</span>\n" +
    "                            <input class=\"form-control\" name=\"defaultConfigName\"\n" +
    "                                   placeholder=\"{{::'Label' | translate}}\"\n" +
    "                                   ng-model=\"ctrlr.ruleSet.defaultConfigName\"\n" +
    "                                   style=\"width:250px; height: 32px; display:inline-block;\">\n" +
    "                            <edge-rule-set-style-config-preview class=\"pull-right\"\n" +
    "                                                                config=\"ctrlr.ruleSet.defaultStyleConfigObj\"\n" +
    "                                                                rule-type=\"ctrlr.ruleSet.configType\">\n" +
    "                            </edge-rule-set-style-config-preview>\n" +
    "                        </div>\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\" ng-click=\"ctrlr.addRule()\">\n" +
    "                                <i class=\"icon icon_plus icon_btn\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                ng-click=\"ctrlr.cloneRule()\"\n" +
    "                                ng-disabled=\"ctrlr.selectedRule == undefined\"\n" +
    "                                title=\"{{::'Duplicate Selected' | translate}}\">\n" +
    "                                <i class=\"icon icon_copy\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-disabled=\"ctrlr.selectedRule == undefined\"\n" +
    "                                    ng-click=\"ctrlr.removeRule()\">\n" +
    "                                <i class=\"icon icon_trash\"></i></button>\n" +
    "                        </div>\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"ctrlr.collapseAllRules()\"><span translate>Collapse All</span></button>\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"ctrlr.expandAllRules()\"><span translate>Expand All</span></button>\n" +
    "                        <button class=\"btn btn-default\" ng-click=\"ctrlr.showJSHelp()\" ng-if=\"ctrlr.isJavascript\">\n" +
    "                            <i class=\"icon icon_question_circle\"></i>&nbsp;\n" +
    "                            <span translate>JavaScript Help</span>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/dialogs/js-help-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/dialogs/js-help-dialog.tpl.html",
    "<h4 translate>Variables available:</h4>\n" +
    "<table class=\"table table-striped\" style=\"table-layout: fixed;\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th translate>Variable</th><th translate>Data Type</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tr ng-repeat=\"v in variables\">\n" +
    "        <td>{{v.variable}}</td>\n" +
    "        <td><code>{{getDataType(v.dataType)}}</code></td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "<h4 translate>JavaScript Libraries available:</h4>\n" +
    "<table class=\"table table-striped\" style=\"table-layout: fixed;\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th translate>Reference</th><th translate>Library Name</th><th translate>Purpose</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "        <tr>\n" +
    "            <td>_</td>\n" +
    "            <td><a href=\"http://underscorejs.org/\" target=\"_blank\">Underscore.js</a></td>\n" +
    "            <td translate>Object and Array manipulation</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>s</td>\n" +
    "            <td><a href=\"https://epeli.github.io/underscore.string/\" target=\"_blank\">Underscore.string</a></td>\n" +
    "            <td translate>String manipulation</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>moment</td>\n" +
    "            <td><a href=\"https://momentjs.com/docs/\" target=\"_blank\">Moment.js</a></td>\n" +
    "            <td translate>Date manipulation and formatting</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>Math</td>\n" +
    "            <td><a href=\"https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math\" target=\"_blank\">JavaScript Math</a></td>\n" +
    "            <td translate>Math functions</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>console</td>\n" +
    "            <td><a href=\"https://developer.mozilla.org/en-US/docs/Web/API/Console\" target=\"_blank\">JavaScript Console</a></td>\n" +
    "            <td translate>Console for debugging</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>StringUtil</td>\n" +
    "            <td><a href=\"https://edgetech.atlassian.net/wiki/spaces/suite33/pages/223084569/Advanced+Rule+Mode+Javascript+Rule+Expression\" target=\"_blank\">StringUtil</a></td>\n" +
    "            <td translate>Additional String helper functions</td>\n" +
    "        </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/rules/dialogs/new-ruleset-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/dialogs/new-ruleset-dialog.tpl.html",
    "<div ng-controller=\"NewRuleSetDialogController as nrsdCtrlr\">\n" +
    "    <form name=\"newRuleSetForm\" class=\"with-padding\">\n" +
    "        <div class=\"form-horizontal\" style=\"height: 100%;\">\n" +
    "            <edge-labeled-control label=\"{{'Renderer Type' | translate}}\"\n" +
    "                                  helpText=\"{{'Choose the type of renderer that this rule set will drive.'| translate}}\"\n" +
    "                                  validation=\"true\">\n" +
    "                <select class=\"form-control\" ng-model=\"nrsdCtrlr.ruleSet.configType\" name=\"selectedRuleConfigType\"\n" +
    "                        ng-options=\"ruleConfigType.value as ruleConfigType.label for ruleConfigType in nrsdCtrlr.ruleConfigTypes\"\n" +
    "                        ng-required=\"true\">\n" +
    "                </select>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </form>\n" +
    "</div>");
}]);

angular.module("edge/core/rules/edgeExpRuleBuilder.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/edgeExpRuleBuilder.tpl.html",
    "<div>\n" +
    "    <textarea ng-if=\"::isJavascript\" edge-codemirror editor=\"jsEditor\" ng-required=\"true\"\n" +
    "              ng-model=\"rule.javascript\" style=\"min-width:200px;min-height:25px;\"\n" +
    "              options=\"{mode:'text/javascript', autoRefresh:true, lineNumbers:true, extraKeys: {'Ctrl-Space': 'autocomplete'}, theme:'default jsExpRule'}\" name=\"expression{{::index}}\">\n" +
    "    </textarea>\n" +
    "    <div ng-if=\"::!isJavascript\">\n" +
    "        <edge-expression-builder group=\"rule.expression\" input-prefix=\"{{::'expression'+index}}\"\n" +
    "            data-sources=\"variablesAsAttributes\" include-selected-attribute=\"false\">\n" +
    "        </edge-expression-builder>\n" +
    "        <div class=\"clearfix\"></div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/edgeRuleBuilder.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/edgeRuleBuilder.tpl.html",
    "<div class=\"edgeRuleBuilderCollapser\">\n" +
    "    <table style=\"table-layout: fixed;width:100%\">\n" +
    "        <tr>\n" +
    "            <td class=\"ruleBuilderHeader\">\n" +
    "                <div style=\"width:15px;height:32px;display:inline-block;line-height:32px; float: left; margin-right: 5px;\" class=\"no-select\" ng-click=\"rule.open=!rule.open;\">\n" +
    "                    <i class=\"icon\" ng-class=\"{'icon_chevron_right':!rule.open, 'icon_chevron_down':rule.open}\"></i>\n" +
    "                </div>\n" +
    "                <div  ng-if=\"!rule.open\" style=\"float: left; line-height: 32px;\">\n" +
    "                    <label class=\"no-select\">{{rule.name}}:</label>\n" +
    "                    <span class=\"edgeRuleSummary\">{{rule.getRuleSummary()}}</span>\n" +
    "                </div>\n" +
    "                <edge-labeled-control ng-show=\"rule.open\" label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\" style=\"display: inline-block; margin-bottom: 0; width:290px; float: left;\">\n" +
    "                    <input class=\"form-control\" name=\"ruleName{{index}}\"\n" +
    "                        placeholder=\"{{'Rule Name (required)' | translate}}\"\n" +
    "                        ng-model=\"rule.name\" ng-required=\"true\" edge-focus-on>\n" +
    "                </edge-labeled-control>\n" +
    "            </td>\n" +
    "            <td style=\"width:20%;text-align: right;\">\n" +
    "                <edge-rule-set-style-config-preview rule=\"rule\"></edge-rule-set-style-config-preview>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <edge-exp-rule-builder ng-hide=\"!rule.open\" style=\"margin-top:8px;\" rule=\"rule\" rule-set=\"ruleSet\" index=\"index\"></edge-exp-rule-builder>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/edgeRuleSetStyleConfigPreview.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/edgeRuleSetStyleConfigPreview.tpl.html",
    "<div ng-switch=\"ruleType\" style=\"display:inline-block;\">\n" +
    "    <!-- Icon Rule Preview -->\n" +
    "    <div ng-switch-when=\"0\" ng-click=\"editFormatter()\" style=\"cursor: pointer;\" class=\"btn-group\">\n" +
    "        <button class=\"btn btn-default\" style=\"padding:5px 5px;height:32px;\">\n" +
    "            <span translate style=\"font-size:0.8em;\">Size: {{config.iconFormatter.size}}</span>\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default eeIconPreview\" style=\"padding: 0px;width:32px;height:32px;\">\n" +
    "            <img class=\"eeCompositeIconPreview\" ng-src=\"{{compositeIconUrl()}}\">\n" +
    "        </button>\n" +
    "        <button type=\"button\" class=\"btn btn-default dropdown-toggle\" style=\"height:32px;\">\n" +
    "            <span class=\"caret\"></span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "    <!-- Font Rule Preview -->\n" +
    "    <div ng-switch-when=\"1\" ng-click=\"editFormatter()\" style=\"cursor: pointer;\" class=\"btn-group\">\n" +
    "        <button class=\"btn btn-default {{config.fontFormatter.style}}\"\n" +
    "                ng-style=\"{'color':getHexColor(config.fontFormatter.color),'font-size':config.fontFormatter.size+'px',height:'32px'}\"\n" +
    "                translate>Sample 123\n" +
    "        </button>\n" +
    "        <button type=\"button\" class=\"btn btn-default dropdown-toggle\" style=\"height:32px;\">\n" +
    "            <span class=\"caret\"></span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "    <!-- Color Rule Preview -->\n" +
    "    <div ng-switch-when=\"2\" ng-click=\"editFormatter()\" style=\"cursor: pointer;\" class=\"btn-group\">\n" +
    "        <button class=\"btn btn-default edgeColorRulePreview\">\n" +
    "            <div class=\"icon-preview-bkg\">\n" +
    "                <div ng-style=\"{'background-color':getHexColor(config.colorFormatter.color),'opacity':config.colorFormatter.alpha}\"></div>\n" +
    "                <div ng-if=\"config.colorFormatter.color === 'transparent'\" class=\"edge-transparent\"></div>\n" +
    "            </div>\n" +
    "        </button>\n" +
    "        <button type=\"button\" class=\"btn btn-default dropdown-toggle\" style=\"height:32px;\">\n" +
    "            <span class=\"caret\"></span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/rules/manage-rulesets.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/rules/manage-rulesets.tpl.html",
    "<edge-view>\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header label=\"{{::'Rule Sets'|translate}}\">\n" +
    "            <div class=\"panel-heading-control pull-right\">\n" +
    "                <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input type=\"search\"\n" +
    "                                                                                                   ng-model=\"panelScope.Controller.searchString\"\n" +
    "                                                                                                   class=\"form-control\"\n" +
    "                                                                                                   placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"overflow:hidden\">\n" +
    "            <div ui-grid=\"panelScope.Controller.dataGridOptions\" style=\"height: 100%\"\n" +
    "                 ui-grid-selection\n" +
    "                 ui-grid-resize-columns\n" +
    "                 class=\"grid backupgrid\"></div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <div class=\"btn-group\">\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-success\"\n" +
    "                            ng-click=\"panelScope.Controller.editRuleSet( true )\"\n" +
    "                            title=\"{{::'Add' | translate}}\"><i class=\"icon icon_plus\"></i></button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-warning\"\n" +
    "                            ng-click=\"panelScope.Controller.editRuleSet()\"\n" +
    "                            ng-disabled=\"panelScope.Controller.selectedRuleSet==null\"\n" +
    "                            title=\"{{::'Edit' | translate}}\"><i class=\"icon icon_pencil\"></i></button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-warning\"\n" +
    "                            ng-click=\"panelScope.Controller.cloneRuleSet()\"\n" +
    "                            ng-disabled=\"panelScope.Controller.selectedRuleSet==null\"\n" +
    "                            title=\"{{::'Duplicate Selected' | translate}}\"><i class=\"icon icon_copy\"></i></button>\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-danger\"\n" +
    "                            ng-click=\"panelScope.Controller.deleteSelectedRuleSet()\"\n" +
    "                            ng-disabled=\"panelScope.Controller.selectedRuleSet==null\"\n" +
    "                            title=\"{{::'Delete' | translate}}\"><i class=\"icon icon_trash\"></i></button>\n" +
    "                    <!--\n" +
    "                    <button type=\"button\"\n" +
    "                            class=\"btn btn-warning\"\n" +
    "                            ng-click=\"panelScope.Controller.saveSelectedRuleSet()\"\n" +
    "                            ng-disabled=\"panelScope.Controller.selectedRuleSet==null\"\n" +
    "                            title=\"{{::'Save' | translate}}\">\n" +
    "                        <i class=\"icon icon_cloud_download\"></i>&nbsp;(For Testing)\n" +
    "                    </button>\n" +
    "                    -->\n" +
    "                </div>\n" +
    "                <span class=\"badge pull-right\"\n" +
    "                      ng-if=\"panelScope.Controller.rulesets.length > 0\"\n" +
    "                      translate\n" +
    "                      translate-params-count=\"(panelScope.Controller.rulesets|filter:panelScope.Controller.doFilter).length\"\n" +
    "                      translate-params-total=\"panelScope.Controller.rulesets.length\">\n" +
    "                          {{count}} of {{total}} Rule Sets\n" +
    "                    </span>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/core/test/integration/integration.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/test/integration/integration.tpl.html",
    "<edge-router-breadcrumb-bar></edge-router-breadcrumb-bar>\n" +
    "<div ng-if=\"!hideChooser\" style=\"padding: 0px 100px 0px 100px\">\n" +
    "    <div class=\"row\">\n" +
    "        <!--<edge-panel>-->\n" +
    "        <!--<edge-panel-header label=\"{{'Integration Tests' | translate}}\"></edge-panel-header>-->\n" +
    "        <!--<edge-panel-body style=\"overflow:hidden\">-->\n" +
    "        <div class=\"col-sm-2\"><h5 class=\"pull-right\">Available Integration Tests</h5></div>\n" +
    "        <div class=\"col-sm-10\">\n" +
    "            <ui-select ng-model=\"controller.selectedTest\" theme=\"bootstrap\">\n" +
    "                <ui-select-match placeholder=\"Choose a test...\">{{$select.selected.name}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"item in controller.integrationTests | orderBy:'name' | filter: $select.search\">\n" +
    "                    <div ng-bind-html=\"controller.getPathRendererHTML(item) | highlight: $select.search\"></div>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"controller.runSingleTest()\"\n" +
    "                    ng-disabled=\"controller.selectedTest==null\">\n" +
    "                <span translate>Run Single Test</span>\n" +
    "            </button>\n" +
    "            <button class=\"btn btn-default\" ng-click=\"controller.runAllTests()\">\n" +
    "                <span translate>Run All Tests</span>\n" +
    "            </button>\n" +
    "            <div>{{controller.lastTestResults}}</div>\n" +
    "        </div>\n" +
    "        <!--<div ui-grid=\"Controller.dataGridOptions\" ui-grid-selection ui-grid-resize-columns class=\"grid backupgrid\"></div>-->\n" +
    "        <!--</edge-panel-body>-->\n" +
    "        <!--<edge-panel-footer>-->\n" +
    "        <!--</edge-panel-footer>-->\n" +
    "        <!--</edge-panel>-->\n" +
    "\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/view/edgeView.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/view/edgeView.tpl.html",
    "<div id=\"edgeView\" class=\"edgeView\" ng-class=\"{hasFooter: ViewController.hasFooter, hasSidebar: showSidebar}\">\n" +
    "    <edge-split-pane ng-if=\"showSidebar\" id=\"edgeViewSplitter\"\n" +
    "                     value=\"ViewController.splitValue\"\n" +
    "                     horizontal=\"false\"\n" +
    "                     collapsed=\"ViewController.hideSidebar\"\n" +
    "                     enable-divider=\"ViewController.enableDivider\"\n" +
    "                     resize-listener=\"ViewController.sidebarResized()\">\n" +
    "        <edge-split-pane-view>\n" +
    "            <div id=\"edgeViewSidebar\"></div>\n" +
    "        </edge-split-pane-view>\n" +
    "        <edge-split-pane-view>\n" +
    "            <div id=\"edgeViewContents\" class=\"edgeViewContents\">\n" +
    "                <edge-transclude></edge-transclude>\n" +
    "            </div>\n" +
    "        </edge-split-pane-view>\n" +
    "    </edge-split-pane>\n" +
    "    <div ng-if=\"! showSidebar\" id=\"edgeViewContents\" class=\"edgeViewContents\">\n" +
    "        <edge-transclude></edge-transclude>\n" +
    "    </div>\n" +
    "    <div id=\"edgeViewFooter\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/view/edgeViewSidebarContent.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/view/edgeViewSidebarContent.tpl.html",
    "<table style=\"width:100%;height:100%\">\n" +
    "    <!--\n" +
    "    <tr ng-if=\"pageController.getLayoutConfig().editMode!=false\">\n" +
    "        <td>\n" +
    "            <div class=\"sidebar-headline\">\n" +
    "                <div class=\"input-group\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_visualization\"></i></span>\n" +
    "                    <ui-select id=\"pageSelector\"\n" +
    "                               ng-model=\"pageController.selectedPage\"\n" +
    "                               theme=\"bootstrap\">\n" +
    "                        <ui-select-match placeholder=\"{{'Choose a page...' | translate}}\">{{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item in pageController.allPages| orderBy:'name' | filter: $select.search\">\n" +
    "                            <div class=\"row\" style=\"padding:0px;\" ng-bind-html=\"item.name | highlightHtmlSafe: $select.search\"></div>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                    <div class=\"input-group-btn\">\n" +
    "                        <button class=\"btn btn-default\"\n" +
    "                                ng-click=\"pageController.addPage()\"\n" +
    "                                title=\"{{'Add Page' | translate}}\">\n" +
    "                            <i class=\"icon icon_page_new\"></i>\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "    -->\n" +
    "    <tr>\n" +
    "        <td height=\"100%\">\n" +
    "            <div style=\"overflow-y:auto;height:100%\">\n" +
    "                <div class=\"sidebar-headline\" ng-if=\"pageController.pageConfig != null && pageController.getLayoutConfig().editMode!=false\">\n" +
    "                    <div>\n" +
    "                        <span translate>Page Variables</span>&nbsp;\n" +
    "                        <small ng-if=\"pageController.selectedPage != null\">\n" +
    "                            <small>(<a href ng-click=\"pageController.managePageVars()\"><span translate>manage</span></a>)\n" +
    "                            </small>\n" +
    "                        </small>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-page-var-editor show-mappings=\"pageController.editMode\" page-controller=\"pageController\" form=\"pageController.pageEditorForm\"></edge-page-var-editor>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "    <tr ng-if=\"pageController.getLayoutConfig().editMode!=null\">\n" +
    "        <td>\n" +
    "            <div class=\"var-palette-footer\">\n" +
    "                <button type=\"button\" ng-click=\"pageController.applyNewValuesToPageVarsFromForm()\" class=\"btn btn-default btn-sm\"\n" +
    "                        ng-class=\"{'pulse':!pageController.getPageVarEditorForm().$pristine}\">\n" +
    "                    <span ng-if=\"!pageController.getPageVarEditorForm().$pristine\" class=\"icon icon_exclamation_triangle\">&nbsp;</span>\n" +
    "                    <span translate>Apply</span>\n" +
    "                </button>\n" +
    "                <button type=\"button\" ng-click=\"pageController.syncPageVars()\" class=\"btn btn-default btn-sm\"\n" +
    "                        style=\"margin-right: 10px\" ng-if=\"pageController.getLayoutConfig().editMode\">\n" +
    "                    <span translate>Sync</span>\n" +
    "                </button>\n" +
    "                <button type=\"button\" ng-click=\"pageController.resetToDefaultValues()\" class=\"btn btn-default btn-sm\"\n" +
    "                        style=\"margin-right: 10px\">\n" +
    "                    <span translate>Reset</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/edgeManageActionsDialogFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/edgeManageActionsDialogFooter.tpl.html",
    "<div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "    <div class=\"pull-left btn-group dropup\" style=\"min-width:300px\">\n" +
    "        <button id=\"addActionBtn\" class=\"btn btn-success dropdown-toggle\" data-toggle=\"dropdown\" aria-haspopup=\"true\"\n" +
    "                aria-expanded=\"false\"><i class=\"icon icon_plus btn_icon\"></i></button>\n" +
    "        <button class=\"btn btn-default\" ng-disabled=\"!dialogCtrlr.selectedAction.actionName\"\n" +
    "                ng-click=\"dialogCtrlr.configureSelectedAction()\"><i class=\"icon icon_pencil btn_icon\"></i>\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-danger\"\n" +
    "                ng-disabled=\"!dialogCtrlr.selectedAction.actionName\"\n" +
    "                ng-click=\"dialogCtrlr.deleteSelectedAction()\">\n" +
    "            <i class=\"icon icon_trash btn_icon\"></i></button>\n" +
    "        <ul class=\"dropdown-menu actions-menu\"></ul>\n" +
    "    </div>\n" +
    "    <button class=\"btn btn-default\" ng-click=\"dialogCtrlr.handleCancel()\" translate>Close</button>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/core/widget/actions/launchurl/action-launch-url-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/launchurl/action-launch-url-wizard.tpl.html",
    "<div ng-controller=\"ActionLaunchURLWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"0\" use-form-validation=\"baseConfig\">\n" +
    "            <form name=\"baseConfig\">\n" +
    "                <div class=\"form-horizontal\">\n" +
    "                    <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                        <input type=\"text\"\n" +
    "                               class=\"form-control\"\n" +
    "                               ng-model=\"actionConfig.actionLabel\"\n" +
    "                               placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control label=\"{{::'Target'|translate}}\" validation=\"true\">\n" +
    "                        <select class=\"form-control\" name=\"target\" ng-model=\"actionConfig.target\" ng-required>\n" +
    "                            <option value=\"_blank\" translate>New Window</option>\n" +
    "                            <option value=\"_top\" translate>This Window</option>\n" +
    "                        </select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control label=\"{{::'URL'|translate}}\" validation=\"true\" required=\"true\">\n" +
    "                        <input type=\"text\" name=\"url\" class=\"form-control\" ng-model=\"actionConfig.url\" required>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <h5 translate>Click on the following to append them to your url to be injected at runtime.</h5>\n" +
    "                    <edge-labeled-control label=\"{{::'Record Attributes'|translate}}\" validation=\"false\">\n" +
    "                        <div class=\"well well-sm action-url-tokens\">\n" +
    "                            <div class=\"action-url-token\"\n" +
    "                                 ng-repeat=\"attrName in dataAttributeNames\"\n" +
    "                                 ng-click=\"WizardCtrlr.addRecordValue(attrName)\">{{attrName}}\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control label=\"{{::'Page Vars'|translate}}\" validation=\"false\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "                        <div class=\"well well-sm action-url-tokens\">\n" +
    "                            <div class=\"action-url-token\"\n" +
    "                                 ng-repeat=\"pageVar in sourcePageVars\"\n" +
    "                                 ng-click=\"WizardCtrlr.addPageVar(pageVar.name)\">{{pageVar.getDisplayName()}}\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\" data-sources=\"::dataAttributes\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/manage-actions-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/manage-actions-dialog.tpl.html",
    "<div ng-controller=\"ManageActionsDialogController as dialogCtrlr\">\n" +
    "    <edge-list items=\"dialogCtrlr.actionsConfig.actions\"\n" +
    "               selected-item=\"dialogCtrlr.selectedAction\">\n" +
    "        <div class=\"with-padding\" ng-dblclick=\"listScope.dialogCtrlr.configureSelectedAction(false)\"><b>{{item.getActionLabel()}}</b>\n" +
    "            <span class=\"pull-right\">\n" +
    "                <code ng-if=\"item.conditions.tokens.length > 0\">{{item.conditions.tokens.length}} {{::'Conditions' | translate}}&nbsp;</code>\n" +
    "                <span class=\"badge badge-inverse\" style=\"line-height: normal\">{{item.widgetEventTypeDisplayName}}&nbsp;{{item.targetName}}</span>\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "    <edge-dialog-footer>\n" +
    "        <edge-manage-actions-dialog-footer></edge-manage-actions-dialog-footer>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/multiselect/action-multiselect-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/multiselect/action-multiselect-wizard.tpl.html",
    "<div ng-controller=\"ActionMultiselectWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"1\">\n" +
    "            <form name=\"pageVarsForm\" class=\"form-horizontal\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "                <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                    <input type=\"text\" class=\"form-control\"  ng-model=\"actionConfig.actionLabel\" placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-repeat=\"pageVar in sourcePageVars\" label=\"{{::pageVar.name}}\">\n" +
    "                    <edge-page-var-mapper action-config=\"actionConfig\" page-var=\"::pageVar\"\n" +
    "                        source-page-vars=\"::[pageVar]\" attributes=\"::dataAttributes\"\n" +
    "                        allow-attribute=\"::false\" is-switch-page=\"::false\">\n" +
    "                    </edge-page-var-mapper>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "            <div ng-if=\"sourcePageVars.length === 0\" class=\"alert alert-info\">\n" +
    "                <span translate>This page does not have any page variables defined.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"::isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/serverupdate/action-server-update-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/serverupdate/action-server-update-wizard.tpl.html",
    "<div ng-controller=\"ActionServerUpdateWizardController as Controller\" style=\"height:100%\">\n" +
    "    <edge-wizard dialog-mode=\"true\" on-save=\"Controller.handleSave\" on-cancel=\"Controller.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"1\" validate=\"Controller.validateData()\" use-form-validation=\"serverActionForm\">\n" +
    "            <form name=\"serverActionForm\" class=\"form-horizontal\" ng-if=\"::(Controller.actionsLoaded && Controller.serverActions.length > 0)\">\n" +
    "                <div>\n" +
    "                    <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                        <input type=\"text\" class=\"form-control\" ng-model=\"actionConfig.actionLabel\" placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div>\n" +
    "                    <edge-labeled-control label=\"{{::'Server Action'|translate}}\" validation=\"true\">\n" +
    "                    <input type=hidden name=\"serverAction\" ng-model=\"Controller.selectedServerAction\"\n" +
    "       ng-required=\"true\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                    <ui-select ng-model=\"Controller.selectedServerAction\" theme=\"bootstrap\" on-select=\"Controller.updateServerActionFields()\">\n" +
    "                        <ui-select-match>\n" +
    "                            {{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item in Controller.serverActions | filter: $select.search\">\n" +
    "                            <div ng-bind-html=\"item.name | highlight: $select.search\"></div>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"Controller.propertyEditorConfig\">\n" +
    "                    <edge-property-editor config=\"Controller.propertyEditorConfig\"></edge-property-editor>\n" +
    "                </div>\n" +
    "                <div>\n" +
    "                    <edge-labeled-control ng-if=\"Controller.paramAttributeList != undefined\" ng-repeat=\"param in Controller.selectedServerAction.parameters track by $index\" label=\"{{::param.parameterName}}\">\n" +
    "                        <div class=\"col-sm-4\" style=\"padding-left: 0\">\n" +
    "                        <ui-select ng-model=\"actionConfig.paramMaps[param.parameterName].type\" theme=\"bootstrap\" on-select=\"Controller.setParamMappingValue(actionConfig.paramMaps[param.parameterName], $index)\">\n" +
    "                            <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                            <ui-select-choices repeat=\"item.type as item in Controller.mappingChoices[$index] | orderBy: 'name' | filter: {name: $select.search}\">\n" +
    "                                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-8\" ng-if='actionConfig.paramMaps[param.parameterName].type === \"pageVar\"'>\n" +
    "                            <ui-select ng-model=\"actionConfig.paramMaps[param.parameterName].value\" theme=\"bootstrap\">\n" +
    "                                <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item.name as item in Controller.paramPageVarList[$index] | orderBy: 'name' | filter: {name: $select.search}\">\n" +
    "                                    <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-8\" ng-if='actionConfig.paramMaps[param.parameterName].type === \"attribute\"'>\n" +
    "                            <edge-data-attribute-picker ng-model=\"actionConfig.paramMaps[param.parameterName].value\" attribute-defs=\"::Controller.paramAttributeList[$index]\" required=\"true\"></edge-data-attribute-picker>\n" +
    "                        </div>\n" +
    "                        <div ng-if='actionConfig.paramMaps[param.parameterName].type === \"static\"' class=\"col-sm-8\" style=\"margin-left: 5px; margin-right: -5px\">\n" +
    "                        <edge-param-control style=\"margin-left: 0; margin-right: 10px\" ng-init=\"readonly=true\"></edge-param-control>\n" +
    "                        </div>\n" +
    "                        <div ng-if='actionConfig.paramMaps[param.parameterName].type === \"nodeVar\"' class=\"col-sm-8\">\n" +
    "                        <input type=\"text\" class=\"form-control\" disabled ng-value=\"Controller.paramDefaultValues[$index]\">\n" +
    "                        </div>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "            <div ng-if=\"::(Controller.actionsLoaded && Controller.serverActions.length < 1)\" class=\"alert alert-info\">\n" +
    "                <span translate>There is no server action defined.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\" ng-if=\"::(Controller.actionsLoaded && Controller.serverActions.length > 0)\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/serverupdate/user-prompter-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/serverupdate/user-prompter-dialog.tpl.html",
    "<form name=\"serverActionParamPromptForm\" class=\"form-horizontal\">\n" +
    "    <div ng-if=\"stage === 'prompt'\">\n" +
    "        <edge-labeled-control ng-repeat=\"param in parameters track by $index\" label=\"{{::param.parameterName}}\" style=\"margin-bottom: 0\">\n" +
    "            <edge-param-control style=\"margin-left: 10px; margin-right: 10px;\" ng-init=\"readonly=true\"></edge-param-control>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div ng-if=\"stage === 'executing'\" class=\"importModule alert alert-info\" role=\"alert\" style=\"text-align: center;\" translate>\n" +
    "        Please wait while your action is being executed.\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/setpagevar/action-set-page-var-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/setpagevar/action-set-page-var-wizard.tpl.html",
    "<div ng-controller=\"ActionSetPageVarWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"1\">\n" +
    "            <form name=\"pageVarsForm\" class=\"form-horizontal\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "                <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                    <input type=\"text\" class=\"form-control\"  ng-model=\"actionConfig.actionLabel\" placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-repeat=\"pageVar in sourcePageVars\" label=\"{{::pageVar.name}}\">\n" +
    "                    <edge-page-var-mapper action-config=\"actionConfig\" page-var=\"::pageVar\"\n" +
    "                        source-page-vars=\"::sourcePageVars\" attributes=\"::dataAttributes\"\n" +
    "                        allow-attribute=\"::isAttributeEnabled\" is-switch-page=\"::false\">\n" +
    "                    </edge-page-var-mapper>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "            <div ng-if=\"sourcePageVars.length == 0\" class=\"alert alert-info\">\n" +
    "                <span translate>This page does not have any page variables defined.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\" ng-if=\"sourcePageVars.length > 0\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"::isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/showrecord/action-show-record-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/showrecord/action-show-record-dialog.tpl.html",
    "<table class=\"edgeShowDetail table table-striped\" cellspacing=\"5\">\n" +
    "    <tr ng-repeat=\"detail in details\">\n" +
    "        <td style=\"text-align: right\"><b>{{detail.name}}</b></td>\n" +
    "        <td>\n" +
    "            <span ng-if=\"!detail.hasNoData\">{{detail.value}}</span>\n" +
    "            <code ng-if=\"detail.hasNoData\">{{detail.value}}</code>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/showrecord/action-show-record-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/showrecord/action-show-record-wizard.tpl.html",
    "<div ng-controller=\"ActionShowRecordWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{'Base Config' | translate}}\" index=\"0\">\n" +
    "            <form name=\"propertiessForm\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                    <input type=\"text\" class=\"form-control\" ng-model=\"actionConfig.actionLabel\"\n" +
    "                           placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Field Visibility'|translate}}\" index=\"1\">\n" +
    "            <edge-dual-list style=\"height:100%\" items=\"dataAttributeNames\" selected-items=\"actionConfig.hiddenFields\"\n" +
    "                            unselected-title=\"{{::'Displayed Fields' | translate}}\"\n" +
    "                            selected-title=\"{{::'Hidden Fields' | translate}}\"\n" +
    "                            collapsed-title=\"{{::'Hidden Fields' | translate}}\">\n" +
    "                <span>{{item}}</span>\n" +
    "            </edge-dual-list>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/showwidget/action-show-widget-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/showwidget/action-show-widget-wizard.tpl.html",
    "<div ng-controller=\"ActionShowWidgetWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\" allow-save=\"::WizardCtrlr.canProceed\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"1\" use-form-validation=\"pageChooser\">\n" +
    "            <form ng-if=\"::WizardCtrlr.canProceed\" name=\"pageChooser\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                    <input type=\"text\" class=\"form-control\" ng-model=\"actionConfig.actionLabel\"\n" +
    "                           placeholder=\"{{::actionConfig.actionDisplayName}}\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Switch To Page' | translate}}\" validation=\"true\">\n" +
    "                    <input type=hidden name=\"selectedPage\" ng-model=\"actionConfig.selectedPage\" ng-required=\"true\">\n" +
    "                    <ui-select ng-model=\"actionConfig.selectedPage\" theme=\"bootstrap\" on-select=\"WizardCtrlr.updateWidgetList($model)\">\n" +
    "                        <ui-select-match placeholder=\"{{::'Choose a Page...'|translate}}\">\n" +
    "                            {{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices\n" +
    "                                repeat=\"item.id as item in pages | orderBy: 'displayName' | filter: {displayName: $select.search} track by $index\">\n" +
    "                            <span ng-bind-html=\"item.displayName | highlightHtmlSafe: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-repeat=\"stack in WizardCtrlr.stackedWidgets track by $index\" label=\"{{::'Switch To Visualization' | translate}}\" validation=\"true\">\n" +
    "                    <input type=hidden name=\"selectedWidget{{$index}}\" ng-model=\"actionConfig.selectedWidgets[$index].id\" ng-required=\"true\">\n" +
    "                    <ui-select ng-model=\"actionConfig.selectedWidgets[$index].id\" theme=\"bootstrap\" on-select=\"WizardCtrlr.setWidgetName($item, $index)\">\n" +
    "                        <ui-select-match>\n" +
    "                            {{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices repeat=\"item.id as item in stack | filter: {name: $select.search}\">\n" +
    "                            <span ng-bind-html=\"item.name | highlightHtmlSafe: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "            <div ng-if=\"::(pages.length == 0)\" class=\"alert alert-info\">\n" +
    "                <span translate>There is no page with stacked visualizations.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"::WizardCtrlr.canProceed\" label=\"{{::'Page Variables (Optional)' | translate}}\" index=\"2\"\n" +
    "                          on-show=\"WizardCtrlr.onPageVarShow()\">\n" +
    "            <form ng-if=\"targetPageVars.length > 0\" name=\"pageVarsForm\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control ng-repeat=\"pageVar in targetPageVars\" label=\"{{::pageVar.name}}\">\n" +
    "                    <edge-page-var-mapper action-config=\"actionConfig\" page-var=\"::pageVar\"\n" +
    "                        source-page-vars=\"::sourcePageVars\" attributes=\"::dataAttributes\"\n" +
    "                        allow-attribute=\"::isAttributeEnabled\" is-switch-page=\"::true\">\n" +
    "                    </edge-page-var-mapper>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "            <div ng-if=\"targetPageVars.length === 0\" class=\"alert alert-info\">\n" +
    "                <span translate>The page you are switching to does not have any page variables defined.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"::WizardCtrlr.canProceed\" label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"3\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/switchpage/action-switch-page-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/switchpage/action-switch-page-wizard.tpl.html",
    "<div ng-controller=\"ActionSwitchPageWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Config' | translate}}\" index=\"1\" use-form-validation=\"pageChooser\">\n" +
    "            <form name=\"pageChooser\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{::'Action Name'|translate}}\">\n" +
    "                    <input type=\"text\" class=\"form-control\" ng-model=\"actionConfig.actionLabel\"\n" +
    "                           placeholder=\"{{actionConfig.actionDisplayName}}\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Switch To Page' | translate}}\" validation=\"true\">\n" +
    "                    <input type=hidden name=\"selectedPage\" ng-model=\"actionConfig.selectedPage\" ng-required=\"true\">\n" +
    "                    <ui-select ng-model=\"actionConfig.selectedPage\" theme=\"bootstrap\">\n" +
    "                        <ui-select-match placeholder=\"{{::'Choose a Page...'|translate}}\">\n" +
    "                            {{$select.selected.name}}\n" +
    "                        </ui-select-match>\n" +
    "                        <ui-select-choices\n" +
    "                                repeat=\"item.id as item in pages | orderBy: 'displayName' | filter: {displayName: $select.search}\">\n" +
    "                            <span ng-bind-html=\"item.displayName | highlightHtmlSafe: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Page Variables (Optional)' | translate}}\" index=\"2\"\n" +
    "                          on-show=\"WizardCtrlr.onPageVarShow()\">\n" +
    "            <form ng-if=\"targetPageVars.length > 0\" name=\"pageVarsForm\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control ng-repeat=\"pageVar in targetPageVars\" label=\"{{::pageVar.name}}\">\n" +
    "                    <edge-page-var-mapper action-config=\"actionConfig\" page-var=\"::pageVar\"\n" +
    "                        source-page-vars=\"::sourcePageVars\" attributes=\"::dataAttributes\"\n" +
    "                        allow-attribute=\"::isAttributeEnabled\" is-switch-page=\"::true\">\n" +
    "                    </edge-page-var-mapper>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "            <div ng-if=\"targetPageVars.length === 0\" class=\"alert alert-info\">\n" +
    "                <span translate>The page you are switching to does not have any page variables defined.</span>\n" +
    "            </div>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"3\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/switchpage/edgePageVarMapper.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/switchpage/edgePageVarMapper.tpl.html",
    "<div>\n" +
    "    <div class=\"col-sm-4\" style=\"padding-left: 0\">\n" +
    "        <ui-select ng-model=\"pvmCtrlr.selectedMapperType\" theme=\"bootstrap\" on-select=\"pvmCtrlr.updateChoices()\">\n" +
    "            <ui-select-match>{{$select.selected.displayName}}</ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item in pvmCtrlr.mapperTypes | filter: {displayName: $select.search}\">\n" +
    "                <span ng-bind-html=\"item.displayName | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-8\">\n" +
    "        <div ng-if=\"param\" style=\"margin-left: 5px; margin-right: -5px\">\n" +
    "            <edge-param-control style=\"margin-left: 0; margin-right: 10px\" ng-init=\"readonly=true\"></edge-param-control>\n" +
    "        </div>\n" +
    "        <ui-select ng-model=\"pvmCtrlr.mapperValue\" theme=\"bootstrap\" ng-if=\"pvmCtrlr.selectedMapperType.type === pvmCtrlr.PageVarMappingType.RECORD_VALUE || pvmCtrlr.selectedMapperType.type === pvmCtrlr.PageVarMappingType.PAGE_VAR_VALUE\" ng-change=\"pvmCtrlr.handleMapperValueChange()\">\n" +
    "            <ui-select-match>{{$select.selected.name}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item.name as item in pvmCtrlr.choices | filter: {name: $select.search}\">\n" +
    "                <small style=\"top:0px\" class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "        <ui-select ng-model=\"pvmCtrlr.mapperValue\" theme=\"bootstrap\" ng-if=\"pvmCtrlr.selectedMapperType.type === pvmCtrlr.PageVarMappingType.ATTRIBUTE\" ng-change=\"pvmCtrlr.handleMapperValueChange()\">\n" +
    "            <ui-select-match>{{$select.selected.displayName}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item.type as item in pvmCtrlr.choices | filter: {displayName: $select.search}\">\n" +
    "                <span ng-bind-html=\"item.displayName | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/tooltip/action-tooltip-wizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/tooltip/action-tooltip-wizard.tpl.html",
    "<div ng-controller=\"ActionTooltipWizardController as WizardCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!isEdit\" dialog-mode=\"true\" on-save=\"WizardCtrlr.handleSave\"\n" +
    "                 on-cancel=\"WizardCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"{{::'List Items'|translate}}\"\n" +
    "                          use-form-validation=\"config\"\n" +
    "                          validate=\"WizardCtrlr.validateRenderer()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <edge-labeled-control label-width=\"0\" validation=\"true\" element-name=\"delay\" show-feedback-icon=\"false\">\n" +
    "                    <div class=\"col-sm-6 input-group\">\n" +
    "                        <span class=\"input-group-addon\" translate>Override Delay?</span>\n" +
    "                        <span class=\"input-group-addon\" style=\"border-left-width: 0;\" ng-style=\"WizardCtrlr.overrideDelay ? {'border-right-width': 0} : {'border-bottom-right-radius': '4px', 'border-top-right-radius': '4px'}\"><input type=\"checkbox\" ng-model=\"WizardCtrlr.overrideDelay\" ng-change=\"WizardCtrlr.delayChanged()\"></span>\n" +
    "                        <edge-number-spinner ng-style=\"! WizardCtrlr.overrideDelay ? {'visibility': 'hidden'} : {}\" inputname=\"delay\" isrequired=\"WizardCtrlr.overrideDelay\" unit-metric=\"{{::'Milliseconds'|translate}}\"\n" +
    "                            ng-model=\"WizardCtrlr.actionConfig.delay\" step=\"50\" minimum=\"WizardCtrlr.minimum\">\n" +
    "                        </edge-number-spinner>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "                <h4 translate>List Items</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"height: 50%;\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Show Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Value Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"WizardCtrlr.attributeSelected\"\n" +
    "                                       type=\"reorderable\" items=\"WizardCtrlr.actionConfig.attributeRendererDefs\">\n" +
    "                                <edge-list-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                         attributes-list=\"::listScope.WizardCtrlr.attributesList\"\n" +
    "                                                         attribute-defs=\"::listScope.WizardCtrlr.dataAttributes\"\n" +
    "                                                         new-label-suffix=\"{{::listScope.WizardCtrlr.labelSuffix}}\"\n" +
    "                                                         new-formatter-overrides=\"::listScope.WizardCtrlr.formatterOverrides\"></edge-list-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"WizardCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"WizardCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"WizardCtrlr.attributeSelected==null || WizardCtrlr.actionConfig.attributeRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "                <h4 translate>Label Formatter</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"width: 50%;\">\n" +
    "                    <edge-font-formatter formatter=\"WizardCtrlr.actionConfig.labelFormatter\">\n" +
    "                    </edge-font-formatter>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Conditions'|translate}}\" use-form-validation=\"conditions\" index=\"2\">\n" +
    "            <form name=\"conditions\" class=\"form-horizontal\">\n" +
    "                <edge-expression-builder group=\"actionConfig.conditions\"\n" +
    "                                         data-sources=\"::dataAttributes\"\n" +
    "                                         include-selected-attribute=\"isAttributeEnabled\">\n" +
    "                </edge-expression-builder>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html",
    "<table class=\"{{::Controller.inlineTableClass}}\" ng-class=\"::Controller.tableStriped\" cellspacing=\"5\">\n" +
    "    <tr ng-repeat=\"attributeRendererDef in Controller.inlineItems\">\n" +
    "        <td ng-if=\"::(attributeRendererDef.labelOn === true)\"\n" +
    "            class=\"{{::Controller.flowLabelClass}}\" >\n" +
    "            <div class=\"{{::Controller.renderLabelClass}} {{::Controller.getClass(attributeRendererDef, record, 'label')}}\">\n" +
    "                {{::attributeRendererDef.labelText}}\n" +
    "            </div>\n" +
    "        </td>\n" +
    "        <td ng-style=\"::{'text-align': attributeRendererDef.labelOn === true ? 'left' : 'center'}\"\n" +
    "            colspan=\"{{ ::(attributeRendererDef.labelOn === true ? 1 : 2)}}\"\n" +
    "            class=\"{{::Controller.flowValueClass}}\">\n" +
    "                <span ng-if=\"::(attributeRendererDef.formatterConfig.type === 0)\">\n" +
    "                     <img ng-src=\"{{::Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </span>\n" +
    "            <div ng-if=\"::(attributeRendererDef.formatterConfig.type !== 0)\"\n" +
    "                 class=\"{{::(attributeRendererDef.labelOn === true ? Controller.renderValueClass : Controller.valueOnlyClass)}} {{::Controller.getClass(attributeRendererDef, record, 'text')}}\">\n" +
    "                {{::Controller.actionTooltipService.getFormattedValue(attributeRendererDef, record)}}\n" +
    "            </div>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/core/widget/actions/tooltip/edgeTooltipContents.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/actions/tooltip/edgeTooltipContents.tpl.html",
    "<div class=\"edgeActionTooltipContents\">\n" +
    "    <!-- @formatter:off -->\n" +
    "    <style>\n" +
    "        .{{::Controller.floatLeftIconClass}} {\n" +
    "            width: {{::Controller.floatLeftIconWidth}}px;\n" +
    "            padding-right: 5px;\n" +
    "        }\n" +
    "        .{{::Controller.floatRightIconClass}} {\n" +
    "            width: {{::Controller.floatRightIconWidth}}px;\n" +
    "            padding-left: 5px;\n" +
    "        }\n" +
    "        {{Controller.styleClassesAsString}}\n" +
    "        td.{{::Controller.flowLabelClass}} {vertical-align: top; padding-left: 5px; padding-right: 5px;}\n" +
    "        td.{{::Controller.flowValueClass}} {padding-right: 5px;}\n" +
    "        div.{{::Controller.renderLabelClass}} { white-space:nowrap; text-overflow: ellipsis; overflow:hidden;}\n" +
    "        /* duplicate word-break is to get better behaviour in Chrome */\n" +
    "        div.{{::Controller.renderValueClass}} { word-wrap: break-word; word-break: break-all; word-break: break-word }\n" +
    "        .{{::Controller.renderLabelClass}} {text-align:right; text-overflow: ellipsis;}\n" +
    "        .{{::Controller.renderValueClass}} {text-align:left;}\n" +
    "        .{{::Controller.valueOnlyClass}} {text-align:center;padding-left: 5px; padding-right: 5px;}\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "    <table ng-if=\"Controller.hasFloatLeft==false && Controller.hasFloatRight==false\">\n" +
    "        <tr>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"Controller.hasFloatLeft==true && Controller.hasFloatRight==false\">\n" +
    "        <tr>\n" +
    "            <td class=\"{{::Controller.floatLeftIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatLeftItems\">\n" +
    "                    <img ng-src=\"{{Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"Controller.hasFloatLeft==false && Controller.hasFloatRight==true\">\n" +
    "        <tr>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "            <td class=\"{{::Controller.floatRightIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatRightItems\">\n" +
    "                    <img ng-src=\"{{Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"Controller.hasFloatLeft==true && Controller.hasFloatRight==true\">\n" +
    "        <tr>\n" +
    "            <td class=\"{{::Controller.floatLeftIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatLeftItems\">\n" +
    "                    <img ng-src=\"{{Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "            <td class=\"{{::Controller.floatRightIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatRightItems\">\n" +
    "                    <img ng-src=\"{{Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/core/widget/edgeWidgetContainer.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/edgeWidgetContainer.tpl.html",
    "<edge-panel class=\"edgeWidgetContainer\" ng-class=\"::{'noBorder': wcCtrlr.hideBorder, 'tranparent': wcCtrlr.isTransparent}\" resize=\"wcCtrlr.resizedHandler\" ng-attr-id=\"{{layout.prodInstanceId}}\">\n" +
    "    <edge-panel-header ng-if=\"::wcCtrlr.showHeader\" label=\"{{wcCtrlr.getTitle()}}\"\n" +
    "                       menu=\"wcCtrlr.widgetMenu\"\n" +
    "                       menu-click-handler=\"wcCtrlr.menuClickHandler\"\n" +
    "                       label-double-click-handler=\"wcCtrlr.toggleContainerSize()\">\n" +
    "        <div ng-if=\"wcCtrlr.isInteractive\">\n" +
    "            <div class=\"panel-label\" style=\"padding-right: 4px;\" uib-dropdown dropdown-append-to-body=\"true\">\n" +
    "                <a uib-dropdown-toggle style=\"padding: 2px 0px;\">\n" +
    "                    <span class=\"caret\"></span>\n" +
    "                </a>\n" +
    "                <ul uib-dropdown-menu class=\"dropdown-menu-right\">\n" +
    "                    <li ng-repeat=\"vis in wcCtrlr.stackedWidgets\">\n" +
    "                        <a ng-class=\"{'disabled': vis.id===wcCtrlr.currentVisInstanceId}\" ng-click=\"wcCtrlr.menuClickHandler('switch-vis', vis.id)\">{{vis.displayName}}</a>\n" +
    "                    </li>\n" +
    "                </ul>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-if=\"wcCtrlr.isAutoPlay\" style=\"line-height:24px; padding-right: 3px;\" class=\"panel-heading-control\">\n" +
    "            <a>\n" +
    "                <i class=\"edge-control-player icon icon_pause\" ng-click=\"wcCtrlr.togglePlay($event)\"></i>\n" +
    "            </a>\n" +
    "        </div>\n" +
    "        <div ng-if=\"wcCtrlr.showFreshnessIcon\">\n" +
    "            <span data-toggle=\"tooltip\" title=\"{{wcCtrlr.getStatusTooltip()}}\" ng-class=\"wcCtrlr.getStatusIcon()\"\n" +
    "                  ng-style=\"{'color': wcCtrlr.getStatusColor(), 'vertical-align' : 'middle'}\"></span>\n" +
    "        </div>\n" +
    "        <div ng-if=\"!wcCtrlr.widgetMenu.presentMode && wcCtrlr.getCurrentParams().length > 0\"\n" +
    "             style=\"line-height:24px;\"\n" +
    "             class=\"panel-heading-control\">\n" +
    "            <a\n" +
    "               ng-mouseover=\"wcCtrlr.handleParamCountMouseOver()\"\n" +
    "               ng-mouseleave=\"wcCtrlr.handleParamCountMouseLeave()\"><i class=\"icon icon_var\"></i>&nbsp;{{wcCtrlr.getCurrentParams().length}}</a>\n" +
    "        </div>\n" +
    "    </edge-panel-header>\n" +
    "    <edge-panel-body ng-style=\"{'overflow': wcCtrlr.widgetContext.overflow}\">\n" +
    "        <div ng-style=\"{'visibility': layout.config.layoutChanging ? 'hidden':'inherit'}\" style=\"height:100%;\"\n" +
    "             ng-switch=\"wcCtrlr.getContainerMode()\">\n" +
    "            <div ng-switch-when=\"addWidget\" style=\"height:100%;\">\n" +
    "                <button ng-click=\"wcCtrlr.menuClickHandler('vis')\"\n" +
    "                        class=\"btn btn-default add-visualization\">\n" +
    "                    <i class=\"icon icon_plus\"/><span translate style=\"padding-left: 5px\">Add Visualization(s)</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div ng-switch-when=\"needsCreds\" class=\"edgeWidgetContainerMessage\" ng-init=\"wcCtrlr.checkIfSettable()\">\n" +
    "                <div class=\"alert alert-warning\" style=\"margin: 0 auto; white-space: nowrap\">\n" +
    "                    <i class='icon icon_info_circle' style='vertical-align: middle'></i>\n" +
    "                    <span translate>Credentials required.</span><br>\n" +
    "                    <div ng-if=\"wcCtrlr.showCredentialEdit\" class=\"pull-right\">\n" +
    "                        <button ng-click=\"wcCtrlr.requestAllCredentials()\"\n" +
    "                                class=\"btn btn-default\"\n" +
    "                                translate>Enter Credentials\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-switch-when=\"badCreds\" class=\"edgeWidgetContainerMessage\" ng-init=\"wcCtrlr.checkIfSettable()\">\n" +
    "                <div class=\"alert alert-warning\" style=\"margin: 0 auto; white-space: nowrap\">\n" +
    "                    <i class='icon icon_info_circle' style='vertical-align: middle'></i>\n" +
    "                    <span translate>Authentication Failure.</span><br>\n" +
    "                    <div ng-if=\"wcCtrlr.showCredentialEdit\" class=\"pull-right\">\n" +
    "                        <button ng-click=\"wcCtrlr.requestAllCredentials()\"\n" +
    "                                class=\"btn btn-default\"\n" +
    "                                translate>Re-enter Credentials\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-switch-when=\"error\" class=\"edgeWidgetContainerMessage\">\n" +
    "                <div class=\"edgeWidgetContainerMessageWrapper\">\n" +
    "                    <div class=\"alert edgeSystemMessage\"\n" +
    "                         translate>A failure has occurred. This visualization can not render.\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"edgeWidgetHolder\" ng-show=\"wcCtrlr.getContainerMode() == 'showWidget'\"\n" +
    "                 style=\"height:100%;overflow:hidden\"></div>\n" +
    "            <div ng-if=\"wcCtrlr.showWaitMessage\" class=\"edgeWidgetContainerMessage\">\n" +
    "                <div style=\"margin: 0 auto;\"><span translate>Loading</span> ...</div>\n" +
    "            </div>\n" +
    "            <div ng-if=\"wcCtrlr.showNoDataMessage\" class=\"edgeWidgetContainerMessage\">\n" +
    "                <div class=\"edge-no-data-container\">\n" +
    "                    <div class=\"alert edge-no-data-message\" translate>No Data To Display</div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div ng-if=\"wcCtrlr.showErrorMessage\" class=\"edgeWidgetContainerMessage\">\n" +
    "                <div class=\"edgeWidgetContainerMessageWrapper\">\n" +
    "                    <div class=\"alert edgeSystemMessage\">{{wcCtrlr.errorMessage}}</div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-panel-body>\n" +
    "    <edge-panel-footer ng-show=\"wcCtrlr.hasFooterContents()\" class=\"edge-widget-footer widget-footer-flex-container\">\n" +
    "        <edge-client-filter-control ng-if=\"wcCtrlr.hasClientFilter()\" ng-repeat=\"filter in wcCtrlr.filters\" filter=\"filter\" class=\"edgeFooterControl edgeFilterControl\"\n" +
    "            widget-context=\"widgetContext\" controller=\"wcCtrlr.widgetController\" index=\"$index\">\n" +
    "        </edge-client-filter-control>\n" +
    "        <div style=\"clear: both;\"></div>\n" +
    "    </edge-panel-footer>\n" +
    "</edge-panel>\n" +
    "");
}]);

angular.module("edge/core/widget/save-dataset-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/save-dataset-dialog.tpl.html",
    "<form name=\"dialogForm\" class=\"form-horizontal\">\n" +
    "    <edge-labeled-control label-width=\"3\" label=\"{{::'File name' | translate}}\">\n" +
    "        <input name=\"fileName\" type=\"text\" class=\"form-control\" ng-model=\"file.name\">\n" +
    "    </edge-labeled-control>\n" +
    "\n" +
    "    <div ng-if=\"hasDateColumn\">\n" +
    "        <edge-labeled-control label=\"{{::'Date Format'|translate}}\" label-width=\"3\" helptext=\"{{::'Format syntax and examples can be found at <a href=\\'https://momentjs.com/docs/#/displaying/\\' target=\\'momentDateFormat\\'>DateTime Format</a>'|translate}}\">\n" +
    "            <ui-select theme=\"bootstrap\" ng-model=\"file.formatSelection\" on-select=\"file.format = file.formatSelection\" append-to-body=\"true\">\n" +
    "                <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                <ui-select-choices repeat=\"field.value as field in (formats | filter: {label: $select.search})\">\n" +
    "                    <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"file.formatSelection !== 'ms'\" label=\"{{::'Time Zone'|translate}}\" label-width=\"3\" helptext=\"{{::'Select a timezone where the date is in. If no value is entered, GMT will be assumed.'|translate}}\">\n" +
    "            <ui-select theme=\"bootstrap\" ng-model=\"file.timezone\" append-to-body=\"true\">\n" +
    "                <ui-select-match>{{$select.selected.value}}</ui-select-match>\n" +
    "                <ui-select-choices group-by=\"::'groupBy'\" repeat=\"field.value as field in (tz | filter: {label: $select.search})\">\n" +
    "                    <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "        <edge-labeled-control ng-if=\"file.formatSelection === ''\" label=\"{{::'Custom Format'|translate}}\" label-width=\"3\" helptext=\"{{::'Please enter a format for your date; syntax and examples can be found at <a href=\\'https://momentjs.com/docs/#/displaying/\\' target=\\'momentDateFormat\\'>DateTime Format</a>'|translate}}\">\n" +
    "            <input class=\"form-control\" type=\"text\" name=\"customFormat\" ng-model=\"file.format\">\n" +
    "        </edge-labeled-control>\n" +
    "    <div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/core/widget/secparams/security-credential-prompt.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/core/widget/secparams/security-credential-prompt.tpl.html",
    "<form name=\"ssoTokenForm\" class=\"form-horizontal\">\n" +
    "    <edge-credential-set ng-model=\"credentialSet\" show-expressions=\"false\"></edge-credential-set>\n" +
    "</form>\n" +
    "");
}]);
