angular.module('edgeUI.TPLS', ['edge/ui/complex/constraints/manage-constraints.tpl.html', 'edge/ui/complex/constraints/new-constraint-dialog.tpl.html', 'edge/ui/complex/constraints/types/edit-number-constraint-dialog.tpl.html', 'edge/ui/complex/constraints/types/edit-realtime-constraint-dialog.tpl.html', 'edge/ui/complex/constraints/types/edit-realtime-custom-constraint-dialog.tpl.html', 'edge/ui/complex/constraints/types/edit-string-constraint-dialog.tpl.html', 'edge/ui/complex/credentialset/edgeCredentialPair.tpl.html', 'edge/ui/complex/credentialset/edgeCredentialPairPassword.tpl.html', 'edge/ui/complex/credentialset/edgeCredentialSet.tpl.html', 'edge/ui/complex/daterangeslider/dateRangeLeftTooltip.tpl.html', 'edge/ui/complex/daterangeslider/dateRangeRightTooltip.tpl.html', 'edge/ui/complex/daterangeslider/edgeDateRangeSlider.tpl.html', 'edge/ui/complex/dialog/generic-delete-prompt.tpl.html', 'edge/ui/complex/dialog/generic-server-error.tpl.html', 'edge/ui/complex/duallist/edgeDualList.tpl.html', 'edge/ui/complex/expression/edgeExpressionBuilder.tpl.html', 'edge/ui/complex/formatters/edgeFormatterChooser.tpl.html', 'edge/ui/complex/formatters/edit-chosen-formatter-dialog.tpl.html', 'edge/ui/complex/formatters/editors/edgeColorFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeColorPaletteFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeCompositeIconFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeDateFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeFontFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeIconFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeNumberFormatter.tpl.html', 'edge/ui/complex/formatters/editors/edgeOffsetControl.tpl.html', 'edge/ui/complex/keyvaluepair/edgeKeyValuePair.tpl.html', 'edge/ui/complex/list/edgeList.tpl.html', 'edge/ui/complex/panel/body/edgePanelBody.tpl.html', 'edge/ui/complex/panel/edgePanel.tpl.html', 'edge/ui/complex/panel/footer/edgePanelFooter.tpl.html', 'edge/ui/complex/panel/header/edgePanelHeader.tpl.html', 'edge/ui/complex/proxyaccesscontrol/edgeProxyAccessControl.tpl.html', 'edge/ui/complex/splitpane/edgeSplitPane.tpl.html', 'edge/ui/complex/splitpane/view/edgeSplitPaneView.tpl.html', 'edge/ui/complex/wizard/edgeWizard.tpl.html', 'edge/ui/complex/wizard/edgeWizardDialog.tpl.html', 'edge/ui/complex/wizard/edgeWizardStep.tpl.html', 'edge/ui/complex/wizard/edgeWizardToolbar.tpl.html', 'edge/ui/form/attribute/edgeDataAttributePicker.tpl.html', 'edge/ui/form/attribute/edgeDataAttributeTypePicker.tpl.html', 'edge/ui/form/checkbox/edgeCheckBox.tpl.html', 'edge/ui/form/classnamecolorpicker/edgeClassnameColorPicker.tpl.html', 'edge/ui/form/classnamecolorpicker/edgeClassnameColorPickerButton.tpl.html', 'edge/ui/form/daterange/date-range-end-popover.tpl.html', 'edge/ui/form/daterange/date-range-start-popover.tpl.html', 'edge/ui/form/daterange/edgeDateRange.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableColor.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableDate.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableFont.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableFormatter.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableIcon.tpl.html', 'edge/ui/form/derivedformatters/edgeDerivableNumber.tpl.html', 'edge/ui/form/icon/edgeIconPicker.tpl.html', 'edge/ui/form/icon/edgeIconPickerList.tpl.html', 'edge/ui/form/labeledControl/edgeLabeledControl.tpl.html', 'edge/ui/form/labeledControl/form_messages.tpl.html', 'edge/ui/form/number/edgeNumberSpinner.tpl.html', 'edge/ui/form/propertycontrol/controls/AttributeDefList.tpl.html', 'edge/ui/form/propertycontrol/controls/Boolean.tpl.html', 'edge/ui/form/propertycontrol/controls/CodeMirror.tpl.html', 'edge/ui/form/propertycontrol/controls/Color.tpl.html', 'edge/ui/form/propertycontrol/controls/Combo.tpl.html', 'edge/ui/form/propertycontrol/controls/CoupledOptionalGroup.tpl.html', 'edge/ui/form/propertycontrol/controls/Credentials.tpl.html', 'edge/ui/form/propertycontrol/controls/CustomCombo.tpl.html', 'edge/ui/form/propertycontrol/controls/DerivableColor.tpl.html', 'edge/ui/form/propertycontrol/controls/DerivableFont.tpl.html', 'edge/ui/form/propertycontrol/controls/DerivableIcon.tpl.html', 'edge/ui/form/propertycontrol/controls/DerivableNumber.tpl.html', 'edge/ui/form/propertycontrol/controls/DiscreteNumber.tpl.html', 'edge/ui/form/propertycontrol/controls/Dropdown.tpl.html', 'edge/ui/form/propertycontrol/controls/File.tpl.html', 'edge/ui/form/propertycontrol/controls/FontStyle.tpl.html', 'edge/ui/form/propertycontrol/controls/Icon.tpl.html', 'edge/ui/form/propertycontrol/controls/KeyValuePair.tpl.html', 'edge/ui/form/propertycontrol/controls/List.tpl.html', 'edge/ui/form/propertycontrol/controls/MultiCombo.tpl.html', 'edge/ui/form/propertycontrol/controls/Multiline.tpl.html', 'edge/ui/form/propertycontrol/controls/Number.tpl.html', 'edge/ui/form/propertycontrol/controls/ObjStringList.tpl.html', 'edge/ui/form/propertycontrol/controls/ProxyAccessControl.tpl.html', 'edge/ui/form/propertycontrol/controls/ProxyAppVersionList.tpl.html', 'edge/ui/form/propertycontrol/controls/ProxyCredentialTypeList.tpl.html', 'edge/ui/form/propertycontrol/controls/String.tpl.html', 'edge/ui/form/propertycontrol/controls/TextAlignment.tpl.html', 'edge/ui/form/propertycontrol/controls/TextDisplay.tpl.html', 'edge/ui/form/propertycontrol/edgePropertyControl.tpl.html', 'edge/ui/form/rulesetcontrol/edgeRuleSetControl.tpl.html', 'edge/ui/form/slider/edgeSlider.tpl.html', 'edge/ui/form/splitbutton/edgeSplitButton.tpl.html', 'edge/ui/form/time/edgeTimePicker.tpl.html']);

angular.module("edge/ui/complex/constraints/manage-constraints.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/manage-constraints.tpl.html",
    "<edge-view>\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-12\">\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header label=\"{{::'Constraints'|translate}}\">\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' : panelScope.Controller.reverse == false }\"\n" +
    "                                    ng-click=\"panelScope.Controller.reverse = false\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Alphabetically' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_asc\"></i>\n" +
    "                            </button>\n" +
    "                            <button class=\"btn btn-default\"\n" +
    "                                    ng-class=\"{ 'active' :panelScope.Controller.reverse == true }\"\n" +
    "                                    ng-click=\"panelScope.Controller.reverse = true\"\n" +
    "                                    data-toggle=\"tooltip\"\n" +
    "                                    title=\"{{::'Sort Reverse Alphabetical' | translate}}\">\n" +
    "                                <i class=\"icon icon_sort_amount_desc\"></i>\n" +
    "                            </button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-heading-control pull-right\">\n" +
    "                        <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                            <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input type=\"search\"\n" +
    "                                                                                                           ng-model=\"panelScope.Controller.q\"\n" +
    "                                                                                                           class=\"form-control\"\n" +
    "                                                                                                           placeholder=\"{{::'filter ...' | translate}}\"/>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <edge-list items=\"panelScope.Controller.constraints\"\n" +
    "                               selected-item=\"panelScope.Controller.selectedConstraint\"\n" +
    "                               sort=\"name\"\n" +
    "								   q=\"panelScope.Controller.doFilter\"\n" +
    "                               reverse=\"panelScope.Controller.reverse\">\n" +
    "                        <div class=\"with-padding\" ng-dblclick=\"listScope.Controller.showEditConstraintDialog()\" >\n" +
    "                                <span ng-if=\"! item.isUserDefined\"><i class=\"icon icon_locked\" title=\"{{::'System Default' | translate}}\"></i></span>\n" +
    "								<span ng-bind-html=\"item.name | highlight:listScope.panelScope.Controller.q\"></span>\n" +
    "								<span class=\"pull-right\">\n" +
    "									 <code ng-bind-html=\"item.propertyTypeName | highlight:listScope.panelScope.Controller.q\"></code>\n" +
    "								</span>\n" +
    "                        </div>\n" +
    "                    </edge-list>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer>\n" +
    "                    <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                        <div class=\"btn-group\">\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-success\"\n" +
    "                                    ng-click=\"panelScope.Controller.newConstraintPrompt()\"\n" +
    "                                    title=\"{{::'Add' | translate}}\"><i class=\"icon icon_plus\"></i></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-warning\"\n" +
    "                                    ng-click=\"panelScope.Controller.showEditConstraintDialog()\"\n" +
    "                                    ng-disabled=\"panelScope.Controller.selectedConstraint==null || ! panelScope.Controller.selectedConstraint.isUserDefined\"\n" +
    "                                    title=\"{{::'Edit' | translate}}\"><i class=\"icon icon_pencil\"></i></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-danger\"\n" +
    "                                    ng-click=\"panelScope.Controller.removeParameterConstraint()\"\n" +
    "                                    ng-disabled=\"panelScope.Controller.selectedConstraint==null || ! panelScope.Controller.selectedConstraint.isUserDefined\"\n" +
    "                                    title=\"{{::'Delete' | translate}}\"><i class=\"icon icon_trash\"></i></button>\n" +
    "                        </div>\n" +
    "                        <span class=\"badge pull-right\"\n" +
    "                              translate translate-params-count=\"(panelScope.Controller.constraints|filter:panelScope.Controller.doFilter).length\"\n" +
    "                              translate-params-total=\"panelScope.Controller.constraints.length\">\n" +
    "                                  {{count}} of {{total}} Constraints\n" +
    "                        </span>\n" +
    "                    </div>\n" +
    "                </edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</edge-view>\n" +
    "");
}]);

angular.module("edge/ui/complex/constraints/new-constraint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/new-constraint-dialog.tpl.html",
    "<form name=\"newConstraintForm\" class=\"with-padding\">\n" +
    "    <div class=\"form-horizontal\" style=\"height: 100%;\">\n" +
    "        <edge-labeled-control label=\"{{'Constraint Data Type' | translate}}\" validation=\"true\">\n" +
    "            <select class=\"form-control\" ng-model=\"vm.constraintType\" name=\"constraintType\"\n" +
    "                    ng-options=\"type.label for type in constraintTypeList\" ng-required=\"true\">\n" +
    "            </select>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/ui/complex/constraints/types/edit-number-constraint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/types/edit-number-constraint-dialog.tpl.html",
    "<form name=\"constraintForm\" class=\"with-padding form-horizontal\">\n" +
    "    <div class=\"col-sm-6\" style=\"margin: auto 20%;\">\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.nameDef\" validation=\"true\" property-value=\"Controller.name\"></edge-property-control>\n" +
    "        <edge-property-control validation=\"true\" label-width=\"3\" property-def=\"::Controller.intervalDef\" property-value=\"Controller.interval\"></edge-property-control>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-6\" style=\"padding-right: 25px\">\n" +
    "        <h4 style=\"margin-bottom: 5px; margin-top: 25px;\" translate>Minimum Value</h4>\n" +
    "        <hr style=\"margin-top: 0; margin-bottom: 15px;\">\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.minValueTypeDef\" property-value=\"Controller.minValueType\" items=\"Controller.valueTypes\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"Controller.minValueType.value === 'Static'\" validation=\"true\" label-width=\"3\" property-def=\"::Controller.minStaticDef\" property-value=\"Controller.min\"></edge-property-control>\n" +
    "        <div ng-if=\"Controller.minValueType.value === 'Derived'\">\n" +
    "            <edge-property-control validation=\"true\" label-width=\"3\" property-def=\"::Controller.producerDef\" property-value=\"Controller.minProducerId\" items=\"Controller.producers\"></edge-property-control>\n" +
    "            <edge-property-control validation=\"true\" label-width=\"3\" property-def=\"::Controller.attributeDef\" property-value=\"Controller.minAttributeName\" items=\"Controller.minAttributes\"></edge-property-control>\n" +
    "            <edge-property-control label-width=\"3\" property-def=\"::Controller.minDerivedDef\" property-value=\"Controller.min\"></edge-property-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-6\">\n" +
    "        <h4 style=\"margin-bottom: 5px; margin-top: 25px;\" translate>Maximum Value</h4>\n" +
    "        <hr style=\"margin-top: 0; margin-bottom: 15px;\">\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.maxValueTypeDef\" property-value=\"Controller.maxValueType\" items=\"Controller.valueTypes\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"Controller.maxValueType.value === 'Static'\" validation=\"true\" label-width=\"3\" property-def=\"::Controller.maxStaticDef\" property-value=\"Controller.max\"></edge-property-control>\n" +
    "        <div ng-if=\"Controller.maxValueType.value === 'Derived'\">\n" +
    "            <edge-property-control validation=\"true\" label-width=\"3\" property-def=\"::Controller.maxProducerDef\" property-value=\"Controller.maxProducerId\" items=\"Controller.producers\"></edge-property-control>\n" +
    "            <edge-property-control validation=\"true\" label-width=\"3\" property-def=\"::Controller.maxAttributeDef\" property-value=\"Controller.maxAttributeName\" items=\"Controller.maxAttributes\"></edge-property-control>\n" +
    "            <edge-property-control label-width=\"3\" property-def=\"::Controller.maxDerivedDef\" property-value=\"Controller.max\"></edge-property-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/ui/complex/constraints/types/edit-realtime-constraint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/types/edit-realtime-constraint-dialog.tpl.html",
    "<form name=\"constraintForm\" class=\"with-padding form-horizontal\" style=\"height: 100%;\">\n" +
    "    <div class=\"col-sm-6\" style=\"padding-right: 25px\">\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.nameDef\" validation=\"true\" property-value=\"Controller.name\"></edge-property-control>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-6\">\n" +
    "    <edge-panel id=\"{{::Controller.panelId}}\" style=\"height: 100%;\">\n" +
    "        <edge-panel-header label=\"{{::'Pre-defined Values'|translate}}\">\n" +
    "            <div class=\"panel-heading-control pull-right\">\n" +
    "                <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input type=\"search\"\n" +
    "                                                                                                   ng-model=\"panelScope.Controller.q\"\n" +
    "                                                                                                   class=\"form-control\"\n" +
    "                                                                                                   placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"min-height:250px\">\n" +
    "            <edge-list items=\"Controller.sampleValues\" selected-item=\"Controller.sampleSelectedValue\" q=\"panelScope.Controller.q\">\n" +
    "                <div class=\"row\" style=\"padding: 15px\">\n" +
    "                    <span ng-bind-html=\"item.displayName | highlight:listScope.panelScope.Controller.q\"></span>\n" +
    "                </div>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <span class=\"badge pull-right\"\n" +
    "                             translate translate-params-count=\"(panelScope.Controller.sampleValues|filter:panelScope.Controller.q).length\"\n" +
    "                             translate-params-total=\"panelScope.Controller.sampleValues.length\">\n" +
    "                      {{count}} of {{total}} Values\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/ui/complex/constraints/types/edit-realtime-custom-constraint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/types/edit-realtime-custom-constraint-dialog.tpl.html",
    "<form name=\"constraintForm\" class=\"with-padding form-horizontal\" style=\"height: 100%;\">\n" +
    "    <div class=\"form-group\">\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"3\" property-def=\"::Controller.nameDef\" validation=\"true\" property-value=\"Controller.name\"></edge-property-control>\n" +
    "    </div>\n" +
    "    <div class=\"form-group\" style=\"height: calc(100% - 68px);\">\n" +
    "        <edge-panel id=\"{{Controller.panelId}}\" style=\"height: 100%;\">\n" +
    "            <edge-panel-header label=\"{{'Allowable Values'|translate}}\">\n" +
    "            </edge-panel-header>\n" +
    "            <edge-panel-body style=\"min-height:250px\">\n" +
    "                <div ng-if=\"Controller.values.length === 0\" style=\"display: flex; align-items: center; width: 60%; margin: 0 20%; height: 100%; position: absolute; top: 0; left: 0\">\n" +
    "                    <div style=\"margin: 0 auto;\"><span translate>Please add new value(s)</span></div>\n" +
    "                </div>\n" +
    "                <edge-list ng-if=\"Controller.values.length > 0\" items=\"Controller.values\" selected-item=\"Controller.selectedValue\" type=\"reorderable\">\n" +
    "                    <div class=\"row\" style=\"padding-top: 15px; margin: 0;\">\n" +
    "                        <edge-labeled-control class=\"col-sm-3\" label=\"{{'Last'|translate}}\" required=\"true\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                            <input class=\"form-control\" type=\"number\" ng-model=\"item.value\" name=\"value{{$index}}\" type=\"text\" ng-required=\"true\" ng-model-options=\"{'updateOn': 'blur'}\" min=\"1\" max=\"{{listScope.Controller.ParameterService.DateTimeService.realtimeUnitConstraints[item.unit]}}\">\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control class=\"col-sm-3\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                            <select class=\"form-control\" name=\"unit{{$index}}\" ng-model=\"item.unit\" ng-options=\"unit.value as unit.label for unit in listScope.Controller.ParameterService.DateTimeService.timeUnits\">\n" +
    "                            </select>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control class=\"col-sm-6\" label=\"{{'Label'|translate}}\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                            <input class=\"form-control\" ng-model=\"item.label\" ng-required=\"true\" type=\"text\" name=\"name{{$index}}\" ng-focus=\"listScope.Controller.generateLabel($index)\">\n" +
    "                        </edge-labeled-control>\n" +
    "                    </div>\n" +
    "                </edge-list>\n" +
    "            </edge-panel-body>\n" +
    "            <edge-panel-footer>\n" +
    "                <button title=\"{{'Add Value'|translate}}\" class=\"btn btn-success\" ng-click=\"Controller.addValue()\">\n" +
    "                    <i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button title=\"{{'Delete Value'|translate}}\" class=\"btn btn-danger\" ng-click=\"Controller.removeValue()\" ng-disabled=\"Controller.selectedValue == null\">\n" +
    "                    <i class=\"icon icon_minus\"></i>\n" +
    "                </button>\n" +
    "            </edge-panel-footer>\n" +
    "        </edge-panel>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/ui/complex/constraints/types/edit-string-constraint-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/constraints/types/edit-string-constraint-dialog.tpl.html",
    "<form name=\"constraintForm\" class=\"with-padding form-horizontal\" style=\"height: 100%;\">\n" +
    "    <div class=\"col-sm-6\" style=\"padding-right: 25px\">\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.nameDef\" validation=\"true\" property-value=\"Controller.name\"></edge-property-control>\n" +
    "        <edge-property-control label-width=\"3\" property-def=\"::Controller.constraintStaticDef\" property-value=\"Controller.constraintStatic\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"! Controller.constraintStatic.value\" validation=\"true\" label-width=\"3\" property-def=\"::Controller.producerDef\" property-value=\"Controller.producerId\" items=\"Controller.producers\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"! Controller.constraintStatic.value && Controller.producerId.value !== null\" validation=\"true\" label-width=\"3\" property-def=\"::Controller.attributeDef\" property-value=\"Controller.attributeName\" items=\"Controller.attributes\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"! Controller.constraintStatic.value && Controller.attributeName.value !== null\" label-width=\"3\" property-def=\"::Controller.constraintUseLabelDef\" property-value=\"Controller.constraintUseAsLabel\"></edge-property-control>\n" +
    "        <edge-property-control ng-if=\"! Controller.constraintStatic.value && ! Controller.constraintUseAsLabel.value && Controller.attributeName.value !== null\" validation=\"true\" label-width=\"3\" property-def=\"::Controller.attributeLabelDef\" property-value=\"Controller.attributeLabel\" items=\"Controller.attributes\"></edge-property-control>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-6\">\n" +
    "    <edge-panel id=\"{{::Controller.panelId}}\" style=\"height: 100%;\">\n" +
    "        <edge-panel-header label=\"{{::'Allowable Values'|translate}}\">\n" +
    "            <div class=\"panel-heading-control pull-right\">\n" +
    "                <div class=\"input-group\" style=\"max-width:220px\">\n" +
    "                    <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input type=\"search\"\n" +
    "                                                                                                   ng-model=\"panelScope.Controller.q\"\n" +
    "                                                                                                   class=\"form-control\"\n" +
    "                                                                                                   placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"min-height:250px\">\n" +
    "            <div ng-if=\"Controller.constraintStatic.value && Controller.values.length === 0\" style=\"display: flex; align-items: center; width: 60%; margin: 0 20%; height: 100%; position: absolute; top: 0; left: 0\">\n" +
    "                <div style=\"margin: 0 auto;\"><span translate>Unbounded</span></div>\n" +
    "            </div>\n" +
    "            <edge-list ng-if=\"Controller.constraintStatic.value && Controller.values.length > 0\" items=\"Controller.values\" selected-item=\"Controller.selectedValue\" type=\"reorderable\">\n" +
    "                <div class=\"row\" style=\"padding-top: 15px; margin: 0;\">\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label=\"{{::'Value'|translate}}\" validation=\"true\">\n" +
    "                        <input class=\"form-control\" ng-model=\"item.value\" name=\"value{{$index}}\" type=\"text\">\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label=\"{{::'Label'|translate}}\">\n" +
    "                        <input class=\"form-control\" ng-model=\"item.label\"  type=\"text\">\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </edge-list>\n" +
    "            <edge-list ng-if=\"! Controller.constraintStatic.value\" items=\"Controller.sampleValues\" selected-item=\"Controller.sampleSelectedValue\" q=\"panelScope.Controller.q\">\n" +
    "                <div class=\"row\" style=\"padding: 15px\" ng-if=\"listScope.panelScope.Controller.constraintUseAsLabel.value\">\n" +
    "                    <span ng-bind-html=\"item.name | highlight:listScope.panelScope.Controller.q\"></span>\n" +
    "                </div>\n" +
    "                <div class=\"row\" style=\"padding: 15px\" ng-if=\"!listScope.panelScope.Controller.constraintUseAsLabel.value\">\n" +
    "                    <span ng-bind-html=\"item.label | highlight:listScope.panelScope.Controller.q\"></span>\n" +
    "                    <span class=\"text-italic pull-right\" ng-bind-html=\"item.name\"></span>\n" +
    "                </div>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div ng-if=\"Controller.constraintStatic.value\" class=\"btn-group\">\n" +
    "                <button title=\"{{::'Add Value'|translate}}\" class=\"btn btn-success\" ng-click=\"Controller.addValue()\"><i\n" +
    "                        class=\"icon icon_plus\"></i></button>\n" +
    "                <button title=\"{{::'Delete Value'|translate}}\" class=\"btn btn-danger\" ng-click=\"Controller.removeValue()\"\n" +
    "                        ng-disabled=\"Controller.selectedValue == null\"><i class=\"icon icon_minus\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "            <div ng-if=\"! Controller.constraintStatic.value\" class=\"btn-toolbar\" role=\"toolbar\">\n" +
    "                <span class=\"badge pull-right\"\n" +
    "                      translate translate-params-count=\"(panelScope.Controller.sampleValues|filter:panelScope.Controller.q).length\"\n" +
    "                      translate-params-total=\"panelScope.Controller.sampleValues.length\">\n" +
    "                      {{count}} of {{total}} Values\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/ui/complex/credentialset/edgeCredentialPair.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/credentialset/edgeCredentialPair.tpl.html",
    "<div class=\"row\">\n" +
    "    <div class=\"col-sm-3\" ng-if=\"cpCtrlr.showExpressions == true\">\n" +
    "        <select ng-model=\"cpCtrlr.type\" class=\"form-control\" ng-change=\"cpCtrlr.handleTypeChange()\" ng-disabled=\"viewonly\">\n" +
    "            <option value=\"static\" translate>Static</option>\n" +
    "            <option value=\"expression\" translate>Expression</option>\n" +
    "        </select>\n" +
    "    </div>\n" +
    "    <div ng-class=\"{'col-sm-9':cpCtrlr.showExpressions == true}\" ng-if=\"cpCtrlr.type == 'static'\">\n" +
    "        <div class=\"input-group\" style=\"padding-right: 5px;\">\n" +
    "            <span class=\"input-group-addon\" ng-class=\"{'disabled':viewonly}\">{{pair.key}}</span>\n" +
    "            <edge-credential-pair-password ng-if=\"pair.hidden\" pair=\"pair\" viewonly=\"viewonly\"></edge-credential-pair-password>\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   name=\"pair_{{pair.key}}\"\n" +
    "                   autocomplete=\"off\"\n" +
    "                   ng-model=\"pair.value.primitiveValue\"\n" +
    "                   ng-required=\"pair.required\"\n" +
    "                   ng-disabled=\"viewonly\"\n" +
    "                   ng-if=\"!pair.hidden\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div ng-class=\"{'col-sm-9':cpCtrlr.showExpressions == true}\" ng-if=\"cpCtrlr.type == 'expression'\">\n" +
    "        <input type=\"hidden\"\n" +
    "               ng-model=\"pair.value.expression\"\n" +
    "               name=\"pair_{{pair.key}}\"\n" +
    "               ng-required=\"pair.required\">\n" +
    "        <div class=\"input-group\" style=\"padding-right: 5px;\">\n" +
    "            <span class=\"input-group-addon\" ng-class=\"{'disabled':viewonly}\">{{pair.key}}</span>\n" +
    "            <ui-select ng-model=\"pair.value.expression\" ng-disabled=\"viewonly\"> <!-- append-to-body=\"true\"  -->\n" +
    "                <ui-select-match theme=\"bootstrap\">{{$select.selected}}</ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item in cpCtrlr.getExpressions($select.search)\">\n" +
    "                    <span ng-bind-html=\"item| highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/credentialset/edgeCredentialPairPassword.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/credentialset/edgeCredentialPairPassword.tpl.html",
    "<input type=\"password\"\n" +
    "       class=\"form-control\"\n" +
    "       name=\"pair_{{pair.key}}\"\n" +
    "       autocomplete=\"off\"\n" +
    "       ng-model=\"pair.value.value\"\n" +
    "       ng-required=\"pair.required\"\n" +
    "       ng-disabled=\"viewonly\"\n" +
    "       placeholder=\"****************\"\n" +
    "       ng-if=\"pair.hidden\">");
}]);

angular.module("edge/ui/complex/credentialset/edgeCredentialSet.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/credentialset/edgeCredentialSet.tpl.html",
    "<div class=\"edgeCredentialSet\">\n" +
    "    <edge-labeled-control label-width=\"0\" validation=\"viewonly !== true\" ng-repeat=\"item in credentials.credentials\" element-name=\"{{item.key}}\">\n" +
    "        <edge-credential-pair pair=\"item\" viewonly=\"viewonly\" show-expressions=\"showExpressions\" expressions=\"expressions\"></edge-credential-pair>\n" +
    "    </edge-labeled-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/daterangeslider/dateRangeLeftTooltip.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/daterangeslider/dateRangeLeftTooltip.tpl.html",
    "<div style=\"white-space: nowrap;font-size:0.9em\">\n" +
    "    <div>{{drsCtrlr.leftTooltipDate}}</div>\n" +
    "    <div ng-if=\"drsCtrlr.showTime\">{{drsCtrlr.leftTooltipTime}}</div>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/daterangeslider/dateRangeRightTooltip.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/daterangeslider/dateRangeRightTooltip.tpl.html",
    "<div style=\"white-space: nowrap;font-size:0.9em\">\n" +
    "    <div>{{drsCtrlr.rightTooltipDate}}</div>\n" +
    "    <div ng-if=\"drsCtrlr.showTime\">{{drsCtrlr.rightTooltipTime}}</div>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/daterangeslider/edgeDateRangeSlider.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/daterangeslider/edgeDateRangeSlider.tpl.html",
    "<div class=\"edgeDateRangeSlider\" ng-dblclick=\"drsCtrlr.handleMidGrappleDoubleClick()\">\n" +
    "    <div class=\"edgeDateRangeSliderSparkline\"></div>\n" +
    "    <div class=\"edgeDRSLeftGrapple\">\n" +
    "        <div class=\"tooltipAnchor\"\n" +
    "             uib-tooltip-template=\"'edge/ui/complex/daterangeslider/dateRangeLeftTooltip.tpl.html'\"\n" +
    "             tooltip-is-open=\"drsCtrlr.showTooltips\"\n" +
    "             tooltip-append-to-body='true'\n" +
    "             tooltip-class=\"edgeDRSLeftTooltip\"\n" +
    "             tooltip-trigger=\"'none'\"\n" +
    "             tooltip-placement=\"auto top-right\"></div>\n" +
    "    </div>\n" +
    "    <div class=\"edgeDRSMidGrapple\"></div>\n" +
    "    <div class=\"edgeDRSRightGrapple\">\n" +
    "        <div class=\"tooltipAnchor\"\n" +
    "             uib-tooltip-template=\"'edge/ui/complex/daterangeslider/dateRangeRightTooltip.tpl.html'\"\n" +
    "             tooltip-is-open=\"drsCtrlr.showTooltips\"\n" +
    "             tooltip-append-to-body='true'\n" +
    "             tooltip-class=\"edgeDRSRightTooltip\"\n" +
    "             tooltip-trigger=\"'none'\"\n" +
    "             tooltip-placement=\"auto right\"></div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/dialog/generic-delete-prompt.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/dialog/generic-delete-prompt.tpl.html",
    "<p>{{::questionText}}</p>\n" +
    "<h4 ng-if=\"::objectText\" class=\"text-danger\">{{::objectText}}</h4>\n" +
    "<span class=\"text-muted\" ng-if=\"::warningText\">\n" +
    "    {{::warningText}}\n" +
    "</span>\n" +
    "");
}]);

angular.module("edge/ui/complex/dialog/generic-server-error.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/dialog/generic-server-error.tpl.html",
    "<div ng-if=\"::heading\" class=\"alert alert-danger\">\n" +
    "    <span>{{::heading}}</span>\n" +
    "    <br>\n" +
    "</div>\n" +
    "<div ng-if=\"::serverResponse\">\n" +
    "    <span translate>Server Response</span>:\n" +
    "    <div class=\"well well-sm\">{{::serverResponse}}\n" +
    "        <br>\n" +
    "        <a class=\"pull-right\" ng-if=\"extraDetail && vm.showInfo === false\" ng-click=\"vm.showInfo = true\" translate>More Info</a>\n" +
    "        <div class=\"clearfix\"></div>\n" +
    "        <span ng-if=\"vm.showInfo\"><br>{{::extraDetail}}</span>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/duallist/edgeDualList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/duallist/edgeDualList.tpl.html",
    "<div class=\"dlist row\">\n" +
    "    <div class=\"expanded\">\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"panel-heading\">\n" +
    "                        <div class=\"title\">{{unselectedTitle}}\n" +
    "                            <div class=\"btn btn-default btn-sm pull-right\" ng-click=\"selectAll()\" title=\"{{::'Move all to right' | translate}}\">\n" +
    "                                <i class=\"icon icon_step_forward select-all\"/>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div class=\"list-group\">\n" +
    "                        <a href class=\"list-group-item\" ng-repeat=\"item in getUnselectedItems()\"\n" +
    "                           ng-click=\"setSelectedItem(item)\">\n" +
    "                            <div edge-inject></div>\n" +
    "                            <div class=\"pull-right\">\n" +
    "                                <i class=\"select icon\"\n" +
    "                                   ng-class=\"{'icon_locked':isLockedItem(item), 'icon_chevron_right':!isLockedItem(item), select:!isLockedItem(item)}\"/>\n" +
    "                            </div>\n" +
    "\n" +
    "                            <!-- <span class=\"pull-right fa\"\n" +
    "                                  ng-class=\"{'icon_locked':isLockedItem(item),select:!isLockedItem(item)}\">\n" +
    "\n" +
    "                             </span>-->\n" +
    "\n" +
    "                        </a><!-- <a class=\"list-group-item list-disabled\"\n" +
    "                                ng-repeat=\"item in getDummyItems(false) track by $index\"> <span>&nbsp;</span> </a>\n" +
    "                                -->\n" +
    "                    </div>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer><span translate>List Items:</span>{{getUnselectedItems().length}}</edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <edge-panel>\n" +
    "                <edge-panel-header hide-label=\"true\">\n" +
    "                    <div class=\"panel-heading\">\n" +
    "                        <div class=\"title\">{{selectedTitle}}\n" +
    "                            <div class=\"btn btn-default btn-sm pull-left\" ng-click=\"unselectAll()\" title=\"{{::'Move all to left' | translate}}\">\n" +
    "                                <i class=\"icon icon_step_backward unselect-all\"/>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-panel-header>\n" +
    "                <edge-panel-body>\n" +
    "                    <div class=\"list-group\">\n" +
    "                        <a class=\"list-group-item\" ng-repeat=\"item in getSelectedItems()\"\n" +
    "                           ng-click=\"setSelectedItem(item)\">\n" +
    "\n" +
    "                            <div class=\"pull-left\">\n" +
    "                                <i class=\"icon icon_chevron_left unselect\"/>\n" +
    "                            </div>\n" +
    "                            <div edge-inject></div>\n" +
    "\n" +
    "                            <!-- <span class=\"fa unselect\"></span>\n" +
    "                             <span edge-inject></span>-->\n" +
    "                        </a><!-- <a class=\"list-group-item list-disabled\"\n" +
    "                                ng-repeat=\"item in getDummyItems(true) track by $index\"> <span>&nbsp;</span> </a>\n" +
    "                                -->\n" +
    "                    </div>\n" +
    "                </edge-panel-body>\n" +
    "                <edge-panel-footer><span translate>List Items:</span>{{getSelectedItems().length}}</edge-panel-footer>\n" +
    "            </edge-panel>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"collapsed\">\n" +
    "        <div class=\"col-sm-12\">\n" +
    "            <div class=\"panel panel-default\">\n" +
    "                <div class=\"panel-heading\">\n" +
    "                    <span class=\"title\">{{collapsedTitle}}</span>\n" +
    "                </div>\n" +
    "                <div class=\"panel-body\">\n" +
    "                    <ul class=\"list-group\">\n" +
    "                        <li class=\"list-group-item\" ng-repeat=\"item in items\" ng-click=\"setSelectedItem(item)\">\n" +
    "                            <span class=\"icon\"\n" +
    "                                  ng-class=\"{'icon_locked':isLockedItem(item),'icon_select_checked':isSelectedItem(item),'icon_select_box':!isLockedItem(item) && !isSelectedItem(item)}\"></span>\n" +
    "                            <span edge-inject></span>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "                <div class=\"panel-footer\" translate translate-params-selected-count=\"getSelectedItems().length\" translate-params-total=\"items.length\">Selected Items:{{selectedCount}} of {{total}}</div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <span>{{layoutDualList()}}</span>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/ui/complex/expression/edgeExpressionBuilder.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/expression/edgeExpressionBuilder.tpl.html",
    "<div class=\"alert-default alert-group col-sm-12\">\n" +
    "    <div class=\"form-inline\" style=\"padding-left: 5px\">\n" +
    "        <select ng-options=\"o.name as o.label for o in service.operators\"\n" +
    "                ng-model=\"group.operator\"\n" +
    "                class=\"form-control\"></select>\n" +
    "        <button style=\"margin-left: 5px\" ng-click=\"addCondition()\" class=\"btn btn-default\">\n" +
    "            <span class=\"glyphicon glyphicon-plus-sign\"></span> <span translate>Condition</span></button>\n" +
    "        <button style=\"margin-left: 5px\" ng-click=\"addGroup()\" class=\"btn btn-default\">\n" +
    "            <span class=\"glyphicon glyphicon-plus-sign\"></span> <span translate>Group</span></button>\n" +
    "        <button style=\"margin-left: 5px\" ng-click=\"removeGroup()\" class=\"btn btn-default\" ng-if=\"showRemove\">\n" +
    "            <span class=\"glyphicon glyphicon-minus-sign\"></span> Group\n" +
    "        </button>\n" +
    "        <label class=\"pull-right negate\"><span translate>NOT</span>&nbsp;&nbsp; <input type=\"checkbox\"\n" +
    "                                                                                       ng-model=\"group.negate\"\n" +
    "                                                                                       edge-boolean-switch\n" +
    "                                                                                       data-on-text=\"{{::'Yes'|translate}}\"\n" +
    "                                                                                       data-off-text=\"{{::'No'|translate}}\">\n" +
    "        </label>\n" +
    "    </div>\n" +
    "    <div class=\"group-conditions\">\n" +
    "        <div ng-repeat=\"rule in group.tokens | orderBy:'index'\" class=\"col-sm-12 condition\">\n" +
    "            <div ng-switch=\"rule.hasOwnProperty('__tokens')\">\n" +
    "                <div ng-switch-when=\"true\" class=\"col-sm-12\">\n" +
    "                    <edge-expression-builder group=\"rule\" sources=\"sources\" inputPrefix=\"{{inputPrefix}}\" include-selected-attribute=\"includeSelectedAttribute\" show-remove=\"true\"></edge-expression-builder>\n" +
    "                </div>\n" +
    "                <div ng-switch-default>\n" +
    "                    <div class=\"col-sm-4\">\n" +
    "                        <div ng-if=\"! clonedSources\" class=\"input-group attribute-select\">\n" +
    "                            <input type=\"text\" class=\"form-control\" ng-model=\"rule.field\">\n" +
    "                        </div>\n" +
    "                        <div ng-if=\"clonedSources\" class=\"input-group attribute-select\">\n" +
    "                            <span class=\"input-group-btn\">\n" +
    "                                <button ng-click=\"removeCondition($index)\" class=\"btn btn-sm btn-danger\"\n" +
    "                                    style=\"padding-top: 6px; padding-bottom: 6px;\">\n" +
    "                                    <span class=\"glyphicon glyphicon-minus-sign\"></span>\n" +
    "                                </button>\n" +
    "                            </span>\n" +
    "                            <!-- force validation -->\n" +
    "                            <input type=\"hidden\" name=\"{{ruleIDPrefix+'-field-'+$index}}\"\n" +
    "                                ng-model=\"rule.field\" ng-required=\"true\"/>\n" +
    "                            <ui-select theme=\"bootstrap\" append-to-body=\"true\"\n" +
    "                                ng-model=\"rule.field\" on-select=\"onSelectAttribute($item, rule)\">\n" +
    "                                <ui-select-match>{{$select.selected.displayName}}</ui-select-match>\n" +
    "                                <ui-select-choices group-by=\"::field.producerName\"\n" +
    "                                    repeat=\"field.name as field in clonedSources | filter: $select.search\">\n" +
    "                                    <div>\n" +
    "                                        <span style=\"font-weight: bold;\"\n" +
    "                                              ng-bind-html=\"::field.displayName | highlight: $select.search\"></span>\n" +
    "                                        <small class=\"pull-right\" ng-bind-html=\"::field.typeAsString.toLowerCase()\"></small>\n" +
    "                                    </div>\n" +
    "                                    <small ng-if=\"::field.sampleData\" style=\"font-style: italic; padding-left: 10px;\">\n" +
    "                                        <span translate>sample</span>: {{::field.sampleData}}\n" +
    "                                    </small>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"col-sm-2\">\n" +
    "                        <select ng-options=\"c.name as c.label for c in service.conditions[rule.type]\"\n" +
    "                                ng-model=\"rule.condition\"\n" +
    "                                class=\"form-control\"\n" +
    "                                style=\"padding-left: 5px;\"></select>\n" +
    "                    </div>\n" +
    "                    <div class=\"col-sm-6\" ng-switch=\"rule.type\" ng-if=\"service.paramType(rule.condition)!='single'\">\n" +
    "                        <div ng-switch-when=\"0\">\n" +
    "                            <edge-labeled-control class=\"col-sm-12\"\n" +
    "                                                  label-width=\"0\"\n" +
    "                                                  validation=\"true\"\n" +
    "                                                  show-feedback-icon=\"false\">\n" +
    "                                <div class=\"input-group\">\n" +
    "                                    <input type=\"text\"\n" +
    "                                           name=\"{{ruleIDPrefix+'-stringvalue-'+$index}}\"\n" +
    "                                           ng-model=\"rule.value\"\n" +
    "                                           class=\"form-control\"\n" +
    "                                           ng-required=\"true\"/> <span class=\"input-group-addon\">\n" +
    "                                        <label>\n" +
    "                                            <input type=\"checkbox\"\n" +
    "                                                   ng-model=\"rule.option\"> <span translate>Ignore Case</span>?\n" +
    "                                        </label>\n" +
    "                                    </span>\n" +
    "                                </div>\n" +
    "                            </edge-labeled-control>\n" +
    "                        </div>\n" +
    "                        <div ng-switch-when=\"5\">\n" +
    "                            <edge-labeled-control class=\"col-sm-12\" label-width=\"0\">\n" +
    "                                <div class=\"input-group\">\n" +
    "                                    <span class=\"input-group-addon\">\n" +
    "                                        <span class=\"glyphicon glyphicon-calendar\" aria-hidden=\"true\"></span>\n" +
    "                                    </span> <input edge-datetime-picker\n" +
    "                                                   picker-options=\"{timePicker: rule.option, timePickerSeconds: true, parentEl: 'parent', locale: {format: rule.option ? 'L LTS' : 'L'}}\"\n" +
    "                                                   on-apply=\"applyDateSelection(rule)\"\n" +
    "                                                   reload=\"{{rule.reload}}\"\n" +
    "                                                   type=\"text\"\n" +
    "                                                   name=\"{{::ruleIDPrefix+'-datevalue-'+$index}}\"\n" +
    "                                                   value=\"rule.value\"\n" +
    "                                                   class=\"form-control\"\n" +
    "                                                   ng-required=\"true\"/> <span class=\"input-group-addon calendar\">\n" +
    "                                         <label>\n" +
    "                                            <input type=\"checkbox\"\n" +
    "                                                   ng-model=\"rule.option\"> <span translate>Show Time</span>?\n" +
    "                                         </label>\n" +
    "                                     </span>\n" +
    "                                </div>\n" +
    "                            </edge-labeled-control>\n" +
    "                        </div>\n" +
    "                        <span ng-switch-when=\"4\">\n" +
    "                            <input type=\"checkbox\"\n" +
    "                                   name=\"{{::ruleIDPrefix+'-value-'+$index}}\"\n" +
    "                                   ng-model=\"rule.value\"\n" +
    "                                   edge-boolean-switch\n" +
    "                                   data-on-text=\"{{::'true'|translate}}\"\n" +
    "                                   data-off-text=\"{{::'false'|translate}}\">\n" +
    "                        </span>\n" +
    "                        <span ng-switch-when=\"6\">\n" +
    "                            <ui-select theme=\"bootstrap\" ng-model=\"rule.value\" append-to-body=\"true\">\n" +
    "                                <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                                <ui-select-choices group-by=\"::field.producerName\"\n" +
    "                                                   repeat=\"field.name as field in sources | filter: $select.search\">\n" +
    "                                    <div>\n" +
    "                                        <span style=\"font-weight: bold;\"\n" +
    "                                              ng-bind-html=\"::field.name | highlight: $select.search\"></span>\n" +
    "                                        <span style=\"float:right\" ng-bind-html=\"::field.typeAsString.toLowerCase()\"></span>\n" +
    "                                    </div>\n" +
    "                                    <small ng-if=\"::field.sampleData\" style=\"font-style: italic; padding-left: 10px;\">\n" +
    "                                        <span translate>sample</span>: {{::field.sampleData}}\n" +
    "                                    </small>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </span>\n" +
    "                        <div ng-switch-default>\n" +
    "                            <edge-labeled-control class=\"col-sm-12\"\n" +
    "                                                  label-width=\"0\"\n" +
    "                                                  validation=\"true\"\n" +
    "                                                  show-feedback-icon=\"false\">\n" +
    "                                <edge-number-spinner inputname=\"{{ruleIDPrefix+'-numbervalue-'+$index}}\"\n" +
    "                                                     ng-model=\"rule.value\"\n" +
    "                                                     isrequired=\"true\"></edge-number-spinner>\n" +
    "                                <edge-number-spinner ng-if=\"service.paramType(rule.condition)=='modulo'\"\n" +
    "                                                     inputname=\"{{ruleIDPrefix+'-numbervalue2-'+$index}}\"\n" +
    "                                                     ng-model=\"rule.value2\"\n" +
    "                                                     isrequired=\"true\"></edge-number-spinner>\n" +
    "                            </edge-labeled-control>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/edgeFormatterChooser.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/edgeFormatterChooser.tpl.html",
    "<div>\n" +
    "    <input type=hidden name=\"type\" ng-model=\"config.type\" ng-required=\"true\">\n" +
    "    <div class=\"form-group\" style=\"margin:0px;padding-left:5px;width: 194px;\">\n" +
    "        <div class=\"input-group\">\n" +
    "            <div class=\"input-group-addon\">\n" +
    "                <i class=\"icon icon_eyedropper\"></i>\n" +
    "            </div>\n" +
    "            <ui-select ng-model=\"config.type\" theme=\"bootstrap\" style=\"width:125px;outline:0;\" append-to-body=\"true\">\n" +
    "                <ui-select-match allow-clear=\"false\"\n" +
    "                                 placeholder=\"{{'Choose...'|translate}}\">{{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item.type as item in fcCtrlr.filteredFormatterTypes | filter: {label:$select.search}\">\n" +
    "                    <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "            <div class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"fcCtrlr.editFormatter()\">\n" +
    "                    <i class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/edit-chosen-formatter-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/edit-chosen-formatter-dialog.tpl.html",
    "<div class=\"row\">\n" +
    "    <form name=\"formatterForm\" class=\"form-horizontal\">\n" +
    "        <div ng-if=\"::options.showTextBackgroundColor !== false\" class=\"col-sm-12\">\n" +
    "            <h4 translate>Background Color</h4>\n" +
    "            <hr>\n" +
    "            <edge-labeled-control label=\"{{'Use Background Color' | translate}}\" validation=\"false\" label-width=\"3\">\n" +
    "                <input type=\"checkbox\" edge-boolean-switch ng-model=\"config.useBackgroundColor\">\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-derivable-color ng-if=\"config.useBackgroundColor\"\n" +
    "                                  config=\"config.backgroundColor\" options=\"::options\"\n" +
    "                                  attribute-defs=\"::attributes\"></edge-derivable-color>\n" +
    "        </div>\n" +
    "        <div ng-if=\"config.type == TYPES.FONT || config.type == TYPES.NUMBER || config.type == TYPES.DATE\" class=\"col-sm-12\">\n" +
    "            <h4><span translate>Text</span></h4>\n" +
    "            <hr>\n" +
    "            <div ng-if=\"::options.showTextAlignment !== false\">\n" +
    "                <edge-labeled-control label=\"{{::'Alignment' | translate}}\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\"\n" +
    "                                      validation=\"true\"\n" +
    "                                      element-name=\"'alignment'\"\n" +
    "                                      required=\"true\">\n" +
    "                    <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "                    <input type=hidden name=\"alignment\" ng-model=\"config.alignment\" ng-required=\"true\">\n" +
    "\n" +
    "                    <ui-select ng-required=\"true\" ng-model=\"config.alignment\" append-to-body=\"true\">\n" +
    "                        <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                        <ui-select-choices\n" +
    "                                repeat=\"textAlignment.className as textAlignment in textAlignments | filter: $select.search\">\n" +
    "                            <span ng-bind-html=\"textAlignment.name | highlight: $select.search\"></span>\n" +
    "                        </ui-select-choices>\n" +
    "                    </ui-select>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "            <div ng-if=\"::options.showTextWordWrap !== false\">\n" +
    "                <edge-labeled-control label=\"{{::'Word Wrap' | translate}}\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\"\n" +
    "                                      validation=\"false\">\n" +
    "                    <input type=\"checkbox\"\n" +
    "                           name=\"showWordWrap\"\n" +
    "                           ng-model=\"config.wordWrap\"\n" +
    "                           edge-boolean-switch>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "            <edge-derivable-font config=\"config.formatter\" options=\"::options\" attribute-defs=\"::attributes\"></edge-derivable-font>\n" +
    "        </div>\n" +
    "        <div ng-if=\"config.type == TYPES.DATE\" class=\"col-sm-12\">\n" +
    "            <h4><span translate>Date</span></h4>\n" +
    "            <hr>\n" +
    "            <edge-derivable-date config=\"config.formatter\" options=\"::options\" attribute-defs=\"::attributes\"></edge-derivable-date>\n" +
    "        </div>\n" +
    "        <div ng-if=\"config.type == TYPES.NUMBER\" class=\"col-sm-12\">\n" +
    "            <h4><span translate>Number</span></h4>\n" +
    "            <hr>\n" +
    "            <edge-derivable-number config=\"config.formatter\" options=\"::options\" attribute-defs=\"::attributes\"></edge-derivable-number>\n" +
    "        </div>\n" +
    "        <div ng-if=\"config.type == TYPES.ICON\" class=\"col-sm-12\">\n" +
    "            <h4><span translate>Icon</span></h4>\n" +
    "            <hr>\n" +
    "            <edge-composite-icon-formatter formatter=\"config.formatter\" options=\"::options\"\n" +
    "                                           attribute-defs=\"::attributes\"></edge-composite-icon-formatter>\n" +
    "        </div>\n" +
    "        <edge-dialog-footer>\n" +
    "            <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "                <button class=\"btn btn-danger\" ng-click=\"dialogRef.close()\"><span translate>Cancel</span></button>\n" +
    "                <button class=\"btn btn-success\"\n" +
    "                        ng-click=\"handleApply()\"\n" +
    "                        ng-disabled=\"formatterForm.$invalid\"><span translate>Apply</span>\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-dialog-footer>\n" +
    "    </form>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeColorFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeColorFormatter.tpl.html",
    "<div>\n" +
    "    <edge-labeled-control label=\"{{::'Color' | translate}}\" validation=\"true\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\" top-label=\"::options.labelTop\">\n" +
    "        <edge-classname-color-picker-button ng-required=\"true\" ng-model=\"formatter.color\"\n" +
    "                                            allow-transparent=\"{{::options.allowTransparent}}\">\n" +
    "        </edge-classname-color-picker-button>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"options.showColorAlpha && formatter.color != 'transparent'\" label=\"{{::'Alpha' | translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\" top-label=\"::options.labelTop\"\n" +
    "                          validation=\"true\" required=\"true\">\n" +
    "        <edge-number-spinner inputname=\"alpha{{::uid}}\" isrequired=\"true\" ng-model=\"formatter.alpha\"\n" +
    "                             step=\"0.1\" minimum=\"0\" maximum=\"1\">\n" +
    "        </edge-number-spinner>\n" +
    "    </edge-labeled-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeColorPaletteFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeColorPaletteFormatter.tpl.html",
    "<div style=\"display:flex;flex-wrap:wrap\" class=\"input-group\">\n" +
    "    <ui-select append-to-body=\"true\" on-select=\"updatePreview($item)\"\n" +
    "               ng-model=\"formatter.paletteID\"\n" +
    "               class=\"edgePaletteSelect\"\n" +
    "               style=\"width:175px;flex:none\">\n" +
    "        <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "        <ui-select-choices\n" +
    "                repeat=\"palette.id as palette in presetPalettes | orderBy: 'name' | filter: {name: $select.search}\">\n" +
    "            <span ng-bind-html=\"palette.name | highlight: $select.search\"></span>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "    <div class=\"input-group-addon input-height\"\n" +
    "         style=\"padding:8px 8px;width:68px; display: inline-block; margin-left: -2px;\">\n" +
    "        <div class=\"edgePalettePreviewSelectContainer\">\n" +
    "            <div class=\"edgePalettePreviewSelectColor\"\n" +
    "                 ng-repeat=\"color in colors track by $index\"\n" +
    "                 ng-style=\"{'background-color':color}\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"input-group-btn\" style=\"display: inline-block;\">\n" +
    "        <button class=\"btn btn-default\" type=\"button\" style=\"flex:none\" ng-click=\"editPalette(false)\">\n" +
    "            <i class=\"icon icon_plus\"></i>\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default\"\n" +
    "                style=\"flex:none\"\n" +
    "                type=\"button\"\n" +
    "                ng-click=\"editPalette(true)\"\n" +
    "                ng-disabled=\"! selectedPalette.isEditable()\">\n" +
    "            <i class=\"icon icon_pencil\"></i>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeCompositeIconFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeCompositeIconFormatter.tpl.html",
    "<div style=\"display:flex;\">\n" +
    "    <div style=\"flex: 0 0 150px;\">\n" +
    "        <div class=\"panel panel-default\" style=\"height: 150px; margin-bottom: 10px;\">\n" +
    "            <div class=\"panel-heading\">\n" +
    "                <label translate>Preview</label>\n" +
    "            </div>\n" +
    "            <div class=\"panel-body icon-preview-bkg\">\n" +
    "                <div ng-style=\"{'background': 'url('+getPreviewURL()+') center center no-repeat'}\" style=\"height:100%;\"></div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"panel panel-default\" style=\"height:353px; min-height:353px;\">\n" +
    "            <div class=\"panel-heading\">\n" +
    "                <label translate>Icon Layers</label>\n" +
    "            </div>\n" +
    "            <div class=\"panel-body\">\n" +
    "                <edge-list selected-item=\"selectedLayer\"\n" +
    "                           type=\"reorderable\"\n" +
    "                           items=\"formatter.layers\"\n" +
    "                           style=\"display:flex\">\n" +
    "                    <div class=\"with-padding\">\n" +
    "                        <div class=\"icon-preview-bkg\"\n" +
    "                             style=\"display:flex; align-items: center;justify-content: center;\">\n" +
    "                            <div style=\"width:48px; height:48px;\">\n" +
    "                                <img ng-src=\"{{listScope.getLayerPreviewURL(item)}}\">\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </edge-list>\n" +
    "            </div>\n" +
    "            <div class=\"panel-footer\">\n" +
    "                <button ng-attr-title=\"{{::'Add Icon Layer' | translate}}\"\n" +
    "                        type=\"button\"\n" +
    "                        class=\"btn btn-default icon icon_plus\"\n" +
    "                        ng-click=\"addLayer()\"></button>\n" +
    "                <button ng-attr-title=\"{{::'Remove Selected Icon Layer' | translate}}\"\n" +
    "                        type=\"button\"\n" +
    "                        class=\"btn btn-default icon icon_minus\"\n" +
    "                        ng-click=\"removeSelectedLayer()\"\n" +
    "                        ng-disabled=\"selectedLayer==null || formatter.layers.length < 2\"></button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"flex: 1 0;padding-left:10px;\">\n" +
    "        <div class=\"panel panel-default\" ng-if=\"selectedLayer!=null\">\n" +
    "            <div class=\"panel-heading\">\n" +
    "                <label translate>Layer Configuration</label>\n" +
    "            </div>\n" +
    "            <div class=\"panel-body edgeCompositeIconEditPanel\" style=\"padding:10px 35px 0 0;\">\n" +
    "                <edge-labeled-control validation=\"false\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\" label=\"{{::'Icon' | translate}}\">\n" +
    "                    <edge-derivable-icon config=\"selectedLayer.icon\"\n" +
    "                                         attribute-defs=\"::attributeDefs\"\n" +
    "                                         options=\"::noLabelOptions\"></edge-derivable-icon>\n" +
    "\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control validation=\"false\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\" label=\"{{::'Color' | translate}}\">\n" +
    "                    <edge-derivable-color config=\"selectedLayer.fillColor\"\n" +
    "                                          attribute-defs=\"::attributeDefs\"\n" +
    "                                          options=\"::noLabelOptions\"></edge-derivable-color>\n" +
    "\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control validation=\"false\"\n" +
    "                                      ng-if=\"selectedLayer.icon.isDerived == true\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\" label=\"{{::'Override Ruleset Size' | translate}}\">\n" +
    "                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"selectedLayer.overrideRulesetSize\">\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Size Override' | translate}}\"\n" +
    "                                      ng-if=\"selectedLayer.overrideRulesetSize == true\"\n" +
    "                                      label-width=\"{{::options.labelWidth}}\"\n" +
    "                                      validation=\"true\"\n" +
    "                                      element-name=\"layerSize{{::uid}}\"\n" +
    "                                      required=\"true\">\n" +
    "                    <edge-number-spinner\n" +
    "                            inputname=\"layerSize{{::uid}}\"\n" +
    "                            isrequired=\"true\"\n" +
    "                            ng-model=\"selectedLayer.size\"\n" +
    "                            step=\"1\" minimum=\"0\"\n" +
    "                            maximum=\"256\"></edge-number-spinner>\n" +
    "                </edge-labeled-control>\n" +
    "                <div ng-if=\"::options.showIconOffset\">\n" +
    "                    <edge-labeled-control label=\"{{::'Offset' | translate}}\"\n" +
    "                                          label-width=\"{{::options.labelWidth}}\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <edge-offset-control layer=\"selectedLayer\"></edge-offset-control>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeDateFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeDateFormatter.tpl.html",
    "<div>\n" +
    "    <edge-labeled-control label-width=\"{{::options.labelWidth}}\"\n" +
    "                          label=\"{{::'Override User Time Zone'|translate}}\"\n" +
    "                          helptext=\"{{::'If yes, show the date in fixed time zone instead of the timezone set in the user\\'s preference.'|translate}}\">\n" +
    "        <input type=\"checkbox\" name=\"overrideUserTimeZone{{::uid}}\" ng-model=\"formatter.tzOverrideOn\" edge-boolean-switch>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"formatter.tzOverrideOn\"\n" +
    "                          label=\"{{::'Time Zone'|translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\">\n" +
    "        <input type=hidden name=\"tzOveride{{::uid}}\" ng-model=\"formatter.tzOverride\" ng-required=\"true\">\n" +
    "        <ui-select theme=\"bootstrap\" ng-model=\"formatter.tzOverride\">\n" +
    "            <ui-select-match>{{$select.selected.value}}</ui-select-match>\n" +
    "            <ui-select-choices group-by=\"::'groupBy'\"\n" +
    "                               repeat=\"field.value as field in (dfCtrlr.tzList | filter: {label: $select.search})\">\n" +
    "                <span ng-bind-html=\"::field.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Format' | translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\"\n" +
    "                          validation=\"true\"\n" +
    "                          helptext=\"{{::dfCtrlr.displayTypeHelpText}}\">\n" +
    "        <input type=hidden name=\"displayType{{::uid}}\" ng-model=\"formatter.displayType\" ng-required=\"true\">\n" +
    "        <ui-select ng-model=\"formatter.displayType\" append-to-body=\"true\">\n" +
    "            <ui-select-match theme=\"bootstrap\"\n" +
    "                             allow-clear=\"false\"\n" +
    "                             placeholder=\"{{::'Select date format...' | translate}}\">\n" +
    "                {{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices\n" +
    "                    repeat=\"item.value as item in (dfCtrlr.formatChoices | filter: $select.search)\">\n" +
    "                <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control ng-if=\"formatter.displayType === 'Custom'\"\n" +
    "                          label=\"{{::'Custom Format'|translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\"\n" +
    "                          helptext=\"{{::dfCtrlr.displayFormatHelpText}}\">\n" +
    "        <input class=\"form-control\" type=\"text\" name=\"timeFormat{{::uid}}\" ng-model=\"formatter.displayFormat\"\n" +
    "               ng-change=\"dfCtrlr.updateSampleValue()\">\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Sample Value'|translate}}\" label-width=\"{{::options.labelWidth}}\">\n" +
    "        <input class=\"form-control\" type=\"text\" name=\"sampleValue{{::uid}}\" ng-model=\"dfCtrlr.sampleValue\"\n" +
    "               ng-disabled=true>\n" +
    "    </edge-labeled-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeFontFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeFontFormatter.tpl.html",
    "<div>\n" +
    "    <div ng-if=\"::options.showFontColor !== false\">\n" +
    "        <edge-labeled-control validation=\"true\"\n" +
    "                              label-width=\"{{::options.labelWidth}}\"\n" +
    "                              label=\"{{::'Color' | translate}}\">\n" +
    "            <edge-classname-color-picker-button ng-required=\"true\"\n" +
    "                                                ng-model=\"formatter.color\"\n" +
    "                                                allow-transparent=\"false\">\n" +
    "            </edge-classname-color-picker-button>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div ng-if=\"::options.showFontSize !== false\">\n" +
    "        <edge-labeled-control label=\"{{::'Size' | translate}}\"\n" +
    "                              label-width=\"{{::options.labelWidth}}\"\n" +
    "                              validation=\"true\"\n" +
    "                              element-name=\"size{{::uid}}\"\n" +
    "                              required=\"true\">\n" +
    "            <edge-number-spinner\n" +
    "                    inputname=\"size{{::uid}}\"\n" +
    "                    isrequired=\"true\"\n" +
    "                    ng-model=\"formatter.size\"\n" +
    "                    step=\"1\" minimum=\"6\"\n" +
    "                    maximum=\"256\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div ng-if=\"::options.showFontStyle !== false\">\n" +
    "        <edge-labeled-control label=\"{{::'Style' | translate}}\"\n" +
    "                              label-width=\"{{::options.labelWidth}}\"\n" +
    "                              validation=\"true\"\n" +
    "                              required=\"true\">\n" +
    "            <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "            <input type=hidden name=\"style{{::uid}}\" ng-model=\"formatter.style\" ng-required=\"true\">\n" +
    "\n" +
    "            <ui-select ng-model=\"formatter.style\" append-to-body=\"true\">\n" +
    "                <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"textStyle.className as textStyle in textStyles | filter: $select.search\">\n" +
    "                    <small class=\"pull-right {{textStyle.className}}\" translate>Sample</small>\n" +
    "                    <span ng-bind-html=\"textStyle.name | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeIconFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeIconFormatter.tpl.html",
    "<div>\n" +
    "    <edge-labeled-control validation=\"true\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\" top-label=\"::options.labelTop\" label=\"{{::'Icon' | translate}}\">\n" +
    "        <edge-icon-picker ng-required=\"true\"\n" +
    "                          ng-model=\"formatter.icon\"\n" +
    "                          default-category=\"{{options.defaultIconCategory}}\"\n" +
    "                          icon=\"formatter\"></edge-icon-picker>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Style' | translate}}\"\n" +
    "                          top-label=\"::options.labelTop\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\"\n" +
    "                          validation=\"true\">\n" +
    "        <input type=hidden name=\"{{::uid}}style\" ng-model=\"formatter.style\" ng-required=\"true\">\n" +
    "        <ui-select ng-model=\"formatter.style\" append-to-body=\"true\">\n" +
    "            <ui-select-match theme=\"bootstrap\"\n" +
    "                             allow-clear=\"false\"\n" +
    "                             placeholder=\"{{::'Select icon style...' | translate}}\">\n" +
    "                {{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices\n" +
    "                    repeat=\"item.value as item in styleList | filter: $select.search\">\n" +
    "                <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <div ng-if=\"::options.showIconSize\">\n" +
    "        <edge-labeled-control label=\"{{::'Size' | translate}}\"\n" +
    "                              top-label=\"::options.labelTop\"\n" +
    "                              label-width=\"{{::options.labelWidth}}\"\n" +
    "                              validation=\"true\"\n" +
    "                              element-name=\"iconSize{{::uid}}\"\n" +
    "                              required=\"true\">\n" +
    "            <edge-number-spinner\n" +
    "                    inputname=\"iconSize{{::uid}}\"\n" +
    "                    isrequired=\"true\"\n" +
    "                    ng-model=\"formatter.size\"\n" +
    "                    step=\"1\" minimum=\"0\"\n" +
    "                    maximum=\"256\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeNumberFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeNumberFormatter.tpl.html",
    "<div>\n" +
    "    <edge-labeled-control label-width=\"{{::options.labelWidth}}\"\n" +
    "                          label=\"{{::'Show Decimal Places' | translate}}\">\n" +
    "        <input type=\"checkbox\"\n" +
    "               name=\"useDecimal{{::uid}}\"\n" +
    "               ng-model=\"formatter.useDecimal\"\n" +
    "               edge-boolean-switch>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label-width=\"{{::options.labelWidth}}\"\n" +
    "                          ng-if=\"formatter.useDecimal\"\n" +
    "                          element-name=\"useDecimal{{::uid}}\"\n" +
    "                          validation=\"true\"\n" +
    "                          label=\"{{::'Decimal Places' | translate}}\">\n" +
    "        <edge-number-spinner\n" +
    "                inputname=\"useDecimal{{::uid}}\"\n" +
    "                isrequired=\"true\"\n" +
    "                ng-model=\"formatter.decimal\"\n" +
    "                step=\"1\" minimum=\"1\"\n" +
    "                style=\"width:94px;\"\n" +
    "                maximum=\"10\"></edge-number-spinner>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label-width=\"{{::options.labelWidth}}\"\n" +
    "                          label=\"{{::'Show Thousands Separator' | translate}}\">\n" +
    "        <input type=\"checkbox\"\n" +
    "               name=\"showThousands{{::uid}}\"\n" +
    "               ng-model=\"formatter.thousands\"\n" +
    "               edge-boolean-switch>\n" +
    "\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Negative Numbers' | translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\"\n" +
    "                          validation=\"true\">\n" +
    "        <input type=hidden name=\"numericStyle{{::uid}}\" ng-model=\"formatter.negativeStyle\" ng-required=\"true\">\n" +
    "        <ui-select ng-model=\"formatter.negativeStyle\">\n" +
    "            <ui-select-match theme=\"bootstrap\"\n" +
    "                             allow-clear=\"false\"\n" +
    "                             placeholder=\"{{::'Select negative style...' | translate}}\">\n" +
    "                {{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices\n" +
    "                    repeat=\"item.value as item in negativeStyles | filter: $select.search\">\n" +
    "                <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Prefix'|translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\">\n" +
    "        <input class=\"form-control\"\n" +
    "               type=\"text\"\n" +
    "               ng-trim=\"false\"\n" +
    "               name=\"prefix{{::uid}}\"\n" +
    "               ng-model=\"formatter.prefix\">\n" +
    "    </edge-labeled-control>\n" +
    "    <edge-labeled-control label=\"{{::'Suffix'|translate}}\"\n" +
    "                          label-width=\"{{::options.labelWidth}}\">\n" +
    "        <input class=\"form-control\"\n" +
    "               ng-trim=\"false\"\n" +
    "               type=\"text\"\n" +
    "               name=\"suffix{{::uid}}\"\n" +
    "               ng-model=\"formatter.suffix\">\n" +
    "    </edge-labeled-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/formatters/editors/edgeOffsetControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/formatters/editors/edgeOffsetControl.tpl.html",
    "<div style=\"display: flex;\">\n" +
    "    <table style=\"table-layout: fixed;\">\n" +
    "        <tr style=\"height: 27px;\">\n" +
    "            <td colspan=\"3\" style=\"text-align: center\">\n" +
    "                <button ng-attr-title=\"{{::'Move Layer Up' | translate}}\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        style=\"padding: 1px 7px 3px 7px;\"\n" +
    "                        ng-click=\"moveUp()\"><i\n" +
    "                        class=\"icon icon_chevron_up\"></i></button>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td>\n" +
    "                <button ng-attr-title=\"{{::'Move Layer Left' | translate}}\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        style=\"padding: 3px 8px 1px 6px;\"\n" +
    "                        ng-click=\"moveLeft()\">\n" +
    "                    <i class=\"icon icon_chevron_left\"></i></button>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <button ng-attr-title=\"{{::'Center Layer' | translate}}\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        style=\"padding: 2px 7px;\"\n" +
    "                        ng-click=\"reset()\"><i\n" +
    "                        class=\"icon icon_circle_o\"></i></button>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <button ng-attr-title=\"{{::'Move Layer Right' | translate}}\"\n" +
    "                        style=\"padding: 3px 6px 1px 8px\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        ng-click=\"moveRight()\"><i class=\"icon icon_chevron_right\"></i></button>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        <tr style=\"height: 28px;\">\n" +
    "            <td colspan=\"3\" style=\"text-align: center\">\n" +
    "                <button ng-attr-title=\"{{::'Move Layer Down' | translate}}\"\n" +
    "                        class=\"btn btn-default\"\n" +
    "                        style=\"padding: 2px 7px;\"\n" +
    "                        ng-click=\"moveDown()\">\n" +
    "                    <i class=\"icon icon_chevron_down\"></i></button>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <div>\n" +
    "        <edge-labeled-control label=\"{{::'X Offset' | translate}}\"\n" +
    "                              label-width=\"3\"\n" +
    "                              validation=\"true\"\n" +
    "                              element-name=\"xOffset{{::uid}}\"\n" +
    "                              required=\"true\">\n" +
    "            <edge-number-spinner\n" +
    "                    inputname=\"xOffset{{::uid}}\"\n" +
    "                    isrequired=\"true\"\n" +
    "                    ng-model=\"layer.xOffset\"\n" +
    "                    step=\"1\" minimum=\"-256\"\n" +
    "                    maximum=\"256\"></edge-number-spinner>\n" +
    "        </edge-labeled-control>\n" +
    "\n" +
    "        <div>\n" +
    "            <edge-labeled-control label=\"{{::'Y Offset' | translate}}\"\n" +
    "                                  label-width=\"3\"\n" +
    "                                  validation=\"true\"\n" +
    "                                  element-name=\"yOffset{{::uid}}\"\n" +
    "                                  required=\"true\">\n" +
    "                <edge-number-spinner\n" +
    "                        inputname=\"yOffset{{::uid}}\"\n" +
    "                        isrequired=\"true\"\n" +
    "                        ng-model=\"layer.yOffset\"\n" +
    "                        step=\"1\" minimum=\"-256\"\n" +
    "                        maximum=\"256\"></edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/keyvaluepair/edgeKeyValuePair.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/keyvaluepair/edgeKeyValuePair.tpl.html",
    "<div class=\"panel panel-default edgeKeyValuePair\">\n" +
    "    <div class=\"panel-body\">\n" +
    "        <edge-list selected-item=\"ctrlr.selectedPair\" items=\"keyValues.pairs\">\n" +
    "            <div class=\"row keyValueRow\">\n" +
    "                <edge-labeled-control class=\"col-sm-6\" label-width=\"0\" show-feedback-icon=\"false\" validation=\"true\" style=\"padding-right: 15px\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\" translate>Key</span>\n" +
    "                        <input class=\"form-control\" name=\"key{{$index}}\" ng-required=\"true\" ng-model=\"item.key\" edge-focus-on>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\" translate>Value</span>\n" +
    "                        <input class=\"form-control\" ng-model=\"item.value\">\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-list>\n" +
    "    </div>\n" +
    "    <div class=\"panel-footer\">\n" +
    "        <div class=\"btn-group\">\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-click=\"ctrlr.addKeyValuePair()\"\n" +
    "                    title=\"{{::'Add a new Key/Value pair' | translate}}\">\n" +
    "                <i class=\"icon icon_plus btn_icon\"></i></button>\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-disabled=\"!ctrlr.selectedPair\"\n" +
    "                    title=\"{{::'Delete selected Key/Value pair' | translate}}\"\n" +
    "                    ng-click=\"ctrlr.deleteKeyValuePair()\">\n" +
    "                <i class=\"icon icon_trash btn_icon\"></i></button>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/list/edgeList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/list/edgeList.tpl.html",
    "<div class=\"list-wrapper\">\n" +
    "    <div ng-if=\"items == null || items.length < 1\"\n" +
    "         class=\"alert alert-info\"\n" +
    "         style=\"margin-bottom: 0\">{{emptyMessage}}\n" +
    "    </div>\n" +
    "    <div ng-if=\"items.length > 0\" ng-switch on=\"::type\">\n" +
    "        <div ng-switch-default class=\"list-group eeList\" vs-repeat>\n" +
    "            <div class=\"list-group-item {{liClass}}\"\n" +
    "                ng-repeat=\"item in items | filter:q | orderBy:sort:reverse track by $index\"\n" +
    "                ng-class=\"{even: $even, odd: $odd, selected: isSelectedItem(item)}\"\n" +
    "                ng-click=\"setSelectedItem(item)\">\n" +
    "                <div edge-inject class=\"ee-list-item\"></div>\n" +
    "                <div ng-if=\"::multiple\" class=\"multiple\" ng-class=\"{selected: isSelectedItem(item)}\"></div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"flow\" class=\"list-group eeList\" vs-repeat>\n" +
    "            <div ng-repeat=\"rows in items\">\n" +
    "                <div class=\"list-group-item {{liClass}}\"\n" +
    "                    ng-repeat=\"item in rows | filter:q | orderBy:sort:reverse track by $index\"\n" +
    "                    ng-class=\"{even: $even, odd: $odd, selected: isSelectedItem(item), flow: true}\"\n" +
    "                    ng-click=\"setSelectedItem(item)\">\n" +
    "                    <div edge-inject></div>\n" +
    "                    <div ng-if=\"::multiple\" class=\"multiple\" ng-class=\"{selected: isSelectedItem(item)}\"></div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"text\" class=\"list-group eeList scrolling-text-widget\">\n" +
    "            <span class=\"list-group-item {{liClass}} animate\"\n" +
    "                 ng-class=\"{selected: isSelectedItem(item)}\"\n" +
    "                 ng-click=\"setSelectedItem(item)\"\n" +
    "                 ng-repeat=\"item in items track by $index\"\n" +
    "                 ng-if=\"$index==listScope.Controller.textItemIndex\">\n" +
    "                <div edge-inject class=\"text-container\"></div>\n" +
    "            </span>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"reorderable\" class=\"list-group eeList\" sv-root sv-part=\"items\">\n" +
    "            <div class=\"list-group-item {{liClass}}\" ng-repeat=\"item in items\" sv-element\n" +
    "                ng-class=\"{even: $even, odd: $odd, selected: isSelectedItem(item)}\"\n" +
    "                ng-click=\"setSelectedItem(item)\">\n" +
    "                <div class=\"grabby\" sv-handle>\n" +
    "                    <label class=\"drag-label\">{{$index + 1}}</label>\n" +
    "                </div>\n" +
    "                <div edge-inject class=\"ee-list-item\"></div>\n" +
    "                <div ng-if=\"::multiple\" class=\"multiple pull-right\" ng-class=\"{selected: isSelectedItem(item)}\"></div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div ng-switch-when=\"simple\" class=\"list-group eeList\">\n" +
    "            <div class=\"list-group-item {{liClass}}\"\n" +
    "                ng-repeat=\"item in items | filter:q | orderBy:sort:reverse track by $index\"\n" +
    "                ng-class=\"{even: $even, odd: $odd, selected: isSelectedItem(item)}\" ng-click=\"setSelectedItem(item)\">\n" +
    "                <div edge-inject class=\"ee-list-item\"></div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/panel/body/edgePanelBody.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/panel/body/edgePanelBody.tpl.html",
    "<div class=\"panel-body\">\n" +
    "    <edge-transclude></edge-transclude>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/panel/edgePanel.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/panel/edgePanel.tpl.html",
    "<div class=\"panel panel-default\" ng-transclude>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/panel/footer/edgePanelFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/panel/footer/edgePanelFooter.tpl.html",
    "<div class=\"panel-footer\">\n" +
    "    <edge-transclude></edge-transclude>\n" +
    "</div>");
}]);

angular.module("edge/ui/complex/panel/header/edgePanelHeader.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/panel/header/edgePanelHeader.tpl.html",
    "<div class=\"panel-heading\" style='display: flex; flex-wrap: nowrap' ng-dblclick=\"labelDoubleClickHandler()\">\n" +
    "    <div ng-if=\"::! hideLabel\" class=\"panel-label\" style='flex: 1' ng-attr-title=\"{{label}}\">{{label}}</div>\n" +
    "    <div class=\"panel-menu btn-toolbar\" style='white-space: nowrap; display: flex;' ng-style='{\"flex\": (hideLabel?1:0) + \" 1 auto\"}'>\n" +
    "        <edge-transclude></edge-transclude>\n" +
    "        <div class=\"btn-group\" style='margin-left: 0'>\n" +
    "            <a ng-if=\"::helpUrl\" href=\"{{::helpUrl}}\" target=\"_blank\" class=\"help-icon hidden-xs\"><i class=\"icon icon_question\"></i></a>\n" +
    "            <edge-hamburger-menu ng-if=\"menu && menu.active\" class=\"hamburger\" menu=\"menu\"\n" +
    "                                 action-callback=\"menuClickHandler\"></edge-hamburger-menu>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/proxyaccesscontrol/edgeProxyAccessControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/proxyaccesscontrol/edgeProxyAccessControl.tpl.html",
    "<div class=\"edgeProxyAccessControl\">\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"col-sm-7\">\n" +
    "                    <label translate style=\"padding-left:15px\">Host</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-2\">\n" +
    "                    <label translate>Allow HTTP</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-2\">\n" +
    "                    <label translate >Allow HTTPS</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-panel-body style=\"flex: 1 0 auto;\">\n" +
    "            <edge-list style=\"height: 120px;\" selected-item=\"ctrlr.selectedHostEntry\" items=\"hostEntries.hosts\" type=\"reorderable\">\n" +
    "                <div class=\"row with-padding hostEntryRow\">\n" +
    "                    <div class=\"col-sm-7 responsive-margin\">\n" +
    "                        <input class=\"form-control\" ng-model=\"item.host\">\n" +
    "                    </div>\n" +
    "                    <div class=\"col-sm-2\">\n" +
    "                        <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.allowHttp\"\n" +
    "                               data-on-text=\"{{::'Yes'|translate}}\" data-off-text=\"{{::'No'|translate}}\">\n" +
    "                    </div>\n" +
    "                    <div class=\"col-sm-2\">\n" +
    "                        <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.allowHttps\"\n" +
    "                               data-on-text=\"{{::'Yes'|translate}}\" data-off-text=\"{{::'No'|translate}}\">\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </edge-list>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button class=\"btn btn-success\"\n" +
    "                    ng-click=\"ctrlr.addHostEntry()\"\n" +
    "                    title=\"{{'Add a new host rule' | translate}}\">\n" +
    "                <i class=\"icon icon_plus btn_icon\"></i></button>\n" +
    "            <button class=\"btn btn-danger\"\n" +
    "                    ng-disabled=\"!ctrlr.selectedHostEntry\"\n" +
    "                    title=\"{{'Delete selected host rule' | translate}}\"\n" +
    "                    ng-click=\"ctrlr.deleteHostEntry()\">\n" +
    "                <i class=\"icon icon_trash btn_icon\"></i></button>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/splitpane/edgeSplitPane.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/splitpane/edgeSplitPane.tpl.html",
    "<div class=\"edgeSplitPane\" ng-transclude></div>\n" +
    "");
}]);

angular.module("edge/ui/complex/splitpane/view/edgeSplitPaneView.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/splitpane/view/edgeSplitPaneView.tpl.html",
    "<div class=\"edgeSplitPaneView\" ng-transclude></div>\n" +
    "");
}]);

angular.module("edge/ui/complex/wizard/edgeWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/wizard/edgeWizard.tpl.html",
    "<div class=\"edgeWizard\">\n" +
    "    <edge-panel ng-if=\"!dialogMode\">\n" +
    "        <edge-panel-header label=\"{{'Wizard' | translate}}\"></edge-panel-header>\n" +
    "        <edge-panel-body>\n" +
    "            <div style=\"position:relative;height:100%\">\n" +
    "                <edge-split-pane ng-if=\"!hideTabs\" value=\"::WizardCtrlr.sidebarSize\" horizontal=\"false\">\n" +
    "                    <edge-split-pane-view style=\"height:100%\">\n" +
    "                        <div class=\"edgeWizardTabs\">\n" +
    "                            <ul class=\"nav nav-pills nav-stacked\">\n" +
    "                                <li role=\"presentation\" ng-repeat=\"step in WizardCtrlr.steps\"\n" +
    "                                    ng-class=\"{'active':step == WizardCtrlr.selectedStep, 'substep':step.isSubStep == true}\">\n" +
    "                                    <a\n" +
    "                                            class=\"edgeWizardTab\"\n" +
    "                                            ng-click=\"WizardCtrlr.setSelectedFromTab(step)\"\n" +
    "                                            ng-disabled=\"forceProgression && step != WizardCtrlr.selectedStep && ! step.isVisited\">{{$index\n" +
    "                                            + 1}}: {{step.label}} <i ng-if=\"step.errorMessage.length > 0\"\n" +
    "                                                                 class=\"pull-right icon icon_exclamation_circle\"></i></a>\n" +
    "                                </li>\n" +
    "                            </ul>\n" +
    "                        </div>\n" +
    "                    </edge-split-pane-view>\n" +
    "                    <edge-split-pane-view>\n" +
    "                        <div style=\"height:100%\" ng-transclude></div>\n" +
    "                    </edge-split-pane-view>\n" +
    "                </edge-split-pane>\n" +
    "                <div ng-if=\"hideTabs\" style=\"height:100%\" ng-transclude></div>\n" +
    "            </div>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <div id=\"edgeWizardToolbar\">\n" +
    "            </div>\n" +
    "            <div class=\"pull-right\">\n" +
    "                <div class=\"btn-block\">\n" +
    "                    <button ng-if=\"WizardCtrlr.activelyValidating || activelySaving\" edge-button-spinner data-spinner-color=\"#AAAAAA\" data-style=\"expand-left\" class=\"btn btn-danger\" spin-toggle=\"true\" translate>\n" +
    "                        Wait\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-default\" ng-click=\"handleCancel()\" translate>Cancel\n" +
    "                    </button>\n" +
    "                    <div class=\"btn-group\">\n" +
    "                        <button ng-if=\"!WizardCtrlr.onFirstStep()\" class=\"btn btn-default\"\n" +
    "                                ng-click=\"WizardCtrlr.handleBack()\"\n" +
    "                                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                                translate>Back\n" +
    "                        </button>\n" +
    "                        <button ng-if=\"!WizardCtrlr.onLastStep()\" class=\"btn btn-default\"\n" +
    "                                ng-click=\"WizardCtrlr.handleNext()\"\n" +
    "                                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                                translate>Next\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                    <button ng-if=\"WizardCtrlr.allowSaveButton()\" class=\"btn btn-primary\"\n" +
    "                            ng-click=\"WizardCtrlr.handleSave()\"\n" +
    "                            ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                            translate>Save\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"clearfix\"></div>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "    <div ng-if=\"dialogMode\" style=\"height:100%\">\n" +
    "        <edge-split-pane ng-if=\"!hideTabs\" value=\"::WizardCtrlr.sidebarSize\" horizontal=\"false\">\n" +
    "            <edge-split-pane-view style=\"height:100%\">\n" +
    "                <div class=\"edgeWizardTabs\">\n" +
    "                    <ul class=\"nav nav-pills nav-stacked\">\n" +
    "                        <li role=\"presentation\" ng-repeat=\"step in WizardCtrlr.steps\"\n" +
    "                            ng-class=\"{'active':step == WizardCtrlr.selectedStep, 'substep':step.isSubStep == true}\"><a\n" +
    "                                ng-click=\"WizardCtrlr.setSelectedFromTab(step)\"\n" +
    "                                ng-disabled=\"forceProgression && step != WizardCtrlr.selectedStep && ! step.isVisited\">{{$index\n" +
    "                            + 1}}: {{step.label}} <i ng-if=\"step.errorMessage.length > 0\"\n" +
    "                                                     class=\"pull-right icon icon_exclamation_circle\"></i></a>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </edge-split-pane-view>\n" +
    "            <edge-split-pane-view>\n" +
    "                <div style=\"height:100%\" ng-transclude></div>\n" +
    "            </edge-split-pane-view>\n" +
    "        </edge-split-pane>\n" +
    "        <div ng-if=\"hideTabs\" style=\"height:100%\" ng-transclude></div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/wizard/edgeWizardDialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/wizard/edgeWizardDialog.tpl.html",
    "<div style=\"position:relative;height:100%\">\n" +
    "    <ng-include src=\"wizardStepsTemplateURL\"></ng-include>\n" +
    "</div>\n" +
    "<edge-dialog-footer>\n" +
    "    <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "        <button ng-if=\"WizardCtrlr.activelyValidating || activelySaving\" edge-button-spinner data-spinner-color=\"#AAAAAA\" data-style=\"expand-left\" class=\"btn btn-danger\" spin-toggle=\"true\" translate>\n" +
    "            Wait\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-danger\" ng-click=\"handleCancel()\" translate>\n" +
    "            Cancel\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default\" ng-if=\"!WizardCtrlr.onFirstStep()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                ng-click=\"WizardCtrlr.handleBack()\" translate>Back\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-default\" ng-if=\"!WizardCtrlr.onLastStep()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                ng-click=\"WizardCtrlr.handleNext()\" translate>Next\n" +
    "        </button>\n" +
    "        <button class=\"btn btn-success\" ng-if=\"WizardCtrlr.allowSaveButton()\"\n" +
    "                ng-disabled=\"WizardCtrlr.activelyValidating || activelySaving\"\n" +
    "                ng-click=\"handleSave()\" ng-class=\"{'pulse':! activelySaving && WizardCtrlr.unsavedChanges}\">\n" +
    "            <span ng-if=\"WizardCtrlr.unsavedChanges\" class=\"icon icon_exclamation_triangle\"></span>\n" +
    "            <span>{{WizardCtrlr.saveButtonLabel}}</span>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</edge-dialog-footer>\n" +
    "");
}]);

angular.module("edge/ui/complex/wizard/edgeWizardStep.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/wizard/edgeWizardStep.tpl.html",
    "<div class=\"edgeWizardStepContainer\" ng-show=\"stepCtrlr.isSelected()\" style=\"height:100%\" ng-transclude>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/complex/wizard/edgeWizardToolbar.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/complex/wizard/edgeWizardToolbar.tpl.html",
    "<div class=\"edgeWizardToolbar pull-left\" ng-transclude>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/attribute/edgeDataAttributePicker.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/attribute/edgeDataAttributePicker.tpl.html",
    "<div>\n" +
    "    <input type=hidden ng-attr-name=\"{{::name}}\" ng-model=\"ctrlr.value\" ng-required=\"{{::required}}\">\n" +
    "    <div class=\"input-group\">\n" +
    "        <span class=\"input-group-addon\" style=\"height:32px;\"><i class=\"icon icon_database\"></i><span ng-if=\"restrictType != undefined\" ng-bind-html=\"ctrlr.getDataType()\"></span></span>\n" +
    "        <ui-select ng-model=\"ctrlr.value\" theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "            <ui-select-match placeholder=\"{{'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices repeat=\"item.name as item in ctrlr.attributeDefs | filter: $select.search\">\n" +
    "                <small style=\"top:0px\" class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/attribute/edgeDataAttributeTypePicker.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/attribute/edgeDataAttributeTypePicker.tpl.html",
    "<div>\n" +
    "    <select class=\"form-control\" style=\"border-top-left-radius: 0 !important;border-bottom-left-radius: 0 !important;\" ng-model=\"value\" ng-options=\"dt.value as dt.label for dt in dataTypes\">\n" +
    "    </select>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/checkbox/edgeCheckBox.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/checkbox/edgeCheckBox.tpl.html",
    "<div class=\"btn btn-default edge-check-box-container\"\n" +
    "     ng-class=\"{'edge-check-box-checked':value}\"\n" +
    "     ng-click=\"value = !value\">\n" +
    "    <input name=\"{{::name}}\" type=\"hidden\" ng-model=\"value\">\n" +
    "    <div class=\"icon icon_check\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/classnamecolorpicker/edgeClassnameColorPicker.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/classnamecolorpicker/edgeClassnameColorPicker.tpl.html",
    "<div>\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"input-group\" style=\"padding-left: 25px\">\n" +
    "            <span class=\"input-group-addon\" translate>Palette</span>\n" +
    "            <ui-select ng-model=\"vm.selectedPalette\" on-select=\"updateColors($item, $model)\">\n" +
    "                <ui-select-match placeholder=\"{{'Select a palette ...'|translate}}\">{{$select.selected.name}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices repeat=\"palette in palettes | orderBy: 'name' | filter: $select.search track by $index\">\n" +
    "                    <span ng-bind-html=\"palette.name | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "            <span class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"editPalette(false)\">\n" +
    "                    <i class=\"icon icon_plus\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"editPalette(true)\"\n" +
    "                        ng-disabled=\"! vm.selectedPalette || ! vm.selectedPalette.isEditable()\">\n" +
    "                    <i class=\"icon icon_pencil\"></i>\n" +
    "                </button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"copyPalette()\"\n" +
    "                        ng-disabled=\"! vm.selectedPalette || ! vm.selectedPalette.isCopyable()\">\n" +
    "                    <i class=\"icon icon_copy\"></i>\n" +
    "                </button>\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"eeColor\">\n" +
    "        <div ng-repeat=\"color in colors track by $index\"\n" +
    "             ng-class=\"{selected: isSelectedItem(vm.selectedPalette.prefix + '-' + $index)}\"\n" +
    "             ng-click=\"setSelectedItem($index)\"\n" +
    "             ng-style=\"{'background-color':color}\"></div>\n" +
    "    </div>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"eeColor\" ng-if=\"allowTransparent === 'true'\" style=\"width:32px;height:32px; float: left; position: relative; top:-6px\">\n" +
    "            <div\n" +
    "                 ng-click=\"setSelectedItem('transparent')\"\n" +
    "                 ng-class=\"{selected: isSelectedItem('transparent')}\" class=\"edge-transparent\">\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/classnamecolorpicker/edgeClassnameColorPickerButton.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/classnamecolorpicker/edgeClassnameColorPickerButton.tpl.html",
    "<div class=\"eeColorPickerButton\" ng-click=\"showDialog()\">\n" +
    "    <span ng-class=\"::{'input-group':!useShort}\">\n" +
    "        <input type=\"hidden\" name=\"{{::name}}\" ng-model=\"selectedItem\" ng-required=\"::required\">\n" +
    "        <span ng-class=\"::{'input-group-btn':!useShort}\">\n" +
    "            <button type=\"button\" class=\"eeColorPatch btn btn-default\">\n" +
    "                <div ng-style=\"{'background-color': getHexValue()}\">\n" +
    "                    <div ng-if=\"selectedItem === 'transparent'\" class=\"edge-transparent\"></div>\n" +
    "                </div>\n" +
    "            </button>\n" +
    "        </span>\n" +
    "        <input ng-if=\"::!useShort\" type=\"text\" class=\"form-control disabled\" placeholder=\"{{getHexValue()}}\"/>\n" +
    "        <span ng-class=\"::{'input-group-btn':!useShort}\">\n" +
    "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n" +
    "                <span class=\"caret\"></span> <span class=\"sr-only\"></span>\n" +
    "            </button>\n" +
    "        </span>\n" +
    "    </span>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/ui/form/daterange/date-range-end-popover.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/daterange/date-range-end-popover.tpl.html",
    "<div uib-datepicker\n" +
    "     ng-if=\"!dpCtrlr.isMobile\"\n" +
    "     ng-disabled=\"dpCtrlr.maxDateActive\"\n" +
    "     ng-model=\"dpCtrlr.endEndpoint.date\"\n" +
    "     class=\"uib-date-picker-no-focus\"\n" +
    "     datepicker-options=\"dpCtrlr.endDatePickerOptions\"></div>\n" +
    "<edge-time-picker ng-if=\"!dpCtrlr.isMobile && dpCtrlr.showTime\" ng-disabled=\"dpCtrlr.maxDateActive\" ng-model=\"dpCtrlr.endEndpoint.date\" style=\"margin-top:5px;\"></edge-time-picker>\n" +
    "<input ng-if=\"dpCtrlr.isMobile\" type=\"date\" ng-disabled=\"dpCtrlr.maxDateActive\" ng-model=\"dpCtrlr.endEndpoint.date\"\n" +
    "       ng-change=\"dpCtrlr.endDateChanged()\" class=\"form-control mobile\">\n" +
    "<input ng-if=\"dpCtrlr.isMobile && dpCtrlr.showTime\" type=\"time\" ng-disabled=\"dpCtrlr.maxDateActive\" ng-model=\"dpCtrlr.endEndpoint.date\"\n" +
    "       ng-change=\"dpCtrlr.endDateChanged()\" class=\"form-control mobile\">\n" +
    "<div class=\"btn-group\" style=\"margin:5px 0px 5px 0px;\">\n" +
    "    <button class=\"btn btn-default\"\n" +
    "            ng-class=\"{'toggle-active':dpCtrlr.maxDateActive}\"\n" +
    "            ng-click=\"dpCtrlr.toggleMaxDate()\"><span translate>Max Date</span>\n" +
    "    </button>\n" +
    "</div>\n" +
    "<div class=\"btn-group pull-right\" style=\"margin:5px 0px 5px 0px;\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"dpCtrlr.applyEndDate()\"><span translate>Ok</span></button>\n" +
    "</div>\n" +
    "<div class=\"btn-group pull-right\" style=\"margin:5px 5px 5px 0px;\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"dpCtrlr.cancel()\"><span translate>Cancel</span></button>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/daterange/date-range-start-popover.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/daterange/date-range-start-popover.tpl.html",
    "<div uib-datepicker\n" +
    "     ng-if=\"!dpCtrlr.isMobile\"\n" +
    "     ng-disabled=\"dpCtrlr.minDateActive\"\n" +
    "     ng-model=\"dpCtrlr.startEndpoint.date\"\n" +
    "     class=\"uib-date-picker-no-focus\"\n" +
    "     datepicker-options=\"dpCtrlr.startDatePickerOptions\"></div>\n" +
    "<edge-time-picker ng-if=\"!dpCtrlr.isMobile && dpCtrlr.showTime\" ng-disabled=\"dpCtrlr.minDateActive\" ng-model=\"dpCtrlr.startEndpoint.date\" style=\"margin-top:5px;\"></edge-time-picker>\n" +
    "<input ng-if=\"dpCtrlr.isMobile\" type=\"date\" ng-disabled=\"dpCtrlr.minDateActive\" ng-model=\"dpCtrlr.startEndpoint.date\"\n" +
    "       ng-change=\"dpCtrlr.startDateChanged()\" class=\"form-control mobile\">\n" +
    "<input ng-if=\"dpCtrlr.isMobile && dpCtrlr.showTime\" type=\"time\" ng-disabled=\"dpCtrlr.minDateActive\" ng-model=\"dpCtrlr.startEndpoint.date\"\n" +
    "       ng-change=\"dpCtrlr.startDateChanged()\" class=\"form-control mobile\">\n" +
    "<div class=\"btn-group btn-group-sm\" style=\"margin:5px 0px 5px 0px;\">\n" +
    "    <button class=\"btn btn-sm btn-default\"\n" +
    "            ng-class=\"{'toggle-active':dpCtrlr.minDateActive}\"\n" +
    "            ng-click=\"dpCtrlr.toggleMinDate()\"><span translate>Min Date</span>\n" +
    "    </button>\n" +
    "</div>\n" +
    "<div class=\"btn-group btn-group-sm pull-right\" style=\"margin:5px 0px 5px 0px;\">\n" +
    "    <button class=\"btn btn-sm btn-default\" ng-click=\"dpCtrlr.applyStartDate()\"><span translate>Ok</span></button>\n" +
    "</div>\n" +
    "<div class=\"btn-group btn-group-sm pull-right\" style=\"margin:5px 5px 5px 0px;\">\n" +
    "    <button class=\"btn btn-sm btn-default\" ng-click=\"dpCtrlr.cancel()\"><span translate>Cancel</span></button>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/daterange/edgeDateRange.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/daterange/edgeDateRange.tpl.html",
    "<div style=\"display: inline-flex\">\n" +
    "    <div style=\"flex:1 0 auto\">\n" +
    "        <div class=\"input-group\"\n" +
    "             uib-popover-template=\"'edge/ui/form/daterange/date-range-start-popover.tpl.html'\"\n" +
    "             popover-placement=\"top-left auto\"\n" +
    "             popover-append-to-body='true'\n" +
    "             popover-is-open=\"dpCtrlr.startDatePopoverOpen\"\n" +
    "             popover-trigger=\"'none'\"\n" +
    "             ng-click=\"dpCtrlr.startDateFieldClicked()\"\n" +
    "             style=\"margin-right:-2px;cursor:pointer;\">\n" +
    "            <span class=\"input-group-addon\" style=\"width:21px\"><span class=\"icon icon_calendar_o\"\n" +
    "                                                                     aria-hidden=\"true\"></span></span>\n" +
    "            <div class=\"form-control\"\n" +
    "                 style=\"border-top-right-radius: 0px;border-bottom-right-radius: 0px;white-space: nowrap;width:auto\"><span\n" +
    "                    ng-bind-html=\"dpCtrlr.getStartDateDisplay()\"></span></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"flex:1 0 auto\">\n" +
    "        <div class=\"form-control\"\n" +
    "             style=\"border-top-left-radius: 0px;border-bottom-left-radius: 0px;white-space: nowrap;width:auto;cursor:pointer;\"\n" +
    "             uib-popover-template=\"'edge/ui/form/daterange/date-range-end-popover.tpl.html'\"\n" +
    "             popover-placement=\"top-left auto\"\n" +
    "             popover-append-to-body='true'\n" +
    "             popover-is-open=\"dpCtrlr.endDatePopoverOpen\"\n" +
    "             popover-trigger=\"'none'\"\n" +
    "             ng-click=\"dpCtrlr.endDateFieldClicked()\"><span ng-bind-html=\"dpCtrlr.getEndDateDisplay()\"></span></div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableColor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableColor.tpl.html",
    "<div>\n" +
    "    <edge-derivable-formatter config=\"config\" attribute-defs=\"attributeDefs\" type=\"2\" derived-only=\"derivedOnly\">\n" +
    "        <edge-color-formatter formatter=\"config.staticFormatterObj\" options=\"options\"></edge-color-formatter>\n" +
    "    </edge-derivable-formatter>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableDate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableDate.tpl.html",
    "<div>\n" +
    "    <edge-date-formatter formatter=\"config.staticFormatterObj\" options=\"options\" style=\"margin-top:10px;\"></edge-date-formatter>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableFont.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableFont.tpl.html",
    "<div>\n" +
    "    <edge-derivable-formatter config=\"config\" attribute-defs=\"attributeDefs\" type=\"1\" derived-only=\"derivedOnly\">\n" +
    "        <edge-font-formatter formatter=\"config.staticFormatterObj\" options=\"options\"></edge-font-formatter>\n" +
    "    </edge-derivable-formatter>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableFormatter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableFormatter.tpl.html",
    "<div>\n" +
    "    <div ng-if=\"derivedOnly != true\" style=\"width:150px;\">\n" +
    "        <select class=\"form-control\"\n" +
    "                ng-model=\"dfCtrlr.config.isDerived\"\n" +
    "                ng-options=\"o.value as o.label for o in dfCtrlr.deriveChoices\">\n" +
    "        </select>\n" +
    "    </div>\n" +
    "    <div>\n" +
    "        <div ng-if=\"derivedOnly != true\" style=\"height:10px;\"></div>\n" +
    "        <div ng-if=\"dfCtrlr.config.isDerived\">\n" +
    "            <edge-labeled-control validation=\"true\"\n" +
    "                                  required=\"true\"\n" +
    "                                  label-width=\"0\"\n" +
    "                                  show-feedback-icon=\"false\"\n" +
    "                                  style=\"margin: 0;\">\n" +
    "                <div style=\"display: flex\">\n" +
    "                    <div style=\"flex-grow:1\">\n" +
    "                        <input type=hidden\n" +
    "                               name=\"{{::dfCtrlr.uid}}_RuleSet\"\n" +
    "                               ng-model=\"dfCtrlr.config.ruleSetID\"\n" +
    "                               ng-required=\"true\">\n" +
    "                        <div class=\"input-group\">\n" +
    "                            <span class=\"input-group-addon\"\n" +
    "                                  style=\"border-right:0px;height:32px;\"><i class=\"icon icon_ruleset\"></i><span translate>&nbsp;Rule Set</span></span>\n" +
    "                            <ui-select ng-required=\"true\" append-to-body=\"true\"\n" +
    "                                       name=\"{{::dfCtrlr.uid}}_RuleSet\"\n" +
    "                                       ng-model=\"dfCtrlr.config.ruleSetID\"\n" +
    "                                       on-select=\"dfCtrlr.ruleSetSelected($item)\">\n" +
    "                                <ui-select-match theme=\"bootstrap\"\n" +
    "                                                 placeholder=\"{{'Select a Rule Set...' | translate}}\">\n" +
    "                                    {{$select.selected.name}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices\n" +
    "                                        repeat=\"item.id as item in dfCtrlr.ruleSets | filter:{name: $select.search} | orderBy:'name'\">\n" +
    "                                    <div>\n" +
    "                                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                        <code class=\"pull-right\"\n" +
    "                                              translate\n" +
    "                                              translate-n=\"item.variables.length\"\n" +
    "                                              translate-plural=\"{{$count}} Variables\">1 Variable</code>\n" +
    "                                    </div>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div>\n" +
    "                        <div class=\"btn-group\" style=\"width:77px;padding-left:5px;\">\n" +
    "                            <button class=\"btn btn-default icon icon_plus\" type=\"button\"\n" +
    "                                    ng-click=\"dfCtrlr.showCreateRuleSetDialog()\"></button>\n" +
    "                            <button class=\"btn btn-default icon icon_pencil\" type=\"button\"\n" +
    "                                    ng-click=\"dfCtrlr.showEditRuleSetDialog()\"\n" +
    "                                    ng-disabled=\"dfCtrlr.config.ruleSetID==null\"></button>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control validation=\"true\"\n" +
    "                                  required=\"true\"\n" +
    "                                  top-label=\"true\"\n" +
    "                                  style=\"margin:10px 0px 0px 0px;\"\n" +
    "                                  show-feedback-icon=\"false\"\n" +
    "                                  label=\"{{mapper.variable}}\"\n" +
    "                                  ng-repeat=\"mapper in dfCtrlr.config.variableMappings\">\n" +
    "                <edge-data-attribute-picker attribute-defs=\"attributeDefs\"\n" +
    "                                            required=\"true\"\n" +
    "                                            restrict-type=\"mapper.type\"\n" +
    "                                            name=\"dfCtrlr.uid + '_var_' + mapper.variable\"\n" +
    "                                            ng-model=\"mapper.field\"></edge-data-attribute-picker>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "        <div ng-if=\"!dfCtrlr.config.isDerived\" ng-transclude style=\"padding:0 5px;margin-bottom:-15px;\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableIcon.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableIcon.tpl.html",
    "<div>\n" +
    "    <edge-derivable-formatter config=\"config\" attribute-defs=\"attributeDefs\" type=\"0\" derived-only=\"derivedOnly\">\n" +
    "        <edge-icon-formatter formatter=\"config.staticFormatterObj\" options=\"options\"></edge-icon-formatter>\n" +
    "    </edge-derivable-formatter>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/derivedformatters/edgeDerivableNumber.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/derivedformatters/edgeDerivableNumber.tpl.html",
    "<div>\n" +
    "    <edge-number-formatter formatter=\"config.staticFormatterObj\" options=\"options\"></edge-number-formatter>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/icon/edgeIconPicker.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/icon/edgeIconPicker.tpl.html",
    "<div class=\"eeIconPickerButton\" ng-click=\"showDialog()\">\n" +
    "    <span ng-class=\"{'input-group':!useShort}\">\n" +
    "        <input type=\"hidden\" name=\"{{::name}}\" id=\"{{::name}}\" ng-model=\"selectedItem\" ng-required=\"::required\">\n" +
    "        <span ng-class=\"{'input-group-btn':!useShort}\" style=\"z-index:3\">\n" +
    "            <button type=\"button\" class=\"icon-preview-bkg eeIconPreview btn btn-default\" style=\"padding:0px\">\n" +
    "                <img ng-if=\"selectedItem !== undefined && selectedItem !== ''\" ng-src=\"{{getPreviewUrl()}}\"></img>\n" +
    "            </button>\n" +
    "        </span>\n" +
    "        <input ng-if=\"!useShort\" type=\"text\" class=\"form-control disabled\" placeholder=\"{{getIconName()}}\"/>\n" +
    "        <span ng-class=\"{'input-group-btn':!useShort}\">\n" +
    "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\" aria-haspopup=\"true\"\n" +
    "                    aria-expanded=\"false\">\n" +
    "                <span class=\"caret\"></span> <span class=\"sr-only\"></span>\n" +
    "            </button>\n" +
    "        </span>\n" +
    "    </span>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/ui/form/icon/edgeIconPickerList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/icon/edgeIconPickerList.tpl.html",
    "<div>\n" +
    "    <div class=\"row iconHeaderArea\">\n" +
    "        <div class=\"col-sm-6 eeColorPalette\">\n" +
    "            <div class=\"input-group\"> <span class=\"input-group-addon\"><i class=\"icon icon_folder\"></i></span>\n" +
    "                <ui-select ng-model=\"selectedCategory\" on-select=\"updateIcons($item, $model)\">\n" +
    "                    <ui-select-match placeholder=\"{{'Select a category ...'|translate}}\">{{$select.selected}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"category in categories | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"category | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span> <input\n" +
    "                    type=\"search\"\n" +
    "                    ng-model=\"q\"\n" +
    "                    class=\"form-control\"\n" +
    "                    placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"eeIcon\">\n" +
    "        <img ng-repeat=\"icon in getCategoryIcons() | filter:doFilter track by $index\"\n" +
    "             ng-class=\"{selected: isSelectedItem(icon.id)}\" ng-click=\"setSelectedItem(icon.id)\"\n" +
    "             ng-src=\"{{getPreviewUrl(icon.id)}}\" title=\"{{icon.id}}\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/labeledControl/edgeLabeledControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/labeledControl/edgeLabeledControl.tpl.html",
    "<div class=\"form-group edgeLabelControl\">\n" +
    "    <label ng-if=\"labelWidth > 0\" class=\"col-sm-{{::labelWidth}} control-label\" for=\"{{::elementName}}\"\n" +
    "           title=\"{{::helptext}}\">{{::label}}</label>\n" +
    "\n" +
    "    <div class=\"col-sm-{{::controlWidth}}\">\n" +
    "        <edge-transclude></edge-transclude>\n" +
    "        <span style=\"display: none;\" class=\"glyphicon glyphicon-ok form-control-feedback\"></span>\n" +
    "        <span style=\"display: none;\" class=\"glyphicon glyphicon-remove form-control-feedback\"></span>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/labeledControl/form_messages.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/labeledControl/form_messages.tpl.html",
    "<div ng-message=\"custom\"><span>{{customMessage}}</span></div>\n" +
    "<div ng-message=\"email\"><span translate>You have entered an incorrect email address.</span></div>\n" +
    "<div ng-message=\"number\"><span translate>This field must be a number.</span></div>\n" +
    "<div ng-message=\"minlength\"><span translate>The value for this field is too short</span>{{minLengthInfo}}.\n" +
    "</div>\n" +
    "<div ng-message=\"maxlength\"><span translate>The value for this field is too long</span>{{maxLengthInfo}}.\n" +
    "</div>\n" +
    "<div ng-message=\"required\"><span translate>This field is required and cannot be blank.</span></div>\n" +
    "<div ng-message=\"min\"><span translate translate-params-min=\"minInfo\">This number is less than the minimum allowed value of {{min}}.</span>\n" +
    "</div>\n" +
    "<div ng-message=\"max\"><span translate translate translate-params-max=\"maxInfo\">This number is more than the maximum allowed value of {{max}}.</span>\n" +
    "</div>\n" +
    "<div ng-message=\"confirmPassword\"><span translate>This entry must match the above password entry.</span></div>\n" +
    "<div ng-message=\"pattern\"><span translate>This field contains invalid characters/pattern.</span></div>\n" +
    "<div ng-message=\"isColor\"><span\n" +
    "        translate>Entry format must be either HEX, RGB/RGBA, HSL/HSLA, or HTML color name.</span></div>\n" +
    "<div ng-message=\"quotedVarObject\"><span translate>Quotes should only be used with raw node or raw secured variables.</span></div>\n" +
    "<div ng-message=\"rawVarsSafety\"><span translate>Quoted raw string variables with unbounded constraints are not supported if safe substitution is on.</span></div>\n" +
    "<div ng-if=\"! elementState.$valid\" ng-bind-html=\"helptext\"></div>\n" +
    "");
}]);

angular.module("edge/ui/form/number/edgeNumberSpinner.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/number/edgeNumberSpinner.tpl.html",
    "<div class=\"input-group edge-number-spinner\">\n" +
    "    <input type=\"number\"\n" +
    "           class=\"form-control\"\n" +
    "           name=\"{{::inputname}}\"\n" +
    "           id=\"{{::inputname}}\"\n" +
    "           string-to-number\n" +
    "           ng-required=\"isrequired\"\n" +
    "           ng-model=\"value\"\n" +
    "           ng-model-options=\"{updateOn: 'blur'}\"\n" +
    "           min=\"{{minimum}}\"\n" +
    "           max=\"{{maximum}}\"\n" +
    "           step=\"{{step}}\">\n" +
    "    <span ng-if=\"::unitMetric != undefined\" class=\"input-group-addon unitMetric\">{{::unitMetric}}</span>\n" +
    "    <span class=\"input-group-btn edge-spinners-group\" style=\"padding-left:1px\">\n" +
    "        <button type=\"button\"\n" +
    "                class=\"btn btn-default edge-spinner-btn-up\"\n" +
    "                ng-mousedown=\"spinnerCtrlr.stepUp()\"\n" +
    "                style=\"border-top-right-radius: 4px\">\n" +
    "            <div class=\"edge-caret-up\"></div>\n" +
    "        </button>\n" +
    "         <button type=\"button\" class=\"btn btn-default edge-spinner-btn-down\" ng-mousedown=\"spinnerCtrlr.stepDown()\">\n" +
    "            <div class=\"edge-caret-down\"></div>\n" +
    "         </button>\n" +
    "    </span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/AttributeDefList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/AttributeDefList.tpl.html",
    "<input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "       ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "<ui-select ng-model=\"propertyValue.value\" theme=\"bootstrap\">\n" +
    "    <ui-select-match allow-clear=\"{{::propertyDef.required !== true}}\"\n" +
    "                     placeholder=\"{{::'Choose an attribute...'|translate}}\">{{$select.selected.label}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices repeat=\"item.value as item in items | filter: {label: $select.search}\">\n" +
    "        <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "        <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Boolean.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Boolean.tpl.html",
    "<input type=\"checkbox\" edge-boolean-switch name=\"{{::propertyDef.name}}\"\n" +
    "       ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\"\n" +
    "       data-on-text=\"{{::propertyDef.constraints.onText}}\" data-off-text=\"{{::propertyDef.constraints.offText}}\">\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/CodeMirror.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/CodeMirror.tpl.html",
    "<textarea class=\"form-control\" edge-codemirror id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\"\n" +
    "          ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\"\n" +
    "          options=\"{{::propertyDef.constraints.options}}\">\n" +
    "</textarea>\n" +
    "\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Color.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Color.tpl.html",
    "<edge-classname-color-picker-button ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\" allow-transparent=\"{{allowTransparent}}\">\n" +
    "</edge-classname-color-picker-button>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Combo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Combo.tpl.html",
    "<div ng-controller=\"UISelectHelperController as uiselectCtrl\">\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "           ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <ui-select ng-model=\"propertyValue.value\">\n" +
    "        <ui-select-match theme=\"bootstrap\" allow-clear=\"{{::propertyDef.required !== true}}\"\n" +
    "                         placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\">\n" +
    "            <span  ng-bind-html=\"$select.selected.label\"></span>\n" +
    "        </ui-select-match>\n" +
    "        <ui-select-choices\n" +
    "                   repeat=\"item.value as item in (uiselectCtrl.items | filter: {label: $select.search})\">\n" +
    "            <small ng-if=\"::propertyDef.constraints.showType == true\" class=\"pull-right\" ng-bind-html=\"item.type\"></small>\n" +
    "            <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/CoupledOptionalGroup.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/CoupledOptionalGroup.tpl.html",
    "<div class=\"row\">\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\" ng-required=\"::propertyDef.required\"><!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <div class=\"col-sm-2\">\n" +
    "        <input type=\"checkbox\" edge-boolean-switch name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.on\" data-on-text=\"{{'Yes'|translate}}\" data-off-text=\"{{'No'|translate}}\">\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-10\" ng-show=\"propertyValue.on\">\n" +
    "        <ui-select ng-model=\"propertyValue.value\">\n" +
    "        <ui-select-match theme=\"bootstrap\" allow-clear=\"{{::propertyDef.required !== true}}\" placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\">{{$select.selected[propertyDef.constraints.labelField || 'label']}}</ui-select-match>\n" +
    "        <ui-select-choices repeat=\"item[propertyDef.constraints.valueField || 'value'] as item in (items | filter: $select.search)\">\n" +
    "        <span ng-bind-html=\"item[propertyDef.constraints.labelField || 'label'] | highlight: $select.search\"></span>\n" +
    "        <small ng-if=\"::propertyDef.constraints.showType == true\" class=\"pull-right\" ng-bind-html=\"item[propertyDef.constraints.typeField || 'type']\"></small>\n" +
    "        </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Credentials.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Credentials.tpl.html",
    "<div ng-controller=\"CredentialsController as ctrl\">\n" +
    "    <div class=\"col-sm-3\">\n" +
    "        <div class=\"btn-group btn-group-justified type-selector\">\n" +
    "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\" style=\"width:100%\">{{ctrl.toggleGroups[ctrl.index]}} &nbsp;<span class=\"caret\" style=\"margin-left: 5px;\"></span></button>\n" +
    "            <ul class=\"dropdown-menu\" role=\"menu\">\n" +
    "                <li ng-repeat=\"group in ctrl.toggleGroups\" ng-click=\"ctrl.index=$index\"><a href=\"\">{{group}}</a></li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-9\">\n" +
    "        <edge-credential-set ng-if=\"ctrl.index === 0\" ng-model=\"propertyValue.value\" constraints=\"propertyDef.constraints\"></edge-credential-set>\n" +
    "        <div ng-if=\"ctrl.index === 1\" class=\"input-group\">\n" +
    "            <ui-select ng-model=\"propertyValue.value\" on-select=\"ctrl.selectParam($item)\">\n" +
    "                <ui-select-match theme=\"bootstrap\">{{$select.selected.securityParameterName}}</ui-select-match>\n" +
    "                <ui-select-choices repeat=\"item in ctrl.credentialParams  | filter:{securityParameterName: $select.search} | orderBy: 'securityParameterName'\">\n" +
    "                    <span ng-bind-html=\"item.securityParameterName | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "            <div class=\"input-group-btn\">\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"ctrl.showEditSecurityParamDialog(true)\"><i class=\"icon icon_plus\"></i></button>\n" +
    "                <button class=\"btn btn-default\" type=\"button\" ng-click=\"ctrl.showEditSecurityParamDialog(false)\" ng-disabled=\"! propertyValue.value.securityParameterName\"><i class=\"icon icon_pencil\"></i></button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <!-- required or enclosing div is 0px high (because the col-* classes float everything) and it screws up layout -->\n" +
    "    <div style='clear: both'></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/CustomCombo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/CustomCombo.tpl.html",
    "<div ng-controller=\"CustomComboController as customComboCtrl\">\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue[customComboCtrl.propertyValueField]\"\n" +
    "           ng-required=\"::propertyDef.required\">\n" +
    "    <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <ui-select ng-model=\"propertyValue[customComboCtrl.propertyValueField]\" on-select=\"customComboCtrl.doSelect($item,$model,$select)\">\n" +
    "        <ui-select-match theme=\"bootstrap\" allow-clear=\"{{::propertyDef.required !== true}}\"\n" +
    "                         placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\">\n" +
    "            {{$select.selected[customComboCtrl.labelField]}}\n" +
    "        </ui-select-match>\n" +
    "        <ui-select-choices\n" +
    "                repeat=\"item[customComboCtrl.valueField] as item in (items | filter: $select.search) track by item[customComboCtrl.valueField]\"\n" +
    "                refresh=\"customComboCtrl.customSelect($select)\" refresh-delay=\"0\">\n" +
    "            <span ng-bind-html=\"item[customComboCtrl.labelField] | highlight: $select.search\"></span>\n" +
    "            <small ng-if=\"::propertyDef.constraints.showType == true\" class=\"pull-right\"\n" +
    "                   ng-bind-html=\"item[customComboCtrl.typeField]\"></small>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/DerivableColor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/DerivableColor.tpl.html",
    "<edge-derivable-color config=\"propertyValue.value\" options=\"::options\" attribute-defs=\"::attributeDefs\"></edge-derivable-color>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/DerivableFont.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/DerivableFont.tpl.html",
    "<edge-derivable-font config=\"propertyValue.value\" options=\"::options\" attribute-defs=\"::attributeDefs\"></edge-derivable-font>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/DerivableIcon.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/DerivableIcon.tpl.html",
    "<edge-derivable-icon config=\"propertyValue.value\" options=\"::options\" attribute-defs=\"::attributeDefs\"></edge-derivable-icon>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/DerivableNumber.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/DerivableNumber.tpl.html",
    "<edge-derivable-number config=\"propertyValue.value\" options=\"::options\" attribute-defs=\"::attributeDefs\"></edge-derivable-number>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/DiscreteNumber.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/DiscreteNumber.tpl.html",
    "<edge-number-spinner inputname=\"{{::propertyDef.name}}\" isrequired=\"::propertyDef.required\"\n" +
    "                     ng-model=\"propertyValue.value\" regex=\"::propertyDef.regex\"\n" +
    "                     step=\"::propertyDef.constraints.step\" minimum=\"::propertyDef.constraints.minimum\"\n" +
    "                     maximum=\"::propertyDef.constraints.maximum\">\n" +
    "</edge-number-spinner>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Dropdown.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Dropdown.tpl.html",
    "<select class=\"form-control\" id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\"\n" +
    "        placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\" ng-required=\"::propertyDef.required\"\n" +
    "        ng-model=\"propertyValue.value\" ng-size=\"::size || 4\">\n" +
    "    <option ng-repeat=\"item in items\"\n" +
    "            value=\"{{item[propertyDef.constraints.valueField || 'value']}}\">\n" +
    "        {{item[propertyDef.constraints.labelField || 'label']}}\n" +
    "    </option>\n" +
    "</select>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/File.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/File.tpl.html",
    "<div class=\"input-group\" ng-controller=\"FileController as fileCtrl\">\n" +
    "    <input type=\"text\" class=\"form-control\" name=\"{{::propertyDef.name}}\" readonly ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\" placeholder=\"{{::propertyDef.constraints.placeholder}}\" title=\" \">\n" +
    "    <input id=\"{{fileCtrl.fileInputId}}\" type=\"file\" class=\"form-control\" style=\"display: none;\" accept=\"{{::propertyDef.constraints.accept}}\">\n" +
    "    <span class=\"input-group-btn\">\n" +
    "        <button class=\"btn btn-default\" type=\"button\" ng-click=\"fileCtrl.openFilePicker()\"><i class=\"icon icon_plus\"></i>\n" +
    "        </button>\n" +
    "    </span>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/FontStyle.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/FontStyle.tpl.html",
    "<div ng-controller=\"FontStyleController as fontStyleCtrl\">\n" +
    "    <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "           ng-required=\"::propertyDef.required\">\n" +
    "\n" +
    "    <ui-select id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\" ng-required=\"::propertyDef.required\"\n" +
    "               ng-model=\"propertyValue.value\">\n" +
    "        <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "        <ui-select-choices\n" +
    "                repeat=\"textStyle.className as textStyle in fontStyleCtrl.getTextStyles() | filter: $select.search\">\n" +
    "            <span ng-bind-html=\"textStyle.name | highlight: $select.search\"></span>\n" +
    "            <span class=\"pull-right {{textStyle.className}}\">Sample</span>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Icon.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Icon.tpl.html",
    "<edge-icon-picker ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\"\n" +
    "                  default-category=\"{{::propertyDef.constraints.defaultCategory}}\" color=\"color.value\" icon=\"icon\">\n" +
    "</edge-icon-picker>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/KeyValuePair.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/KeyValuePair.tpl.html",
    "<edge-key-value-pair ng-model=\"propertyValue.value\" ng-attr-name=\"{{::propertyDef.name}}\"></edge-key-value-pair>");
}]);

angular.module("edge/ui/form/propertycontrol/controls/List.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/List.tpl.html",
    "<select class=\"form-control\" id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\"\n" +
    "        placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\" ng-required=\"::propertyDef.required\"\n" +
    "        ng-model=\"propertyValue.value\">\n" +
    "    <option ng-repeat=\"item in items\"\n" +
    "            value=\"{{item[propertyDef.constraints.valueField || 'value']}}\">\n" +
    "        {{item[propertyDef.constraints.labelField || 'label']}}\n" +
    "    </option>\n" +
    "</select>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/MultiCombo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/MultiCombo.tpl.html",
    "<ui-select multiple ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\">\n" +
    "    <ui-select-match theme=\"bootstrap\" allow-clear=\"{{::propertyDef.required !== true}}\"\n" +
    "                     placeholder=\"{{::propertyDef.constraints.placeholder || ''}}\">\n" +
    "        {{$item[propertyDef.constraints.labelField || 'label']}}\n" +
    "    </ui-select-match>\n" +
    "    <ui-select-choices\n" +
    "            repeat=\"item[propertyDef.constraints.valueField || 'value'] as item in items | filter: $select.search\">\n" +
    "        <div ng-bind-html=\"item[propertyDef.constraints.labelField || 'label'] | highlight: $select.search\"></div>\n" +
    "    </ui-select-choices>\n" +
    "</ui-select>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Multiline.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Multiline.tpl.html",
    "<textarea class=\"form-control\" ng-style=\"::{'height': propertyDef.constraints.height}\" name=\"{{::propertyDef.name}}\" ng-trim=\"true\" ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\"\n" +
    "       ng-pattern=\"::propertyDef.regex\">\n" +
    "</textarea>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/Number.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/Number.tpl.html",
    "<input class=\"form-control\" type=\"number\" id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\"\n" +
    "       placeholder=\"{{::propertyDef.constraints.placeholder}}\"\n" +
    "       ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\" ng-pattern=\"::propertyDef.regex\"\n" +
    "       step=\"{{::propertyDef.constraints.step}}\" min=\"{{::propertyDef.constraints.minimum}}\"\n" +
    "       max=\"{{::propertyDef.constraints.maximum}}\">\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/ObjStringList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/ObjStringList.tpl.html",
    "<div ng-controller=\"ObjStringListController as sListCtrl\">\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-body style=\"flex: 1 0 auto;\" ng-style=\"{'min-height': sListCtrl.minimumHeight}\">\n" +
    "            <ul class=\"list-group eeList stringList\">\n" +
    "                <li class=\"list-group-item\" style=\"padding: 8px 30px 8px 20px;\"\n" +
    "                    ng-repeat=\"item in panelScope.sListCtrl.stringList.values track by $index\"\n" +
    "                    ng-class=\"{even: $even, odd: $odd, selected: panelScope.sListCtrl.isSelectedItem($index)}\"\n" +
    "                    ng-click=\"panelScope.sListCtrl.setSelectedItem($index)\">\n" +
    "                        <edge-labeled-control label-width=\"0\" validation=\"true\">\n" +
    "                            <input class=\"form-control\" type=\"{{::panelScope.propertyDef.constraints.hint || 'text'}}\"\n" +
    "                                name=\"{{panelScope.propertyDef.name+$index}}\"\n" +
    "                                ng-trim=\"true\" ng-required=\"true\"\n" +
    "                                ng-model=\"panelScope.sListCtrl.stringList.values[$index]\"\n" +
    "                                ng-pattern=\"::panelScope.propertyDef.regex\" edge-focus-on>\n" +
    "                        </edge-labeled-control>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </edge-panel-body>\n" +
    "        <edge-panel-footer>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"panelScope.sListCtrl.addRow()\"></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"panelScope.sListCtrl.removeRow()\"\n" +
    "                    ng-disabled=\"panelScope.sListCtrl.selectedIndex===null\"></button>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/ProxyAccessControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/ProxyAccessControl.tpl.html",
    "<edge-proxy-access-control ng-model=\"propertyValue.value\" ng-attr-name=\"{{::propertyDef.name}}\"></edge-proxy-access-control>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/ProxyAppVersionList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/ProxyAppVersionList.tpl.html",
    "<edge-proxy-app-version-chooser property-value=\"propertyValue\" property-def=\"::propertyDef\"></edge-proxy-app-version-chooser>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/ProxyCredentialTypeList.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/ProxyCredentialTypeList.tpl.html",
    "<edge-sso-handler-chooser property-value=\"propertyValue\" property-def=\"::propertyDef\"></edge-sso-handler-chooser>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/String.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/String.tpl.html",
    "<input class=\"form-control\" type=\"{{::propertyDef.constraints.hint || 'text'}}\" id=\"{{::propertyDef.name}}\"\n" +
    "       name=\"{{::propertyDef.name}}\" ng-trim=\"false\" ng-required=\"::propertyDef.required\" ng-model=\"propertyValue.value\"\n" +
    "       ng-pattern=\"::propertyDef.regex\" edge-focus-on>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/TextAlignment.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/TextAlignment.tpl.html",
    "<div ng-controller=\"TextAlignmentController as textAlignmentCtrl\">\n" +
    "    <!-- dummy field to force form validation on required, since ui-select currently not supporting it -->\n" +
    "    <input type=hidden name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\"\n" +
    "           ng-required=\"::propertyDef.required\">\n" +
    "\n" +
    "    <ui-select id=\"{{::propertyDef.name}}\" name=\"{{::propertyDef.name}}\" ng-required=\"::propertyDef.required\"\n" +
    "               ng-model=\"propertyValue.value\">\n" +
    "        <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "        <ui-select-choices\n" +
    "                repeat=\"textAlignment.className as textAlignment in textAlignmentCtrl.getTextAlignments() | filter: $select.search\">\n" +
    "            <span ng-bind-html=\"textAlignment.name | highlight: $select.search\"></span>\n" +
    "            <span class=\"pull-right {{textAlignment.className}}\">Sample</span>\n" +
    "        </ui-select-choices>\n" +
    "    </ui-select>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/controls/TextDisplay.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/controls/TextDisplay.tpl.html",
    "<input class=\"form-control\" type=\"text\" disabled name=\"{{::propertyDef.name}}\" ng-model=\"propertyValue.value\">\n" +
    "");
}]);

angular.module("edge/ui/form/propertycontrol/edgePropertyControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/propertycontrol/edgePropertyControl.tpl.html",
    "<div class=\"property-control\">\n" +
    "    <edge-labeled-control ng-if=\"::propertyDef.isParseable\"\n" +
    "                          label-width=\"{{::labelWidth}}\"\n" +
    "                          label=\"{{::propertyDef.displayName}}\" validation=\"::validation\"\n" +
    "                          helptext=\"{{::propertyDef.helpText}}\" element-name=\"{{::propertyDef.name}}\"\n" +
    "                          required=\"propertyDef.required\">\n" +
    "        <div style=\"display: flex;flex-wrap: wrap;\">\n" +
    "            <div style=\"width:100px;margin-right:8px;\">\n" +
    "                <select class=\"form-control\" ng-model=\"propertyValue.boundToParameter\"\n" +
    "                        ng-options=\"PropertyControlCtrlr.boolToStr(item) for item in [false, true]\">\n" +
    "                </select>\n" +
    "            </div>\n" +
    "            <div style=\"flex:1; min-width:200px;\" ng-if=\"!propertyValue.boundToParameter\">\n" +
    "                <div ng-include=\"getContentUrl(propertyDef, propertyValue)\"></div>\n" +
    "            </div>\n" +
    "            <div style=\"flex:1; min-width:200px;\" ng-if=\"propertyValue.boundToParameter\">\n" +
    "                <textarea edge-codemirror name=\"{{::propertyDef.name}}\" ng-required=\"{{::propertyDef.required}}\"\n" +
    "                    sec-params=\"vm.secParams\" editor=\"PropertyControlCtrlr.paramEditor\" rows=\"3\"\n" +
    "                    ng-model=\"propertyValue.value\" producers=\"vm.producers\" vm=\"vm\"\n" +
    "                    options=\"{oneLiner:true,backdrop:'text/text',mode:'edgeParsed',extraKeys:{'Ctrl-Space': 'autocomplete'}}\">\n" +
    "                </textarea>\n" +
    "                <div class=\"dropup\">\n" +
    "                    <button id=\"insertBtn\"\n" +
    "                            class=\"btn btn-default dropup dropdown-toggle\"\n" +
    "                            data-toggle=\"dropdown\"\n" +
    "                            aria-haspopup=\"true\"\n" +
    "                            aria-expanded=\"false\">\n" +
    "                        <span translate>Insert</span>&nbsp;<span class=\"caret\"></span>\n" +
    "                    </button>\n" +
    "                    <ul class=\"dropdown-menu\">\n" +
    "                        <li ng-click=\"PropertyControlCtrlr.insertParameter()\">\n" +
    "                            <a><span translate>Node Variable</span></a></li>\n" +
    "                        <li ng-click=\"PropertyControlCtrlr.insertSecParameter()\">\n" +
    "                            <a><span translate>Secured Variable</span></a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-labeled-control>\n" +
    "    <div ng-include=\"getContentUrl(propertyDef, propertyValue)\"\n" +
    "         ng-if=\"::!propertyDef.isDataDriven && !propertyDef.isParameterizable && !propertyDef.isParseable && ! labelWidth\"></div>\n" +
    "    <edge-labeled-control ng-if=\"::!propertyDef.isDataDriven && !propertyDef.isParameterizable && !propertyDef.isParseable && labelWidth\"\n" +
    "                          label-width=\"{{::labelWidth}}\"\n" +
    "                          label=\"{{::propertyDef.displayName}}\" validation=\"::validation\" show-feedback-icon=\"::showFeedbackIcon\"\n" +
    "                          helptext=\"{{::propertyDef.helpText}}\" element-name=\"{{::propertyDef.name}}\">\n" +
    "        <div ng-include=\"getContentUrl(propertyDef, propertyValue)\"></div>\n" +
    "    </edge-labeled-control>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/ui/form/rulesetcontrol/edgeRuleSetControl.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/rulesetcontrol/edgeRuleSetControl.tpl.html",
    "<div>\n" +
    "    <edge-transclude></edge-transclude>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/slider/edgeSlider.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/slider/edgeSlider.tpl.html",
    "<div class=\"slider well form-control\">\n" +
    "    <div class=\"slider slider-horizontal\">\n" +
    "        <div class=\"slider-track\">\n" +
    "            <div class=\"slider-selection\"></div>\n" +
    "            <div class=\"slider-handle min-slider-handle\"></div>\n" +
    "            <div class=\"slider-handle max-slider-handle\"></div>\n" +
    "            <div class=\"slider-min-value\">{{minimum}}</div>\n" +
    "            <div class=\"slider-max-value\">{{maximum}}</div>\n" +
    "            <div class=\"slider-value\"></div>\n" +
    "        </div>\n" +
    "        <div id=\"tooltip\" class=\"tooltip\">\n" +
    "            <div class=\"tooltip-arrow\"></div>\n" +
    "            <div class=\"tooltip-inner\"></div>\n" +
    "        </div>\n" +
    "        <div id=\"tooltip_min\" class=\"tooltip\">\n" +
    "            <div class=\"tooltip-arrow\"></div>\n" +
    "            <div class=\"tooltip-inner\"></div>\n" +
    "        </div>\n" +
    "        <div id=\"tooltip_max\" class=\"tooltip\">\n" +
    "            <div class=\"tooltip-arrow\"></div>\n" +
    "            <div class=\"tooltip-inner\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <input type=\"text\">\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/ui/form/splitbutton/edgeSplitButton.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/splitbutton/edgeSplitButton.tpl.html",
    "<div class=\"btn-group\">\n" +
    "    <button id=\"doSelection\" type=\"button\" class=\"btn btn-default\">\n" +
    "        {{selectedItem[labelField]}}\n" +
    "    </button>\n" +
    "    <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\">\n" +
    "        <i class=\"icon icon_chevron_down split-down\"></i>\n" +
    "    </button>\n" +
    "    <ul class=\"dropdown-menu\" role=\"menu\">\n" +
    "        <li id=\"menuItem\" style=\"cursor: pointer;\">\n" +
    "            <a>\n" +
    "                <edge-transclude/>\n" +
    "            </a>\n" +
    "        </li>\n" +
    "    </ul>\n" +
    "</div>");
}]);

angular.module("edge/ui/form/time/edgeTimePicker.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/ui/form/time/edgeTimePicker.tpl.html",
    "<table class=\"edge-time-picker\" style=\"table-layout:fixed;\">\n" +
    "    <tr>\n" +
    "        <td style=\"padding-right:5px\">\n" +
    "            <edge-number-spinner ng-model=\"tpCtrlr.hours\"\n" +
    "                                 ng-change=\"tpCtrlr.handleControlsChange()\"\n" +
    "                                 time-formatter=\"12\"\n" +
    "                                 title=\"{{'hour' | translate}}\"\n" +
    "                                 class=\"edge-number-spinner-2-digit\"\n" +
    "                                 minimum=\"1\"\n" +
    "                                 maximum=\"12\"></edge-number-spinner>\n" +
    "\n" +
    "        </td>\n" +
    "        <td style=\"padding-right:5px\">:</td>\n" +
    "        <td style=\"padding-right:5px\">\n" +
    "            <edge-number-spinner ng-model=\"tpCtrlr.mins\"\n" +
    "                                 ng-change=\"tpCtrlr.handleControlsChange()\"\n" +
    "                                 time-formatter=\"60\"\n" +
    "                                 title=\"{{'minutes' | translate}}\"\n" +
    "                                 class=\"edge-number-spinner-2-digit\"\n" +
    "                                 minimum=\"0\"\n" +
    "                                 maximum=\"59\"\n" +
    "                                 step=\"5\"></edge-number-spinner>\n" +
    "        </td>\n" +
    "        <td style=\"padding-right:5px\">:</td>\n" +
    "        <td style=\"padding-right:5px\">\n" +
    "            <edge-number-spinner ng-model=\"tpCtrlr.secs\"\n" +
    "                                 ng-change=\"tpCtrlr.handleControlsChange()\"\n" +
    "                                 time-formatter=\"60\"\n" +
    "                                 title=\"{{'seconds' | translate}}\"\n" +
    "                                 class=\"edge-number-spinner-2-digit\"\n" +
    "                                 minimum=\"0\"\n" +
    "                                 maximum=\"59\"\n" +
    "                                 step=\"15\"></edge-number-spinner>\n" +
    "        </td>\n" +
    "        <td>\n" +
    "            <select ng-model=\"tpCtrlr.period\" class=\"form-control\" ng-change=\"tpCtrlr.handleControlsChange()\">\n" +
    "                <option>AM</option>\n" +
    "                <option>PM</option>\n" +
    "            </select>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>");
}]);
