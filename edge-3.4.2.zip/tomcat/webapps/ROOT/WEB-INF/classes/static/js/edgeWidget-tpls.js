angular.module('edgeWidget.TPLS', ['edge/widget/chart/config/edgeChartSeriesDef.tpl.html', 'edge/widget/chart/config/edgeChartWidgetConfigWizard.tpl.html', 'edge/widget/chart/config/edit-renderer-dialog.tpl.html', 'edge/widget/flow/config/edgeFlowWidgetConfigWizard.tpl.html', 'edge/widget/flow/edgeFlowWidget.tpl.html', 'edge/widget/flow/edgeFlowWidgetFooter.tpl.html', 'edge/widget/flow/sankey/edgeSankey.tpl.html', 'edge/widget/gauge/config/arc-preview.tpl.html', 'edge/widget/gauge/config/edgeGaugeThresholdConfig.tpl.html', 'edge/widget/gauge/config/edgeGaugeThresholdDef.tpl.html', 'edge/widget/gauge/config/edgeGaugeWidgetConfigWizard.tpl.html', 'edge/widget/gauge/config/linear-preview.tpl.html', 'edge/widget/gauge/edgeGaugeWidget.tpl.html', 'edge/widget/heatmap/config/edgeHeatMapWidgetConfigWizard.tpl.html', 'edge/widget/heatmap/edgeHeatMapWidget.tpl.html', 'edge/widget/list/config/edgeListAttributeDef.tpl.html', 'edge/widget/list/config/edgeListSortAttributeDef.tpl.html', 'edge/widget/list/config/edgeListWidgetConfigWizard.tpl.html', 'edge/widget/list/edgeListCell.tpl.html', 'edge/widget/list/edgeListWidget.tpl.html', 'edge/widget/map/config/edgeMapWidgetConfigWizard.tpl.html', 'edge/widget/piechart/config/edgePieChartAttributeDef.tpl.html', 'edge/widget/piechart/config/edgePieChartWidgetConfigWizard.tpl.html', 'edge/widget/piechart/config/edit-renderer-dialog.tpl.html', 'edge/widget/proxy/config/edgeProxyConfigWizard.tpl.html', 'edge/widget/proxy/edgeProxyWidget.tpl.html', 'edge/widget/regionmap/config/edgeRegionMapWidgetConfigWizard.tpl.html', 'edge/widget/sm/config/edgeSmAttributeDef.tpl.html', 'edge/widget/sm/config/edgeSMWidgetConfigWizard.tpl.html', 'edge/widget/sm/edgeSMWidget.tpl.html', 'edge/widget/table/config/edgeTableColumnCellConfig.tpl.html', 'edge/widget/table/config/edgeTableColumnCellDef.tpl.html', 'edge/widget/table/config/edgeTableColumnConfig.tpl.html', 'edge/widget/table/config/edgeTableColumnDef.tpl.html', 'edge/widget/table/config/edgeTableConfigWizard.tpl.html', 'edge/widget/table/edgeTableWidget.tpl.html', 'edge/widget/table/edgeTableWidgetFooter.tpl.html', 'edge/widget/table/templates/cellTemplate.tpl.html', 'edge/widget/table/templates/cellWordWrapTemplate.tpl.html', 'edge/widget/table/templates/columnHeaderTemplate.tpl.html', 'edge/widget/table/templates/columnHidingHeaderBtn.tpl.html', 'edge/widget/table/templates/rowBkgColorTemplate.tpl.html', 'edge/widget/table/templates/rowBkgColorTemplateCellShadding.tpl.html', 'edge/widget/table/templates/rowBkgColorTemplateCellShaddingWithTaphold.tpl.html', 'edge/widget/table/templates/rowBkgColorTemplateWithTaphold.tpl.html', 'edge/widget/table/templates/rowTemplate.tpl.html', 'edge/widget/table/templates/rowTemplateCellShadding.tpl.html', 'edge/widget/table/templates/rowTemplateCellShaddingWithTaphold.tpl.html', 'edge/widget/table/templates/rowTemplateWithTaphold.tpl.html', 'edge/widget/template/config/edgeTemplateWidgetConfigWizard.tpl.html', 'edge/widget/template/config/show-attrs-dialog.tpl.html', 'edge/widget/template/config/show-events-dialog.tpl.html', 'edge/widget/template/config/show-load-resources-dialog.tpl.html', 'edge/widget/template/config/show-rows-dialog.tpl.html', 'edge/widget/template/edgeTemplateWidget.tpl.html', 'edge/widget/template/less-css-compile-error-dialog.tpl.html', 'edge/widget/text/config/edgeTextWidgetConfigWizard.tpl.html', 'edge/widget/text/edgeTextWidget.tpl.html', 'edge/widget/timeline/config/edgeTimelineWidgetConfigWizard.tpl.html', 'edge/widget/timeline/edgeTimelineWidget.tpl.html', 'edge/widget/timeline/edgeTimelineWidgetFooter.tpl.html', 'edge/widget/timeline/impl/edgeTimelineItem.tpl.html', 'edge/widget/topo/config/edgeNodeRendererDefInfo.tpl.html', 'edge/widget/topo/config/edgeTopoWidgetConfigWizard.tpl.html', 'edge/widget/topo/config/edgeTopoWidgetNodeRendererEditor.tpl.html', 'edge/widget/topo/edgeTopoWidget.tpl.html', 'edge/widget/topo/perform-layout-dialog.tpl.html', 'edge/widget/treemap/config/edgeTreeMapWidgetConfigWizard.tpl.html', 'edge/widget/treemap/edgeTreeMapWidget.tpl.html', 'edge/widget/treemap/edgeTreeMapWidgetFooter.tpl.html']);

angular.module("edge/widget/chart/config/edgeChartSeriesDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/chart/config/edgeChartSeriesDef.tpl.html",
    "<div class=\"row with-padding\">\n" +
    "    <div class=\"col-sm-3\">\n" +
    "        <select class=\"form-control\" ng-model=\"chartSeriesDef.column.value\">\n" +
    "            <option ng-repeat=\"yAxisAttribute in yAxisAttributes\" ng-value=\"yAxisAttribute.value\">{{yAxisAttribute.label}}</option>\n" +
    "        </select>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-3\">\n" +
    "        <input class=\"form-control\" ng-model=\"chartSeriesDef.label.value\" placeholder=\"{{chartSeriesDef.column.value}}\"/>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-3\">\n" +
    "        <select ng-if=\"baseChartType !== 'pie'\" class=\"form-control\" ng-model=\"chartSeriesDef.type.value\">\n" +
    "            <option ng-repeat=\"chartType in chartTypesList\" ng-value=\"chartType.value\">{{chartType.label}}</option>\n" +
    "        </select>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-3\">\n" +
    "        <div class=\"eeColorPickerButton\" ng-click=\"showEditRendererTemplate()\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-btn\" ng-switch=\"chartSeriesDef.meta.value.fill+chartSeriesDef.fill.value\">\n" +
    "                    <span ng-switch-when=\"truepattern\">\n" +
    "                        <button type=\"button\" class=\"eeIconPreview btn btn-default\" style=\"padding:0px\">\n" +
    "                            <img ng-if=\"chartSeriesDef.pattern.value\" ng-src=\"{{getPatternUrl()}}\">\n" +
    "                        </button>\n" +
    "                    </span>\n" +
    "                    <span ng-switch-default>\n" +
    "                        <button type=\"button\" class=\"eeColorPatch btn btn-default\">\n" +
    "                            <div ng-style=\"{'background-color': getHex()}\"></div>\n" +
    "                        </button>\n" +
    "                    </span>\n" +
    "                </span>\n" +
    "                <input ng-if=\"chartSeriesDef.meta.value.fill  && !chartSeriesDef.meta.value.stroke\"\n" +
    "                    type=\"text\" class=\"form-control disabled\" placeholder=\"{{chartSeriesDef.fill.value}}\"/>\n" +
    "                <input ng-if=\"chartSeriesDef.meta.value.fill  && chartSeriesDef.meta.value.stroke\"\n" +
    "                    type=\"text\" class=\"form-control disabled\" placeholder=\"{{chartSeriesDef.fill.value}}\"/>\n" +
    "                <input ng-if=\"!chartSeriesDef.meta.value.fill && chartSeriesDef.meta.value.stroke\"\n" +
    "                    type=\"text\" class=\"form-control disabled\" placeholder=\"{{chartSeriesDef.strokeStyle.value}}\"/>\n" +
    "                <input ng-if=\"!chartSeriesDef.meta.value.fill && !chartSeriesDef.meta.value.stroke\"\n" +
    "                    type=\"text\" class=\"form-control disabled\" placeholder=\"{{chartSeriesDef.marker.value}}\"/>\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                    <button type=\"button\" class=\"form-control btn btn-default icon icon_pencil\"></button>\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/chart/config/edgeChartWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/chart/config/edgeChartWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"ChartWidgetWizardController as ChartConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!ChartConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'><span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"!ChartConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"ChartConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ChartConfigCtrlr.handleCancel\" ng-if=\"ChartConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Chart'|translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Chart Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('type')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('type')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showLegend')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('showLegend')\"></edge-property-control>\n" +
    "                <edge-property-control ng-if=\"ChartConfigCtrlr.showPolar\" class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('polar')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('polar')\"></edge-property-control>\n" +
    "\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Dimensions'|translate}}\" index=\"1\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "            <h4 style=\"clear: both\"><span translate>Dimensions</span>  ({{ChartConfigCtrlr.getAxisLabel().primary}} <span translate>Axis</span>)</h4>\n" +
    "            <hr>\n" +
    "            <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('type').value !== 'pie'\">\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisType')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisType')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showPrimaryAxisLabels')\"\n" +
    "                                       property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('showPrimaryAxisLabels')\"></edge-property-control>\n" +
    "            </div>\n" +
    "            <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                   property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisAttribute')\"\n" +
    "                                   property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisAttribute')\"\n" +
    "                                   items=\"ChartConfigCtrlr.xAxisAttributes\"></edge-property-control>\n" +
    "            <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                   property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisTitle')\"\n" +
    "                                   property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisTitle')\"></edge-property-control>\n" +
    "            <!--\n" +
    "            <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('type').value !== 'pie'\">\n" +
    "               <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                      ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisType').value === 'datetime'\"\n" +
    "                                      property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisTimeUnit')\"\n" +
    "                                      property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisTimeUnit')\"></edge-property-control>\n" +
    "               <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                      ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisType').value === 'datetime'\"\n" +
    "                                      property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisTimeFormat')\"\n" +
    "                                      property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisTimeFormat')\"></edge-property-control>\n" +
    "               <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                      property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('minPrimaryAxisValue')\"\n" +
    "                                      property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('minPrimaryAxisValue')\"></edge-property-control>\n" +
    "               <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                      property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxPrimaryAxisValue')\"\n" +
    "                                      property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('maxPrimaryAxisValue')\"></edge-property-control>\n" +
    "           </div>\n" +
    "           -->\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Measures'|translate}}\" index=\"2\" use-form-validation=\"config\" validate=\"ChartConfigCtrlr.setDefaultSeries()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('type').value !== 'pie'\">\n" +
    "                    <h4><span translate>Measures</span>  ({{ChartConfigCtrlr.getAxisLabel().secondary}} <span translate>Axis</span>)</h4>\n" +
    "                    <hr>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('secondaryAxisTitle')\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisTitle')\"></edge-property-control>\n" +
    "                    <edge-property-control style=\"clear: both;\" class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('secondaryAxisType')\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisType')\"></edge-property-control>\n" +
    "                    <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisType').value === 'linear' || ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisType').value === 'logarithmic'\">\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                            property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('minSecondaryAxisValue')\"\n" +
    "                            property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('minSecondaryAxisValue')\">\n" +
    "                        </edge-property-control>\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                            property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxSecondaryAxisValue')\"\n" +
    "                            property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('maxSecondaryAxisValue')\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showSecondaryAxisLabels')\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('showSecondaryAxisLabels')\"></edge-property-control>\n" +
    "                    <!--\n" +
    "                    <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisType').value === 'datetime'\">\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                               property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('secondaryAxisTimeUnit')\"\n" +
    "                                               property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisTimeUnit')\"></edge-property-control>\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                               property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('secondaryAxisTimeFormat')\"\n" +
    "                                               property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('secondaryAxisTimeFormat')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                    -->\n" +
    "                </div>\n" +
    "                <div ng-if=\"ChartConfigCtrlr.showRenderOption\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                        property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('renderOption')\"\n" +
    "                        property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('renderOption')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('type').value === 'pie'\" style=\"clear: both;\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('radius')\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('radius')\"></edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showSecondaryAxisLabels')\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('showSecondaryAxisLabels')\"></edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Series'|translate}}\" index=\"3\" use-form-validation=\"config\" validate=\"ChartConfigCtrlr.checkBubbleChartColumnRadius()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal edgeFlexColumn\" style=\"height: 100%\">\n" +
    "                <div ng-if=\"ChartConfigCtrlr.allowMultipleSeries\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                        property-def=\"::ChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('dynamicSeries')\"\n" +
    "                        property-value=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"ChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value\" class=\"edgeFlexColumn\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ChartConfigCtrlr.dynamicColumnTypeDef\"\n" +
    "                                           property-value=\"ChartConfigCtrlr.series[0].dynamicColumnType\"\n" +
    "                                           items=\"ChartConfigCtrlr.dynamicColumnTypesList\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"ChartConfigCtrlr.series[0].dynamicColumnType.value !== 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                               property-def=\"::ChartConfigCtrlr.columnPatternDef\"\n" +
    "                                               property-value=\"ChartConfigCtrlr.series[0].columnPattern\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"ChartConfigCtrlr.series[0].dynamicColumnType.value === 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"3\" style=\"cursor: hand\"\n" +
    "                                               property-def=\"::ChartConfigCtrlr.seriesColumnsExcludeDef\"\n" +
    "                                               property-value=\"ChartConfigCtrlr.series[0].excludedColumns\"\n" +
    "                                               items=\"ChartConfigCtrlr.bubbleRadiusAttributes\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <edge-labeled-control label=\"{{'Color Palette' | translate}}\" label-width=\"3\" validation=\"false\">\n" +
    "                        <edge-color-palette-formatter class=\"col-sm-12\" options=\"ChartConfigCtrlr.paletteOptions\"\n" +
    "                                                      formatter=\"ChartConfigCtrlr.dynamicColorPalette\">\n" +
    "                        </edge-color-palette-formatter>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"! ChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value\" class=\"edgeFlexColumn\" style=\"height: 100%\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Display Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label ng-if=\"ChartConfigCtrlr.baseChartType.value !== 'pie'\" translate style=\"padding-left:10px\">Chart Type Override</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:5px\">Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                        <edge-list selected-item=\"ChartConfigCtrlr.seriesSelected\"\n" +
    "                                   type=\"reorderable\" items=\"ChartConfigCtrlr.series\">\n" +
    "                            <edge-chart-series-def chart-series-def=\"item\"\n" +
    "                                                   y-axis-attributes=\"listScope.ChartConfigCtrlr.yAxisAttributes\"\n" +
    "                                                   base-chart-type=\"listScope.ChartConfigCtrlr.baseChartType.value\"\n" +
    "                                                   bubble-radius-attributes=\"::listScope.ChartConfigCtrlr.bubbleRadiusAttributes\"\n" +
    "                                                   bar-width-list=\"::listScope.ChartConfigCtrlr.barWidthList\"\n" +
    "                                                   chart-types-list=\"listScope.ChartConfigCtrlr.chartTypesList\"\n" +
    "                                                   fill-list=\"::listScope.ChartConfigCtrlr.fillList\"\n" +
    "                                                   series-fill-def=\"::listScope.ChartConfigCtrlr.seriesFillDef\"\n" +
    "                                                   series-stroke-style-def=\"::listScope.ChartConfigCtrlr.seriesStrokeStyleDef\"\n" +
    "                                                   series-stroke-width-def=\"::listScope.ChartConfigCtrlr.seriesStrokeWidthDef\"\n" +
    "                                                   series-bar-width-def=\"::listScope.ChartConfigCtrlr.seriesBarWidthDef\"\n" +
    "                                                   series-legend-def=\"::listScope.ChartConfigCtrlr.seriesLegendDef\"\n" +
    "                                                   series-type-def=\"::listScope.ChartConfigCtrlr.seriesTypeDef\"\n" +
    "                                                   series-color-def=\"::listScope.ChartConfigCtrlr.seriesColorDef\"\n" +
    "                                                   series-alpha-def=\"::listScope.ChartConfigCtrlr.seriesAlphaDef\"\n" +
    "                                                   series-marker-def=\"::listScope.ChartConfigCtrlr.seriesMarkerDef\"\n" +
    "                                                   series-radius-def=\"::listScope.ChartConfigCtrlr.seriesRadiusDef\"\n" +
    "                                                   marker-options-list=\"::listScope.ChartConfigCtrlr.markerOptionsList\"\n" +
    "                                                   series-pattern-def=\"::listScope.ChartConfigCtrlr.seriesPatternDef\"\n" +
    "                                                   series-patternl-size-def=\"::listScope.ChartConfigCtrlr.seriesPatternlSizeDef\"\n" +
    "                                                   series-rotation-def=\"::listScope.ChartConfigCtrlr.seriesRotationDef\"\n" +
    "                                                   series-scale-def=\"::listScope.ChartConfigCtrlr.seriesScaleDef\"\n" +
    "                                                   stroke-styles-list=\"::listScope.ChartConfigCtrlr.strokeStylesList\"\n" +
    "                                                   series-symbol-def=\"::listScope.ChartConfigCtrlr.seriesSymbolDef\"\n" +
    "                                                   series-symbol-size-def=\"::listScope.ChartConfigCtrlr.seriesSymbolSizeDef\"></edge-chart-series-def>\n" +
    "                        </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"ChartConfigCtrlr.addSeries()\"></button>\n" +
    "                            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"ChartConfigCtrlr.removeSeries()\"\n" +
    "                                    ng-disabled=\"ChartConfigCtrlr.seriesSelected==null || ChartConfigCtrlr.series.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\"\n" +
    "                          on-show=\"ChartConfigCtrlr.previewShown()\" on-hide=\"ChartConfigCtrlr.hidePreview()\">\n" +
    "            <edge-preview-widget ng-if=\"ChartConfigCtrlr.showPreview\" controller=\"::ChartConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"ChartConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"ChartConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/chart/config/edit-renderer-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/chart/config/edit-renderer-dialog.tpl.html",
    "<form name=\"chartSeriesPropForm\" class=\"form-horizontal\">\n" +
    "    <edge-property-control ng-if=\"baseChartType !== 'pie'\" class=\"col-sm-6\" label-width=\"4\" property-def=\"::seriesLegendDef\"\n" +
    "        property-value=\"chartSeriesDef.legend\">\n" +
    "    </edge-property-control>\n" +
    "    <edge-property-control ng-if=\"chartSeriesDef.meta.value.radius\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "        validation=\"true\" property-def=\"::seriesRadiusDef\"\n" +
    "        property-value=\"chartSeriesDef.radiusColumn\" items=\"::bubbleRadiusAttributes\">\n" +
    "    </edge-property-control>\n" +
    "    <edge-property-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "        property-def=\"::seriesColorDef\" property-value=\"chartSeriesDef.color\">\n" +
    "    </edge-property-control>\n" +
    "    <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "        property-def=\"::seriesAlphaDef\" property-value=\"chartSeriesDef.alpha\">\n" +
    "    </edge-property-control>\n" +
    "    <div style=\"clear: both;\" class=\"row\" ng-if=\"chartSeriesDef.type.value === 'bar' || chartSeriesDef.type.value === 'column'\">\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" items=\"::barWidthList\"\n" +
    "            property-def=\"::seriesBarWidthDef\" property-value=\"chartSeriesDef.barWidth\">\n" +
    "        </edge-property-control>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both;\" ng-if=\"chartSeriesDef.meta.value.marker\">\n" +
    "        <div class=\"row\">\n" +
    "            <edge-property-control class=\"col-sm-6\" label-width=\"4\" items=\"::markerOptionsList\"\n" +
    "                property-def=\"::seriesMarkerDef\"\n" +
    "                property-value=\"chartSeriesDef.marker\">\n" +
    "            </edge-property-control>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"chartSeriesDef.marker.value === 'custom'\">\n" +
    "            <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                property-def=\"::seriesSymbolDef\" property-value=\"chartSeriesDef.symbol\">\n" +
    "            </edge-property-control>\n" +
    "            <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "                property-def=\"::seriesSymbolSizeDef\" property-value=\"chartSeriesDef.symbolSize\">\n" +
    "            </edge-property-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div style=\"clear: both\" class=\"row\" ng-if=\"chartSeriesDef.meta.value.stroke\">\n" +
    "        <edge-property-control ng-if=\"chartSeriesDef.meta.value.strokeStyle\" class=\"col-sm-6\"\n" +
    "            label-width=\"4\" items=\"::strokeStylesList\"\n" +
    "            property-def=\"::seriesStrokeStyleDef\" property-value=\"chartSeriesDef.strokeStyle\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesStrokeWidthDef\" property-value=\"chartSeriesDef.strokeWidth\">\n" +
    "        </edge-property-control>\n" +
    "    </div>\n" +
    "    <edge-property-control style=\"clear: both\" ng-if=\"chartSeriesDef.meta.value.fill\"\n" +
    "        class=\"col-sm-6\" label-width=\"4\" items=\"::fillList\"\n" +
    "        property-def=\"::seriesFillDef\" property-value=\"chartSeriesDef.fill\">\n" +
    "    </edge-property-control>\n" +
    "    <div style=\"clear: both\"\n" +
    "         ng-if=\"chartSeriesDef.fill.value === 'pattern' && chartSeriesDef.meta.value.fill\">\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesPatternDef\" property-value=\"chartSeriesDef.pattern\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesPatternlSizeDef\" property-value=\"chartSeriesDef.patternSize\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control style=\"clear: both\" class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesRotationDef\" property-value=\"chartSeriesDef.rotation\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesScaleDef\" property-value=\"chartSeriesDef.scale\">\n" +
    "        </edge-property-control>\n" +
    "    </div>\n" +
    "    <!-- need this to ensure everything fits inside the dialog -->\n" +
    "    <div style=\"clear: both\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/widget/flow/config/edgeFlowWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/flow/config/edgeFlowWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"FlowWidgetWizardController as FlowConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!FlowConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"FlowConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"FlowConfigCtrlr.handleCancel\" ng-if=\"FlowConfigCtrlr.initialized\">\n" +
    "        <edge-wizard-step label=\"{{'Configure' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('type')\"\n" +
    "                                       property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('type')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('allowTypeChange')\"\n" +
    "                                       property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('allowTypeChange')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('showNodeTooltip')\"\n" +
    "                                       property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('showNodeTooltip')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('showLinkTooltip')\"\n" +
    "                                       property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('showLinkTooltip')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Renderer' | translate}}\" index=\"1\" use-form-validation=\"rendererconfig\">\n" +
    "            <form name=\"rendererconfig\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Renderer</h4>\n" +
    "                <div class=\"panel panel-default\" style=\"height:calc(65% - 50px)\">\n" +
    "                    <div class=\"panel-heading\">\n" +
    "                        <div class=\"row\">\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate>Name</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate>Display Name</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-6\">\n" +
    "                                <label translate>Color Palette</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <div class=\"panel-body\" style=\"height:calc(100% - 78px); flex-basis: auto\">\n" +
    "                        <edge-list items=\"FlowConfigCtrlr.rendererConfig.rendererDefs\" class=\"edgeListHorizontalScroll\">\n" +
    "                            <div class=\"row\">\n" +
    "                                <div class=\"col-sm-3\" style=\"padding:10px\">\n" +
    "                                    {{item.dataProducerName}}\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3 with-padding\">\n" +
    "                                    <input ng-model=\"item.displayName\" class=\"form-control\">\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-6 with-padding\">\n" +
    "                                    <edge-color-palette-formatter formatter=\"item.palette\"></edge-color-palette-formatter>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <h4 translate>Label Options</h4>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-font-formatter formatter=\"FlowConfigCtrlr.rendererConfig.labelConfig\"\n" +
    "                                         options=\"::FlowConfigCtrlr.fontOptions\"></edge-font-formatter>\n" +
    "                </div>\n" +
    "                <div ng-if=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('type').value === 'Sankey' || FlowConfigCtrlr.propertyBundle.findPropertyValueByName('allowTypeChange').value === true\">\n" +
    "                    <h4 translate>Sankey Header Options</h4>\n" +
    "                    <div class=\"col-sm-6\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"4\"\n" +
    "                                               property-def=\"::FlowConfigCtrlr.propertyBundleDef.findPropertyDefByName('showHeader')\"\n" +
    "                                               property-value=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('showHeader')\"></edge-property-control>\n" +
    "                        <edge-font-formatter ng-if=\"FlowConfigCtrlr.propertyBundle.findPropertyValueByName('showHeader').value === true\"\n" +
    "                                             formatter=\"FlowConfigCtrlr.rendererConfig.headerConfig\"\n" +
    "                                             options=\"::FlowConfigCtrlr.fontOptions\"></edge-font-formatter>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"FlowConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"FlowConfigCtrlr.hidePreview()\" index=\"2\">\n" +
    "            <edge-preview-widget ng-if=\"FlowConfigCtrlr.showPreview\" controller=\"::FlowConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"FlowConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"FlowConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/flow/edgeFlowWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/flow/edgeFlowWidget.tpl.html",
    "<div class=\"edgeFlow\">\n" +
    "    <div ng-if=\"flowCtrlr.type === 'Sankey'\">\n" +
    "        <edge-sankey flow-controller=\"flowCtrlr\"></edge-sankey>\n" +
    "    </div>\n" +
    "    <div ng-if=\"flowCtrlr.type === 'Chord'\">\n" +
    "        <edge-chord flow-controller=\"flowCtrlr\"></edge-chord>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/widget/flow/edgeFlowWidgetFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/flow/edgeFlowWidgetFooter.tpl.html",
    "<table style=\"table-layout: fixed\">\n" +
    "    <td ng-if=\"flowCtrlr.allowTypeChange\">\n" +
    "        <button class=\"btn btn-default\"\n" +
    "                style=\"padding:0px 4px;\"\n" +
    "                title=\"{{'Toggle Sankey' | translate}}\"\n" +
    "                ng-click=\"flowCtrlr.toggleSankey()\">\n" +
    "            <i class=\"icon\" ng-class=\"flowCtrlr.isSankey() ? 'icon_vis_chord' : 'icon_vis_sankey'\"></i>\n" +
    "        </button>\n" +
    "    </td>\n" +
    "    <td style=\"max-width:150px;\" ng-if=\"flowCtrlr.linkValues && flowCtrlr.linkValues.length > 1\">\n" +
    "        <select class=\"form-control\"\n" +
    "                ng-model=\"flowCtrlr.selectedLinkValue\"\n" +
    "                ng-options=\"linkValue for linkValue in flowCtrlr.linkValues\"></select>\n" +
    "    </td>\n" +
    "</table>");
}]);

angular.module("edge/widget/flow/sankey/edgeSankey.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/flow/sankey/edgeSankey.tpl.html",
    "<div>\n" +
    "    <div class=\"edgeSankeyHeading\" ng-if=\"sankeyCtrlr.showHeaders\">\n" +
    "        <table><tbody><tr>\n" +
    "            <td ng-repeat=\"field in sankeyCtrlr.headers track by $index\"\n" +
    "                ng-attr-width=\"{{ ($first || $last) ? sankeyCtrlr.headerItemWidth/2 : sankeyCtrlr.headerItemWidth}}%\"\n" +
    "                ng-class=\"sankeyCtrlr.rendererConfig.headerConfig.style\"\n" +
    "                ng-style=\"{'font-size':sankeyCtrlr.rendererConfig.headerConfig.size,'color':sankeyCtrlr.colorService.getHex(sankeyCtrlr.rendererConfig.headerConfig.color)}\"\n" +
    "                ng-attr-title=\"{{field}}\">{{field}}</td>\n" +
    "        </tr></tbody></table>\n" +
    "    </div>\n" +
    "    <div class=\"edgeSankeyDiagram\" ng-class=\"{'edgeSankeyVScroll':sankeyCtrlr.scrollingNeeded}\" ng-style=\"{'height':(sankeyCtrlr.flowCtrlr.availHeight+'px')}\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/config/arc-preview.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/config/arc-preview.tpl.html",
    "<div class=\"row\" style=\"margin-bottom:10px\">\n" +
    "    <div class=\"col-sm-3\">\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-9\">\n" +
    "        <div class=\"gaugeTypePreview edgeGaugePreviewDivArc\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/config/edgeGaugeThresholdConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/config/edgeGaugeThresholdConfig.tpl.html",
    "<div>\n" +
    "    <edge-panel>\n" +
    "        <edge-panel-header hide-label=\"true\">\n" +
    "            <div style=\"width: 100%\">\n" +
    "                <div class=\"col-sm-3\">\n" +
    "                    <label translate style=\"padding-left:20px\">Color</label>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-9\">\n" +
    "                    <label translate style=\"padding-left:15px\">Value</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </edge-panel-header>\n" +
    "        <edge-list style=\"height: 273px;\" selected-item=\"Controller.selectedItem\"\n" +
    "                   type=\"reorderable\" items=\"Controller.thresholdConfig.thresholds\">\n" +
    "            <edge-gauge-threshold-def config=\"item\"\n" +
    "                                   columns=\"listScope.Controller.dataAttributes\"\n" +
    "                                   controller=\"listScope.Controller\"></edge-gauge-threshold-def>\n" +
    "        </edge-list>\n" +
    "        <edge-panel-footer>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"Controller.addRow()\"></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"Controller.removeRow()\"\n" +
    "                    ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "        </edge-panel-footer>\n" +
    "    </edge-panel>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/config/edgeGaugeThresholdDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/config/edgeGaugeThresholdDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <edge-classname-color-picker-button ng-model=\"config.color\"></edge-classname-color-picker-button>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <ui-select ng-model=\"config.type\" append-to-body=\"true\">\n" +
    "                <ui-select-match><span ng-bind-html=\"$select.selected.label\"></span></ui-select-match>\n" +
    "                <ui-select-choices repeat=\"type.value as type in controller.getThresholdTypes() | filter: {label: $select.search}\">\n" +
    "                    <span ng-bind-html=\"type.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-6\">\n" +
    "            <edge-labeled-control ng-if=\"config.type==0\" validation=\"true\" label-width=\"0\"\n" +
    "                                  show-feedback-icon=\"false\" style=\"margin:0px;\">\n" +
    "                <edge-number-spinner inputname=\"{{'staticValue' + config.id}}\" ng-model=\"config.staticValueAsNumber\"\n" +
    "                                     step=\"inputInfo.spinner.interval\" minimum=\"0\" isrequired=\"true\">\n" +
    "                </edge-number-spinner>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"config.type==1\" validation=\"true\" required=\"true\"\n" +
    "                                label-width=\"0\" show-feedback-icon=\"false\" style=\"margin:0px;\">\n" +
    "                <edge-data-attribute-picker required=\"true\"\n" +
    "                                            attribute-defs=\"controller.dataAttributes\"\n" +
    "                                            ng-model=\"config.derivedValue\">\n" +
    "                </edge-data-attribute-picker>\n" +
    "            </edge-labeled-control>\n" +
    "            <edge-labeled-control ng-if=\"config.type==2\" validation=\"true\" label-width=\"0\"\n" +
    "                                  show-feedback-icon=\"false\" style=\"margin:0px;\">\n" +
    "                <input type=hidden name=\"{{'calculatedValue' + config.id}}\" ng-model=\"config.calculatedValue\" required>\n" +
    "                <ui-select ng-model=\"config.calculatedValue\"\n" +
    "                           theme=\"bootstrap\"\n" +
    "                           ng-required=\"true\">\n" +
    "                    <ui-select-match>{{$select.selected.label}}</ui-select-match>\n" +
    "                    <ui-select-choices repeat=\"type.value as type in controller.getCalculatedValueTypes() | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"type.label | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/config/edgeGaugeWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/config/edgeGaugeWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"GaugeWidgetWizardController as GaugeConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!GaugeConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"!GaugeConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"GaugeConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"GaugeConfigCtrlr.handleCancel\" ng-if=\"GaugeConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{'Base Gauge'|translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('type')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type')\">\n" +
    "\n" +
    "                </edge-property-control>\n" +
    "                <div ng-include=\"GaugeConfigCtrlr.getTypePreview()\"></div>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('itemPadding')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('itemPadding')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value != 'Linear'\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('itemMargin')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('itemMargin')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value != 'Linear'\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('showBorder')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('showBorder')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Labels'|translate}}\" index=\"1\" use-form-validation=\"labels\">\n" +
    "            <form name=\"labels\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Value Label</h4>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('valueField')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('valueField')\"\n" +
    "                                       items=\"::GaugeConfigCtrlr.numberedAttributesList\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-labeled-control label=\"{{'Styling' | translate}}\"\n" +
    "                                      validation=\"false\"\n" +
    "                                      label-width=\"3\"\n" +
    "                                      ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value != 'Linear'\">\n" +
    "                    <edge-derivable-font config=\"GaugeConfigCtrlr.valueLabelConfig\"\n" +
    "                                         attribute-defs=\"::GaugeConfigCtrlr.dataAttributes\"></edge-derivable-font>\n" +
    "                    <div style=\"padding-top:15px;padding-left:2px;\">\n" +
    "                        <edge-derivable-number config=\"GaugeConfigCtrlr.valueLabelConfig\"></edge-derivable-number>\n" +
    "                    </div>\n" +
    "                </edge-labeled-control>\n" +
    "                <h4 translate>Gauge Label</h4>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('labelField')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('labelField')\"\n" +
    "                                       items=\"::GaugeConfigCtrlr.attributesList\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-labeled-control label=\"{{'Styling' | translate}}\"\n" +
    "                                      validation=\"false\"\n" +
    "                                      label-width=\"3\"\n" +
    "                                      ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value != 'Linear'\">\n" +
    "                    <edge-derivable-font config=\"GaugeConfigCtrlr.primaryLabelConfig\"\n" +
    "                                         attribute-defs=\"::GaugeConfigCtrlr.dataAttributes\"></edge-derivable-font>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Thresholds'|translate}}\" index=\"2\" use-form-validation=\"thresholds\">\n" +
    "            <form name=\"thresholds\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{'Gauge Color' | translate}}\" label-width=\"4\">\n" +
    "                    <edge-radio-group name=\"gaugeColor\"\n" +
    "                                      ng-model=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('gaugeColor').value\">\n" +
    "                        <edge-radio-button value=\"threshold\">\n" +
    "                            <span translate>Use Threshold Colors</span><br/>\n" +
    "                        </edge-radio-button>\n" +
    "                        <edge-radio-button value=\"default\">\n" +
    "                            <span translate>Only use Default Threshold Color</span><br/>\n" +
    "                        </edge-radio-button>\n" +
    "                    </edge-radio-group>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"4\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('defaultColor')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('defaultColor')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\"\n" +
    "                                       label-width=\"4\"\n" +
    "                                       validation=\"true\"\n" +
    "                                       ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value == 'Linear'\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('thresholdAlpha')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('thresholdAlpha')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-gauge-threshold-config ng-if=\"GaugeConfigCtrlr.hasData && GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('gaugeColor').value === 'threshold'\"></edge-gauge-threshold-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Options'|translate}}\" index=\"3\" validate=\"GaugeConfigCtrlr.validateOptionsSetting()\" use-form-validation=\"options\">\n" +
    "            <form name=\"options\" class=\"form-horizontal\">\n" +
    "                <div ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value==='Arc'\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('gaugeWidth')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('gaugeWidth')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('thickness')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('thickness')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('startArcAngle')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('startArcAngle')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('endArcAngle')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('endArcAngle')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('type').value=='Linear'\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('gaugeHeight')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('gaugeHeight')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"4\"\n" +
    "                                           property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('showComparative')\"\n" +
    "                                           property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('showComparative')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('showComparative').value == true\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                               property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('comparativeValueField')\"\n" +
    "                                               property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('comparativeValueField')\"\n" +
    "                                               items=\"::GaugeConfigCtrlr.numberedAttributesList\">\n" +
    "                        </edge-property-control>\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"4\"\n" +
    "                                               property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('comparativeColor')\"\n" +
    "                                               property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('comparativeColor')\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"4\"\n" +
    "                                       property-def=\"::GaugeConfigCtrlr.propertyBundleDef.findPropertyDefByName('useLowestValue')\"\n" +
    "                                       property-value=\"GaugeConfigCtrlr.propertyBundle.findPropertyValueByName('useLowestValue')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"GaugeConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"GaugeConfigCtrlr.hidePreview()\">\n" +
    "            <edge-preview-widget ng-if=\"GaugeConfigCtrlr.showPreview\" controller=\"::GaugeConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"GaugeConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"GaugeConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/config/linear-preview.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/config/linear-preview.tpl.html",
    "<div class=\"row\" style=\"margin-bottom:10px\">\n" +
    "    <div class=\"col-sm-3\">\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-9\">\n" +
    "        <div class=\"gaugeTypePreview\"><div class=\"edgeGaugePreviewDivLinear\"></div></div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/gauge/edgeGaugeWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/gauge/edgeGaugeWidget.tpl.html",
    "<div class=\"no-selection no-hover\" style=\"position:relative\">\n" +
    "    <ul ng-if=\"Controller.canRender() && Controller.getGaugeType() === 'linear'\" class=\"edge-gauge-widget\">\n" +
    "    <!-- @formatter:off -->\n" +
    "        <style>\n" +
    "            .{{::Controller.itemClass}} {\n" +
    "                padding:{{::Controller.config.itemPadding.value}}px;\n" +
    "                width: 100%;\n" +
    "            }\n" +
    "            .{{::Controller.itemClass}} .highcharts-container {\n" +
    "                overflow: visible !important; /* needed for IE or bottom of labels clipped by 1px */\n" +
    "            }\n" +
    "        </style>\n" +
    "        <li mn-touch\n" +
    "            ng-repeat=\"item in Controller.dataSource\"\n" +
    "            ng-class=\"{'selected':Controller.selectedIndex == $index}\"\n" +
    "            class=\"gauge-linear-item {{::(Controller.itemClass+Controller.noSelectClass)}} \"\n" +
    "            ng-click=\"Controller.gaugeClicked($index)\"\n" +
    "            ng-mouseenter=\"Controller.mouseEnter(item)\"\n" +
    "            ng-mouseleave=\"Controller.mouseLeave(item)\" hold=\"Controller.hold(item,$event)\">\n" +
    "            <edge-gauge-renderer gauge-scope-data=\"Controller.gaugeScopeData[$index]\"\n" +
    "                                 controller=\"::Controller\"\n" +
    "                                 do-layout=\"$last\">\n" +
    "            </edge-gauge-renderer>\n" +
    "        </li>\n" +
    "    </ul>\n" +
    "    <ul ng-if=\"Controller.canRender() && Controller.getGaugeType() === 'arc'\" class=\"edge-gauge-widget\">\n" +
    "        <style>\n" +
    "            .{{::Controller.itemClass}} {\n" +
    "                padding:{{::Controller.config.itemPadding.value}}px;\n" +
    "                margin:{{::Controller.config.itemMargin.value}}px 0 0 {{::Controller.config.itemMargin.value}}px;\n" +
    "                height:{{Controller.itemHeight}}px;\n" +
    "                width:{{Controller.itemWidth}}px;\n" +
    "            }\n" +
    "            .{{::Controller.itemClass}}:last-child {\n" +
    "                margin-bottom: {{::Controller.config.itemMargin.value}}px;\n" +
    "            }\n" +
    "            .{{::Controller.itemClass}} .edgeGaugeArcLabel {\n" +
    "                    height:{{Controller.itemInnerHeight}}px;\n" +
    "                    width:{{Controller.itemInnerWidth}}px;\n" +
    "                }\n" +
    "            .{{::Controller.itemClass}} .edgeGaugeArcLabel > div {\n" +
    "                    width:{{Controller.getArcGaugeLableWidth()}}px;\n" +
    "                }\n" +
    "            .{{::Controller.itemClass}} .edgeGaugeLabel > div > span {\n" +
    "                    cursor: default;\n" +
    "                }\n" +
    "            .{{::Controller.itemClass}} .edgeGaugePrimaryLabel {\n" +
    "                    width:{{Controller.itemInnerWidth}}px;\n" +
    "                }\n" +
    "            .{{::Controller.itemClass}} .highcharts-container {\n" +
    "                margin-left: auto;\n" +
    "                margin-right: auto;\n" +
    "            }\n" +
    "            {{Controller.styleClassesAsString}}\n" +
    "        </style>\n" +
    "        <style ng-if=\"Controller.data.unfilteredRecords.length === 1 && Controller.height > Controller.width\">\n" +
    "            .{{::Controller.itemClass}} {\n" +
    "                padding-top:{{::Controller.verticalPadding}}px;\n" +
    "                padding-bottom:{{::Controller.verticalPadding}}px;\n" +
    "            }\n" +
    "            .{{::Controller.itemClass}} .edgeGaugeArcLabel {\n" +
    "                height:{{::Controller.options.chart.height}}px;\n" +
    "            }\n" +
    "        </style>\n" +
    "        <li mn-touch\n" +
    "            ng-repeat=\"item in Controller.dataSource\"\n" +
    "            ng-class=\"{'selected':Controller.selectedIndex == $index}\"\n" +
    "            class=\"{{::(Controller.itemClass+Controller.noSelectClass+(Controller.showBorder() ? ' gauge-border-item' : ''))}} \"\n" +
    "            ng-click=\"Controller.gaugeClicked($index)\"\n" +
    "            ng-mouseenter=\"Controller.mouseEnter(item)\"\n" +
    "            ng-mouseleave=\"Controller.mouseLeave(item)\" hold=\"Controller.hold(item,$event)\">\n" +
    "            <div class=\"edgeGaugeArcLabel\">\n" +
    "                <div>\n" +
    "                    <span class=\"{{Controller.gaugeScopeData[$index].valueClass}}\">{{Controller.gaugeScopeData[$index].formattedValue}}</span><br>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <edge-gauge-renderer gauge-scope-data=\"Controller.gaugeScopeData[$index]\"\n" +
    "                                 controller=\"::Controller\"\n" +
    "                                 do-layout=\"$last\">\n" +
    "            </edge-gauge-renderer>\n" +
    "            <div class=\"edgeGaugePrimaryLabel {{Controller.gaugeScopeData[$index].labelClass}}\">\n" +
    "                {{Controller.gaugeScopeData[$index].label}}\n" +
    "            </div>\n" +
    "        </li>\n" +
    "    <!-- @formatter:on -->\n" +
    "    </ul>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/heatmap/config/edgeHeatMapWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/heatmap/config/edgeHeatMapWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"HeatMapWidgetWizardController as ConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!ConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"ConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ConfigCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"Configure\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('xAxisColumn')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('xAxisColumn')\"\n" +
    "                                       items=\"::ConfigCtrlr.attributesList\"></edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('showXAxisLabels')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('showXAxisLabels')\"></edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('yAxisColumn')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('yAxisColumn')\"\n" +
    "                                       items=\"::ConfigCtrlr.attributesList\"></edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('showYAxisLabels')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('showYAxisLabels')\"></edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('labelWidth')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('labelWidth')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"Renderer\" index=\"1\" use-form-validation=\"renderer\">\n" +
    "            <form name=\"renderer\" class=\"form-horizontal\">\n" +
    "                <edge-labeled-control label=\"{{::'Threshold Calculation' | translate}}\" validation=\"false\">\n" +
    "                    <edge-radio-group name=\"optionsRadios\"\n" +
    "                                      ng-model=\"ConfigCtrlr.paletteConfig.usePalette\">\n" +
    "                        <edge-radio-button ng-value=\"true\">\n" +
    "                            <span translate>Auto generate from a palette</span><br/>\n" +
    "                            <span class=\"text-muted\" translate>Generates a dynamic ruleset based on colors available in a color palette.</span>\n" +
    "                        </edge-radio-button>\n" +
    "                        <edge-radio-button ng-value=\"false\">\n" +
    "                            <span translate>Generate from a ruleset</span><br/>\n" +
    "                            <span class=\"text-muted\" translate>Uses an explicit ruleset to determine heat.</span>\n" +
    "                        </edge-radio-button>\n" +
    "                    </edge-radio-group>\n" +
    "                </edge-labeled-control>\n" +
    "\n" +
    "                <edge-property-control validation=\"true\" label-width=\"4\" ng-if=\"ConfigCtrlr.paletteConfig.usePalette\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('valueColumn')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('valueColumn')\"\n" +
    "                                       items=\"::ConfigCtrlr.numberedAttributesList\"></edge-property-control>\n" +
    "\n" +
    "                <edge-labeled-control ng-if=\"ConfigCtrlr.paletteConfig.usePalette\" label=\"{{'Color Palette' | translate}}\" validation=\"false\">\n" +
    "                    <edge-color-palette-formatter options=\"ConfigCtrlr.paletteOptions\"\n" +
    "                                                  formatter=\"ConfigCtrlr.paletteConfig.colorPalette\"></edge-color-palette-formatter>\n" +
    "                </edge-labeled-control>\n" +
    "\n" +
    "                <edge-labeled-control ng-if=\"!ConfigCtrlr.paletteConfig.usePalette\" label=\"{{'Color RuleSet' | translate}}\" validation=\"false\">\n" +
    "                    <edge-derivable-color config=\"ConfigCtrlr.paletteConfig.derivableColor\" attribute-defs=\"::ConfigCtrlr.dataAttributes\" derived-only=\"true\"></edge-derivable-color>\n" +
    "                </edge-labeled-control>\n" +
    "\n" +
    "                <edge-property-control class=\"col-sm-6\" validation=\"true\" label-width=\"8\"\n" +
    "                                       property-def=\"::ConfigCtrlr.propertyBundleDef.findPropertyDefByName('radius')\"\n" +
    "                                       property-value=\"ConfigCtrlr.propertyBundle.findPropertyValueByName('radius')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"ConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"ConfigCtrlr.hidePreview()\">\n" +
    "            <edge-preview-widget ng-if=\"ConfigCtrlr.showPreview\" controller=\"::ConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"ConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"ConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/heatmap/edgeHeatMapWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/heatmap/edgeHeatMapWidget.tpl.html",
    "<div class=\"heat-map-widget\" style=\"overflow-x:hidden;\">\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/list/config/edgeListAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/list/config/edgeListAttributeDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <ui-select ng-model=\"attributeRendererDef.column\" append-to-body=\"true\" on-select=\"update($item)\">\n" +
    "                <ui-select-match theme=\"bootstrap\"\n" +
    "                                 allow-clear=\"false\"\n" +
    "                                 placeholder=\"{{'Select Attribute ...' | translate}}\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"item.value as item in attributesList | orderBy: 'label' | filter: $select.search\" style=\"width:200%;\">\n" +
    "                    <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                    <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <input class=\"form-control\"\n" +
    "                   ng-disabled=\"!attributeRendererDef.labelOn\"\n" +
    "                   ng-model=\"attributeRendererDef.labelText\"\n" +
    "                   placeholder=\"{{attributeRendererDef.displayName}}\"></input>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <div ng-if=\"!(attributeRendererDef.formatterConfig.type == 0 && attributeRendererDef.iconPosition != 'inline')\">\n" +
    "                <input type=\"checkbox\"\n" +
    "                       name=\"labelOn\"\n" +
    "                       ng-model=\"attributeRendererDef.labelOn\"\n" +
    "                       edge-boolean-switch>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-4\">\n" +
    "            <div class=\"btn-toolbar\" style=\"width:100%\">\n" +
    "                <div class=\"btn-group\" style=\"margin:0\">\n" +
    "                    <edge-formatter-chooser class=\"pull-left\"\n" +
    "                                                config=\"attributeRendererDef.formatterConfig\"\n" +
    "                                                attributes=\"::attributeDefs\"\n" +
    "                                                attribute-name=\"attributeRendererDef.column\"\n" +
    "                                                new-formatter-overrides=\"::newFormatterOverrides\">\n" +
    "                    </edge-formatter-chooser>\n" +
    "                    <div ng-if=\"attributeRendererDef.formatterConfig.type == 0\"\n" +
    "                         class=\"pull-left\"\n" +
    "                         style=\"margin-left:6px;\">\n" +
    "                        <ui-select ng-model=\"attributeRendererDef.iconPosition\">\n" +
    "                            <ui-select-match theme=\"bootstrap\"\n" +
    "                                             allow-clear=\"false\"\n" +
    "                                             placeholder=\"{{'Icon position...' | translate}}\">\n" +
    "                                {{$select.selected.label}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices\n" +
    "                                    repeat=\"item.value as item in iconPositionDef | filter: $select.search\">\n" +
    "                                <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/list/config/edgeListSortAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/list/config/edgeListSortAttributeDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <ui-select ng-model=\"sortAttributeDef.column\">\n" +
    "                <ui-select-match theme=\"bootstrap\"\n" +
    "                                 allow-clear=\"false\"\n" +
    "                                 placeholder=\"{{'Select Attribute ...' | translate}}\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"item.value as item in attributesList | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            <ui-select ng-model=\"sortAttributeDef.sortDirection\">\n" +
    "                <ui-select-match theme=\"bootstrap\"\n" +
    "                                 allow-clear=\"false\"\n" +
    "                                 placeholder=\"{{'Select sort direction...' | translate}}\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"item.value as item in sortDirections | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/widget/list/config/edgeListWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/list/config/edgeListWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"ListWidgetWizardController as ListConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!ListConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"!ListConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"ListConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ListConfigCtrlr.handleCancel\" ng-if=\"ListConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base List'|translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base List Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <h4 translate>Layout Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutType')\"\n" +
    "                                       property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('layoutType')\"></edge-property-control>\n" +
    "                <h4 translate>Appearance</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" style=\"clear: both;\" validation=\"true\"\n" +
    "                                       property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('itemPadding')\"\n" +
    "                                       property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('itemPadding')\"></edge-property-control>\n" +
    "                <div ng-if=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('layoutType').value !== 'vertical'\"\n" +
    "                     style=\"clear: both;\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                           property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('flow_margin')\"\n" +
    "                                           property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('flow_margin')\"></edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                           property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('minWidth')\"\n" +
    "                                           property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('minWidth')\"></edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::ListConfigCtrlr.propertyBundleDef.findPropertyDefByName('autoExpand')\"\n" +
    "                                           property-value=\"ListConfigCtrlr.propertyBundle.findPropertyValueByName('autoExpand')\"></edge-property-control>\n" +
    "\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'List Items'|translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          validate=\"ListConfigCtrlr.validateRenderer()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <h4 translate>List Items</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"height: 50%;\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Show Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Value Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"ListConfigCtrlr.attributeSelected\"\n" +
    "                                       type=\"reorderable\" items=\"ListConfigCtrlr.attributes.attributeRendererDefs\">\n" +
    "                                <edge-list-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                         attributes-list=\"::listScope.ListConfigCtrlr.attributesList\"\n" +
    "                                                         attribute-defs=\"::listScope.ListConfigCtrlr.dataAttributes\"></edge-list-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"ListConfigCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"ListConfigCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"ListConfigCtrlr.attributeSelected==null || ListConfigCtrlr.attributes.attributeRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "                <h4 translate>Label Formatter</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"width: 50%;\">\n" +
    "                    <edge-font-formatter formatter=\"ListConfigCtrlr.labelFormatter\"></edge-font-formatter>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Sort Option'|translate}}\" index=\"2\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <edge-panel>\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div style=\"width: 100%\">\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate style=\"padding-left:20px\">Attribute</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate style=\"padding-left:15px\">Order</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <edge-list selected-item=\"ListConfigCtrlr.sortAttributeSelected\"\n" +
    "                               type=\"reorderable\" items=\"ListConfigCtrlr.sortAttributeConfig.sortAttributeDefs\">\n" +
    "                            <edge-list-sort-attribute-def sort-attribute-def=\"item\"\n" +
    "                                                          attributes-list=\"::listScope.ListConfigCtrlr.attributesList\"></edge-list-sort-attribute-def>\n" +
    "                        </edge-list>\n" +
    "                    </edge-panel-body>\n" +
    "                    <edge-panel-footer>\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-default icon icon_plus\"\n" +
    "                                ng-click=\"ListConfigCtrlr.addSortEntry()\"></button>\n" +
    "                        <button type=\"button\"\n" +
    "                                class=\"btn btn-default icon icon_minus\"\n" +
    "                                ng-click=\"ListConfigCtrlr.removeSortEntry()\"\n" +
    "                                ng-disabled=\"ListConfigCtrlr.sortAttributeSelected==null\"></button>\n" +
    "                    </edge-panel-footer>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"ListConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"ListConfigCtrlr.hidePreview()\">\n" +
    "            <edge-preview-widget ng-if=\"ListConfigCtrlr.showPreview\" controller=\"::ListConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"ListConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"ListConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/list/edgeListCell.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/list/edgeListCell.tpl.html",
    "<table class=\"listCell {{listScope.Controller.isFlow() ? 'isFlow' : ''}}\" ng-animate=\"'textanimate'\">\n" +
    "    <colgroup>\n" +
    "        <col class='listItemLabel' />\n" +
    "        <col class='listItemValue' />\n" +
    "    </colgroup>\n" +
    "    <tr ng-repeat=\"attributeRendererDef in listScope.Controller.inlineItems\">\n" +
    "        <td ng-if=\"attributeRendererDef.labelOn == true\" class=\"listItemLabel {{listScope.Controller.getClass(attributeRendererDef, item, 'label')}}\" >\n" +
    "            {{::attributeRendererDef.labelText}}\n" +
    "        </td>\n" +
    "\n" +
    "        <td colspan=\"{{ attributeRendererDef.labelOn == true ? 1 : 2}}\"\n" +
    "            class=\"listItemValue {{attributeRendererDef.labelOn == true ? 'render-value' : 'value-only'}}\n" +
    "                   {{attributeRendererDef.formatterConfig.type != 0 ? listScope.Controller.getClass(attributeRendererDef, item, 'text') : ''}}\">\n" +
    "                <span ng-if=\"attributeRendererDef.formatterConfig.type == 0\">\n" +
    "                     <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\">\n" +
    "                </span>\n" +
    "                <span ng-if=\"attributeRendererDef.formatterConfig.type != 0\">\n" +
    "                    {{listScope.Controller.actionTooltipService.getFormattedValue(attributeRendererDef, item)}}\n" +
    "                </span>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "</table>\n" +
    "");
}]);

angular.module("edge/widget/list/edgeListWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/list/edgeListWidget.tpl.html",
    "<div class=\"edge-list-no-selection edge-list-no-hover\">\n" +
    "    <!-- @formatter:off -->\n" +
    "    <style>\n" +
    "        .list-group-item.flow.{{::Controller.liClass}} {\n" +
    "            margin: {{::Controller.config.flow.margin.value}}px 0 0 {{::Controller.config.flow.margin.value}}px;\n" +
    "            font-size: {{::Controller.bodyFontSize}};\n" +
    "            width: {{Controller.flowWidth}}px;\n" +
    "        }\n" +
    "        .eeList div.flex-box.{{::Controller.liClass}} {\n" +
    "            padding: {{::Controller.itemPadding}};\n" +
    "        }\n" +
    "        {{Controller.styleClassesAsString}}\n" +
    "        .{{::Controller.liClass}} table.listCell {width:100%}\n" +
    "        .{{::Controller.liClass}} col.listItemLabel {width:0%}\n" +
    "        .{{::Controller.liClass}} col.listItemValue {width:100%}\n" +
    "        .{{::Controller.liClass}} .isFlow col.listItemLabel {width:50%}\n" +
    "        .{{::Controller.liClass}} .isFlow col.listItemValue {width:50%}\n" +
    "        .{{::Controller.liClass}} td {padding-right: 5px; white-space:nowrap; text-overflow: ellipsis; overflow:hidden}\n" +
    "        .{{::Controller.liClass}} td.listItemLabel {text-align: right; padding-left: 5px;}\n" +
    "        .{{::Controller.liClass}} .isFlow td.listItemLabel {max-width: 0}\n" +
    "        .{{::Controller.liClass}} td.listItemValue {text-align: left; max-width: 0} /* max-width to ensure overflow works - strange but works... */\n" +
    "        .{{::Controller.liClass}} .isFlow td.value-only {text-align: center; padding-left: 5px;}\n" +
    "        .{{::Controller.liClass}} .flex-box {display: flex; align-items: center}\n" +
    "        .{{::Controller.liClass}} .grow {flex-grow: 1;}\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "    <edge-list ng-if=\"Controller.canRender()\" items=\"Controller.listItems\" unique-property=\"__recordKey\"\n" +
    "               selected-item=\"Controller.selectedItem\" type=\"{{::Controller.layoutType()}}\" class=\"edge-list-widget\"\n" +
    "               li-class=\"::Controller.liClass\" selectable=\"Controller.selectable\" empty-message=\" \">\n" +
    "        <div mn-touch class=\"{{::(listScope.Controller.liClass+listScope.Controller.noSelectClass)}} flex-box\" ng-mouseenter=\"listScope.Controller.mouseEnter(item)\" ng-mouseleave=\"listScope.Controller.mouseLeave(item)\" hold=\"listScope.Controller.hold(item,$event)\" data-record-key=\"{{item.__recordKey}}\">\n" +
    "            <div ng-if=\"::listScope.Controller.hasFloatLeft\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatLeftItems\">\n" +
    "                    <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\" ng-attr-style=\"padding-right: {{::listScope.Controller.config.itemPadding.value}}px\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"grow\">\n" +
    "                <ng-include src=\"::'edge/widget/list/edgeListCell.tpl.html'\"></ng-include>\n" +
    "            </div>\n" +
    "            <div ng-if=\"::listScope.Controller.hasFloatRight\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatRightItems\">\n" +
    "                    <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/map/config/edgeMapWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/map/config/edgeMapWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"MapWidgetWizardController as MapConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!MapConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"false\" dialog-mode=\"true\" on-save=\"MapConfigCtrlr.handleSave\"\n" +
    "        on-cancel=\"MapConfigCtrlr.handleCancel\" ng-if=\"MapConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Map'|translate}}\" index=\"0\" validate=\"MapConfigCtrlr.validateBaseSetting()\"\n" +
    "                          use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Map Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Tile Provider Info</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('tileProvider')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('tileProvider')\"\n" +
    "                    items=\"::MapConfigCtrlr.tileProviders\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('autoZoomLevel')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel')\">\n" +
    "                </edge-property-control>\n" +
    "                <div class=\"col-sm-12 property-control\">\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        label=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').displayName}}\">\n" +
    "                        <edge-number-spinner inputname=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').name}}\"\n" +
    "                            isrequired=\"true\"\n" +
    "                            ng-model=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('minZoom').value\"\n" +
    "                            reload=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                            enable=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                            minimum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').constraints.minimum\"\n" +
    "                            maximum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').constraints.maximum\">\n" +
    "                        </edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        label=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').displayName}}\">\n" +
    "                        <edge-number-spinner inputname=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').name}}\"\n" +
    "                            isrequired=\"true\"\n" +
    "                            ng-model=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('maxZoom').value\"\n" +
    "                            reload=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                            enable=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                            minimum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').constraints.minimum\"\n" +
    "                            maximum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').constraints.maximum\">\n" +
    "                        </edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <h4 translate>Initial Zoom Level and Center Point</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                                       property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('zoomToFit')\"\n" +
    "                                       property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomToFit')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomToFit').value\">\n" +
    "                    <edge-property-control label-width=\"3\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_zoom')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_zoom')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_lat')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_lat')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_lng')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_lng')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <h4 translate>Map Controls</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('zoomControlPosition')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomControlPosition')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Addtional Options</h4>\n" +
    "                <hr>\n" +
    "                <!--\n" +
    "                YEL-1367: While working with Dark themes Brian decided that turning of world wrap is too ugly and we should just leave it on\n" +
    "                Going to leave the option in the properties and just hide the control to change it so we can easily turn the feature back on\n" +
    "                if needed.\n" +
    "\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('wrap')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('wrap')\">\n" +
    "                </edge-property-control>\n" +
    "                -->\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('geoSearch')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('geoSearch')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Markers'|translate}}\" index=\"1\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"padding-bottom: 20px\">\n" +
    "                <h4 class=\"top\" translate>Base Marker Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_lat')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_lat')\"\n" +
    "                    items=\"::MapConfigCtrlr.attributesList\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_lng')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_lng')\"\n" +
    "                    items=\"::MapConfigCtrlr.attributesList\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_cluster_on')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_cluster_on')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_labelOn')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_labelOn')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Marker Properties</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"4\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_placementType')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_placementType')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-composite-icon-formatter formatter=\"MapConfigCtrlr.primaryIcon\"\n" +
    "                    options=\"::MapConfigCtrlr.formatterOptions\"\n" +
    "                    attribute-defs=\"::MapConfigCtrlr.dataAttributes\">\n" +
    "                </edge-composite-icon-formatter>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Marker Labels'|translate}}\" index=\"2\" use-form-validation=\"labelConfig\"\n" +
    "            ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_labelOn').value\">\n" +
    "            <form name=\"labelConfig\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Label Properties</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_labelPosition')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_labelPosition')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    items=\"::MapConfigCtrlr.attributesList\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('marker_labelAttribute')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_labelAttribute')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-labeled-control validation=\"true\" required=\"true\" label-width=\"6\" label=\"{{::'Formatter' | translate}}\" class=\"col-sm-6\">\n" +
    "                    <edge-formatter-chooser config=\"MapConfigCtrlr.markerFormatter\" show-icon=\"false\"\n" +
    "                        attributes=\"::MapConfigCtrlr.dataAttributes\"\n" +
    "                        attribute-name=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('marker_labelAttribute').value\">\n" +
    "                    </edge-formatter-chooser>\n" +
    "                </edge-labeled-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.primaryIcon.layers[0].fillColor.isDerived\" id=\"legend\" label=\"{{::'Legend'|translate}}\" index=\"3\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendPosition')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendPosition')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendPosition').value !== 'None'\">\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendTitle')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendTitle')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendTextColor')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendTextColor')\">\n" +
    "                    </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Optional Layers'|translate}}\" id=\"optionalLayers\" index=\"5\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Optional Layers Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('showWeatherLayers')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showWeatherLayers')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('showHeatMapLayer')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showHeatMapLayer')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showHeatMapLayer').value\"\n" +
    "            label=\"{{::'Heat Map'|translate}}\" index=\"6\" substep=\"true\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Heat Map Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_scaleRadius')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_scaleRadius')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_radius')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_radius')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" style=\"clear: both;\" label-width=\"6\" validation=\"true\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_minopacity')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_minopacity')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_maxopacity')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_maxopacity')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_blur')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_blur')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Aggregated Heat Map</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('aggregatedHeatMap')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('aggregatedHeatMap')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('aggregatedHeatMap').value\">\n" +
    "                    <edge-property-control label-width=\"3\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_intensity')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_intensity')\"\n" +
    "                        items=\"::MapConfigCtrlr.attributesList\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control label-width=\"3\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('heatMap_showMarkers')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('heatMap_showMarkers')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showWeatherLayers').value\"\n" +
    "            label=\"{{::'Weather'|translate}}\" index=\"8\" substep=\"true\" use-form-validation=\"config\"\n" +
    "            validate=\"MapConfigCtrlr.validateAPIKey()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal tableList\" style=\"height: 100%;\">\n" +
    "                <edge-panel>\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div style=\"width: 100%\">\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label style=\"padding-left: 15px\" translate>Enable Layer</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <label style=\"padding-left: 20px\" translate>Name</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate>On by default</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-2\">\n" +
    "                                <label translate>Layer Opacity</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <edge-list items=\"panelScope.MapConfigCtrlr.weatherLayers\" selected-item=\"panelScope.ruleSetDialog.selectedRule\" type=\"reorderable\">\n" +
    "                            <div class=\"row with-padding\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.enabled\">\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <div class=\"text\" title=\"{{::item.name}}\">{{::item.name}}</div>\n" +
    "                                </div>\n" +
    "                                <div ng-if=\"item.enabled\">\n" +
    "                                    <div class=\"col-sm-3\">\n" +
    "                                        <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.layer.visible\">\n" +
    "                                    </div>\n" +
    "                                    <div class=\"col-sm-2\">\n" +
    "                                        <edge-labeled-control class=\"col-sm-12\" label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                                            <edge-number-spinner inputname=\"{{::'layeropacity-'+$index}}\" ng-model=\"item.layer.options.opacity\" isrequired=\"true\" step=\"0.1\" minimum=\"0\" maximum=\"1\">\n" +
    "                                            </edge-number-spinner>\n" +
    "                                        </edge-labeled-control>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </edge-panel-body>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"MapConfigCtrlr.onShowPreview()\"\n" +
    "            on-hide=\"MapConfigCtrlr.hidePreview()\" id=\"preview\" index=\"10\">\n" +
    "            <edge-preview-widget ng-if=\"MapConfigCtrlr.showPreview\" controller=\"::MapConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"MapConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"MapConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/piechart/config/edgePieChartAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/piechart/config/edgePieChartAttributeDef.tpl.html",
    "<div class=\"row with-padding\">\n" +
    "    <div class=\"col-sm-4\">\n" +
    "        <ui-select ng-model=\"attributeRendererDef.column\" append-to-body=\"true\">\n" +
    "            <ui-select-match theme=\"bootstrap\">\n" +
    "                {{$select.selected.label}}\n" +
    "            </ui-select-match>\n" +
    "            <ui-select-choices\n" +
    "                    repeat=\"item.value as item in attributesList | filter: $select.search\">\n" +
    "                <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "            </ui-select-choices>\n" +
    "        </ui-select>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-4\">\n" +
    "        <edge-labeled-control label-width=\"0\" style=\"margin-bottom: 0\">\n" +
    "            <input class=\"form-control\" ng-model=\"attributeRendererDef.labelText\" placeholder=\"{{attributeRendererDef.column}}\">\n" +
    "        </edge-labeled-control>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-4\">\n" +
    "        <div class=\"eeColorPickerButton\" ng-click=\"showEditRendererTemplate()\">\n" +
    "            <div class=\"input-group\">\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                    <button ng-if=\"pattern\" type=\"button\" class=\"eeIconPreview btn btn-default\" style=\"padding:0px\">\n" +
    "                        <img ng-src=\"{{pattern}}\">\n" +
    "                    </button>\n" +
    "                    <button ng-if=\"hex\" type=\"button\" class=\"eeColorPatch btn btn-default\">\n" +
    "                        <div ng-style=\"{'background-color': hex}\"></div>\n" +
    "                    </button>\n" +
    "                </span>\n" +
    "                <input type=\"text\" class=\"form-control disabled\"\n" +
    "                    placeholder=\"{{attributeRendererDef.fill}}\">\n" +
    "                <span class=\"input-group-btn\">\n" +
    "                    <button type=\"button\" class=\"form-control btn btn-default icon icon_pencil\"></button>\n" +
    "                </span>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/piechart/config/edgePieChartWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/piechart/config/edgePieChartWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"PieChartWidgetWizardController as PieChartConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!PieChartConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'><span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"!PieChartConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"PieChartConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"PieChartConfigCtrlr.handleCancel\" ng-if=\"PieChartConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base PieChart'|translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base PieChart Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-3\"></div>\n" +
    "                    <div class=\"col-sm-9\">\n" +
    "                        <div ng-if=\"PieChartConfigCtrlr.showWarning('STRING')\" class=\"alert alert-warning pre-validate\">\n" +
    "                            <i class=\"icon list-icon pull-left icon_exclamation_triangle\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i>\n" +
    "                            {{PieChartConfigCtrlr.warningMsg('STRING')}}\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('nameAttribute')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('nameAttribute')\"\n" +
    "                                       items=\"PieChartConfigCtrlr.nameAttributes\"></edge-property-control>\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-3\"></div>\n" +
    "                    <div class=\"col-sm-9\">\n" +
    "                        <div ng-if=\"PieChartConfigCtrlr.showWarning('NUMBER')\" class=\"alert alert-warning pre-validate\">\n" +
    "                            <i class=\"icon pull-left icon_exclamation_triangle\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i>\n" +
    "                            {{PieChartConfigCtrlr.warningMsg('NUMBER')}}\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('valueAttribute')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('valueAttribute')\"\n" +
    "                                       items=\"PieChartConfigCtrlr.valueAttributes\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('primaryAxisTitle')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('primaryAxisTitle')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Series'|translate}}\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal edgeFlexColumn\" style=\"height: 100%\">\n" +
    "                <div>\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('dynamicSeries')\"\n" +
    "                                           property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value === true\" class=\"edgeFlexColumn\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                           property-def=\"::PieChartConfigCtrlr.dynamicColumnTypeDef\"\n" +
    "                                           property-value=\"PieChartConfigCtrlr.dynamicColumnType\"\n" +
    "                                           items=\"PieChartConfigCtrlr.dynamicColumnTypesListForSingleColumn\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"PieChartConfigCtrlr.dynamicColumnType.value !== 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                               property-def=\"::PieChartConfigCtrlr.columnPatternDef\"\n" +
    "                                               property-value=\"PieChartConfigCtrlr.columnPattern\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"PieChartConfigCtrlr.dynamicColumnType.value === 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"3\" style=\"cursor: hand\"\n" +
    "                                               property-def=\"::PieChartConfigCtrlr.seriesColumnsExcludeDef\"\n" +
    "                                               property-value=\"PieChartConfigCtrlr.excludedColumns\"\n" +
    "                                               items=\"PieChartConfigCtrlr.dsAttributes\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <edge-labeled-control label=\"{{::'Color Palette' | translate}}\" label-width=\"3\" validation=\"false\">\n" +
    "                        <edge-color-palette-formatter class=\"col-sm-12\" options=\"PieChartConfigCtrlr.paletteOptions\"\n" +
    "                                                      formatter=\"PieChartConfigCtrlr.colorPalette\">\n" +
    "                        </edge-color-palette-formatter>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div class=\"edgeFlexColumn\" style=\"height: 100%\"\n" +
    "                     ng-if=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value === false\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Display Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:5px\">Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"PieChartConfigCtrlr.seriesSelected\"\n" +
    "                                       type=\"reorderable\"\n" +
    "                                       items=\"PieChartConfigCtrlr.seriesRendererConfig.seriesRendererDefs\">\n" +
    "                                <edge-pie-chart-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                       attributes-list=\"::listScope.PieChartConfigCtrlr.dsAttributes\"></edge-pie-chart-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"PieChartConfigCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"PieChartConfigCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"PieChartConfigCtrlr.seriesSelected==null || PieChartConfigCtrlr.seriesRendererConfig.seriesRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Options'|translate}}\" index=\"2\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showLegend')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('showLegend')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('radius')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('radius')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showLabel')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('showLabel')\"></edge-property-control>\n" +
    "                <edge-property-control ng-if=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('showLabel').value\" class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                                       property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('labelDistance')\"\n" +
    "                                       property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('labelDistance')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                    property-def=\"::PieChartConfigCtrlr.propertyBundleDef.findPropertyDefByName('showZeroValue')\"\n" +
    "                    property-value=\"PieChartConfigCtrlr.propertyBundle.findPropertyValueByName('showZeroValue')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\"\n" +
    "                          on-show=\"PieChartConfigCtrlr.previewShown()\" on-hide=\"PieChartConfigCtrlr.hidePreview()\">\n" +
    "            <edge-preview-widget ng-if=\"PieChartConfigCtrlr.showPreview\" controller=\"::PieChartConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"PieChartConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"PieChartConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/piechart/config/edit-renderer-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/piechart/config/edit-renderer-dialog.tpl.html",
    "<form name=\"chartSeriesPropForm\" class=\"form-horizontal\">\n" +
    "    <edge-property-control style=\"clear: both;\" class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "        property-def=\"::seriesColorDef\" property-value=\"chartSeriesDef.color\">\n" +
    "    </edge-property-control>\n" +
    "    <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "        property-def=\"::seriesAlphaDef\" property-value=\"chartSeriesDef.alpha\">\n" +
    "    </edge-property-control>\n" +
    "    <edge-property-control style=\"clear: both\" class=\"col-sm-6\" label-width=\"4\"\n" +
    "        property-def=\"::seriesFillDef\" property-value=\"chartSeriesDef.fill\" items=\"::fillList\">\n" +
    "    </edge-property-control>\n" +
    "    <div ng-if=\"chartSeriesDef.fill.value === 'pattern'\" style=\"clear: both\">\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesPatternDef\" property-value=\"chartSeriesDef.pattern\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesPatternlSizeDef\" property-value=\"chartSeriesDef.patternSize\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control style=\"clear: both\" class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesRotationDef\" property-value=\"chartSeriesDef.rotation\">\n" +
    "        </edge-property-control>\n" +
    "        <edge-property-control class=\"col-sm-6\" label-width=\"4\" validation=\"true\"\n" +
    "            property-def=\"::seriesScaleDef\" property-value=\"chartSeriesDef.scale\">\n" +
    "        </edge-property-control>\n" +
    "    </div>\n" +
    "    <!-- need this to ensure everything fits inside the dialog -->\n" +
    "    <div style=\"clear: both\"></div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/widget/proxy/config/edgeProxyConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/proxy/config/edgeProxyConfigWizard.tpl.html",
    "<div ng-controller=\"ProxyWizardController as ProxyConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!ProxyConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"ProxyConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"ProxyConfigCtrlr.handleCancel\">\n" +
    "        <edge-wizard-step label=\"Configure\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::ProxyConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"ProxyConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/proxy/edgeProxyWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/proxy/edgeProxyWidget.tpl.html",
    "<iframe ng-src=\"{{Controller.proxyUrl}}\" name=\"{{Controller.proxyFrameName}}\" width=\"100%\" height=\"100%\">Content should load for: {{Controller.proxyUrl}}\n" +
    "</iframe>\n" +
    "");
}]);

angular.module("edge/widget/regionmap/config/edgeRegionMapWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/regionmap/config/edgeRegionMapWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"RegionMapWidgetWizardController as MapConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!MapConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"false\" dialog-mode=\"true\" on-save=\"MapConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"MapConfigCtrlr.handleCancel\" ng-if=\"MapConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Map'|translate}}\" index=\"0\" validate=\"MapConfigCtrlr.validateBaseSetting()\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Map Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Tile Provider Info</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('tileProvider')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('tileProvider')\"\n" +
    "                    items=\"::MapConfigCtrlr.tileProviders\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('autoZoomLevel')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel')\">\n" +
    "                </edge-property-control>\n" +
    "                <div class=\"col-sm-12 property-control\">\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        label=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').displayName}}\">\n" +
    "                        <edge-number-spinner inputname=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').name}}\"\n" +
    "                             isrequired=\"true\"\n" +
    "                             ng-model=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('minZoom').value\"\n" +
    "                             reload=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                             enable=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                             minimum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').constraints.minimum\"\n" +
    "                             maximum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoom').constraints.maximum\">\n" +
    "                        </edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        label=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').displayName}}\" >\n" +
    "                        <edge-number-spinner inputname=\"{{::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').name}}\"\n" +
    "                             isrequired=\"true\"\n" +
    "                             ng-model=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('maxZoom').value\"\n" +
    "                             reload=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                             enable=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('autoZoomLevel').value\"\n" +
    "                             minimum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').constraints.minimum\"\n" +
    "                             maximum=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('maxZoom').constraints.maximum\">\n" +
    "                        </edge-number-spinner>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <h4 translate>Initial Zoom Level and Center Point</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('zoomToFit')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomToFit')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"! MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomToFit').value\">\n" +
    "                    <edge-property-control label-width=\"3\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_zoom')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_zoom')\"></edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_lat')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_lat')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('center_lng')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('center_lng')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <h4 translate>Map Controls</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('zoomControlPosition')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('zoomControlPosition')\">\n" +
    "                </edge-property-control>\n" +
    "                <h4 translate>Addtional Options</h4>\n" +
    "                <hr>\n" +
    "                <!--\n" +
    "                YEL-1367: While working with Dark themes Brian decided that turning of world wrap is too ugly and we should just leave it on\n" +
    "                Going to leave the option in the properties and just hide the control to change it so we can easily turn the feature back on\n" +
    "                if needed.\n" +
    "\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('wrap')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('wrap')\">\n" +
    "                </edge-property-control>\n" +
    "                -->\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('geoSearch')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('geoSearch')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Regions'|translate}}\" index=\"1\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Region Config</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"col-sm-10\">\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\" items=\"::MapConfigCtrlr.jsonFileAttributesList\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionFileAttribute')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionFileAttribute')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionFileLocation')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionFileLocation')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\" attribute-defs=\"::MapConfigCtrlr.dataAttributes\"\n" +
    "                        options=\"::MapConfigCtrlr.fillColorOptions\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionFill')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionFill')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionBorderWidth')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionBorderWidth')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control validation=\"true\" label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionBorderOpacity')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionBorderOpacity')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "                <h4 class=\"top\" translate>Additional Adornments</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"col-sm-10\">\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionLabelOn')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionLabelOn')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('showMarker')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showMarker')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionLabelOn').value || MapConfigCtrlr.propertyBundle.findPropertyValueByName('showMarker').value\"\n" +
    "            label=\"{{::'Labels & Markers'|translate}}\" index=\"2\" use-form-validation=\"labelConfig\">\n" +
    "            <form name=\"labelConfig\" class=\"form-horizontal\">\n" +
    "                <div ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showMarker').value\">\n" +
    "                    <h4 translate>Marker Properties</h4>\n" +
    "                    <hr>\n" +
    "                    <edge-composite-icon-formatter formatter=\"MapConfigCtrlr.markerIcon\"\n" +
    "                        options=\"::MapConfigCtrlr.markerIconOptions\"\n" +
    "                 \n" +
    "                        attribute-defs=\"::MapConfigCtrlr.dataAttributes\">\n" +
    "                    </edge-composite-icon-formatter>\n" +
    "                </div>\n" +
    "                <div ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionLabelOn').value\">\n" +
    "                    <h4 translate>Label Properties</h4>\n" +
    "                    <hr>\n" +
    "                    <edge-property-control validation=\"true\" class=\"col-sm-8\" label-width=\"4\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('regionLabelAttribute')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionLabelAttribute')\" items=\"::MapConfigCtrlr.attributesList\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-labeled-control validation=\"true\" required=\"true\" label-width=\"4\" label=\"{{::'Formatter' | translate}}\" class=\"col-sm-8\">\n" +
    "                        <edge-formatter-chooser config=\"MapConfigCtrlr.regionLabelFormatter\" show-icon=\"false\"\n" +
    "                            attributes=\"::MapConfigCtrlr.dataAttributes\"\n" +
    "                            attribute-name=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('regionLabelAttribute').value\">\n" +
    "                        </edge-formatter-chooser>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-property-control ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showMarker').value\" label-width=\"4\" class=\"col-sm-8\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('labelPosition')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('labelPosition')\">\n" +
    "                    </edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.regionFill.isDerived || MapConfigCtrlr.propertyBundle.findPropertyValueByName('showMarker').value && MapConfigCtrlr.markerIcon.layers[0].fillColor.isDerived\" id=\"legend\" label=\"{{::'Legend'|translate}}\" index=\"3\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendPosition')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendPosition')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendPosition').value !== 'None'\">\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendTitle')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendTitle')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control label-width=\"5\"\n" +
    "                        property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('legendTextColor')\"\n" +
    "                        property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('legendTextColor')\">\n" +
    "                    </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Optional Layers'|translate}}\" id=\"optionalLayers\" index=\"4\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Optional Layers Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                    property-def=\"::MapConfigCtrlr.propertyBundleDef.findPropertyDefByName('showWeatherLayers')\"\n" +
    "                    property-value=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showWeatherLayers')\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step ng-if=\"MapConfigCtrlr.propertyBundle.findPropertyValueByName('showWeatherLayers').value\"\n" +
    "            label=\"{{::'Weather'|translate}}\" index=\"5\" substep=\"true\" use-form-validation=\"config\"\n" +
    "            validate=\"MapConfigCtrlr.validateAPIKey()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal tableList\" style=\"height: 100%;\">\n" +
    "                <edge-panel>\n" +
    "                    <edge-panel-header hide-label=\"true\">\n" +
    "                        <div style=\"width: 100%\">\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label style=\"padding-left: 15px\" translate>Enable Layer</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-4\">\n" +
    "                                <label style=\"padding-left: 20px\" translate>Name</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-3\">\n" +
    "                                <label translate>On by default</label>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-sm-2\">\n" +
    "                                <label translate>Layer Opacity</label>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <edge-list items=\"panelScope.MapConfigCtrlr.weatherLayers\" selected-item=\"panelScope.ruleSetDialog.selectedRule\" type=\"reorderable\">\n" +
    "                            <div class=\"row with-padding\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.enabled\">\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <div class=\"text\" title=\"{{::item.name}}\">{{::item.name}}</div>\n" +
    "                                </div>\n" +
    "                                <div ng-if=\"item.enabled\">\n" +
    "                                    <div class=\"col-sm-3\">\n" +
    "                                        <input type=\"checkbox\" edge-boolean-switch ng-model=\"item.layer.visible\">\n" +
    "                                    </div>\n" +
    "                                    <div class=\"col-sm-2\">\n" +
    "                                        <edge-labeled-control class=\"col-sm-12\" label-width=\"0\" validation=\"true\" show-feedback-icon=\"false\">\n" +
    "                                            <edge-number-spinner inputname=\"{{::'layeropacity-'+$index}}\" ng-model=\"item.layer.options.opacity\" isrequired=\"true\" step=\"0.1\" minimum=\"0\" maximum=\"1\">\n" +
    "                                            </edge-number-spinner>\n" +
    "                                        </edge-labeled-control>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-list>\n" +
    "                    </edge-panel-body>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"MapConfigCtrlr.onShowPreview()\"\n" +
    "            on-hide=\"MapConfigCtrlr.hidePreview()\" id=\"preview\" index=\"6\">\n" +
    "            <edge-preview-widget ng-if=\"MapConfigCtrlr.showPreview\" controller=\"::MapConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"MapConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"MapConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/sm/config/edgeSmAttributeDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/sm/config/edgeSmAttributeDef.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\">\n" +
    "        <div class=\"col-sm-5\">\n" +
    "            <ui-select ng-model=\"attributeRendererDef.column\" append-to-body=\"true\">\n" +
    "                <ui-select-match theme=\"bootstrap\"\n" +
    "                                 allow-clear=\"false\"\n" +
    "                                 placeholder=\"{{'Select Attribute ...' | translate}}\">\n" +
    "                    {{$select.selected.label}}\n" +
    "                </ui-select-match>\n" +
    "                <ui-select-choices\n" +
    "                        repeat=\"item.value as item in attributesList | filter: $select.search\">\n" +
    "                    <span ng-bind-html=\"item.label | highlight: $select.search\"></span>\n" +
    "                </ui-select-choices>\n" +
    "            </ui-select>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-5\">\n" +
    "            <input class=\"form-control\"\n" +
    "                   ng-disabled=\"!attributeRendererDef.labelOn\"\n" +
    "                   ng-model=\"attributeRendererDef.labelText\"\n" +
    "                   placeholder=\"{{attributeRendererDef.column}}\"></input>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-2\">\n" +
    "            <input type=\"checkbox\"\n" +
    "                   name=\"labelOn\"\n" +
    "                   ng-model=\"attributeRendererDef.labelOn\"\n" +
    "                   edge-boolean-switch>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/widget/sm/config/edgeSMWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/sm/config/edgeSMWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"SMWidgetWizardController as SMConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!SMConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"SMConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"SMConfigCtrlr.handleCancel\" ng-if=\"SMConfigCtrlr.initialized\">\n" +
    "        <edge-wizard-step label=\"{{'Base Small Multiples' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Name</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <h4 class=\"top\" translate>Data Parsing</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('dataStructure')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure')\"></edge-property-control>\n" +
    "                <div ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure').value == SMConfigCtrlr.SINGLE_COLUMN\"\n" +
    "                     style=\"clear: both;\">\n" +
    "\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-3\"></div>\n" +
    "                        <div class=\"col-sm-9\">\n" +
    "                            <div ng-if=\"SMConfigCtrlr.showWarning('STRING')\" class=\"alert alert-warning pre-validate\">\n" +
    "                                <i class=\"icon list-icon pull-left icon_exclamation_triangle\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i>\n" +
    "                                {{SMConfigCtrlr.warningMsg('STRING')}}\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('nameAttribute')\"\n" +
    "                                           property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('nameAttribute')\"\n" +
    "                                           items=\"SMConfigCtrlr.nameAttributes\"></edge-property-control>\n" +
    "\n" +
    "                </div>\n" +
    "                <div ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure').value == SMConfigCtrlr.SINGLE_COLUMN\"\n" +
    "                     style=\"clear: both;\">\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-3\"></div>\n" +
    "                        <div class=\"col-sm-9\">\n" +
    "                            <div ng-if=\"SMConfigCtrlr.showWarning('NUMBER')\" class=\"alert alert-warning pre-validate\">\n" +
    "                                <i class=\"icon pull-left icon_exclamation_triangle\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i>\n" +
    "                                {{SMConfigCtrlr.warningMsg('NUMBER')}}\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('valueAttribute')\"\n" +
    "                                           property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('valueAttribute')\"\n" +
    "                                           items=\"SMConfigCtrlr.valueAttributes\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <h4 class=\"top\" translate>X-Axis</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-3\"></div>\n" +
    "                    <div class=\"col-sm-9\">\n" +
    "                        <div ng-if=\"SMConfigCtrlr.showWarning('DATE')\" class=\"alert alert-warning pre-validate\">\n" +
    "                            <i class=\"icon pull-left icon_exclamation_triangle\" ng-class=\"item.adapter.adapterTypeHelper.getDomainIcon()\"></i>\n" +
    "                            {{SMConfigCtrlr.warningMsg('DATE')}}\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('xAxisAttribute')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('xAxisAttribute')\"\n" +
    "                                       items=\"SMConfigCtrlr.xAxisAttributes\"></edge-property-control>\n" +
    "\n" +
    "\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Series'|translate}}\" index=\"1\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <div>\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('dynamicSeries')\"\n" +
    "                                           property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value === true\">\n" +
    "                    <h4 translate>Dynamic Series Configuration</h4>\n" +
    "                    <hr>\n" +
    "                    <edge-property-control ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure').value == SMConfigCtrlr.SINGLE_COLUMN\"\n" +
    "                                           class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::SMConfigCtrlr.dynamicColumnTypeDef\"\n" +
    "                                           property-value=\"SMConfigCtrlr.dynamicColumnType\"\n" +
    "                                           items=\"SMConfigCtrlr.dynamicColumnTypesListForSingleColumn\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure').value != SMConfigCtrlr.SINGLE_COLUMN\"\n" +
    "                                           class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::SMConfigCtrlr.dynamicColumnTypeDef\"\n" +
    "                                           property-value=\"SMConfigCtrlr.dynamicColumnType\"\n" +
    "                                           items=\"SMConfigCtrlr.dynamicColumnTypesListForMultipleColumn\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"SMConfigCtrlr.dynamicColumnType.value !== 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"1\" validation=\"true\"\n" +
    "                                               property-def=\"::SMConfigCtrlr.columnPatternDef\"\n" +
    "                                               property-value=\"SMConfigCtrlr.columnPattern\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                    <div ng-if=\"SMConfigCtrlr.dynamicColumnType.value === 'all numeric'\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" label-width=\"2\"\n" +
    "                                               property-def=\"::SMConfigCtrlr.seriesColumnsExcludeDef\"\n" +
    "                                               property-value=\"SMConfigCtrlr.excludedColumns\"\n" +
    "                                               items=\"SMConfigCtrlr.dsAttributes\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div style=\"height: calc(100% - 110px)\"\n" +
    "                     ng-if=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('dynamicSeries').value === false\">\n" +
    "                    <h4 translate>Static Series Configuration</h4>\n" +
    "                    <hr>\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-5\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-5\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Use Label</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"SMConfigCtrlr.attributeSelected\"\n" +
    "                                       type=\"{{SMConfigCtrlr.propertyBundle.findPropertyValueByName('dataStructure').value == SMConfigCtrlr.MULTIPLE_COLUMN ? 'reorderable' : 'simple'}}\"\n" +
    "                                       items=\"SMConfigCtrlr.manualSeriesConfig.attributeRendererDefs\">\n" +
    "                                <edge-sm-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                       attributes-list=\"::listScope.SMConfigCtrlr.dsAttributes\"></edge-sm-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"SMConfigCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"SMConfigCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"SMConfigCtrlr.attributeSelected==null || SMConfigCtrlr.manualSeriesConfig.attributeRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Renderer'|translate}}\" index=\"2\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Chart Renderer</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('chartType')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('chartType')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('baseColor')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('baseColor')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('highlightColor')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('highlightColor')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('strokeWidth')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('strokeWidth')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::SMConfigCtrlr.propertyBundleDef.findPropertyDefByName('rowHeight')\"\n" +
    "                                       property-value=\"SMConfigCtrlr.propertyBundle.findPropertyValueByName('rowHeight')\"></edge-property-control>\n" +
    "                <h4 translate>Label Formatter</h4>\n" +
    "                <hr>\n" +
    "                <edge-font-formatter class=\"col-sm-6\" formatter=\"SMConfigCtrlr.labelFormatter\"\n" +
    "                    options=\"SMConfigCtrlr.labelFormatterOptions\">\n" +
    "                </edge-font-formatter>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"SMConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"SMConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"SMConfigCtrlr.showPreview\" controller=\"::SMConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"SMConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"SMConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/sm/edgeSMWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/sm/edgeSMWidget.tpl.html",
    "<div style=\"overflow-y: auto;\">\n" +
    "    <!-- @formatter:off -->\n" +
    "    <style>\n" +
    "\n" +
    "    .{{::Controller.widgetClass}} text {\n" +
    "      {{::Controller.fontString}}\n" +
    "      fill: {{::Controller.fontColor}};\n" +
    "      margin: 0;\n" +
    "      padding: 0;\n" +
    "      font-family: \"Open Sans\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n" +
    "    }\n" +
    "\n" +
    "    .{{::Controller.widgetClass}} svg:hover .line {\n" +
    "      stroke: {{::Controller.highlightColor}};\n" +
    "    }\n" +
    "\n" +
    "    .{{::Controller.widgetClass}} .line {\n" +
    "      fill: none;\n" +
    "      stroke: {{::Controller.strokeColor}};\n" +
    "      stroke-width: {{::Controller.strokeWidth}}px;\n" +
    "    }\n" +
    "\n" +
    "    .{{::Controller.widgetClass}} .area {\n" +
    "      fill: {{::Controller.baseColorRgba}};\n" +
    "    }\n" +
    "\n" +
    "    .{{::Controller.widgetClass}}  svg:hover .area {\n" +
    "       fill: {{::Controller.highlightColorRgba}};\n" +
    "    }\n" +
    "\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "<div class=\"edgeSM {{::Controller.widgetClass}}\">\n" +
    "    <edge-small-multiples smw-controller=\"Controller\"></edge-small-multiples>\n" +
    "</div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/config/edgeTableColumnCellConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/config/edgeTableColumnCellConfig.tpl.html",
    "<div style=\"height: 100%\">\n" +
    "    <div class=\"panel panel-default\" style=\"height:100%;min-width:650px;\">\n" +
    "        <div class=\"panel-heading\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "                    <label translate style=\"padding-left:15px\">Column Name</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "                    <label translate>Cell Renderer</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:20%;\">\n" +
    "                    <label translate>Cell Alignment</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:10%;\">\n" +
    "                    <label ng-if=\"!Controller.useVirtualScrolling\" translate>Word Wrap</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\">\n" +
    "            <edge-list selected-item=\"Controller.selectedItem\" items=\"Controller.columnConfig.columnDefs\">\n" +
    "                <edge-table-column-cell-def config=\"item\" columns=\"listScope.Controller.dataAttributes\"\n" +
    "                    controller=\"listScope.Controller\">\n" +
    "                </edge-table-column-cell-def>\n" +
    "            </edge-list>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/config/edgeTableColumnCellDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/config/edgeTableColumnCellDef.tpl.html",
    "<div class=\"with-padding\" style=\"width: 100%;\">\n" +
    "    <div class=\"row\" style=\"width: 100%;\">\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "            <div class=\"input-group\" style=\"table-layout: fixed;width:100%;\">\n" +
    "                <div class=\"input-group-addon\" style=\"width:65px;min-height:32px;\">\n" +
    "                    <small><small class=\"text-muted\">{{controller.getDataTypeName(config.type)}}</small></small>\n" +
    "                </div>\n" +
    "            <input type=\"text\"\n" +
    "                   disabled\n" +
    "                   class=\"form-control\"\n" +
    "                   ng-model=\"config.label\"\n" +
    "                   placeholder=\"{{config.column}}\"\n" +
    "                   ng-trim=\"false\"></input>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "            <edge-formatter-chooser\n" +
    "                    config=\"config.formatter\"\n" +
    "                    attributes=\"::controller.dataAttributes\"\n" +
    "                    attribute-name=\"config.column\"\n" +
    "                    options=\"::controller.formatterOptions\">\n" +
    "            </edge-formatter-chooser>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:20%;\">\n" +
    "            <select class=\"form-control\"\n" +
    "                    ng-model=\"config.formatter.alignment\"\n" +
    "                    ng-options=\"textAlignment.className as textAlignment.name for textAlignment in controller.textAlignments\"></select>\n" +
    "\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:10%;\">\n" +
    "            <edge-check-box ng-if=\"!controller.useVirtualScrolling\" class=\"pull-right\" ng-model=\"config.formatter.wordWrap\">\n" +
    "            </edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/config/edgeTableColumnConfig.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/config/edgeTableColumnConfig.tpl.html",
    "<div style=\"height: 100%\">\n" +
    "    <div class=\"panel panel-default\" style=\"height: 100%;min-width:850px;\">\n" +
    "        <div class=\"panel-heading\">\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:20%;\">\n" +
    "                    <label translate style=\"padding-left:15px\">Display Name</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:25%;\">\n" +
    "                    <label translate style=\"padding-left:10px\">Column Width (pixels)</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:10%;\">\n" +
    "                    <label translate style=\"padding-left:10px\">Header Alignment</label>\n" +
    "                </div>\n" +
    "                <div class=\"nonresponsive-col\" style=\"width:10%;\">\n" +
    "                    <label style=\"padding-right:10px;\" class=\"pull-right\" translate>Visible</label>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\">\n" +
    "            <edge-list selected-item=\"Controller.selectedItem\" type=\"reorderable\" items=\"Controller.columnConfig.columnDefs\" style=\"display:flex\">\n" +
    "                <edge-table-column-def config=\"item\" columns=\"listScope.Controller.dataAttributes\"\n" +
    "                    controller=\"listScope.Controller\">\n" +
    "                </edge-table-column-def>\n" +
    "            </edge-list>\n" +
    "        </div>\n" +
    "        <div class=\"panel-footer\">\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_plus\" ng-click=\"Controller.addRow()\"></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default icon icon_minus\" ng-click=\"Controller.removeRow()\"\n" +
    "                    ng-disabled=\"Controller.selectedItem==null\"></button>\n" +
    "            <button type=\"button\" class=\"btn btn-default\" ng-click=\"Controller.removeAllRows()\"\n" +
    "                    ng-disabled=\"Controller.columnConfig.columnDefs.length === 0\"><span translate>Remove All</span></button>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/config/edgeTableColumnDef.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/config/edgeTableColumnDef.tpl.html",
    "<div class=\"with-padding\" style=\"width:100%;\">\n" +
    "    <div class=\"row\" style=\"width:100%;\">\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:35%;\">\n" +
    "            <div class=\"input-group\" style=\"table-layout: fixed;width:100%;\">\n" +
    "                <div class=\"input-group-addon\" style=\"width:65px;min-height:32px;\">\n" +
    "                    <small><small>{{controller.getDataTypeName(config.type)}}</small></small>\n" +
    "                </div>\n" +
    "                <ui-select ng-model=\"config.column\" append-to-body=\"true\"\n" +
    "                           on-select=\"controller.attributeSelected(config, $item)\">\n" +
    "                    <ui-select-match>{{$select.selected.name}}</ui-select-match>\n" +
    "                    <ui-select-choices\n" +
    "                            repeat=\"column.name as column in controller.dataAttributes | filter: $select.search | orderBy: 'name'\"\n" +
    "                            style=\"width:200%;\">\n" +
    "                        <small class=\"pull-right\" ng-bind-html=\"column.typeAsString\"></small>\n" +
    "                        <span ng-bind-html=\"column.name | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:20%;\">\n" +
    "            <input type=\"text\"\n" +
    "                   class=\"form-control\"\n" +
    "                   ng-model=\"config.label\"\n" +
    "                   placeholder=\"{{config.column}}\"\n" +
    "                   ng-trim=\"false\"></input>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:15%;\">\n" +
    "            <div class=\"input-group-btn\" style=\"margin:0;\">\n" +
    "                <select class=\"form-control\"\n" +
    "                        ng-model=\"config.widthOption\"\n" +
    "                        ng-options=\"option.value as option.label for option in controller.getWidthOptions()\"></select>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:13%;\">\n" +
    "            <div class=\"input-group-btn\" style=\"margin:0;min-width:80px\">\n" +
    "                <!-- would like to just place spinner in edge-label-control for error messages but couldn't get it to work -->\n" +
    "\n" +
    "                <edge-labeled-control validation=\"true\"\n" +
    "                                      label-width=\"0\"\n" +
    "                                      show-feedback-icon=\"false\"\n" +
    "                                      style=\"margin:0px;\">\n" +
    "                    <edge-number-spinner inputname=\"{{config.name}}\"\n" +
    "                                         ng-model=\"config.width\"\n" +
    "                                         step=\"1\"\n" +
    "                                         minimum=\"10\"\n" +
    "                                         maximum=\"1200\"\n" +
    "                                         isrequired=\"true\"\n" +
    "                                         style=\"border-left: 0px; margin-left: -1\">\n" +
    "                    </edge-number-spinner>\n" +
    "                </edge-labeled-control>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:12%;\">\n" +
    "            <select class=\"form-control pull-right\"\n" +
    "                    ng-model=\"config.headerAlignment\"\n" +
    "                    ng-options=\"textAlignment.className as textAlignment.name for textAlignment in controller.textAlignments\"></select>\n" +
    "\n" +
    "        </div>\n" +
    "        <div class=\"nonresponsive-col\" style=\"width:5%;\">\n" +
    "            <edge-check-box ng-model=\"config.shown\" class=\"pull-right\">\n" +
    "            </edge-check-box>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/config/edgeTableConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/config/edgeTableConfigWizard.tpl.html",
    "<div ng-controller=\"TableWizardController as TableConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!TableConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "\n" +
    "    <edge-wizard force-progression=\"!TableConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"TableConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TableConfigCtrlr.handleCancel\" ng-if=\"TableConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{::'Base Table'|translate}}\" index=\"0\" use-form-validation=\"base\">\n" +
    "            <form name=\"base\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Base Options</h4>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <edge-labeled-control label=\"{{::'Default Font Size' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-property-control property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('fontSize')\"\n" +
    "                                           property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('fontSize')\"\n" +
    "                                           style=\"max-width:200px;\">\n" +
    "                    </edge-property-control>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{'Virtual Scrolling' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-radio-group name=\"useVirtualScroll\"\n" +
    "                                      ng-model=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('useVirtualScroll').value\">\n" +
    "                        <edge-radio-button ng-value=\"true\">\n" +
    "                            <span translate style=\"font-weight: bold\">Yes</span><br><span class=\"text-muted\" translate>Enables virtual scrolling.  This greatly improves performance of large datasets but it also requires uniform row heights.  Enabling virtual scrolling will disable word wrap within cell renderers.</span><br/>\n" +
    "                        </edge-radio-button>\n" +
    "                        <edge-radio-button ng-value=\"false\">\n" +
    "                            <span translate style=\"font-weight: bold\">No</span><br><span class=\"text-muted\" translate>Disables virtual scrolling.  This means that all rows will be loaded, which can cause performance issues with large datasets.  Disabling virtual scrolling will enable word wrap within cell renderers. Use of a Client Pagination Filter is highly recommended.</span><br/>\n" +
    "                        </edge-radio-button>\n" +
    "                    </edge-radio-group>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Allow Column Reordering' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-property-control property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('allowColumnReorder')\"\n" +
    "                                           property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('allowColumnReorder')\">\n" +
    "                    </edge-property-control>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Allow Column Hiding' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-property-control property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('allowColumnHiding')\"\n" +
    "                                           property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('allowColumnHiding')\">\n" +
    "                    </edge-property-control>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Show Row Count in Footer' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-property-control property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('showFooter')\"\n" +
    "                                           property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('showFooter')\">\n" +
    "                    </edge-property-control>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control label=\"{{::'Enable Row Shading' | translate}}\" label-width=\"3\">\n" +
    "                    <edge-property-control property-def=\"::TableConfigCtrlr.propertyBundleDef.findPropertyDefByName('useRowColorRule')\"\n" +
    "                                           property-value=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('useRowColorRule')\">\n" +
    "                    </edge-property-control>\n" +
    "                </edge-labeled-control>\n" +
    "                <edge-labeled-control ng-if=\"TableConfigCtrlr.propertyBundle.findPropertyValueByName('useRowColorRule').value == true\" label=\"{{::'Row Shading' | translate}}\" label-width=\"3\" validation=\"false\">\n" +
    "                    <edge-derivable-color\n" +
    "                                          config=\"TableConfigCtrlr.rowColorRule\"\n" +
    "                                          options=\"TableConfigCtrlr.rowColorRuleOptions\"\n" +
    "                                          attribute-defs=\"::TableConfigCtrlr.dataAttributes\"></edge-derivable-color>\n" +
    "                </edge-labeled-control>\n" +
    "                <h4 translate>Column Header Appearance</h4>\n" +
    "                <edge-font-formatter formatter=\"TableConfigCtrlr.headerStyle.staticFormatterObj\" options=\"TableConfigCtrlr.headerStyleOptions\"></edge-font-formatter>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Columns'|translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          validate=\"TableConfigCtrlr.validateColumnConfig()\"\n" +
    "                          use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <edge-table-column-config ng-if=\"TableConfigCtrlr.hasData\"></edge-table-column-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Column Renderers'|translate}}\"\n" +
    "                          index=\"2\"\n" +
    "                          use-form-validation=\"headerconfig\">\n" +
    "            <form name=\"headerconfig\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <edge-table-column-cell-config ng-if=\"TableConfigCtrlr.hasData\"></edge-table-column-cell-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Sort'|translate}}\" use-form-validation=\"sort\" index=\"3\">\n" +
    "            <form name=\"sort\" class=\"form-horizontal tableList\" style=\"height: 100%;\">\n" +
    "                <edge-select-sort-config ng-if=\"TableConfigCtrlr.columnConfig.value.columnDefs.length > 0\"></edge-select-sort-config>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"TableConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TableConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"TableConfigCtrlr.showPreview\" controller=\"::TableConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TableConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TableConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/edgeTableWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/edgeTableWidget.tpl.html",
    "<div class=\"edge-table-widget no-selection no-hover\">\n" +
    "    <div ui-grid=\"ctrlr.dataGridOptions\"\n" +
    "         ng-style=\"{width:ctrlr.width, height:ctrlr.height}\"\n" +
    "         ng-if=\"ctrlr.canRender()\"\n" +
    "         ui-grid-resize-columns\n" +
    "         ui-grid-move-columns\n" +
    "         ui-grid-selection\n" +
    "         ui-grid-auto-resize\n" +
    "         ui-grid-save-state\n" +
    "         class=\"grid grid-loading\"></div>\n" +
    "    <div ng-if=\"ctrlr.canRender() && ctrlr.options.columns == null\" class=\"alert alert-info\">\n" +
    "        <span translate>There are currently no columns defined.</span>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/edgeTableWidgetFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/edgeTableWidgetFooter.tpl.html",
    "<div style=\"padding:1px 0px;\">\n" +
    "    <span translate\n" +
    "          translate-params-total=\"ctrlr.data.unfilteredRecords.length\"\n" +
    "          ng-if=\"ctrlr.data.records.length == ctrlr.data.unfilteredRecords.length\">\n" +
    "        Showing {{total}}\n" +
    "    </span>\n" +
    "    <span translate translate-params-count=\"ctrlr.data.records.length\"\n" +
    "          translate-params-total=\"ctrlr.data.unfilteredRecords.length\"\n" +
    "          ng-if=\"ctrlr.data.records.length != ctrlr.data.unfilteredRecords.length\">\n" +
    "        Showing {{count}} of {{total}}\n" +
    "    </span>\n" +
    "</div>");
}]);

angular.module("edge/widget/table/templates/cellTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/cellTemplate.tpl.html",
    "<div class=\"ui-grid-cell-contents\"\n" +
    "     ng-bind-html=\"::(grid.appScope.getCellContents(row, col) | trustedHTML)\"></div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/cellWordWrapTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/cellWordWrapTemplate.tpl.html",
    "<div class=\"ui-grid-cell-contents ui-grid-cell-contents-wordwrap\"\n" +
    "     ng-bind-html=\"::(grid.appScope.getCellContents(row, col) | trustedHTML)\"></div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/columnHeaderTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/columnHeaderTemplate.tpl.html",
    "<div\n" +
    "        role=\"columnheader\"\n" +
    "        ng-class=\"{ 'sortable': sortable }\"\n" +
    "        class=\"edge-table-column-header\"\n" +
    "        ui-grid-one-bind-aria-labelledby-grid=\"col.uid + '-header-text ' + col.uid + '-sortdir-text'\"\n" +
    "        aria-sort=\"{{col.sort.direction == asc ? 'ascending' : ( col.sort.direction == desc ? 'descending' : (!col.sort.direction ? 'none' : 'other'))}}\">\n" +
    "    <div\n" +
    "            role=\"button\"\n" +
    "            tabindex=\"0\"\n" +
    "            class=\"ui-grid-cell-contents ui-grid-header-cell-primary-focus\"\n" +
    "            col-index=\"renderIndex\"\n" +
    "            title=\"TOOLTIP\">\n" +
    "\n" +
    "        <table>\n" +
    "            <tr>\n" +
    "                <td class=\"edge-table-column-name\">\n" +
    "                    <span ng-bind-html=\"::(grid.appScope.getHeaderContents(col) | trustedHTML)\"></span>\n" +
    "                </td>\n" +
    "                <td class=\"edge-table-sort-container\" ng-if=\"col.sort.direction\">\n" +
    "                    <span ui-grid-one-bind-id-grid=\"col.uid + '-sortdir-text'\"\n" +
    "                          aria-label=\"{{getSortDirectionAriaLabel()}}\">\n" +
    "                          <i\n" +
    "                                  ng-class=\"{ 'ui-grid-icon-up-dir': col.sort.direction == asc, 'ui-grid-icon-down-dir': col.sort.direction == desc, 'ui-grid-icon-blank': !col.sort.direction }\"\n" +
    "                                  title=\"{{isSortPriorityVisible() ? i18n.headerCell.priority + ' ' + ( col.sort.priority + 1 )  : null}}\"\n" +
    "                                  aria-hidden=\"true\">\n" +
    "                         </i>\n" +
    "                         <sup\n" +
    "                                 ui-grid-visible=\"isSortPriorityVisible()\"\n" +
    "                                 class=\"ui-grid-sort-priority-number\">\n" +
    "                           {{col.sort.priority + 1}}\n" +
    "                         </sup>\n" +
    "                    </span>\n" +
    "                </td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <div ui-grid-filter></div>\n" +
    "</div>");
}]);

angular.module("edge/widget/table/templates/columnHidingHeaderBtn.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/columnHidingHeaderBtn.tpl.html",
    "<form class=\"form-horizontal\">\n" +
    "    <div class=\"col-sm-6\">\n" +
    "        <div ng-repeat=\"columnDef in left\" class=\"checkbox\">\n" +
    "            <label><input type=\"checkbox\" ng-model=\"columnDef.visible\">{{columnDef.displayName}}</label>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-sm-6\">\n" +
    "        <div ng-repeat=\"columnDef in right\" class=\"checkbox\">\n" +
    "            <label><input type=\"checkbox\" ng-model=\"columnDef.visible\">{{columnDef.displayName}}</label>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</form>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowBkgColorTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowBkgColorTemplate.tpl.html",
    "<div ng-style=\"::grid.appScope.rowBkgFormatter( row, rowRenderIndex )\">\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-mouseenter=\"grid.appScope.handleMouseCellEnter(row, col)\"\n" +
    "         ng-mouseleave=\"grid.appScope.handleMouseCellLeave()\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowBkgColorTemplateCellShadding.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowBkgColorTemplateCellShadding.tpl.html",
    "<div ng-style=\"::grid.appScope.rowBkgFormatter( row, rowRenderIndex )\">\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-style=\"::grid.appScope.cellBkgColor(row, col, colRenderIndex)\"\n" +
    "         ng-mouseenter=\"grid.appScope.handleMouseCellEnter(row, col)\"\n" +
    "         ng-mouseleave=\"grid.appScope.handleMouseCellLeave()\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowBkgColorTemplateCellShaddingWithTaphold.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowBkgColorTemplateCellShaddingWithTaphold.tpl.html",
    "<div ng-style=\"::grid.appScope.rowBkgFormatter( row, rowRenderIndex )\">\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         mn-touch ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-style=\"::grid.appScope.cellBkgColor(row, col, colRenderIndex)\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"\n" +
    "         edge-taphold=\"grid.appScope.handleTaphold(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowBkgColorTemplateWithTaphold.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowBkgColorTemplateWithTaphold.tpl.html",
    "<div ng-style=\"::grid.appScope.rowBkgFormatter( row, rowRenderIndex )\">\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         mn-touch ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"\n" +
    "         edge-taphold=\"grid.appScope.handleTaphold(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowTemplate.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowTemplate.tpl.html",
    "<div>\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-mouseenter=\"grid.appScope.handleMouseCellEnter(row, col)\"\n" +
    "         ng-mouseleave=\"grid.appScope.handleMouseCellLeave()\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowTemplateCellShadding.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowTemplateCellShadding.tpl.html",
    "<div>\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-style=\"::grid.appScope.cellBkgColor(row, col, colRenderIndex)\"\n" +
    "         ng-mouseenter=\"grid.appScope.handleMouseCellEnter(row, col)\"\n" +
    "         ng-mouseleave=\"grid.appScope.handleMouseCellLeave()\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowTemplateCellShaddingWithTaphold.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowTemplateCellShaddingWithTaphold.tpl.html",
    "<div>\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         mn-touch ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-style=\"::grid.appScope.cellBkgColor(row, col, colRenderIndex)\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"\n" +
    "         edge-taphold=\"grid.appScope.handleTaphold(row, col)\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/table/templates/rowTemplateWithTaphold.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/table/templates/rowTemplateWithTaphold.tpl.html",
    "<div>\n" +
    "    <div ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\"\n" +
    "         mn-touch ui-grid-cell class=\"ui-grid-cell\"\n" +
    "         ng-click=\"grid.appScope.handlCellClick(row, col)\"\n" +
    "         edge-taphold=\"grid.appScope.handleTaphold(row, col)\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/config/edgeTemplateWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/config/edgeTemplateWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"TemplateWidgetWizardController as TplConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!TplConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"TplConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TplConfigCtrlr.handleCancel\" ng-if=\"TplConfigCtrlr.initialized\" class=\"edge-performance-boost\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TplConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"TplConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Renderer' | translate}}\" index=\"1\"\n" +
    "                          use-form-validation=\"rendererconfig\"\n" +
    "                          class=\"small-padding\">\n" +
    "            <form name=\"rendererconfig\" class=\"form-horizontal\" style=\"height:100%;\">\n" +
    "                <edge-panel on-init=\"JSONWizardCtrlr.previewPanelCreated()\" id=\"JSONPreviewPanel\">\n" +
    "                    <edge-panel-header class=\"panel-heading-with-tabs\" hide-label=\"true\">\n" +
    "                        <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                            <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                                <a aria-controls=\"HTML\" role=\"tab\" data-toggle=\"tab\" data-target=\"#html\">\n" +
    "                                    <span translate>HTML</span>\n" +
    "                                </a>\n" +
    "                            </li>\n" +
    "                            <li role=\"presentation\">\n" +
    "                                <a aria-controls=\"CSS\" role=\"tab\" data-toggle=\"tab\" data-target=\"#css\">\n" +
    "                                    <span translate>LESS/CSS</span>\n" +
    "                                </a>\n" +
    "                            </li>\n" +
    "                            <li role=\"presentation\">\n" +
    "                                <a aria-controls=\"JS\" role=\"tab\" data-toggle=\"tab\" data-target=\"#js\">\n" +
    "                                    <span translate>JavaScript</span>\n" +
    "                                </a>\n" +
    "                            </li>\n" +
    "                        </ul>\n" +
    "                    </edge-panel-header>\n" +
    "                    <edge-panel-body>\n" +
    "                        <!-- @formatter:off -->\n" +
    "                        <style>\n" +
    "                            .cm-s-templateConfig {\n" +
    "                                height: 100% !important;\n" +
    "                                border-radius:0px;\n" +
    "                                border:0px;\n" +
    "                            }\n" +
    "                        </style>\n" +
    "                        <!-- @formatter:on -->\n" +
    "                        <div class=\"tab-content\" style=\"height:100%;\">\n" +
    "                            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"html\">\n" +
    "                                <textarea edge-codemirror\n" +
    "                                          editor=\"TplConfigCtrlr.htmlEditor\"\n" +
    "                                          options=\"{mode:'text/html', lineNumbers:true, extraKeys: {'Ctrl-Space': 'autocomplete'}, theme:'default templateConfig'}\"\n" +
    "                                          ng-model=\"TplConfigCtrlr.templateConfig.htmlString\"></textarea>\n" +
    "                            </div>\n" +
    "                            <div role=\"tabpanel\" class=\"tab-pane\" id=\"css\">\n" +
    "                                <textarea edge-codemirror\n" +
    "                                          editor=\"TplConfigCtrlr.cssEditor\"\n" +
    "                                          options=\"{mode:'text/x-less', lineNumbers:true, extraKeys: {'Ctrl-Space': 'autocomplete'}, theme:'default templateConfig'}\"\n" +
    "                                          ng-model=\"TplConfigCtrlr.templateConfig.cssString\"></textarea>\n" +
    "                            </div>\n" +
    "                            <div role=\"tabpanel\" class=\"tab-pane\" id=\"js\">\n" +
    "                                <textarea edge-codemirror\n" +
    "                                          editor=\"TplConfigCtrlr.jsEditor\"\n" +
    "                                          options=\"{mode:'text/javascript', lineNumbers:true, extraKeys: {'Ctrl-Space': 'autocomplete'}, theme:'default templateConfig'}\"\n" +
    "                                          ng-model=\"TplConfigCtrlr.templateConfig.jsString\"></textarea>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </edge-panel-body>\n" +
    "                    <edge-panel-footer>\n" +
    "                            <div class=\"dropup\" style=\"display:inline-block\">\n" +
    "                                <button class=\"btn btn-default dropup dropdown-toggle\"\n" +
    "                                        data-toggle=\"dropdown\"\n" +
    "                                        aria-haspopup=\"true\"\n" +
    "                                        aria-expanded=\"false\">\n" +
    "                                    <i class=\"icon icon_question_circle\"></i>&nbsp;<span translate>Help</span>&nbsp;<span\n" +
    "                                        class=\"caret\"></span>\n" +
    "                                </button>\n" +
    "                                <ul class=\"dropdown-menu\">\n" +
    "                                    <li ng-click=\"TplConfigCtrlr.showAttrs()\">\n" +
    "                                        <a><span translate>Variable <em class=\"text-info\">attributes</em></span></a></li>\n" +
    "                                    <li ng-click=\"TplConfigCtrlr.showRows()\">\n" +
    "                                        <a><span translate>Variable <em class=\"text-info\">rows</em></span></a></li>\n" +
    "                                    <li ng-click=\"TplConfigCtrlr.showEvents()\">\n" +
    "                                        <a><span translate>Event Firing</span></a></li>\n" +
    "                                    <li ng-click=\"TplConfigCtrlr.showLoad()\">\n" +
    "                                        <a><span translate>Resource Loading</span></a></li>\n" +
    "                                </ul>\n" +
    "                            </div>\n" +
    "                            <span class=\"pull-right\" style=\"line-height:24px;\">\n" +
    "                            <span translate>Press <kbd><kbd>Ctrl</kbd> + <kbd>Space</kbd></kbd> for autocomplete assistance.</span>\n" +
    "                        </span>\n" +
    "                    </edge-panel-footer>\n" +
    "                </edge-panel>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"TplConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TplConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"TplConfigCtrlr.showPreview\" controller=\"::TplConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TplConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TplConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/config/show-attrs-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/config/show-attrs-dialog.tpl.html",
    "<div class=\"alert alert-info\">\n" +
    "    <div translate>\n" +
    "    <b><em>attributes[ ]</em></b> is an array of strings.  The 'attribute' array is comprised of attribute names from the underlaying data set.\n" +
    "    </div>\n" +
    "    <br><br>\n" +
    "    <div class=\"panel panel-default\">\n" +
    "        <div class=\"panel-heading panel-heading-with-tabs\">\n" +
    "            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                    <a aria-controls=\"HTML Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#htmlSample\">\n" +
    "                        <span translate>HTML Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a aria-controls=\"JS Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#jsSample\">\n" +
    "                        <span translate>JavaScript Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\" style=\"max-height: 300px;flex: 1 0 auto;\">\n" +
    "            <div class=\"tab-content\">\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"htmlSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"html\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "<div ng-repeat=\"attr in attributes\">{{attr}}</div>\n" +
    "    <!-- or access a specific attribute by index -->\n" +
    "<div>{{attributes[0]}}</div></pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane\" id=\"jsSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"js\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "$scope.attributes.forEach(function (attr){ console.log(rows[0][attr]) });</pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "<span translate>Current values:</span>\n" +
    "<div class=\"panel panel-default\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-4\">\n" +
    "                <label translate style=\"line-height:27px\">Attribute Name</label>\n" +
    "            </div>\n" +
    "            <div class=\"col-sm-4\" style=\"text-align:center;\">\n" +
    "                <label translate style=\"line-height:27px;margin-left:55px\">Data Type</label>\n" +
    "            </div>\n" +
    "            <div class=\"col-sm-4\">\n" +
    "                <div class=\"form-group\" style=\"margin-bottom: 0px;\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                        <input type=\"search\"\n" +
    "                               ng-model=\"searchString\"\n" +
    "                               class=\"form-control\"\n" +
    "                               placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"panel-body\" style=\"max-height: 200px;flex: 1 0 auto;\">\n" +
    "        <edge-list items=\"attributes\" q=\"searchString\">\n" +
    "            <div class=\"col-sm-6\">{{item.label}}</div>\n" +
    "            <div class=\"col-sm-6\" style=\"font-size:.8em;\">{{item.type}}</div>\n" +
    "        </edge-list>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/config/show-events-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/config/show-events-dialog.tpl.html",
    "<div class=\"alert alert-info\">\n" +
    "    <span translate>Use the following scope functions to send events that can be wired up to actions.</span>\n" +
    "    <ul>\n" +
    "        <li translate><b><em>fireRowClickEvent(row, attributeName, attributeValue)</em></b> <small>//attributeName and attributeValue are optional</small></li>\n" +
    "        <li translate><b><em>fireAttributeClickEvent(attributeName, attributeValue)</em></b></li>\n" +
    "        <li translate><b><em>fireRowHoverEvent(row)</em></b></li>\n" +
    "    </ul>\n" +
    "    <br>\n" +
    "    <div class=\"panel panel-default\">\n" +
    "        <div class=\"panel-heading panel-heading-with-tabs\">\n" +
    "            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                    <a aria-controls=\"HTML Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#htmlSample\">\n" +
    "                        <span translate>HTML Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a aria-controls=\"JS Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#jsSample\">\n" +
    "                        <span translate>JavaScript Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\" style=\"max-height: 300px;flex: 1 0 auto;\">\n" +
    "            <div class=\"tab-content\">\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"htmlSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"html\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "<!-- fireRowClickEvent with row only -->\n" +
    "<div ng-repeat=\"row in rows\"\n" +
    "     ng-click=\"fireRowClickEvent(row)\">{{row.myCoolAttribute}}</div>\n" +
    "<!-- fireRowClickEvent with attribute context -->\n" +
    "<div ng-repeat=\"attr in attributes\"\n" +
    "     ng-click=\"fireRowClickEvent(rows[0], attr, rows[0].attr)\">\n" +
    "    {{rows[0].attr}}\n" +
    "</div>\n" +
    "<!-- fireRowHoverEvent -->\n" +
    "<div ng-repeat=\"row in rows\"\n" +
    "     ng-mouseenter=\"fireRowHoverEvent(row)\"\n" +
    "     ng-mouseleave=\"fireRowHoverEvent()\">{{row.myCoolAttribute}}</div></pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane\" id=\"jsSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"js\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "$scope.rowClicked = function (row) {\n" +
    "    if (row != undefined) {\n" +
    "        $scope.fireRowClickEvent(row);\n" +
    "    }\n" +
    "}</pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/config/show-load-resources-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/config/show-load-resources-dialog.tpl.html",
    "<div class=\"alert alert-info\">\n" +
    "    <span translate>Use either of the following functions to load external Javascript and/or CSS into your custom visualization.</span>\n" +
    "    <ul>\n" +
    "        <li translate><b><em>loadResource(url)</em></b><small> //url is a string that can be relative or fully qualified (as in a CDN)</small>\n" +
    "        </li>\n" +
    "        <li translate><b><em>loadResources(urls[&nbsp;])</em></b><small> //urls is an array of strings</small>\n" +
    "        </li>\n" +
    "    </ul>\n" +
    "    <br>\n" +
    "    <i class=\"icon icon_exclamation_circle pull-left\"></i><span translate>You can place custom static assets like CSS, JavaScript, and Images in <span\n" +
    "        class=\"text-success\">[product home]/static-web</span>, which is mapped to a relative URL of <em>'custom/'</em> like the JavaScript example below.</span>\n" +
    "    <br>\n" +
    "    <br>\n" +
    "    <div class=\"panel panel-default\">\n" +
    "        <div class=\"panel-heading panel-heading-with-tabs\">\n" +
    "            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                <li role=\"presentation\" style=\"margin-left: 10px;\">\n" +
    "                    <a aria-controls=\"HTML Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#htmlSample\">\n" +
    "                        <span translate>HTML Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\" class=\"active\">\n" +
    "                    <a aria-controls=\"JS Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#jsSample\">\n" +
    "                        <span translate>JavaScript Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\" style=\"max-height: 300px;flex: 1 0 auto;\">\n" +
    "            <div class=\"tab-content\" style=\"height:100%;\">\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane\" id=\"htmlSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"html\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "<!-- While technically you could place either of the loadResource(s) functions\n" +
    "on an ng-init, it's not really a good idea to to do so because you can not\n" +
    "easily wait for the load to complete before usage. We recommend using the\n" +
    "JavaScript example.  --></pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"jsSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "                    <pre pretty-print lang=\"js\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "function init(){\n" +
    "    $scope.loadResources(['custom/js/myCoolJavascript.js',\n" +
    "        'custom/js/myCoolCSS.css']).then(function() {\n" +
    "            console.log('resources have been loaded and can now be used');\n" +
    "            //Please note, the then() function will be called every time the visualization\n" +
    "            //is initialized, despite if the script has previously been loaded.  The resource\n" +
    "            //loading functions will NOT reload previously loaded scripts until the\n" +
    "            //browser is refreshed.\n" +
    "    });\n" +
    "}\n" +
    "// ... any additional javascript or functions ...\n" +
    "init();</pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/config/show-rows-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/config/show-rows-dialog.tpl.html",
    "<div class=\"alert alert-info\">\n" +
    "    <span translate><b><em>rows[ ]</em></b> is an array of Objects, where each Object is the data for a given row.</span>\n" +
    "    <br><br>\n" +
    "    <div class=\"panel panel-default\">\n" +
    "        <div class=\"panel-heading panel-heading-with-tabs\">\n" +
    "            <ul class=\"nav nav-tabs\" role=\"tablist\">\n" +
    "                <li role=\"presentation\" class=\"active\" style=\"margin-left: 10px;\">\n" +
    "                    <a aria-controls=\"HTML Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#htmlSample\">\n" +
    "                        <span translate>HTML Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li role=\"presentation\">\n" +
    "                    <a aria-controls=\"JS Sample\" role=\"tab\" data-toggle=\"tab\" data-target=\"#jsSample\">\n" +
    "                        <span translate>JavaScript Example</span>\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "        <div class=\"panel-body\" style=\"max-height: 300px;flex: 1 0 auto;\">\n" +
    "            <div class=\"tab-content\">\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"htmlSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "<pre pretty-print lang=\"html\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "<div ng-repeat=\"row in rows\">{{row.attribute}}</div>\n" +
    "     <!-- or access a specific row by index -->\n" +
    "<div>{{rows[0].attribute}}</div></pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "                <div role=\"tabpanel\" class=\"tab-pane\" id=\"jsSample\">\n" +
    "                    <!-- @formatter:off -->\n" +
    "<pre pretty-print lang=\"js\" linenums=\"true\" ng-non-bindable style=\"white-space: nowrap\">\n" +
    "$scope.getFirstRow = function () {\n" +
    "    return $scope.rows[0];\n" +
    "}\n" +
    "</pre>\n" +
    "                    <!-- @formatter:on -->\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "<div class=\"panel panel-default\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-sm-8\"><label style=\"line-height:27px;\" translate>Sample Rows From Pipeline</label></div>\n" +
    "            <div class=\"col-sm-4\">\n" +
    "                <div class=\"form-group\" style=\"margin-bottom: 0px;\">\n" +
    "                    <div class=\"input-group\">\n" +
    "                        <span class=\"input-group-addon\"><i class=\"icon icon_search\"></i></span>\n" +
    "                        <input type=\"search\"\n" +
    "                               ng-model=\"searchString\"\n" +
    "                               class=\"form-control\"\n" +
    "                               placeholder=\"{{'filter ...' | translate}}\"/>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"panel-body\" style=\"overflow:hidden; height: 196px;flex: 1 0 auto;\">\n" +
    "        <edge-tabular-data-preview-table data=\"rows\"\n" +
    "                                         attributes=\"attributes\"\n" +
    "                                         search-text=\"searchString\"\n" +
    "                                         style=\"height:200px;\"></edge-tabular-data-preview-table>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/template/edgeTemplateWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/edgeTemplateWidget.tpl.html",
    "<div class=\"edgeTemplateWidget\">\n" +
    "    <!--use angular to inject the compiled CSS into the widget-->\n" +
    "    <style>{{tplCtrlr.compiledCSS}}</style>\n" +
    "    <div id=\"{{tplCtrlr.widgetID}}\" class=\"edgeTemplateConent\" ng-style=\"{height:tplCtrlr.height, width:tplCtrlr.width}\"></div>\n" +
    "</div>");
}]);

angular.module("edge/widget/template/less-css-compile-error-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/template/less-css-compile-error-dialog.tpl.html",
    "<big translate>There is a parsing error in your LESS/CSS:</big>\n" +
    "<br><big class=\"text-danger\">{{error.message}}</big><br>\n" +
    "<span translate>at line:{{error.line}} and column:{{error.column}}</span><br><br>\n" +
    "<span tranlate>All defined styles will not be applied.</span>\n" +
    "");
}]);

angular.module("edge/widget/text/config/edgeTextWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/text/config/edgeTextWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"TextWidgetWizardController as TextConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!TextConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"TextConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TextConfigCtrlr.handleCancel\" ng-if=\"TextConfigCtrlr.initialized\">\n" +
    "        <edge-wizard-step label=\"{{'Base Text' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Text Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <h4 translate>Appearance</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('speed')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('speed')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('direction')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('direction')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('pause')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('pause')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('itemPadding')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('itemPadding')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\" validation=\"true\"\n" +
    "                                       property-def=\"::TextConfigCtrlr.propertyBundleDef.findPropertyDefByName('verticalAlignment')\"\n" +
    "                                       property-value=\"TextConfigCtrlr.propertyBundle.findPropertyValueByName('verticalAlignment')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Renderer'|translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          validate=\"TextConfigCtrlr.attributes.attributeRendererDefs.length>0\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <h4 translate>Renderer</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"height: 50%;\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Show Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Value Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"TextConfigCtrlr.attributeSelected\"\n" +
    "                                       type=\"reorderable\" items=\"TextConfigCtrlr.attributes.attributeRendererDefs\">\n" +
    "                                <edge-list-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                         attributes-list=\"::listScope.TextConfigCtrlr.attributesList\"\n" +
    "                                                         attribute-defs=\"::listScope.TextConfigCtrlr.dataAttributes\"></edge-list-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"TextConfigCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"TextConfigCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"TextConfigCtrlr.attributeSelected==null || TextConfigCtrlr.attributes.attributeRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "                <h4 translate>Label Formatter</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"form-group\">\n" +
    "                    <div class=\"col-sm-6\">\n" +
    "                        <edge-font-formatter formatter=\"TextConfigCtrlr.labelFormatter\">\n" +
    "                        </edge-font-formatter>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"TextConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TextConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"TextConfigCtrlr.showPreview\" controller=\"::TextConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TextConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TextConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/text/edgeTextWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/text/edgeTextWidget.tpl.html",
    "<div class=\"edge-text-widget edge-list-no-selection edge-list-no-hover\">\n" +
    "    <!-- @formatter:off -->\n" +
    "    <!-- stylelint-disable -->\n" +
    "    <style>\n" +
    "        .list-group-item.{{::Controller.liClass}} {\n" +
    "            font-size: {{::Controller.bodyFontSize}};\n" +
    "            height: 100%;\n" +
    "            padding: 0px;\n" +
    "            width: 100%;\n" +
    "        }\n" +
    "        .list-group-item.{{::Controller.liClass}} .text-container {\n" +
    "            height: {{Controller.calcItemHeight}}px;\n" +
    "            padding: {{::Controller.config.itemPadding.value}}px;\n" +
    "        }\n" +
    "        {{Controller.styleClassesAsString}}\n" +
    "        .{{::Controller.floatLeftIconClass}} {\n" +
    "            width: {{::Controller.floatLeftIconWidth}}px; padding-left:10px;\n" +
    "        }\n" +
    "        .{{::Controller.floatRightIconClass}} {\n" +
    "            width: {{::Controller.floatRightIconWidth}}px; padding-left:5px; padding-right:5px;\n" +
    "        }\n" +
    "\n" +
    "        .{{::Controller.liClass}} table {height:100%}\n" +
    "        .{{::Controller.liClass}} table.listCell {width:100%}\n" +
    "        .{{::Controller.liClass}} col.listItemLabel {width:0%}\n" +
    "        .{{::Controller.liClass}} col.listItemValue {width:100%}\n" +
    "		.{{::Controller.liClass}} tr { vertical-align: {{::Controller.config.verticalAlignment.value}} }\n" +
    "        .{{::Controller.liClass}} td {padding-right: 5px; text-overflow: ellipsis; overflow:hidden}\n" +
    "        .{{::Controller.liClass}} td.listItemLabel {text-align: right; padding-left: 5px; vertical-align: top; white-space: nowrap}\n" +
    "        .{{::Controller.liClass}} td.listItemValue {text-align: left;}\n" +
    "\n" +
    "        .list-group-item.{{::Controller.liClass}}.animate.ng-enter,.list-group-item.{{::Controller.liClass}}.animate.ng-leave\n" +
    "        {\n" +
    "            transition: {{Controller.speed}}ms {{Controller.easing}};\n" +
    "         }\n" +
    "         .list-group-item.{{::Controller.liClass}}.animate.ng-enter {\n" +
    "            {{Controller.css.enter}}\n" +
    "         }\n" +
    "         .list-group-item.{{::Controller.liClass}}.animate.ng-enter.list-group-item.{{::Controller.liClass}}.animate.ng-enter-active {\n" +
    "            {{Controller.css.enterActive}}\n" +
    "         }\n" +
    "         .list-group-item.{{::Controller.liClass}}.animate.ng-leave {\n" +
    "            {{Controller.css.leave}}\n" +
    "         }\n" +
    "         .list-group-item.{{::Controller.liClass}}.animate.ng-leave.list-group-item.{{::Controller.liClass}}.animate.ng-leave-active {\n" +
    "            {{Controller.css.leaveActive}}\n" +
    "         }\n" +
    "        <!-- stylelint-enable -->\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "    <edge-list ng-if=\"Controller.canRender()\" items=\"Controller.listItems\" unique-property=\"__recordKey\"\n" +
    "               selected-item=\"Controller.selectedItem\" type=\"text\" class=\"edge-list-widget\" q=\"q\"\n" +
    "               li-class=\"::Controller.liClass\" empty-message=\"\">\n" +
    "        <div mn-touch class=\"{{::(listScope.Controller.liClass+listScope.Controller.noSelectClass)}}\" style=\"height: 100%\"  ng-mouseenter=\"listScope.Controller.mouseEnter(item)\" ng-mouseleave=\"listScope.Controller.mouseLeave(item)\" hold=\"listScope.Controller.hold(item,$event)\">\n" +
    "\n" +
    "            <table ng-if=\"listScope.Controller.hasFloatLeft==false && listScope.Controller.hasFloatRight==false\"\n" +
    "                   data-record-key=\"{{item.__recordKey}}\">\n" +
    "                <tr>\n" +
    "                    <td>\n" +
    "                        <ng-include src=\"::'edge/widget/list/edgeListCell.tpl.html'\"></ng-include>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "            <table ng-if=\"listScope.Controller.hasFloatLeft==true && listScope.Controller.hasFloatRight==false\"\n" +
    "                   data-record-key=\"{{item.__recordKey}}\">\n" +
    "                <tr>\n" +
    "                    <td class=\" {{::listScope.Controller.floatLeftIconClass}}\">\n" +
    "                        <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatLeftItems\">\n" +
    "                            <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\" style=\"padding-right: {{::listScope.Controller.config.itemPadding.value}}px\">\n" +
    "                        </div>\n" +
    "                    </td>\n" +
    "                    <td>\n" +
    "                        <ng-include src=\"::'edge/widget/list/edgeListCell.tpl.html'\"></ng-include>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "            <table ng-if=\"listScope.Controller.hasFloatLeft==false && listScope.Controller.hasFloatRight==true\"\n" +
    "                   data-record-key=\"{{item.__recordKey}}\">\n" +
    "                <tr>\n" +
    "                    <td>\n" +
    "                        <ng-include src=\"::'edge/widget/list/edgeListCell.tpl.html'\"></ng-include>\n" +
    "                    </td>\n" +
    "                    <td class=\" {{::listScope.Controller.floatRightIconClass}}\">\n" +
    "                        <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatRightItems\">\n" +
    "                            <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\">\n" +
    "                        </div>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "            <table ng-if=\"listScope.Controller.hasFloatLeft==true && listScope.Controller.hasFloatRight==true\"\n" +
    "                   data-record-key=\"{{item.__recordKey}}\">\n" +
    "                <tr>\n" +
    "                    <td class=\" {{::listScope.Controller.floatLeftIconClass}}\">\n" +
    "                        <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatLeftItems\">\n" +
    "                            <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\" style=\"padding-right: {{::listScope.Controller.config.itemPadding.value}}px\">\n" +
    "                        </div>\n" +
    "                    </td>\n" +
    "                    <td>\n" +
    "                        <ng-include src=\"::'edge/widget/list/edgeListCell.tpl.html'\"></ng-include>\n" +
    "                    </td>\n" +
    "                    <td class=\" {{::listScope.Controller.floatRightIconClass}}\">\n" +
    "                        <div ng-repeat=\"attributeRendererDef in listScope.Controller.floatRightItems\">\n" +
    "                            <img ng-src=\"{{listScope.Controller.getIconUrl(attributeRendererDef.formatterConfig, item)}}\">\n" +
    "                        </div>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "        </div>\n" +
    "    </edge-list>\n" +
    "</div>\n" +
    "\n" +
    "\n" +
    "\n" +
    "");
}]);

angular.module("edge/widget/timeline/config/edgeTimelineWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/timeline/config/edgeTimelineWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"TimelineWidgetWizardController as TimelineConfigCtrlr\" style=\"height:100%\">\n" +
    "    <div ng-if=\"!TimelineConfigCtrlr.hasData\" style=\"padding: 2em 6.5em\">\n" +
    "        <div style='position:absolute; left:2em; margin-top: 6px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "            <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        <h3 translate>Loading Configuration... </h3>\n" +
    "    </div>\n" +
    "    <edge-wizard force-progression=\"!TimelineConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"TimelineConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TimelineConfigCtrlr.handleCancel\" ng-if=\"TimelineConfigCtrlr.hasData\">\n" +
    "        <edge-wizard-step label=\"{{'Base Timeline' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Base Timeline Config</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('name')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('dateField')\"\n" +
    "                                       property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('dateField')\"\n" +
    "                                       items=\"::TimelineConfigCtrlr.dateAttributesList\">\n" +
    "                </edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Renderer'|translate}}\" index=\"1\"\n" +
    "                          validate=\"TimelineConfigCtrlr.validateRenderer()\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\" style=\"height: 100%\">\n" +
    "                <h4 translate>Renderer</h4>\n" +
    "                <hr>\n" +
    "                <div style=\"height: 50%;\">\n" +
    "                    <edge-panel>\n" +
    "                        <edge-panel-header hide-label=\"true\">\n" +
    "                            <div style=\"width: 100%\">\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Attribute Name</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-3\">\n" +
    "                                    <label translate style=\"padding-left:20px\">Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-2\">\n" +
    "                                    <label translate style=\"padding-left:15px\">Show Label</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-4\">\n" +
    "                                    <label translate style=\"padding-left:10px\">Value Renderer</label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </edge-panel-header>\n" +
    "                        <edge-panel-body>\n" +
    "                            <edge-list selected-item=\"TimelineConfigCtrlr.attributeSelected\"\n" +
    "                                       type=\"reorderable\" items=\"TimelineConfigCtrlr.attributes.attributeRendererDefs\">\n" +
    "                                <edge-list-attribute-def attribute-renderer-def=\"item\"\n" +
    "                                                         attributes-list=\"::listScope.TimelineConfigCtrlr.attributesList\"\n" +
    "                                                         attribute-defs=\"::listScope.TimelineConfigCtrlr.dataAttributes\"></edge-list-attribute-def>\n" +
    "                            </edge-list>\n" +
    "                        </edge-panel-body>\n" +
    "                        <edge-panel-footer>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_plus\"\n" +
    "                                    ng-click=\"TimelineConfigCtrlr.addEntry()\"></button>\n" +
    "                            <button type=\"button\"\n" +
    "                                    class=\"btn btn-default icon icon_minus\"\n" +
    "                                    ng-click=\"TimelineConfigCtrlr.removeEntry()\"\n" +
    "                                    ng-disabled=\"TimelineConfigCtrlr.attributeSelected==null || TimelineConfigCtrlr.attributes.attributeRendererDefs.length==1\"></button>\n" +
    "                        </edge-panel-footer>\n" +
    "                    </edge-panel>\n" +
    "                </div>\n" +
    "                <h4 translate>Label Formatter</h4>\n" +
    "                <hr>\n" +
    "                <edge-font-formatter class=\"col-sm-6\" style=\"height: auto;\" formatter=\"TimelineConfigCtrlr.labelFormatter\"\n" +
    "                    options=\"TimelineConfigCtrlr.labelFormatterOptions\">\n" +
    "                </edge-font-formatter>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Layout Options' | translate}}\"  use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <h4 class=\"top\" translate>Layout Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" validation=\"true\" label-width=\"6\"\n" +
    "                                       property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('orientationAxis')\"\n" +
    "                                       property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('orientationAxis')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-6\" validation=\"true\" label-width=\"6\"\n" +
    "                                       property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('orientationItem')\"\n" +
    "                                       property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('orientationItem')\"></edge-property-control>\n" +
    "                <edge-property-control label-width=\"3\" style=\"clear: both;\"\n" +
    "                    property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('stack')\"\n" +
    "                    property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('stack')\">\n" +
    "                </edge-property-control>\n" +
    "                <!--\n" +
    "                <edge-property-control label-width=\"3\"\n" +
    "                    property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('moveable')\"\n" +
    "                    property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('moveable')\">\n" +
    "                </edge-property-control>\n" +
    "                <div ng-if=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('moveable').value === true\">\n" +
    "                -->\n" +
    "                <edge-property-control class=\"col-sm-6\" validation=\"true\" label-width=\"6\" show-feedback-icon=\"false\"\n" +
    "                    property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoomValue')\"\n" +
    "                    property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('minZoomValue')\">\n" +
    "                </edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-3\" label-width=\"0\"\n" +
    "                    property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('minZoomUnit')\"\n" +
    "                    property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('minZoomUnit')\">\n" +
    "                </edge-property-control>\n" +
    "\n" +
    "                <h4 translate>Date Slider Control &amp; Sparkline Options</h4>\n" +
    "                <hr>\n" +
    "                <edge-property-control class=\"col-sm-6\" label-width=\"6\" style=\"clear: both;\"\n" +
    "                    property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('showRangeControl')\"\n" +
    "                    property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('showRangeControl')\">\n" +
    "                </edge-property-control>\n" +
    "\n" +
    "                <div ng-if=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('showRangeControl').value === true\" style=\"clear: both;\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" validation=\"true\"\n" +
    "                        property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('controlHeight')\"\n" +
    "                        property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('controlHeight')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"6\" style=\"clear: both;\"\n" +
    "                        property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('showSparkline')\"\n" +
    "                        property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('showSparkline')\">\n" +
    "                    </edge-property-control>\n" +
    "                    <div ng-if=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('showSparkline').value === true\">\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"6\"\n" +
    "                            property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('sparklineType')\"\n" +
    "                            property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('sparklineType')\">\n" +
    "                        </edge-property-control>\n" +
    "                        <edge-labeled-control label=\"{{::TimelineConfigCtrlr.aggregationTypeDef.displayName}}\"\n" +
    "                            class=\"col-sm-6\" label-width=\"6\" style=\"clear: both; margin-left: 0; margin-right: 0;\">\n" +
    "                            <select class=\"form-control\" ng-model=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('aggregationType').value\"\n" +
    "                                ng-options=\"type.type as type.displayName for type in TimelineConfigCtrlr.aggregationTypes\">\n" +
    "                            </select>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-labeled-control ng-if=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('aggregationType').value !== 0\"\n" +
    "                            class=\"col-sm-6\" validation=\"true\" label-width=\"0\" helptext=\"{{::TimelineConfigCtrlr.aggregationTypeDef.helpText}}\">\n" +
    "                            <input type=\"hidden\" name=\"sparklineAttribute\" ng-required=\"true\"\n" +
    "                                    ng-model=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('sparklineAttribute').value\">\n" +
    "                            <ui-select theme=\"bootstrap\"\n" +
    "                                ng-model=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('sparklineAttribute').value\">\n" +
    "                                <ui-select-match placeholder=\"{{::'Choose an attribute...'|translate}}\">{{$select.selected.name}}\n" +
    "                                </ui-select-match>\n" +
    "                                <ui-select-choices repeat=\"item.name as item in TimelineConfigCtrlr.numberAttributes | filter: $select.search\">\n" +
    "                                    <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                    <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                </ui-select-choices>\n" +
    "                            </ui-select>\n" +
    "                        </edge-labeled-control>\n" +
    "                        <edge-property-control class=\"col-sm-6\" validation=\"true\" label-width=\"6\" show-feedback-icon=\"false\" style=\"clear: both;\"\n" +
    "                            property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('intervalValue')\"\n" +
    "                            property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('intervalValue')\">\n" +
    "                        </edge-property-control>\n" +
    "                        <edge-property-control class=\"col-sm-3\" label-width=\"0\"\n" +
    "                            property-def=\"::TimelineConfigCtrlr.propertyBundleDef.findPropertyDefByName('intervalUnit')\"\n" +
    "                            property-value=\"TimelineConfigCtrlr.propertyBundle.findPropertyValueByName('intervalUnit')\">\n" +
    "                        </edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <!--</div> -->\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{'Preview'|translate}}\" on-show=\"TimelineConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TimelineConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"TimelineConfigCtrlr.showPreview\" controller=\"::TimelineConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TimelineConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TimelineConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/timeline/edgeTimelineWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/timeline/edgeTimelineWidget.tpl.html",
    "<div class=\"edge-timeline-no-hover edge-timeline-no-selection\">\n" +
    "    <!-- @formatter:off -->\n" +
    "    <style>\n" +
    "        .{{::Controller.floatLeftIconClass}} {\n" +
    "            width: {{::Controller.floatLeftIconWidth}}px;\n" +
    "            padding-right: 5px;\n" +
    "        }\n" +
    "        .{{::Controller.floatRightIconClass}} {\n" +
    "            width: {{::Controller.floatRightIconWidth}}px;\n" +
    "            padding-left: 5px;\n" +
    "        }\n" +
    "        {{Controller.timelineStyleService.styleClassesAsString}}\n" +
    "        table.{{::Controller.inlineTableClass}} {table-layout:fixed;}\n" +
    "        td.{{::Controller.flowLabelClass}} {vertical-align: middle; padding-left: 5px; padding-right: 5px;}\n" +
    "        td.{{::Controller.flowValueClass}} {padding-right: 5px;}\n" +
    "        div.{{::Controller.renderLabelClass}} { white-space:nowrap; text-overflow: ellipsis; overflow:hidden;}\n" +
    "        div.{{::Controller.renderValueClass}} { white-space:nowrap; text-overflow: ellipsis; overflow:hidden;}\n" +
    "        .{{::Controller.renderLabelClass}} {text-align:right; text-overflow: ellipsis;}\n" +
    "        .{{::Controller.renderValueClass}} {text-align:left; text-overflow: ellipsis;}\n" +
    "        .{{::Controller.valueOnlyClass}} {text-align:center;padding-left: 5px; padding-right: 5px;}\n" +
    "    </style>\n" +
    "    <!-- @formatter:on -->\n" +
    "    <div class=\"edge-timelime\" style=\"height: 100%; width: 100%\"></div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/timeline/edgeTimelineWidgetFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/timeline/edgeTimelineWidgetFooter.tpl.html",
    "<div style=\"display:inline-block;\">\n" +
    "    <edge-date-range-slider\n" +
    "            size=\"Controller.sliderSize\"\n" +
    "            min-date=\"Controller.minDate\"\n" +
    "            max-date=\"Controller.maxDate\"\n" +
    "            on-change=\"Controller.onChange(startEndpoint, endEndpoint)\"\n" +
    "            start-date=\"Controller.startDate.date\"\n" +
    "            end-date=\"Controller.endDate.date\"\n" +
    "            granularity=\"Controller.granularity\"\n" +
    "            sparkline-type=\"Controller.sparklineType\"\n" +
    "            sparkline-data=\"Controller.sparklineData\"></edge-date-range-slider>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/timeline/impl/edgeTimelineItem.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/timeline/impl/edgeTimelineItem.tpl.html",
    "<div>\n" +
    "    <table ng-if=\"::(Controller.hasFloatLeft===false && Controller.hasFloatRight===false)\">\n" +
    "        <tr>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"::(Controller.hasFloatLeft===true && Controller.hasFloatRight===false)\">\n" +
    "        <tr>\n" +
    "            <td class=\"{{::Controller.floatLeftIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatLeftItems\">\n" +
    "                    <img ng-src=\"{{::Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"::(Controller.hasFloatLeft===false && Controller.hasFloatRight===true)\">\n" +
    "        <tr>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "            <td class=\"{{::Controller.floatRightIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatRightItems\">\n" +
    "                    <img ng-src=\"{{::Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "    <table ng-if=\"::(Controller.hasFloatLeft===true && Controller.hasFloatRight===true)\">\n" +
    "        <tr>\n" +
    "            <td class=\"{{::Controller.floatLeftIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatLeftItems\">\n" +
    "                    <img ng-src=\"{{::Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                <ng-include src=\"::'edge/core/widget/actions/tooltip/edgeTooltipCell.tpl.html'\"></ng-include>\n" +
    "            </td>\n" +
    "            <td class=\"{{::Controller.floatRightIconClass}}\">\n" +
    "                <div ng-repeat=\"attributeRendererDef in Controller.floatRightItems\">\n" +
    "                    <img ng-src=\"{{::Controller.getIconUrl(attributeRendererDef.formatterConfig, record)}}\">\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "    </table>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/topo/config/edgeNodeRendererDefInfo.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/topo/config/edgeNodeRendererDefInfo.tpl.html",
    "<div class=\"with-padding\">\n" +
    "    <div class=\"row\" ng-dblclick=\"controller.editNodeRenderer()\">\n" +
    "        <div class=\"col-sm-3\">\n" +
    "            {{nodeRendererDef.dataProducer.name}}\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\" style=\"padding-left:60px\">\n" +
    "            <big><b><i class=\"icon icon_check text-success\"></i></b></big>\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\" style=\"padding-left:60px\">\n" +
    "        </div>\n" +
    "        <div class=\"col-sm-3\" style=\"padding-left:60px\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/topo/config/edgeTopoWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/topo/config/edgeTopoWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"TopoWidgetWizardController as TopoConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!TopoConfigCtrlr.isEdit\" dialog-mode=\"true\" on-save=\"TopoConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TopoConfigCtrlr.handleCancel\" ng-if=\"TopoConfigCtrlr.initialized\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <h4 translate>General Options</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('webgl')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('webgl')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('toolbar')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('toolbar')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('enableMap')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('enableMap')\"></edge-property-control>\n" +
    "                </div>\n" +
    "\n" +
    "                <div ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('webgl').value == false\">\n" +
    "                    <h4 translate>Overview Options</h4>\n" +
    "                    <hr>\n" +
    "                    <div class=\"row\">\n" +
    "                        <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                               property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('overview')\"\n" +
    "                                               property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('overview')\"></edge-property-control>\n" +
    "                        <edge-property-control\n" +
    "                                ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('overview').value\"\n" +
    "                                class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('overviewPos')\"\n" +
    "                                property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('overviewPos')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <h4 translate>Link Options</h4>\n" +
    "                <hr>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('labelAvoid')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('labelAvoid')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-6\" label-width=\"4\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('linkSpacing')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('linkSpacing')\"></edge-property-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Map Options' | translate}}\"\n" +
    "                          index=\"1\"\n" +
    "                          use-form-validation=\"mapconfig\"\n" +
    "                          ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('enableMap').value === true\">\n" +
    "            <form name=\"mapconfig\" class=\"form-horizontal\">\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-8\">\n" +
    "                        <edge-property-control label-width=\"4\"\n" +
    "                                               property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('displayMap')\"\n" +
    "                                               property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('displayMap')\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <div class=\"col-sm-8\">\n" +
    "                        <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"4\"\n" +
    "                                               property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('tileProvider')\"\n" +
    "                                               property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('tileProvider')\"\n" +
    "                                               items=\"::TopoConfigCtrlr.tileProviders\"></edge-property-control>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Layout Options' | translate}}\" index=\"2\" use-form-validation=\"layout\">\n" +
    "            <form name=\"layout\" class=\"form-horizontal\">\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutType')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutType')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutAnimate')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutAnimate')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutTidy')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutTidy')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutTightness')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutTightness')\"></edge-property-control>\n" +
    "\n" +
    "                </div>\n" +
    "                <div class=\"row\"\n" +
    "                     ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutAnimate').value === true\">\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutTime')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutTime')\"></edge-property-control>\n" +
    "                </div>\n" +
    "                <div class=\"row\"\n" +
    "                     ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutAnimate').value === true\">\n" +
    "\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutEasing')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutEasing')\"></edge-property-control>\n" +
    "\n" +
    "                </div>\n" +
    "                <div class=\"row\"\n" +
    "                     ng-if=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutType').value === 'Hierarchical'\">\n" +
    "\n" +
    "                    <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                           property-def=\"::TopoConfigCtrlr.propertyBundleDef.findPropertyDefByName('layoutOrientation')\"\n" +
    "                                           property-value=\"TopoConfigCtrlr.propertyBundle.findPropertyValueByName('layoutOrientation')\"></edge-property-control>\n" +
    "\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Node Renderers' | translate}}\" index=\"3\" use-form-validation=\"nodeRenderers\"\n" +
    "                          style=\"padding-top:0px;\">\n" +
    "            <form name=\"nodeRenderers\" class=\"form-horizontal\">\n" +
    "                <div ng-repeat=\"def in TopoConfigCtrlr.nodeRendererConfig.nodeRendererDefs\">\n" +
    "                    <h4>Renderer for: {{def.dataProducer.name}}</h4>\n" +
    "                    <hr>\n" +
    "                    <div class=\"row\">\n" +
    "                        <div class=\"col-sm-3\">\n" +
    "                            <div class=\"panel panel-default\" style=\"height: auto;\">\n" +
    "                                <div class=\"panel-heading\">\n" +
    "                                    <label translate>Icon Preview</label>\n" +
    "                                </div>\n" +
    "                                <div class=\"panel-body\" style=\"flex-basis: auto;\">\n" +
    "                                    <div class=\"panel-body icon-preview-bkg\">\n" +
    "                                        <div ng-style=\"{'background': 'url('+TopoConfigCtrlr.getPreviewURL(def)+') center center no-repeat'}\" style=\"height:100px;\"></div>\n" +
    "                                    </div>\n" +
    "                                </div>\n" +
    "                                <div class=\"panel-footer\">\n" +
    "                                    <button type=\"button\"\n" +
    "                                            title=\"{{::'Edit Icon Renderer' | translate}}\"\n" +
    "                                            class=\"btn btn-default\"\n" +
    "                                            ng-click=\"TopoConfigCtrlr.editNodeRenderer(def)\">\n" +
    "                                        <i class=\"btn_icon icon icon_pencil\"></i>\n" +
    "                                    </button>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                        <div class=\"col-sm-9\">\n" +
    "                            <div class=\"row\">\n" +
    "                                <div class=\"col-sm-6\">\n" +
    "                                    <edge-labeled-control label-width=\"6\"\n" +
    "                                                          label=\"{{::'Show Label'|translate}}\">\n" +
    "                                        <input type=\"checkbox\"\n" +
    "                                               name=\"showLabel_{{$index}}\"\n" +
    "                                               ng-model=\"def.showLabel\"\n" +
    "                                               edge-boolean-switch>\n" +
    "                                    </edge-labeled-control>\n" +
    "                                </div>\n" +
    "                                <div class=\"col-sm-6\">\n" +
    "                                    <edge-labeled-control label-width=\"6\"\n" +
    "                                                          label=\"{{::'Circle Shaped Nodes'|translate}}\">\n" +
    "                                        <input type=\"checkbox\"\n" +
    "                                               name=\"useCircleShapedNodes_{{$index}}\"\n" +
    "                                               ng-model=\"def.useCircleShapedNodes\"\n" +
    "                                               edge-boolean-switch>\n" +
    "                                    </edge-labeled-control>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            <div ng-if=\"def.showLabel\">\n" +
    "                                <edge-labeled-control validation=\"true\"\n" +
    "                                                      required=\"true\"\n" +
    "                                                      label-width=\"3\"\n" +
    "                                                      label=\"{{::'Label Attribute' | translate}}\">\n" +
    "                                    <input type=hidden name=\"labelAttribute_{{$index}}\" ng-model=\"def.labelAttribute\"\n" +
    "                                           ng-required=\"true\">\n" +
    "                                    <ui-select ng-model=\"def.labelAttribute\" theme=\"bootstrap\">\n" +
    "                                        <ui-select-match allow-clear=\"false\"\n" +
    "                                                         placeholder=\"{{::'Choose an attribute...'|translate}}\">\n" +
    "                                            {{$select.selected.name}}\n" +
    "                                        </ui-select-match>\n" +
    "                                        <ui-select-choices\n" +
    "                                                repeat=\"item.name as item in def.dataDef.dataAttributes | filter: $select.search\">\n" +
    "                                            <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                            <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                        </ui-select-choices>\n" +
    "                                    </ui-select>\n" +
    "                                </edge-labeled-control>\n" +
    "                                <edge-labeled-control\n" +
    "                                                      label-width=\"3\"\n" +
    "                                                      label=\"{{::'Label Appearance' | translate}}\">\n" +
    "                                    <edge-derivable-font config=\"def.labelFormatter\"\n" +
    "                                                         options=\"TopoConfigCtrlr.labelOptions\"\n" +
    "                                                         attribute-defs=\"def.dataDef.dataAttributes\"></edge-derivable-font>\n" +
    "                                </edge-labeled-control>\n" +
    "                            </div>\n" +
    "                            <edge-labeled-control validation=\"false\"\n" +
    "                                                  ng-if=\"TopoConfigCtrlr.showMap\"\n" +
    "                                                  label-width=\"3\"\n" +
    "                                                  label=\"{{::'Latitude Attribute' | translate}}\">\n" +
    "                                <input type=hidden name=\"latAttribute_{{$index}}\" ng-model=\"def.latAttribute\">\n" +
    "                                <ui-select ng-model=\"def.latAttribute\" theme=\"bootstrap\">\n" +
    "                                    <ui-select-match allow-clear=\"false\"\n" +
    "                                                     placeholder=\"{{::'Choose an attribute...'|translate}}\">\n" +
    "                                        {{$select.selected.name}}\n" +
    "                                    </ui-select-match>\n" +
    "                                    <ui-select-choices\n" +
    "                                            repeat=\"item.name as item in def.dataDef.dataAttributes | filter: $select.search\">\n" +
    "                                        <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                    </ui-select-choices>\n" +
    "                                </ui-select>\n" +
    "                            </edge-labeled-control>\n" +
    "                            <edge-labeled-control validation=\"false\"\n" +
    "                                                  ng-if=\"TopoConfigCtrlr.showMap\"\n" +
    "                                                  label-width=\"3\"\n" +
    "                                                  label=\"{{::'Longitude Attribute' | translate}}\">\n" +
    "                                <input type=hidden name=\"lonAttribute_{{$index}}\" ng-model=\"def.lonAttribute\">\n" +
    "                                <ui-select ng-model=\"def.lonAttribute\" theme=\"bootstrap\">\n" +
    "                                    <ui-select-match allow-clear=\"false\"\n" +
    "                                                     placeholder=\"{{::'Choose an attribute...'|translate}}\">\n" +
    "                                        {{$select.selected.name}}\n" +
    "                                    </ui-select-match>\n" +
    "                                    <ui-select-choices\n" +
    "                                            repeat=\"item.name as item in def.dataDef.dataAttributes | filter: $select.search\">\n" +
    "                                        <small class=\"pull-right\" ng-bind-html=\"item.typeAsString\"></small>\n" +
    "                                        <span ng-bind-html=\"item.name | highlight: $select.search\"></span>\n" +
    "                                    </ui-select-choices>\n" +
    "                                </ui-select>\n" +
    "                            </edge-labeled-control>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"TopoConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TopoConfigCtrlr.hidePreview()\" index=\"4\">\n" +
    "            <edge-preview-widget ng-if=\"TopoConfigCtrlr.showPreview\" controller=\"::TopoConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TopoConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TopoConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/topo/config/edgeTopoWidgetNodeRendererEditor.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/topo/config/edgeTopoWidgetNodeRendererEditor.tpl.html",
    "<div ng-controller=\"TopoWidgetNodeRendererEditorController as ctrlr\"\n" +
    "     class=\"edgeWizardStepContainer\"\n" +
    "     style=\"padding: 20px 20px 0 20px;\">\n" +
    "    <form name=\"formatterForm\" class=\"form-horizontal\">\n" +
    "        <div>\n" +
    "            <h4 translate>Icon</h4>\n" +
    "            <hr>\n" +
    "            <edge-composite-icon-formatter\n" +
    "                    formatter=\"ctrlr.nodeRendererDef.primaryIcon\"\n" +
    "                    attribute-defs=\"::attributeDefs\"></edge-composite-icon-formatter>\n" +
    "\n" +
    "        </div>\n" +
    "        <edge-dialog-footer>\n" +
    "            <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "                <button class=\"btn btn-danger\" ng-click=\"ctrlr.handleClose()\" translate>Cancel</button>\n" +
    "                <button class=\"btn btn-success\"\n" +
    "                        ng-click=\"ctrlr.handleSave()\"\n" +
    "                        ng-disabled=\"formatterForm.$invalid\"\n" +
    "                        translate>Save\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </edge-dialog-footer>\n" +
    "    </form>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/topo/edgeTopoWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/topo/edgeTopoWidget.tpl.html",
    "<div class=\"edgeTopo\">\n" +
    "    <div class=\"edgeWidgetContentWithOverlay\">\n" +
    "        <div class=\"edgeWidgetBusyOverlay\" ng-if=\"Ctrlr.showBusyOverlay\">\n" +
    "            <div style='position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:rgba(255,255,255,0.5); border-radius:7px; width:50px; height:50px'>\n" +
    "                <span us-spinner=\"{hwaccel: 'true'}\"></span></div>\n" +
    "        </div>\n" +
    "        <div class=\"edgeTopoContainer\"></div>\n" +
    "        <div class=\"edgeWidgetOverlay\" ng-if=\"Ctrlr.showSidebarButtons\">\n" +
    "            <ul>\n" +
    "                <li><a rel=\"tooltip\"\n" +
    "                       title=\"{{'Zoom in' | translate}}\"\n" +
    "                       ng-click=\"Ctrlr.zoomIn()\"><i class=\"icon icon_plus btn_icon\"></i></a>\n" +
    "                </li>\n" +
    "                <li><a rel=\"tooltip\"\n" +
    "                       title=\"{{'Zoom out' | translate}}\"\n" +
    "                       ng-click=\"Ctrlr.zoomOut()\"><i class=\"icon icon_minus btn_icon\"></i></a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "            <ul>\n" +
    "                <li ng-if=\"Ctrlr.showingMap === false\"><a rel=\"tooltip\" title=\"{{'Layout Options' | translate}}\" ng-click=\"Ctrlr.handleLayout()\"><i\n" +
    "                        class=\"icon icon_sitemap\"></i></a></li>\n" +
    "                <li><a rel=\"tooltip\" title=\"{{'Fit to View' | translate}}\" ng-click=\"Ctrlr.fitToView()\"><i\n" +
    "                        class=\"icon icon_fit_to_zoom\"></i></a></li>\n" +
    "                <li ng-if=\"Ctrlr.mapSupported\" ng-class=\"{'active':Ctrlr.showingMap === true}\">\n" +
    "                    <a rel=\"tooltip\" title=\"{{'Toggle Map' | translate}}\" ng-click=\"Ctrlr.toggleMap()\"><i\n" +
    "                        class=\"icon icon_vis_map\"></i></a></li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);

angular.module("edge/widget/topo/perform-layout-dialog.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/topo/perform-layout-dialog.tpl.html",
    "<div>\n" +
    "    <form name=\"dialogForm\">\n" +
    "        <div class=\"form-horizontal\">\n" +
    "            <edge-labeled-control label=\"{{'Layout Type' | translate}}\" validation=\"true\">\n" +
    "                <input type=hidden name=\"style\" ng-model=\"Ctrlr.selectedLayout\" ng-required=\"true\">\n" +
    "                <ui-select ng-model=\"Ctrlr.selectedLayout\">\n" +
    "                    <ui-select-match theme=\"bootstrap\"\n" +
    "                                     allow-clear=\"false\"\n" +
    "                                     placeholder=\"{{'Select layout...' | translate}}\">\n" +
    "                        {{$select.selected.displayName}}\n" +
    "                    </ui-select-match>\n" +
    "                    <ui-select-choices\n" +
    "                            repeat=\"item in Ctrlr.supportedLayouts | filter: $select.search\">\n" +
    "                        <span ng-bind-html=\"item.displayName | highlight: $select.search\"></span>\n" +
    "                    </ui-select-choices>\n" +
    "                </ui-select>\n" +
    "            </edge-labeled-control>\n" +
    "            <!--\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{'Animate' | translate}}\" label-width=\"7\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               name=\"animate\"\n" +
    "                               ng-model=\"Ctrlr.selectedLayout.layout.config.animate\"\n" +
    "                               edge-boolean-switch>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{'Fit to View' | translate}}\" label-width=\"7\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               name=\"fit\"\n" +
    "                               ng-model=\"Ctrlr.selectedLayout.layout.config.fit\"\n" +
    "                               edge-boolean-switch>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <div class=\"row\">\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{'Reduce Overlap' | translate}}\" label-width=\"7\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               name=\"tidy\"\n" +
    "                               ng-model=\"Ctrlr.selectedLayout.layout.config.tidy\"\n" +
    "                               edge-boolean-switch>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-labeled-control label=\"{{'Straighten Links' | translate}}\" label-width=\"7\">\n" +
    "                        <input type=\"checkbox\"\n" +
    "                               name=\"straighten\"\n" +
    "                               ng-model=\"Ctrlr.selectedLayout.layout.config.straighten\"\n" +
    "                               edge-boolean-switch>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            -->\n" +
    "        </div>\n" +
    "    </form>\n" +
    "    <edge-dialog-footer>\n" +
    "        <div class=\"bootstrap-dialog-footer-buttons\">\n" +
    "            <button class=\"btn btn-danger\" ng-click=\"handleCancel()\" translate>Cancel and Close</button>\n" +
    "            <button class=\"btn btn-success\" ng-click=\"handleRunLayout()\" translate>Perform Layout</button>\n" +
    "        </div>\n" +
    "    </edge-dialog-footer>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/treemap/config/edgeTreeMapWidgetConfigWizard.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/treemap/config/edgeTreeMapWidgetConfigWizard.tpl.html",
    "<div ng-controller=\"TreeMapWidgetWizardController as TreeMapConfigCtrlr\" style=\"height:100%\">\n" +
    "    <edge-wizard force-progression=\"!TreeMapConfigCtrlr.isEdit\"\n" +
    "                 dialog-mode=\"true\"\n" +
    "                 on-save=\"TreeMapConfigCtrlr.handleSave\"\n" +
    "                 on-cancel=\"TreeMapConfigCtrlr.handleCancel\"\n" +
    "                 ng-if=\"TreeMapConfigCtrlr.initialized\">\n" +
    "        <edge-wizard-step label=\"{{::'Configure' | translate}}\" index=\"0\" use-form-validation=\"config\">\n" +
    "            <form name=\"config\" class=\"form-horizontal\">\n" +
    "                <edge-property-control class=\"col-sm-12\" validation=\"true\" label-width=\"3\"\n" +
    "                                       property-def=\"::TreeMapConfigCtrlr.propertyBundleDef.findPropertyDefByName('name')\"\n" +
    "                                       property-value=\"TreeMapConfigCtrlr.propertyBundle.findPropertyValueByName('name')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::TreeMapConfigCtrlr.propertyBundleDef.findPropertyDefByName('type')\"\n" +
    "                                       property-value=\"TreeMapConfigCtrlr.propertyBundle.findPropertyValueByName('type')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       property-def=\"::TreeMapConfigCtrlr.propertyBundleDef.findPropertyDefByName('allowTypeChange')\"\n" +
    "                                       property-value=\"TreeMapConfigCtrlr.propertyBundle.findPropertyValueByName('allowTypeChange')\"></edge-property-control>\n" +
    "                <edge-property-control class=\"col-sm-12\" label-width=\"3\"\n" +
    "                                       validation=\"true\"\n" +
    "                                       property-def=\"::TreeMapConfigCtrlr.propertyBundleDef.findPropertyDefByName('animDuration')\"\n" +
    "                                       property-value=\"TreeMapConfigCtrlr.propertyBundle.findPropertyValueByName('animDuration')\"></edge-property-control>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Renderers' | translate}}\" index=\"1\" use-form-validation=\"rendererconfig\">\n" +
    "            <form name=\"rendererconfig\" class=\"form-horizontal\">\n" +
    "                <div ng-repeat=\"rendererDef in TreeMapConfigCtrlr.rendererConfig.rendererDefs\">\n" +
    "                    <h4>{{rendererDef.dataProducerName}}&nbsp;<span translate>Renderer</span></h4>\n" +
    "                    <edge-labeled-control label=\"{{::'TreeMap Value Field' | translate}}\" validation=\"false\">\n" +
    "                        <ui-select ng-model=\"rendererDef.sizeField\" theme=\"bootstrap\" append-to-body=\"true\">\n" +
    "                            <ui-select-match allow-clear=\"false\"\n" +
    "                                             placeholder=\"{{::'Choose a column...'|translate}}\">\n" +
    "                                {{$select.selected.name}}\n" +
    "                            </ui-select-match>\n" +
    "                            <ui-select-choices\n" +
    "                                    repeat=\"attr.name as attr in TreeMapConfigCtrlr.getDataAttributes(rendererDef.dataSourceId) | filter: $select.search\">\n" +
    "                                <small class=\"pull-right\" ng-bind-html=\"attr.typeAsString\"></small>\n" +
    "                                <span ng-bind-html=\"attr.name | highlight: $select.search\"></span>\n" +
    "                            </ui-select-choices>\n" +
    "                        </ui-select>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control label=\"{{::'Color Selection' | translate}}\" validation=\"false\">\n" +
    "                        <select class=\"form-control\" style=\"max-width:300px;\" ng-model=\"rendererDef.colorMethod\">\n" +
    "                            <option value=\"dynamic\" translate>From Palette</option>\n" +
    "                            <option value=\"derived\" translate>Derived from RuleSet</option>\n" +
    "                        </select>\n" +
    "                    </edge-labeled-control>\n" +
    "\n" +
    "                    <edge-labeled-control ng-if=\"rendererDef.colorMethod == 'dynamic'\"\n" +
    "                                          label=\"{{::'Color Palette' | translate}}\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <edge-color-palette-formatter formatter=\"rendererDef.palette\"></edge-color-palette-formatter>\n" +
    "                    </edge-labeled-control>\n" +
    "                    <edge-labeled-control ng-if=\"rendererDef.colorMethod == 'derived'\"\n" +
    "                                          label=\"{{::'Color RuleSet' | translate}}\"\n" +
    "                                          validation=\"false\">\n" +
    "                        <edge-derivable-color\n" +
    "                                config=\"rendererDef.colorRule\"\n" +
    "                                derived-only=\"true\"\n" +
    "                                attribute-defs=\"::TreeMapConfigCtrlr.getDataAttributes(rendererDef.dataSourceId)\"></edge-derivable-color>\n" +
    "                    </edge-labeled-control>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Label Options'|translate}}\"\n" +
    "                          use-form-validation=\"labelconfig\"\n" +
    "                          index=\"2\">\n" +
    "            <form name=\"labelconfig\" class=\"form-horizontal\">\n" +
    "                <h4 translate>Label Options</h4>\n" +
    "                <div class=\"col-sm-6\">\n" +
    "                    <edge-font-formatter formatter=\"TreeMapConfigCtrlr.rendererConfig.labelConfig\"\n" +
    "                                         options=\"::TreeMapConfigCtrlr.fontOptions\"></edge-font-formatter>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "        </edge-wizard-step>\n" +
    "        <edge-wizard-step label=\"{{::'Preview'|translate}}\" on-show=\"TreeMapConfigCtrlr.previewShown()\"\n" +
    "                          on-hide=\"TreeMapConfigCtrlr.hidePreview()\" index=\"3\">\n" +
    "            <edge-preview-widget ng-if=\"TreeMapConfigCtrlr.showPreview\" controller=\"::TreeMapConfigCtrlr\">\n" +
    "            </edge-preview-widget>\n" +
    "            <div ng-if=\"TreeMapConfigCtrlr.showPreview === false\" class=\"alert alert-danger\"\n" +
    "                 ng-bind-html=\"TreeMapConfigCtrlr.PREVIEWERROR\"></div>\n" +
    "        </edge-wizard-step>\n" +
    "    </edge-wizard>\n" +
    "</div>\n" +
    "");
}]);

angular.module("edge/widget/treemap/edgeTreeMapWidget.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/treemap/edgeTreeMapWidget.tpl.html",
    "<div class=\"edgeTreeMap\">\n" +
    "    <div ng-if=\"treeMapCtrlr.type === 'TreeMap'\">\n" +
    "        <edge-tree-map widget-controller=\"treeMapCtrlr\"></edge-tree-map>\n" +
    "    </div>\n" +
    "    <div ng-if=\"treeMapCtrlr.type === 'Sunburst'\">\n" +
    "        <edge-sunburst widget-controller=\"treeMapCtrlr\"></edge-sunburst>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("edge/widget/treemap/edgeTreeMapWidgetFooter.tpl.html", []).run(["$templateCache", function ($templateCache) {
  $templateCache.put("edge/widget/treemap/edgeTreeMapWidgetFooter.tpl.html",
    "<div class=\"form-inline\" role=\"group\">\n" +
    "    <div class=\"form-group\">\n" +
    "        <button class=\"btn btn-default\"\n" +
    "                ng-class=\"{'active':treeMapCtrlr.type === 'TreeMap'}\"\n" +
    "                style=\"padding:0px 4px;\"\n" +
    "                title=\"{{'Toggle TreeMap/Sunburst' | translate}}\"\n" +
    "                ng-click=\"treeMapCtrlr.toggleTreeMap()\">\n" +
    "            <i class=\"icon\" ng-class=\"treeMapCtrlr.isTreeMap() ? 'icon_vis_chord' : 'icon_vis_treemap'\"></i>\n" +
    "        </button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);
