logger.info("***************************************************");
logger.info("* converting JsonAttributes to SelectedAttributes *");
logger.info("***************************************************");

function fillMissingAttributes(cachedAttrs, selectedAttrsList, hiddenList) {
	var lookup = {};
	for ( var i=0; i<selectedAttrsList.length; i++) {
		lookup[selectedAttrsList[i].attributeName] = selectedAttrsList[i];
	}
	for ( var k=0; k<cachedAttrs.length; k++ ) {
		var dataAttr = cachedAttrs[k];
		var sourceName = dataAttr.sourceName;
		if ( !sourceName ) {
			sourceName = dataAttr.name;
		}
		if ( !lookup[sourceName] && !hiddenList[sourceName]) {
			logger.debug("* Generating SelectedAttribute: ");
			var selectedAttr = {
					"doClass":"SelectedAttributeDO",
					"attributeName":sourceName,
					"newAttributeName":dataAttr.name,
					"attributeType":0,
					"primaryKey":dataAttr.isId,
					"indexingOn":false,
					"elucidators":[],
					"optionalModifier":null
			};
			if ( selectedAttr.attributeName == selectedAttr.newAttributeName ) {
				selectedAttr.newAttributeName = undefined;
			}
			if ( dataAttr.type == "STRING" ) {
				selectedAttr.attributeType = 0;
			} else if ( dataAttr.type == "INT" ) {
				selectedAttr.attributeType = 1;
			} else if ( dataAttr.type == "LONG" ) {
				selectedAttr.attributeType = 2;
			} else if ( dataAttr.type == "NUMBER" ) {
				selectedAttr.attributeType = 3;
			} else if ( dataAttr.type == "BOOLEAN" ) {
				selectedAttr.attributeType = 4;
			} else if ( dataAttr.type == "DATE" ) {
				selectedAttr.attributeType = 5;
			} 

			if ( logger.isDebugEnabled() ) {
				logger.debug("* Pushing SelectedAttribute: {}", JSON.stringify(selectedAttr));
			}
			selectedAttrsList.push( selectedAttr );
		}
	}
	
}

upgradeUtil.updateAllObjects("DataFeedDO", function (obj) {
    if (obj.typeName.indexOf("JSON") > -1) {
        var propertyValues = obj.properties.propertyValues;
        var hiddenList = {};
        for (var i=0; i < propertyValues.length; i++) {
            if (propertyValues[i].propertyTypeName === "JsonAttributes") {
                propertyValues[i].propertyTypeName = "SelectedAttributes";
                var jsonAttributes = JSON.parse(propertyValues[i].value);
                jsonAttributes.doClass = "SelectedAttributesDO";
                var shownList = [];
                var allList = jsonAttributes.jsonAttributeList;
                for (var j=0; j < allList.length; j++) {
                    if (! allList[j].hidden) {
                        delete allList[j].hidden;
                        delete allList[j].preview;
                        allList[j].doClass = "SelectedAttributeDO";
                        if (allList[j].attributeName === allList[j].newAttributeName) {
                            allList[j].newAttributeName = undefined;
                        }
                        shownList.push(allList[j]);
                    } else {
                    		hiddenList[allList[j].attributeName] = allList[j];
                    }
                }
                
                fillMissingAttributes(obj.cachedAttributeDefs, shownList, hiddenList);
                
                jsonAttributes.selectedAttributeList = shownList;
                delete jsonAttributes.jsonAttributeList;
                propertyValues[i].value = JSON.stringify(jsonAttributes);
                break;
            }
        }
    }

    return obj;
}, false);

