logger.info("***********************************************");
logger.info("* updating ConnectionDO creationTime          *");
logger.info("***********************************************");

var Date = Java.type("java.util.Date");
var nowValue = new Date().getTime();

var path = "ConnectionService/ConnectionDO.json"

if (upgradeUtil.fileExists(path)) {
    var json = upgradeUtil.readFileByPath(path);
    var obj = JSON.parse(json);

    var connections = obj.objects;

    for (var connectionCount = 0; connectionCount < connections.length; connectionCount++) {

        var connection = connections[connectionCount];

        connection.creationTime = nowValue;
        connection.requiresLicense = true;
    }

    upgradeUtil.writeFile(path, JSON.stringify(obj));
}
