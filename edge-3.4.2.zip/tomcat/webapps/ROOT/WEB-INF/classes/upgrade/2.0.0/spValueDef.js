(function () {

    var jsonFileNames = upgradeUtil.listAllJsonFiles();

    for (var key in jsonFileNames) {
        var jsonFilePath = jsonFileNames[key];

        var jsonIn = upgradeUtil.readFileByPath(jsonFilePath);

        var jsonOut = jsonIn.replace(/SpPrimitiveValueDefDO/g, "SpStringValueDefDO");

        if (jsonIn !== jsonOut) {
            logger.info("File changed: " + jsonFilePath);
            upgradeUtil.writeFile(jsonFilePath, jsonOut);
        }
    }


})();