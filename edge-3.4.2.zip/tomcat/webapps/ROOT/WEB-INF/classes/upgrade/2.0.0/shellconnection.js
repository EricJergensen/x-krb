logger.info("***********************************************");
logger.info("*       updating Shell Connections            *");
logger.info("***********************************************");

var connectionsPath = "ConnectionService/ConnectionDO.json";

if (upgradeUtil.fileExists(connectionsPath)) {
    var json = upgradeUtil.readFileByPath(connectionsPath);
    var connections = JSON.parse(json);
    var changed = false;
    
    for (i = 0; i < connections.objects.length; i++) {
        var connection = connections.objects[i];
	if( connection.typeName == "ShellExec" ) {

	    var pathIndex = -1;
	    var pathProp = null;
	    for( j = 0 ; j < connection.properties.propertyValues.length ; j++ ) {

		if( connection.properties.propertyValues[j].propertyDefName == "path" ) {

		    pathIndex = j;
		    pathProp = connection.properties.propertyValues[j];
		    break;
		}
	    }

	    if( pathIndex > -1 ) {

		changed = true;
		connection.properties.propertyValues.splice(pathIndex, 1);
		if( connection.endpoints.length > 0 ) {

		    connection.endpoints[0].properties.propertyValues.push(pathProp);
		}
	    }
	    
	}
    }

    if( changed ) {

	upgradeUtil.writeFile(connectionsPath, JSON.stringify(connections));
    }
}

function logObject(object) {
	logger.info(JSON.stringify(object, true));
}

function logObjectWithLabel(label, object) {
	logger.info(label + ":" + JSON.stringify(object, true));
}
