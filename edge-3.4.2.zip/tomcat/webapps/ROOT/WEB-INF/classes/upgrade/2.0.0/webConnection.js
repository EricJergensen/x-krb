var json = upgradeUtil.readFileByPath("ConnectionService/ConnectionDO.json");

//logger.info(json);
var obj = JSON.parse(json);
var connections = obj.objects, properties;
for (var i=0, len=connections.length; i < len; i++) {
    properties = connections[i].properties.propertyValues;
    for (var j=0; j < properties.length; j++) {
        if (properties[j].propertyDefName === "ssoHandlerType") {
            //logger.info(properties[j].value);
            properties[j].propertyTypeName = "ProxyCredentialTypeList";
        } else if (properties[j].propertyDefName === "appVersion") {
            //logger.info(properties[j].name);
            properties[j].propertyTypeName = "ProxyAppVersionList";
        }
    }
}
//logger.info(obj.doClass);
upgradeUtil.writeFile("ConnectionService/ConnectionDO.json", JSON.stringify(obj));
