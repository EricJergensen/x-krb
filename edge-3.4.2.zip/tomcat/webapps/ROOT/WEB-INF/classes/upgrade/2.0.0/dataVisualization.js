logger.info("***********************************************");
logger.info("*       updating DataVisualization            *");
logger.info("***********************************************");

loadScript('MegaFormatterUtil.js');
loadScript('ListVis.js');
loadScript('ChartVis.js');
loadScript('TableVis.js');
loadScript('TopoVis.js');
loadScript('GaugeVis.js');
loadScript('MapVis.js');

function loadScript(script) {
    upgradeUtil.loadUpgradeScript('2.0.0/lib/' + script);
}

var path = "DataVisualizationService/DataVisualizationDO.json";
if (upgradeUtil.fileExists(path)) {
    var json = upgradeUtil.readFileByPath(path);
    var obj = JSON.parse(json);
    for (i = 0; i < obj.objects.length; i++) {
        var currentConfig = obj.objects[i];
        switch (currentConfig.type.name) {
            case "Table":
                updateTable(currentConfig);
            break;
            case "List":
                updateList(currentConfig);
            break;
            case "Gauge":
                updateGauge(currentConfig);
            break;
            case "Topo":
                updateTopo(currentConfig);
            break;
            case "Map":
                updateMap(currentConfig);
            break;
            case "Chart":
                updateChart(currentConfig);
            break;
        }
    }
    upgradeUtil.writeFile(path, JSON.stringify(obj));
}

function logObject(object) {
	logger.info(JSON.stringify(object, true));
}

function logObjectWithLabel(label, object) {
	logger.info(label + ":" + JSON.stringify(object, true));
}



