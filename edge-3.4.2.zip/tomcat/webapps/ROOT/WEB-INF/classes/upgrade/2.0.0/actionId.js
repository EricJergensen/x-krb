logger.info("***********************************************");
logger.info("*       updating switch-to-page action IDs    *");
logger.info("***********************************************");

var contentPath = "MenuContentManager/AContentNodeDO.json";
if (upgradeUtil.fileExists(contentPath)) {
    var json = upgradeUtil.readFileByPath(contentPath);
    var content = JSON.parse(json);

    if( content.objects && content.objects[0] ) {

        var rootNodes = content.objects;

        if (typeof edgeCore_deployingBundle !== 'undefined') {
            logger.info("Adjusting switch-to-page references for bundle: {} => {}", edgeCore_bundlePrefix, edgeCore_deployPrefix);
            setPathsForBundleDeployment(rootNodes, "Root", edgeCore_bundlePrefix, edgeCore_deployPrefix);
        } else {
            setPathsForUpgrade(rootNodes, "Root");
        }

        // Now, find and update all the actions
        var prodInstancePath = "VisualizationService/ProducerInstanceDO.json";
        if (upgradeUtil.fileExists(prodInstancePath)) {
            json = upgradeUtil.readFileByPath(prodInstancePath);
            var pis = JSON.parse(json);

            var changed = false;
//	    logger.info("Processing producer instances");
            for( var i = 0 ; i < pis.objects.length ; i++ ) {

                for( var j = 0 ; j < pis.objects[i].visualizationInstances.length ; j++ ) {

                    var vi = pis.objects[i].visualizationInstances[j];
                    if( vi.actionsConfig != null ) {

                        var changedActions = false;
                        var actionsConfig = JSON.parse(vi.actionsConfig);
                        if( actionsConfig.hasOwnProperty("actions") ) {
                            for( var k = 0 ; k < actionsConfig.actions.length ; k++ ) {
                                var action = actionsConfig.actions[k];

                                if( action.hasOwnProperty("selectedPage")) {

				    // logger.info("Found switch to page action");
                                    var elems = action.selectedPage.split("/");
//				    logger.info( "stp node hash: " + action.selectedPage + " (" + elems[0] + ")");
                                    var node = findNodeByHash(rootNodes, elems[0], elems[1]);

                                    if( node != null ) {

					// logger.info( "found stp node" );
                                        var oldSelectedPage = action.selectedPage;
                                        action.selectedPage = node.newHash + "/" + node.name;
                                        logger.info( "Replacing \"" + oldSelectedPage + "\" with: " + action.selectedPage );
                                        changed = true;
                                        changedActions = true;
                                    } else {

                                        logger.warn( "Did not find switch to page action: " + action.selectedPage );
                                    }
                                }
                            }
                        }

                        if( changedActions ) {

                            pis.objects[i].visualizationInstances[j].actionsConfig = JSON.stringify(actionsConfig);
                        }
                    }
                }
            }

            if( changed ) {

                upgradeUtil.writeFile(prodInstancePath, JSON.stringify(pis, null, 3));
            }
        }
    }

}

function findNodeByHash(rootNodes, hash, pageName) {

    for( var i = 0 ; i < rootNodes.length ; i++ ) {

        var result = findNodeByHash_(rootNodes[i], hash, pageName);

        if( result ) {

            return result;
        }
    }

    return null;
}

function findNodeByHash_(parent, hash, pageName) {

//    logger.info( "comparing " + parent.parentPath + ":" + parent.name + " (" + parent.oldHash + ") to " + hash );
    if( parent.oldHash == hash && parent.name == pageName) {

        return parent;
    }

    if( parent.hasOwnProperty("children") ) {

        for( var i = 0 ; i < parent.children.length ; i++ ) {

            var cHash = findNodeByHash_(parent.children[i], hash, pageName);
            if( cHash ) {

                return cHash;
            }
        }
    }

    return null;
}

function setPathsForUpgrade(roots, pathSoFar) {
    setPathsOnRootNodes(roots, pathSoFar,
        function(parent) { return upgradeUtil.legacyMenuHash(parent.name, parent.parentPath); },
        function(parent) { return upgradeUtil.menuHash(parent.parentPath); });
}

function setPathsForBundleDeployment(roots, pathSoFar, bundlePrefix, deployPrefix) {
    setPathsOnRootNodes(roots, pathSoFar,
        function(parent) { return upgradeUtil.menuHash(parent.parentPath); },
        function(parent) { return upgradeUtil.menuHash(parent.parentPath.replace(bundlePrefix, deployPrefix)); });
}

function setPathsOnRootNodes(roots, pathSoFar, calcOldHash, calcNewHash) {

    for( var i = 0 ; i < roots.length ; i++ ) {

        var rootPath = pathSoFar;
        logger.info( "parentPath = " + roots[i].parentPath );
        var parentPath = roots[i].parentPath;
        if (parentPath) {
            if (parentPath.length > 0) {
                if (parentPath[0] !== '/') {
                    parentPath = '/' + parentPath;
                }
            }

            if (parentPath.length > 1) {
                rootPath += parentPath;
            }
        }
        setPathsOnNodes(roots[i],rootPath,calcOldHash,calcNewHash);
    }
}

function setPathsOnNodes(parent, pathSoFar, calcOldHash, calcNewHash) {

    parent.parentPath = pathSoFar;
    parent.oldHash = calcOldHash(parent);
    parent.newHash = calcNewHash(parent);
//    logger.info( "processing: " + parent.parentPath + ":" + parent.name + "; OLD=" + parent.oldHash + "; NEW=" + parent.newHash );

    if( pathSoFar.length > 0 ) {
        pathSoFar = pathSoFar + "/";
    }
    pathSoFar = pathSoFar + parent.name;

    if( parent.hasOwnProperty("children") ) {

        for( var i = 0 ; i < parent.children.length ; i++ ) {

            setPathsOnNodes(parent.children[i], pathSoFar, calcOldHash, calcNewHash);
        }
    }
}

function logObject(object) {
    logger.info(JSON.stringify(object, true));
}

function logObjectWithLabel(label, object) {
    logger.info(label + ":" + JSON.stringify(object, true));
}
