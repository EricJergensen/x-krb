logger.info("***********************************************");
logger.info("* Updating System Menu                        *");
logger.info("***********************************************");
//**********************************************************************************************************************
//* Load New System Menu Data
//**********************************************************************************************************************
upgradeUtil.loadUpgradeScript('3.0.0/lib/NewSystemMenuData.js');
//**********************************************************************************************************************
//* Upgrade the Menu Content
//**********************************************************************************************************************
var menuContentFile = "MenuContentManager/AContentNodeDO.json";
//wrap in TRY/CATCH just in case it's a partial backup without Menu Content
try {
	var json = upgradeUtil.readFileByPath(menuContentFile);
	var obj  = JSON.parse(json);
	if (upgradeUtil.fileExists("lib/devOverlay.jar")) {
	    //the backup had devOverlay
	
	    //while technically you aren't supposed to manage modules in product upgrade it's quicker and easier to make a
	    //special exception for the devOverlay here.  Otherwise we would force all developers to upgrade their module to
	    //get the menu fixed.
	    newMenu.children[2].children.push(adminTools);  //add the Admin Tools menu back into the menu
	}
	//find and replace the System menu in the archive with the new one
	//this does mean if the archive modified the System Menu it would be lost, but we didn't officially support that in
	//version 1.0
	obj.objects = obj.objects.map(function (item) {
	    return item.name === "System Menu" ? newMenu : item;
	});
	upgradeUtil.writeFile(menuContentFile, JSON.stringify(obj));
} catch (e) {
	logger.info("Content Menu data was not found in this archive, nothing to upgrade.");
	logger.info(e);
}
