logger.info("***********************************************");
logger.info("*       updating DataVisualization            *");
logger.info("***********************************************");

var path = "DataVisualizationService/DataVisualizationDO.json";
if (upgradeUtil.fileExists(path)) {

	upgradeUtil.updateAllObjectsInFile(path, "ColorPaletteDO", function(propertyValue) {
            
       if (propertyValue.name === 'Default') 
           propertyValue.name = 'Chart'; 

       return propertyValue; 
    }, true);  
}




