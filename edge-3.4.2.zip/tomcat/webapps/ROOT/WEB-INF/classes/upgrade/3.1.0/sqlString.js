logger.info("***********************************************");
logger.info("* updating SQLString                          *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("PropertyValueDO", function(propertyValue) {

    if (propertyValue.propertyTypeName !== "SQLString") {
        return propertyValue;
    }

    var sqlString = propertyValue.value;

    if (sqlString) {

        sqlString = sqlString.replace(/'{nodeVar.(\w+)}'/g, "{nodeVar.$1}");
        sqlString = sqlString.replace(/'{secVar.(\w+)}'/g, "{secVar.$1}");

        // now attempt to deal with less trivial literal strings that include variable references
        // NB nested 2 arg concat calls for better portability:
        sqlString = sqlString.replace(/'([\w%]+){nodeVar.(\w+)}([\w%]+)'/g, "CONCAT('$1',CONCAT({nodeVar.$2},'$3'))");
        sqlString = sqlString.replace(/'([\w%]+){secVar.(\w+)}([\w%]+)'/g, "CONCAT('$1',CONCAT({secVar.$2},'$3'))");

        logger.debug("Found SQLString property, value was {}\nis now: {}", propertyValue.value, sqlString);

        propertyValue.value = sqlString;
    }
    return propertyValue;

}, true);

