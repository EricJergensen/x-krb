if (!fullBackup) {
	// remove user info from partial restores
	logger.info("***********************************************");
	logger.info("*   removing user info from partial restore   *");
	logger.info("***********************************************");
	
	var filePath = "entities/AccountAdapterManager-AccountAdapterRestoreBundleDO.json";
	if (upgradeUtil.fileExists(filePath)) {
	    //get original JSON
	    var originalJSON = JSON.parse(upgradeUtil.readFileByPath(filePath));
	    
	    // confirm we're looking at the right backup data
	    // "backupClass" : "edge.server.account.adapter.AccountAdapterRestoreBundleDO"
	    if (originalJSON.hasOwnProperty("backupClass") && originalJSON["backupClass"] == "edge.server.account.adapter.AccountAdapterRestoreBundleDO") {
	    	// if we're in the right file, remove the backup data
	    	originalJSON.objects = [];
	    	logger.info("File changed: " + filePath);
	    }
	    
	    upgradeUtil.writeFile(filePath, JSON.stringify(originalJSON));
	}
}