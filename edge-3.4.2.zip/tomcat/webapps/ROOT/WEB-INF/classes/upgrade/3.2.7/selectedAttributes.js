logger.info("*********************************************************");
logger.info("* deduplicating newAttributeNames in SelectedAttributes *");
logger.info("*********************************************************");

var configService = upgradeUtil.getBean("configService");
var dropDuplicateSelectedAttributes = configService.getDefaultConfiguration().getBoolean("edge.import.dropDuplicateSelectedAttributes", true);
if ( dropDuplicateSelectedAttributes ) {
	logger.info("* system configured to drop duplicated selected attributes.  Add edge.import.dropDuplicateSelectedAttributes=false to /conf/custom.properties to rename using _index suffix pattern.")
}
upgradeUtil.updateAllObjects("PropertyValueDO", function (obj) {
    if ( obj.propertyTypeName && ( obj.propertyTypeName === "SelectedAttributes" ) && obj.value ) {
    		var selectedAttributes = JSON.parse(obj.value); 
    		// Avoid processing any data sources that have a huge amount of selectedAttributes (slows the system down too much).
    		if ( selectedAttributes.selectedAttributeList.length < 1000) {
	    		var newSelectedAttributes = [];
	            
	    		// JS version of ProducerHelper.makeSafeAttributeSets
	    		var upperAttrNames = {};
	    		var modified = false;
	    		var newIndex = 0;
        		selectedAttributes.selectedAttributeList.forEach(function(selectedAttr)  {
         		//for (var j = 0; j < selectedAttributeList.length; j++) {
        			
        			//var selectedAttr = selectedAttributeList[j];
        			// get newAttributeName if the override exists, original attr name otherwise
        			var newName = (selectedAttr.newAttributeName) ? selectedAttr.newAttributeName : selectedAttr.attributeName;
        			var origNewName = newName;
        			var upperName = newName.toUpperCase();
        			var origUpperName = upperName;
        		    
        			// Check if name is a duplicate of a prior attribute, rename if so; want to avoid dupes even if case differences
    				var appendedId = 1;
	                // if name already used, build list of names coming after to confirm renamed attribute doesn't collide            				
    				while(upperAttrNames[upperName]) {
    					upperName = origUpperName  + "_" + appendedId;
    					newName = origNewName + "_" + appendedId;
    					appendedId++;
    				}
    				
    				if (appendedId > 1) {
    					modified = true;
    					if ( dropDuplicateSelectedAttributes ) {
        					logger.info("Deduplicating attribute: {}, dropping duplicate mapping of: {} will be dropped.", origNewName, selectedAttr.attributeName);
    					} else {
        					logger.info("Deduplicating attribute: {}, creating new attribute named: {}", origNewName, newName);
            				selectedAttr.newAttributeName = newName;
            				selectedAttributeList[j] = selectedAttr;
        					newSelectedAttributes[newIndex++] = selectedAttr;
    					}
    				} else {
    					newSelectedAttributes[newIndex++] = selectedAttr;
    				}
    				upperAttrNames[upperName] = upperName;
        		});
            
        		if ( modified ) {
        			logger.info("Deduplication complete (modified list) writing back to source...");
                    selectedAttributes.selectedAttributeList = newSelectedAttributes;
                    obj.value = JSON.stringify(selectedAttributes);
        		}
    		}
    }

    return obj;
}, false);