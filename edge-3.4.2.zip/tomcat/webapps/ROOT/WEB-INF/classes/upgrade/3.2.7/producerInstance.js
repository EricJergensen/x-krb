logger.info("**************************************************");
logger.info("* upgrade Producer Instance config               *");
logger.info("**************************************************");


var producerInstances = {};

upgradeUtil.updateAllObjects("ProducerInstanceDO", function (producerInstance) {
    producerInstances[producerInstance["id"]] = producerInstance;
    return null;
});

upgradeUtil.updateAllObjects("PageDO", function (page) {

    var producerInstanceIds = page["producerInstanceIds"];

    page["producerInstances"] = [];
    for (var i = 0; i < producerInstanceIds.length; i++) {
    	var producerInstance = producerInstances[producerInstanceIds[i]];
    	if ( producerInstance != null ) {
    	    if ( logger.isDebugEnabled() ) {
    	        logger.debug("producerInstance {} = {}", producerInstanceIds[i], JSON.stringify(producerInstance));
    	    }
    	    page["producerInstances"].push(producerInstance);
    	} else {
	        logger.warn("Unable to update producerInstance not found for  producerInstanceIds[{}] = {}", i, producerInstanceIds[i]);
    	}
    }

    return page;
});
