if (!fullBackup) {
	logger.info("***********************************************");
	logger.info("*   removing config.sql for partial restore   *");
	logger.info("***********************************************");
	
	var filePath = "config.sql";
	if (upgradeUtil.fileExists(filePath)) {

		upgradeUtil.deleteFile(filePath);
	}
}
