logger.info("***********************************************");
logger.info("*       updating PropertyBundles              *");
logger.info("***********************************************");

function unique(properties) {
    var u = {}, propertyValueDO, result = { "foundDuplicates": false, "uniqueProps": [], "duplicatePropValues": [] };
    for(var i = 0, l = properties.length; i < l; ++i){
        propertyValueDO = properties[i];
        if(!u.hasOwnProperty(propertyValueDO.propertyDefName)) {
            result.uniqueProps.push(propertyValueDO.propertyDefName);
            u[propertyValueDO.propertyDefName] = 1;
        } else {
           result.foundDuplicates = true;
           result.duplicatePropValues.push(propertyValueDO);
           //logger.warn("Duplicate PropertyValueDO entry found for key: {}, value: {}", propertyValueDO.propertyDefName, propertyValueDO.value );
        }
    }
    return result;
}

upgradeUtil.updateAllObjects("PropertyBundleDO", function(propertyBundleDO) {
    if (propertyBundleDO.propertyValues) {
        var result = unique( propertyBundleDO.propertyValues );
        
        var propertyValues = [];
        if ( result.duplicatePropValues.length > 0 ) {
           for ( var k=0; k<result.uniqueProps.length; k++ ) {
              propertyValues.push( upgradeUtil.getProperty(result.uniqueProps[k], propertyBundleDO) );
           }
           
		   logger.warn("Processing duplicate PropertyValueDO's found: {} duplicates on PropertyBundleDO, expected: {}, total found: {}", result.duplicatePropValues.length, propertyValues.length, propertyBundleDO.propertyValues.length);
           propertyBundleDO.propertyValues = propertyValues;
           for ( var h=0; h < result.duplicatePropValues.length > 0; h++ ) {
              //logger.warn("Checking for duplicate value on: {}, value: {}", result.duplicatePropValues[h].propertyDefName, result.duplicatePropValues[h].value);
              var propValSet = upgradeUtil.getProperty(result.duplicatePropValues[h].propertyDefName, propertyBundleDO);
              if ( propValSet.value !== result.duplicatePropValues[h].value && !propValSet.value ) {
                  logger.warn("Overriding duplicate PropertyValueDO on key: {}, value: {} existing value: {}", propValSet.propertyDefName, result.duplicatePropValues[h].value, propValSet.value );
                  propValSet.value = result.duplicatePropValues[h].value;
				  //} else {
	              //logger.warn("skipping update current value: {}", propValSet.value);
              }
           }
        }
    }
    return propertyBundleDO;
});

