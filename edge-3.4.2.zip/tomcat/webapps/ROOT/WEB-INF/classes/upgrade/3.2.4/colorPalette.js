logger.info("**************************************************");
logger.info("* updating HeapMap, Flow, TreeMap Visualizations *");
logger.info("**************************************************");

function getProperty(propName, configDO) {
	var propertyValues = configDO.properties.propertyValues;
    for (var i = 0; i < propertyValues.length; i++) {
        var pv = propertyValues[i];
        if (pv.propertyDefName === propName) {
            return pv;
        }
    }
    return null;
}

function getPropertyValue(propName, propertyValues) {
	var prop = getProperty(propName, propertyValues);
	if ( prop != null ) {
		return prop.value;
	}
	return null;
}

upgradeUtil.updateAllObjects("DataVisualizationDO", function (dataVisualizationDO) {
    if (dataVisualizationDO.typeName === "HeatMap") {
        var palette = upgradeUtil.getProperty("palette", dataVisualizationDO);

        var colorPalette = JSON.parse(palette.value);
        //logger.info(colorPalette);
        colorPalette.paletteName = colorPalette._palette.name;
        colorPalette._palette = undefined;
        colorPalette._maxSize = undefined;
        palette.value = JSON.stringify(colorPalette);
    } else if (dataVisualizationDO.typeName === "Flow" || dataVisualizationDO.typeName === "TreeMap") {
        var rendererConfig = upgradeUtil.getProperty("rendererConfig", dataVisualizationDO);

        var config = JSON.parse(rendererConfig.value);
        //logger.info(config);
        for (var i = 0; i < config.rendererDefs.length; i++) {
            var colorPalette = config.rendererDefs[i].palette;
            if ( colorPalette._palette ) {
                colorPalette.paletteName = colorPalette._palette.name;
                //var visName = upgradeUtil.getPropertyValue("name", dataVisualizationDO);
                //logger.warn("Visualization named: {} of type: {} has colorPalette config named: {} on renderer: {}", visName, dataVisualizationDO.typeName, colorPalette.paletteName, config.rendererDefs[i].displayName);
            } else {
                var visName = upgradeUtil.getPropertyValue("name", dataVisualizationDO);
                logger.warn("Visualization named: {} of type: {} is missing colorPalette config renderer on: {}", visName, dataVisualizationDO.typeName, config.rendererDefs[i].displayName);
            }
            colorPalette._palette = undefined;
            colorPalette._maxSize = undefined;
        }
        rendererConfig.value = JSON.stringify(config);
    }
    return dataVisualizationDO;
}, false);


logger.info("***********************************************");
logger.info("*        updating Color Palettes              *");
logger.info("***********************************************");

var modifiedSystemPalettes = {};

function palettesAreEqual(existingPalette, archivePalette) {

    var same = existingPalette.getId() === archivePalette['id'] &&
        existingPalette.getName() === archivePalette['name'] &&
        existingPalette.getType() === archivePalette['type'] &&
        existingPalette.getMaxSize() === archivePalette['maxSize'];

    if (!same) {
        return false;
    }

    var existingSize = existingPalette.getColors().size();
    var archiveSize = archivePalette['colors'].length;

    if (existingSize !== archiveSize) {
        return false;
    }

    var i = 0;
    existingPalette.getColors().forEach(function(color) {
        if (color !== archivePalette['colors'][i]) {
            same = false;
        }
        i++;
    });

    return same;
}

upgradeUtil.updateAllObjects("ColorPaletteDO", function(palette) {

    if (palette.id.startsWith('_system_')) {

        // compare with system created one - if same, then drop, else rename
        var visualizationService = upgradeUtil.getBean('visualizationService');

        var existingPalette = visualizationService.getColorPalette(palette.id);

        if (existingPalette && palettesAreEqual(existingPalette, palette)) {
            // drop from archive - unchanged from system definition
            return null;
        }

        // keep track of renamed ones, so we can update all refs in the system below
        var systemPaletteName = palette.name;
        palette.id = upgradeUtil.getUID();
        palette.name = palette.name + " (modified system palette)";

        modifiedSystemPalettes[systemPaletteName] = palette;

        logger.info('Renamed modified system palette: ' + systemPaletteName);
    }

    return palette;

}, false);

// now fix any refs for the renamed palettes
upgradeUtil.updateAllObjects("PropertyValueDO", function(propVal) {

    var val = propVal.value;
    if (val && typeof(val) === 'string') {
        for (var systemPaletteName in modifiedSystemPalettes) {
            if (val === systemPaletteName) {
                val = modifiedSystemPalettes[systemPaletteName].name;
            } else {
                val = val.replace(new RegExp('"' + systemPaletteName + '"', 'g'), '"' + modifiedSystemPalettes[systemPaletteName].name + '"');
                val = val.replace(new RegExp('\\"' + systemPaletteName + '\\"', 'g'), '\\"' + modifiedSystemPalettes[systemPaletteName].name + '\\"');
                val = val.replace(new RegExp('"' + systemPaletteName + '-(\d+)"', 'g'), '"' + modifiedSystemPalettes[systemPaletteName].name + '-$1"');
                val = val.replace(new RegExp('\\"' + systemPaletteName + '-(\d+)\\"', 'g'), '\\"' + modifiedSystemPalettes[systemPaletteName].name + '-$1\\"');
            }
            propVal.value = val;
        }
    }

    return propVal;

}, false);
