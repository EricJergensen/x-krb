logger.info("***********************************************");
logger.info("*          updating Map Layers                *");
logger.info("***********************************************");

var modifiedSystemLayers = {};

function layersAreEqual(existingLayer, archiveLayer) {
    return existingLayer.getId() === archiveLayer['id'] &&
        existingLayer.getType() === archiveLayer['type'] &&
        existingLayer.getLayerType() === archiveLayer['layerType'] &&
        existingLayer.getName() === archiveLayer['name'] &&
        existingLayer.getDisplayName() === archiveLayer['displayName'] &&
        existingLayer.getOptions() === archiveLayer['options'] &&
        existingLayer.getUrls() === archiveLayer['urls'] &&
        existingLayer.getThemeOptions() === archiveLayer['themeOptions'] &&
        existingLayer.getApiKeyName() === archiveLayer['apiKeyName'];
}

upgradeUtil.updateAllObjects("MapLayerDO", function(layer) {

    if (layer.id.startsWith('_system_')) {

        // compare with system created one - if same, then drop, else rename
        var mapService = upgradeUtil.getBean('mapService');

        var existingLayer = mapService.getMapTile(layer.id);

        if (existingLayer && layersAreEqual(existingLayer, layer)) {
            // drop from archive - unchanged from system definition
            return null;
        }

        // keep track of renamed ones, so we can update all refs in the system below
        var systemLayerName = layer.name;
        layer.id = upgradeUtil.getUID();
        layer.name = layer.name + " (modified system layer)";
        layer.displayName = layer.displayName + " (modified system layer)";

        modifiedSystemLayers[systemLayerName] = layer;

        logger.info('Renamed modified system map layer: ' + systemLayerName);
    }

    return layer;

}, false);

// now fix any refs for the renamed layers
upgradeUtil.updateAllObjects("PropertyValueDO", function(propVal) {

    var val = propVal.value;
    if (val && typeof(val) === 'string') {
        for (var systemLayerName in modifiedSystemLayers) {
            if (val === systemLayerName) {
                val = modifiedSystemLayers[systemLayerName].name;
            } else {
                val = val.replace(new RegExp('"' + systemLayerName + '"'), '"' + modifiedSystemLayers[systemLayerName].name + '"');
                val = val.replace(new RegExp('\\"' + systemLayerName + '\\"'), '\\"' + modifiedSystemLayers[systemLayerName].name + '\\"');
            }
            propVal.value = val;
        }
    }

    return propVal;

}, false);
