logger.info("***********************************************");
logger.info("* updating JavaScript producers               *");
logger.info("***********************************************");

var path = "DataProducerService/AbstractTabularProducerDO.json";

if (upgradeUtil.fileExists(path)) {
    var json = upgradeUtil.readFileByPath(path);
    var obj = JSON.parse(json);

    var producers = obj.objects;

    for (var producerCount = 0; producerCount < producers.length; producerCount++) {

        var producer = producers[producerCount];

        if (producer.doClass == "TabularTransformDO" || producer.doClass == "DataFeedDO") {
            var props = producer.properties.propertyValues;
            for (var propCount = 0; propCount < props.length; propCount++) {
                if (props[propCount].propertyTypeName == "JSString") {

                    var userJs = props[propCount].value;
                    var matches = userJs.match(/\n.*new TabularRecordDO\(.*;[.]*\n/m);

                    if (!matches) continue;

                    for (var matchCount = 0; matchCount < matches.length; matchCount++) {
                        var newCode = "\n\n// replaced by 2.1.0 upgrade\n"
                            + "// " + matches[matchCount].substr(1)
                            + matches[matchCount].replace(/new TabularRecordDO\(.*;/, "outputBundle.getResultSet().newRecord();").substr(1)
                            + "\n";

                        props[propCount].value = userJs.replace(matches[matchCount], newCode);
                    }
                }
            }
        }
    }

    upgradeUtil.writeFile(path, JSON.stringify(obj));
}
