logger.info("**************************************************");
logger.info("* upgrade ConfigItems                            *");
logger.info("**************************************************");


var moduleDefs = [];

function createModuleDef(configItem) {

    var moduleDef;
    var valueItems = configItem["value"].split(":::");

    if (valueItems.length === 6) {
        moduleDef = {
            "doClass": "ModuleDefDO",
            "name": valueItems[0],
            "version": valueItems[1],
            "vendor": valueItems[2],
            "vendorDescription": valueItems[3],
            "description": valueItems[4],
            "fileName": valueItems[5]
        };
    } else {
        moduleDef = {
            "doClass": "ModuleDefDO",
            "name": valueItems[0],
            "version": valueItems[1],
            "vendor": valueItems[2],
            "vendorDescription": valueItems[2],
            "description": valueItems[3],
            "fileName": valueItems[4]
        };
    }

    return moduleDef;
}

upgradeUtil.updateAllObjects("RestoreBundleDO", function (bundle) {

    var backupClass = bundle["backupClass"];
    if (backupClass === "edge.server.config.ConfigItem") {
        bundle["backupClass"] = "edge.server.config.shared.ConfigItem";

        if (bundle["objects"]) {
            var objects = bundle["objects"];
            bundle["objects"] = [];
            for (var i = 0; i < objects.length; i++) {
                var configItem = objects[i];

                if (configItem["key"] === "modules.loaded") {
                    moduleDefs.push(createModuleDef(configItem));
                } else {
                    bundle["objects"].push(configItem);
                }
            }
        }
    }

    return bundle;
});

if (moduleDefs.length > 0) {

    logger.info("Moved " + moduleDefs.length + " module configuration items to local table");

    var moduleBundle = {
        "doClass": "RestoreBundleDO",
        "backupClass": "edge.server.admin.backup.ModuleDefDO",
        "objects": moduleDefs
    };

    upgradeUtil.writeFile("entities/ModuleService-ModuleDefDO.json", JSON.stringify(moduleBundle));
}
