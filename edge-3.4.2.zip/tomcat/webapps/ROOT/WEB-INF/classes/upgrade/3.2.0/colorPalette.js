logger.info("***********************************************");
logger.info("*       updating ColorPalette                 *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("ColorPaletteDO", function(palette) {
	switch (palette.name) {
	case "Chart":
		palette.id = "_system_chart";
		break;
	case "Fire":
		palette.id = "_system_fire";
		break;
	case "Ice":
		palette.id = "_system_ice";
		break;
	case "Spectrum":
		palette.id = "_system_spectrum";
		break;
	case "ColorWheel":
		palette.id = "_system_colorwheel";
		break;
	case "Greyscale":
		palette.id = "_system_greyscale";
		break;
	case "Autumn":
		palette.id = "_system_autumn";
		break;
	case "Spring":
		palette.id = "_system_spring";
		break;
	case "Summer":
		palette.id = "_system_summer";
		break;
	case "Evergreen":
		palette.id = "_system_evergreen";
		break;
	case "Ocean":
		palette.id = "_system_ocean";
		break;
	}
	
	return palette;
	
}, false);





