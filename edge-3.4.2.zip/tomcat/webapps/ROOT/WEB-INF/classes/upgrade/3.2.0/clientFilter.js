logger.info("***********************************************");
logger.info("*       updating Client Filters               *");
logger.info("***********************************************");

var filterIDFixMap = {};
var filterIDFixed = false;
upgradeUtil.updateAllObjects("ClientFilterDO", function(filter) {
	switch (filter.name) {
	case "Date Range Picker":
		filterIDFixMap[filter.id] = "_system_daterangefilter";
		filter.id = "_system_daterangefilter";
		filterIDFixed = true;
		break;
	case "Date Range Slider":
		filterIDFixMap[filter.id] = "_system_daterangeslider";
		filter.id = "_system_daterangeslider";
		filterIDFixed = true;
		break;
	case "Client Pagination":
		filterIDFixMap[filter.id] = "_system_pagination";
		filter.id = "_system_pagination";
		filterIDFixed = true;
		break;
	case "Search Field":
		filterIDFixMap[filter.id] = "_system_searchfield";
		filter.id = "_system_searchfield";
		filterIDFixed = true;
		break;
	}
	return filter;
}, false);

if (filterIDFixed == true) {
	upgradeUtil.updateAllObjects("VisualizationInstanceDO", function(vis) {
		
		if (vis.hasOwnProperty('filtersConfig') && vis.filtersConfig != undefined) {
			var filters = JSON.parse(vis.filtersConfig);
			
			for (var i = 0; i < filters.instances.length; i++) {
				var filterInstance = filters.instances[i];
				if (filterIDFixMap[filterInstance.clientFilterID] != undefined) {
					filterInstance.clientFilterID = filterIDFixMap[filterInstance.clientFilterID];
				}
			}
			
			vis.filtersConfig = JSON.stringify(filters);
		}
		
		return vis;
		
	}, false);
}



