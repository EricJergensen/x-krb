logger.info("***********************************************");
logger.info("*       updating Chart Visualization          *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("DataVisualizationDO", function (dataVisualizationDO) {
    if (dataVisualizationDO.typeName === "Chart" || dataVisualizationDO.typeName === "piechart") {
        var propertyValues = dataVisualizationDO.properties.propertyValues;
        var dynamicSeries = false;
        var seriesPV;
        for (var i = 0; i < propertyValues.length; i++) {
            var pv = propertyValues[i];
            if (pv.propertyDefName === "dynamicSeries" && pv.value === true) {
                dynamicSeries = true;
            } else if (pv.propertyDefName === "series" && pv.value) {
                seriesPV = pv;
            }
        }

        if (seriesPV) {
            var series = JSON.parse(seriesPV.value);
            if (dataVisualizationDO.typeName === "Chart") {
                if (dynamicSeries) {
                    series[0].color.value = "";//clear out color info
                    if (series[0].palette && series[0].palette.name) {
                        series[0].palette = {value: series[0].palette.name};//simplify the palette object to string
                    }
                } else {
                    for (var i=0; i < series.length; i++) {//clear out palette object
                        series[i].palette = {value: ""};
                    }
                }
            } else {
                //logger.info(series);
                if (dynamicSeries) {
                    if (series.palette && series.palette._palette) {
                    series.palette = series.palette._palette.name;//simplify the palette object to string
                    }
                } else {
                    series.palette = undefined;
                }
            }
            seriesPV.value = JSON.stringify(series);
        }
    }
    return dataVisualizationDO;
}, false);
