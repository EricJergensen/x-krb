logger.info("***********************************************");
logger.info("* Updating System Manage Menu                 *");
logger.info("***********************************************");
//**********************************************************************************************************************
//* Load New System Manage Menu Data
//**********************************************************************************************************************
upgradeUtil.loadUpgradeScript('3.2.0/lib/NewSystemMenuData.js');
//**********************************************************************************************************************
//* Upgrade the System Manage Menu Content
//**********************************************************************************************************************
upgradeUtil.updateAllObjects("ContentFolderDO", function(folderItem) {

    if (folderItem.name === "System Menu") {
        for (var j=0; j < folderItem.children.length; j++) {
            var sysMenuItem = folderItem.children[j];
            if (sysMenuItem.name === "Manage") {
                sysMenuItem.children = newManageMenu;
                break;
            }
        }
    }

    return folderItem;

}, true);
