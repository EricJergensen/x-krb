logger.info("***********************************************");
logger.info("updating layout to support stacked Visualization");
logger.info("***********************************************");

function getCellData(prodInstanceDO, cell) {
    var found = false;
    if (cell.contentType === "content") {
        if (cell.prodInstanceId && cell.prodInstanceId.length > 0) {
            if (prodInstanceDO.id === cell.prodInstanceId) {
                delete cell.prodInstanceId;
                cell.stack = []
                for (var i=0; i < prodInstanceDO.visualizationInstances.length; i++) {
                    cell.stack.push(prodInstanceDO.visualizationInstances[i].id);
                }

                if (cell.stack.length > 1) {
                    var index = cell.stack.indexOf(prodInstanceDO.selectedVisualizationInstance);
                    if (index > 0) {
                        cell.stack.unshift(cell.stack.splice(index, 1)[0]);
                    }
                }
                cell.stackType = "interactive";
                found = true;
            }
        }
    } else if (cell.contentType === "rowContainer") {
        for (var i = 0; i < cell.cellData.length && !found; i++) {
            found = this.getCellData(prodInstanceDO, cell.cellData[i]);
        }
    } else {//columnContainer
        for (var i = 0; i < cell.cellData.length && !found; i++) {
            found = this.getCellData(prodInstanceDO, cell.cellData[i]);
        }
    }

    return found;
}

upgradeUtil.updateAllObjects("ProducerInstanceDO", function (prodInstanceDO) {
    var visInstanceDOs = prodInstanceDO.visualizationInstances;
    var newVisInstanceDOs = [];
    for (var i = 0; i < visInstanceDOs.length; i++) {
        var selectedVis = prodInstanceDO.selectedVisualizationInstance === visInstanceDOs[i].id;
        if (prodInstanceDO.allowAllVisualizations || selectedVis) {
            //new visId now with ":" separator between prod inst id and vis id
            visInstanceDOs[i].id = prodInstanceDO.id + ":" + visInstanceDOs[i].visualizationId;
            newVisInstanceDOs.push(visInstanceDOs[i]);
            if (selectedVis) {
                prodInstanceDO.selectedVisualizationInstance = visInstanceDOs[i].id;
            }

            if (! prodInstanceDO.allowAllVisualizations) {
                break;
            }
        }
    }

    //allowAllVisualizations not going to be used anymore so set it to false
    prodInstanceDO.allowAllVisualizations = false;
    prodInstanceDO.visualizationInstances = newVisInstanceDOs;

    //now look for this prod inst in our pages, and update the page when we found it

    var pageUpdateFunction = function (pageDO) {

        if (pageDO.hasOwnProperty("layout") && pageDO.layout) {
            var foundInPage = false;

            var layout = JSON.parse(pageDO.layout);
            if (pageDO.layoutType === "dashboard") {//only have 1 row of 100% height
                for (var i = 0; i < layout.rows[0].cellData.length && !foundInPage; i++) {
                    cellData = layout.rows[0].cellData[i];
                    foundInPage = this.getCellData(prodInstanceDO, cellData);
                }
            } else {
                for (var i = 0; i < layout.rows.length && !foundInPage; i++) {
                    cellData = layout.rows[i].cellData;
                    for (var j = 0; j < cellData.length && !foundInPage; j++) {
                        foundInPage = this.getCellData(prodInstanceDO, cellData[j]);
                    }
                }
            }

            if (foundInPage) {
                logger.info("found page for " + prodInstanceDO.properties.propertyValues[0].value);
                pageDO.layout = JSON.stringify(layout);
                found = true;
            }
        }

        return pageDO;
    };

    var menuContentFiles = [
        "entities/MenuContentManager-AContentNodeDO.json",
        "MenuContentManager/AContentNodeDO.json"
    ];
    var found = false;
    for (var fileCount = 0; fileCount < menuContentFiles.length; fileCount++) {
        if (upgradeUtil.fileExists(menuContentFiles[fileCount])) {
            upgradeUtil.updateAllObjectsInFile(menuContentFiles[fileCount], "PageDO", pageUpdateFunction, false);
        }
        if (found) {
            return prodInstanceDO;
        }
    }

    //return undefined to remove the instance
    logger.info("page not found for "+prodInstanceDO.properties.propertyValues[0].value);
    return undefined;

}, false);
