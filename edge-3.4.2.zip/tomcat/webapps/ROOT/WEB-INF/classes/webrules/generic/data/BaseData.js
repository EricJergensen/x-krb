/*
 * Copyright 2016 Edge Technologies
 */

/**
 * Created by erik on 9/06/2016.
 */

var BaseData = function(appContext) {

    this.baseRule = new BaseWeb(appContext);

    this.onRequest = function(ctx) {

        this.baseRule.onRequest(ctx);
    };

    this.onResponse = function(ctx) {

        this.baseRule.handleResponseHeaders(ctx);

        // Web data feeds must use the binary pipeline.  If transformation of the data is required, then use the
        // data pipeline.
        ctx.appRequestContext.setResponsePipelineType(ResponsePipelineType.BINARY);
        
        ctx.responsePipeline.setEvalStageEnabled(false);
    };
};
