// Replace getPrincipal and rename to customAuth.js to enable the custom JS authenticator.

function getPrincipal(request) {
  var userName = request.getHeader('edgeUser');
  if (userName != null && userName.length() > 0) {
	  return accountService.getUserByUsername(userName);
  }
  return null;
}
