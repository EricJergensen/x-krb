
                                edgeSuite
                      edgeCore / edgeData / edgeWeb
                           Edge Technologies


Overview
--------

  This archive is a turnkey installation of edgeSuite. Please ensure your
  system meets the system requirements and some post installation tasks
  may be necessary - see the sections below.

  edgeCore, edgeData, and edgeWeb run within a single instance of Tomcat. Actual
  product capabilities depend on adapters loaded into the system and issued
  license.


System Requirements
-------------------

  Refer to the "docs/System_Requirements_v3.1.pdf" document.


Installation
------------

  Refer to the "docs/Quick_Start_Guide_v3.1.pdf" document.

  Complete information covering installation and runtime options is
  available with the online documentation. This can access within the
  product via the Help -> Help page, or directly online at
  http://docs.edge-technologies.com


Included Versions
-----------------

  To make sure you have accurate version information please refer to the
  following scripts. Version information is also available within the
  product via the System Menu -> About page.

  * Run: [INSTALL_HOME]/bin/edge[.bat|.sh] version


License File
------------

  A license file is required for this software to run. Please contact
  support if you do not have this already.


License Agreement 
-----------------

  This product is commercial software and the terms of licensing may
  depend on the contact with Edge Technologies. Also refer to 
  "Edge_Software_EULA.pdf" and the Acknowledgements section below.


Acknowledgements
----------------

  edgeCore, edgeData, and edgeWeb are packaged with Apache Tomcat and
  rely on various commercial and open source third party libraries. 

  Refer to acknowledgements.txt for more information.


Contacts
--------

  * Support: support@edge-technologies.com

  * Online Documentation: http://docs.edge-technologies.com

  * Main Website: http://www.edge-technologies.com
