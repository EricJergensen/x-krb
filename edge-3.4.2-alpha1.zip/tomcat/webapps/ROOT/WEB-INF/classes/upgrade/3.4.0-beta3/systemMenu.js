logger.info("***********************************************");
logger.info("* Updating System Menu                        *");
logger.info("***********************************************");
//**********************************************************************************************************************
//* Load New System Menu Data
//**********************************************************************************************************************
upgradeUtil.loadUpgradeScript('3.4.0-beta3/lib/NewSystemMenuData.js');

if (!Array.prototype.find) {
	  Object.defineProperty(Array.prototype, 'find', {
	    value: function(predicate) {
	     // 1. Let O be ? ToObject(this value).
	      if (this == null) {
	        throw new TypeError('"this" is null or not defined');
	      }

	      var o = Object(this);

	      // 2. Let len be ? ToLength(? Get(O, "length")).
	      var len = o.length >>> 0;

	      // 3. If IsCallable(predicate) is false, throw a TypeError exception.
	      if (typeof predicate !== 'function') {
	        throw new TypeError('predicate must be a function');
	      }

	      // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
	      var thisArg = arguments[1];

	      // 5. Let k be 0.
	      var k = 0;

	      // 6. Repeat, while k < len
	      while (k < len) {
	        // a. Let Pk be ! ToString(k).
	        // b. Let kValue be ? Get(O, Pk).
	        // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
	        // d. If testResult is true, return kValue.
	        var kValue = o[k];
	        if (predicate.call(thisArg, kValue, k, o)) {
	          return kValue;
	        }
	        // e. Increase k by 1.
	        k++;
	      }

	      // 7. Return undefined.
	      return undefined;
	    }
	  });
	}

//**********************************************************************************************************************
//* Upgrade the Menu Content
//**********************************************************************************************************************
var menuContentFiles = [
    "entities/MenuContentManager-AContentNodeDO.json",
    "MenuContentManager/AContentNodeDO.json"
];

var menuBundle = upgradeUtil.findUpgradeBundleInFiles(
	function (backupClass) { return backupClass.endsWith(".AContentNodeDO") }, menuContentFiles
);

if (menuBundle) {

    var obj = JSON.parse(menuBundle.json);

    if (upgradeUtil.fileExists("lib/devOverlay.jar")) {
        //the backup had devOverlay

        var newSystem = systemMenu34.children.find(function (thisMenu) {
            return thisMenu.name == "System";
        });

        //while technically you aren't supposed to manage modules in product upgrade it's quicker and easier to make a
        //special exception for the devOverlay here.  Otherwise we would force all developers to upgrade their module to
        //get the menu fixed.
        if (newSystem) {
            logger.info("Adding Admin Tools to new System Menu...");
            newSystem.children.push(adminTools34)
        }
    }
    //find and replace the System menu in the archive with the new one
    //this does mean if the archive modified the System Menu it would be lost
    obj.objects = obj.objects.map(function (item) {
        if (item.name === "System Menu") {
            item = systemMenu34;
        } else if (item.name === "Admin Menu") {
            item = null;
        }
        return item;
    });

    upgradeUtil.writeFile(menuBundle.path, JSON.stringify(obj));

} else {
    logger.info("Cannot find restore bundle for menu content");
}

//**********************************************************************************************************************
//* Upgrade the Provisioning
//*
//* It's possible that someone provisioned a System Menu item to a specific user or role.   So we're going to have
//* to check each and every one looking for any that need to be updated to the new structure.
//**********************************************************************************************************************

var accountProvisioningFiles = [
    "entities/AccountProvisioningService-AccountProvisionDO.json",
    "AccountProvisioningService/AccountProvisionDO.json"
];

// Lookup table for all path changes that need to be fixed.  The key is the old path, the value is the new path.
var pathChanges = {
    '/System Menu/Manage/Connections'       : '/System Menu/Content/Connections',
    '/System Menu/Manage/License'           : '/System Menu/System/License',
    '/System Menu/Manage/Pages'             : '/System Menu/Content/Pages',
    '/System Menu/Manage/Pipeline'          : '/System Menu/Content/Pipeline',
    '/System Menu/Manage/Sessions'          : '/System Menu/System/Sessions',
    '/System Menu/Manage/Server Cluster'    : '/System Menu/System/Server Cluster',
    	'/System Menu/System/Backup & Restore'  : '/System Menu/Content/Backup & Restore',
    	'/System Menu/Manage/Provision/Users'   : '/System Menu/Content/Provisioning',
    	'/System Menu/Manage/Provision/Domains' : '/System Menu/Content/Provisioning',
    	'/System Menu/Manage/Provision/Defaults': '/System Menu/Content/Provisioning',
    	'/System Menu/Manage/Provision/Roles'   : '/System Menu/Content/Provisioning'
};

var provisioningBundle = upgradeUtil.findUpgradeBundleInFiles(
	function(backupClass) { return backupClass.endsWith(".AccountProvisionDO") }, accountProvisioningFiles
);

if (provisioningBundle) {

	obj = JSON.parse(provisioningBundle.json);
	obj.objects = obj.objects.map(
		function (item) {
			if (pathChanges[item.contentPath] != undefined) {
				logger.info('Found an AccountProvisionDO that needs to be changed: ' + item.contentPath + ' --> ' + pathChanges[item.contentPath]);
				item.contentPath = pathChanges[item.contentPath];
			} else if (item.contentPath === "/Admin Menu") {
				item = null;
			}
			return item;
		});

	upgradeUtil.writeFile(provisioningBundle.path, JSON.stringify(obj));

} else {
    logger.info("Cannot find restore bundle for account provisioning");
}
