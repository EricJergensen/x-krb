if (!fullBackup) {
	logger.info("*************************************");
	logger.info("* Updating Pages missing parentPath *");
	logger.info("*************************************");
	var parentPathReplacement = "/Content Menu";
	var counter = 0;
	var existingContentMenuItems = {};
	var recoveredItems = {};
	upgradeUtil.updateAllObjects("PageDO", function (pageDO) {
		if ( !pageDO.parentPath === "/Content Menu" ) {
			existingContentMenuItems[pageDO.name] = pageDO;
		} else if ( (!pageDO.parentPath || ( pageDO.parentPath === "/") ) && !pageDO.parentId) {
			if ( existingContentMenuItems[pageDO.name] ) {
	        	 	logger.warn("Existing page '/Content Menu/{}' found; ignoring duplicate page missing parentPath configuration.", pageDO.name);
	        	    return null;
	         } else if ( recoveredItems[pageDO.name] ) {
            	 	logger.warn("Dropping page named: '{}' that is missing a parentPath; another page in a similar state already moved to this location.", pageDO.name);
            	    return null;
             } else {
            	    pageDO.parentPath = parentPathReplacement;
            	    recoveredItems[pageDO.name] = pageDO;
            	    logger.warn("Processing page: '{}' that is missing a parentPath; moving it into: {}", pageDO.name, parentPathReplacement);
             }
	    }
	    return pageDO;
	}, false);
}
