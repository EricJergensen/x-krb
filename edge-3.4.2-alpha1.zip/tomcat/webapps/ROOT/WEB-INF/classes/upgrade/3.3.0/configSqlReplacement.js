logger.info("***********************************************");
logger.info("* replacing config.sql                        *");
logger.info("***********************************************");

var configSqlPath = "config.sql";
var configEntitiesPath = "entities";
var configEntitiesFileName = "ConfigService-ConfigItem.json";

if (upgradeUtil.fileExists(configSqlPath)) {

    var configSql = upgradeUtil.readFileByPath(configSqlPath);

    // remember to allow for (/g) modifications to config.sql by other upgrade scripts (ie. 3.2.2/sqlString.js)
    var sqlRegex = /^INSERT INTO PUBLIC[.]CONFIG[\s\S]*?[)];\s*$/mg;
    var configSqlDdl = configSql.match(sqlRegex);

    if (configSqlDdl) {

        var configEntities = [];
        var numMatches = configSqlDdl.length;
        for (var i = 0; i < numMatches; i++) {

            var ddl = configSqlDdl[i];

            // note the ID column is optional - it isn't specified in the 3.2.4/sqlString upgrade script
            var insertRegex = /[(]((\d+), )?'((?:.*?[^'])?(?:'')*)', '((?:.*?[^'])?(?:'')*)', '((?:.*?[^'])?(?:'')*)'[)][,;]/g;

            var insertMatches;
            while ((insertMatches = insertRegex.exec(ddl)) !== null) {
                var entity = {// "id": '' + insertMatches[2],
                    "bundle": insertMatches[3],
                    "key": insertMatches[4],
                    "value": insertMatches[5]
                };
                if (insertMatches[2] && insertMatches[2] !== "undefined") {
                    entity["id"] = '' + insertMatches[2];
                }
                configEntities.push(entity);
                logger.debug('config entity = ' + JSON.stringify(entity));
            }
        }

        if (configEntities.length > 0) {
            var restoreBundle = {"doClass" : "RestoreBundleDO",
                "backupClass" : "edge.server.config.ConfigItem",
                "objects" : configEntities
            };

            upgradeUtil.writeNewFile(configEntitiesPath, configEntitiesFileName, JSON.stringify(restoreBundle));

            logger.info("  Converted " + configEntities.length + " config objects");
        }

    } else {
        logger.warn("config.sql not parsed correctly");
    }

}
