logger.info("**************************************************");
logger.info("* upgrade Producer Instance config               *");
logger.info("**************************************************");

// only upgrade 3.3.x -> everything else will have been upgraded by 3.2.7
var archiveVersion = upgradeUtil.getArchiveProductVersion();
if (archiveVersion.getMajor() >= 3 && archiveVersion.getMinor() >= 3) {
    upgradeUtil.loadUpgradeScript('3.2.7/producerInstance.js');
}
