logger.info("***********************************************");
logger.info("*       updating remove TEMP: from ids        *");
logger.info("***********************************************");

var pattern = /^TEMP\: /;

function getCellData(cell) {
    if (cell.contentType === "content") {
        if (cell.stack && cell.stack.length > 0) {
            for (var i = 0; i < cell.stack.length; i++) {
                cell.stack[i] = cell.stack[i].replace(pattern, "");
            }
        }
    } else if (cell.contentType === "rowContainer") {
        for (var i = 0; i < cell.cellData.length; i++) {
            this.getCellData(cell.cellData[i]);
        }
    } else {//columnContainer
        for (var i = 0; i < cell.cellData.length; i++) {
            this.getCellData(cell.cellData[i]);
        }
    }
}

upgradeUtil.updateAllObjects("TabularTransformDO", function (obj) {
    for (var i=0; i < obj.upstreamConstructIds.length; i++) {
        obj.upstreamConstructIds[i] = obj.upstreamConstructIds[i].replace(pattern, "");
    }

    return obj;
}, false);

upgradeUtil.updateAllObjects("DataFeedDO", function (obj) {
    obj.id = obj.id.replace(pattern, "");

    return obj;
}, false);

upgradeUtil.updateAllObjects("DataVisualizationDO", function (obj) {
    for (var i=0; i < obj.upstreamConstructIds.length; i++) {
        obj.upstreamConstructIds[i] = obj.upstreamConstructIds[i].replace(pattern, "");
    }

    return obj;
}, false);

upgradeUtil.updateAllObjects("ProducerInstanceDO", function (obj) {
    obj.id = obj.id.replace(pattern, "");
    if (obj.producerId) {//make sure it is not null, not sure how it become null, but it can
        obj.producerId = obj.producerId.replace(pattern, "");
    }
    obj.selectedVisualizationInstance = obj.selectedVisualizationInstance.replace(pattern, "");
    for (var i=0; i < obj.visualizationInstances.length; i++) {
        obj.visualizationInstances[i].id = obj.visualizationInstances[i].id.replace(pattern, "");
    }

    return obj;
}, false);

upgradeUtil.updateAllObjects("PageDO", function (obj) {
    for (var i=0; i < obj.producerInstanceIds.length; i++) {
        obj.producerInstanceIds[i] = obj.producerInstanceIds[i].replace(pattern, "");
    }

    if (obj.hasOwnProperty("layout") && obj.layout) {
        var layout = JSON.parse(obj.layout);
        if (obj.layoutType === "dashboard") {//only have 1 row of 100% height
            for (var i = 0; i < layout.rows[0].cellData.length; i++) {
                cellData = layout.rows[0].cellData[i];
                this.getCellData(cellData);
            }
        } else {
            for (var i = 0; i < layout.rows.length; i++) {
                cellData = layout.rows[i].cellData;
                for (var j = 0; j < cellData.length; j++) {
                    this.getCellData(cellData[j]);
                }
            }
        }

        obj.layout = JSON.stringify(layout);
    }

    return obj;
}, false);

