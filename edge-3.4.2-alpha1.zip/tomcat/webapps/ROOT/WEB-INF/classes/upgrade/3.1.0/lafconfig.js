logger.info("***********************************************");
logger.info("*       updating system themes to laf         *");
logger.info("***********************************************");

var configSqlPath = "config.sql";
if (upgradeUtil.fileExists(configSqlPath)) {
    //remove user's theme first - first replace is for any line except the last one, the 2nd replace is for
    //if it is the last line
    var modifiedSql = upgradeUtil.readFileByPath(configSqlPath).replace(/\(\d+, 'user\.\w+', 'client.theme', .*(?!\)),/g, "").replace(/,\s+\(\d+, 'user\.\w+', 'client.theme', .*(?!\));/g, ";");
    //now remove old custom themes setting
    modifiedSql = modifiedSql.replace(/\(\d+, 'GLOBAL', 'client.themes.\w+.\w+', .*(?!\)),/g, "").replace(/,\s+\(\d+, 'GLOBAL', 'client.themes.\w+.\w+', .*(?!\));/g, ";");
    //now remove home page setting
    modifiedSql = modifiedSql.replace(/\(\d+, '\w+(\.\w+)?', 'client.homepage', .*(?!\)),/g, "").replace(/,\s+\(\d+, '\w+(\.\w+)?', 'client.homepage', .*(?!\));/g, ";");
    //now remove pagelogo setting
    modifiedSql = modifiedSql.replace(/\(\d+, '\w+(\.\w+)?', 'client.pagelogo', .*(?!\)),/g, "").replace(/,\s+\(\d+, '\w+(\.\w+)?', 'client.pagelogo', .*(?!\));/g, ";");
    //now replace old config client.theme with client.laf
    modifiedSql = modifiedSql.replace(/'client.theme', 'css\/LightTheme'/g, "'client.laf', 'Light'").replace(/'client.theme', 'css\/DarkTheme'/g, "'client.laf', 'Dark'");
    //now remove old config client.theme
    modifiedSql = modifiedSql.replace(/\(\d+, 'GLOBAL', 'client.theme', 'custom\/themes\/.*(?!\)),/g, "").replace(/,\s+\(\d+, 'GLOBAL', 'client.theme', 'custom\/themes\/.*(?!\));/g, ";");

    logger.info("File changed: " + configSqlPath);
    //logger.info("File changed: " + modifiedSql);
    upgradeUtil.writeFile(configSqlPath, modifiedSql);
}
