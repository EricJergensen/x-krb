logger.info("***********************************************");
logger.info("* updating Account objects for failover       *");
logger.info("***********************************************");

upgradeUtil.updateAllObjects("RestoreBundleDO", function(bundle) {

    if (bundle.backupClass == "edge.server.account.adapter.AccountAdapterConfigDO") {
        bundle.backupClass = "edge.server.account.config.adapter.AccountAdapterConfigDO"; 
    }
	
    if (bundle.backupClass == "edge.server.account.adapter.AccountAdapterRestoreBundleDO") {
        bundle.backupClass = "edge.server.account.config.adapter.AccountAdapterRestoreBundleDO"; 
    }
	
    if (bundle.backupClass == "edge.server.account.AccountProvisionDO") {
        bundle.backupClass = "edge.server.account.principal.AccountProvisionDO"; 
    }

    if (bundle.backupClass == "edge.server.account.PasswordPolicyDO") {
        bundle.backupClass = "edge.server.account.principal.PasswordPolicyDO"; 
    }

    if (bundle.backupClass == "edge.server.account.config.adapter.AccountAdapterDO") {
        bundle.backupClass = "edge.server.account.config.adapter.AccountAdapterConfigDO"; 
    }
    
    if (bundle.backupClass == "edge.server.account.adapter.embedded.AccountGroup") {
        bundle.backupClass = "edge.server.account.principal.embedded.AccountGroup"; 
    }
    
    if (bundle.backupClass == "edge.server.account.adapter.embedded.AccountUser") {
        bundle.backupClass = "edge.server.account.principal.embedded.AccountUser"; 
    }
    
    return bundle;

}, false);

