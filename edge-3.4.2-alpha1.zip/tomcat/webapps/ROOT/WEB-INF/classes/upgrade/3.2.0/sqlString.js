logger.info("***********************************************");
logger.info("* scanning for SQLStrings                     *");
logger.info("***********************************************");

var sqlNodeVarCount = 0;

upgradeUtil.updateAllObjects("PropertyValueDO", function(propertyValue) {

    if (propertyValue.propertyTypeName !== "SQLString") {
        return propertyValue;
    }

    var sqlString = propertyValue.value;

    if (sqlString) {

        if (sqlString.match(/{nodeVar.(\w+)}/)) {
            logger.debug("Found SQLString property: {}", sqlString);
            sqlNodeVarCount++;
        }
    }
    return propertyValue;

}, true);

var configSqlPath = "config.sql";
if (upgradeUtil.fileExists(configSqlPath)) {

    var modifiedSql = upgradeUtil.readFileByPath(configSqlPath);

    // only enable safe substitution mode if no relevant config has been imported that might potentially be broken
    var safeSubstitution = sqlNodeVarCount === 0;

    modifiedSql += "INSERT INTO PUBLIC.CONFIG(CONFIG_BUNDLE, KEY, VALUE) VALUES"
        + "('GLOBAL', 'pipeline.safeSubstitution', '" + safeSubstitution + "');";

    upgradeUtil.writeFile(configSqlPath, modifiedSql);
}

