logger.info("***********************************************");
logger.info("*       updating AbstractTabularProducer      *");
logger.info("***********************************************");

var path = "DataProducerService/AbstractTabularProducerDO.json";
if (upgradeUtil.fileExists(path)) {

	upgradeUtil.updateAllObjectsInFile(path, "PropertyValueDO", function(propertyValue) {

        var DataAttributeTypeDO = Java.type("edge.server.pipeline.data.document.DataAttributeTypeDO");

        if (propertyValue.propertyTypeName !== "SelectedAttributes") {
            return propertyValue;
        }

        var selectedAttributes = JSON.parse(propertyValue.value);

        if (selectedAttributes && selectedAttributes.hasOwnProperty("selectedAttributeList")) {
            var attributeList = selectedAttributes.selectedAttributeList;
            for (var k = 0; k < attributeList.length; k++) {
                var attribute = attributeList[k];
                if ( logger.isTraceEnabled() ) {
             	   logger.trace("converting DataAttributeTypeDO value: {} => {}", attribute.attributeType, DataAttributeTypeDO.byTypeName(attribute.attributeType).getOrdinal());
                }
                attribute.attributeType = DataAttributeTypeDO.byTypeName(attribute.attributeType).getOrdinal();
            }
            propertyValue.value = JSON.stringify(selectedAttributes);
            if ( logger.isDebugEnabled() ) {
                logger.debug("updated SelectedAttributes property: {}", propertyValue.value);
            }

        }
        return propertyValue;

    }, true);
}
