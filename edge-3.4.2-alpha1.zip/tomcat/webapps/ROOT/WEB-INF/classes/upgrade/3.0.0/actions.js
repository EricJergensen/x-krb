logger.info("***********************************************");
logger.info("* Updating Actions                            *");
logger.info("***********************************************");

var path = "VisualizationService/ProducerInstanceDO.json";
var DataAttributeTypeDO = Java.type("edge.server.pipeline.data.document.DataAttributeTypeDO");
if (upgradeUtil.fileExists(path)) {
    var json = upgradeUtil.readFileByPath(path);
    var obj = JSON.parse(json);
    for (var i = 0; i < obj.objects.length; i++) {
        var currentConfig = obj.objects[i];
    	for (var j = 0; j < currentConfig.visualizationInstances.length; j++) {
    		var visInstance = currentConfig.visualizationInstances[j];
		    if (visInstance.actionsConfig) {
		    	var actionConfig = JSON.parse(visInstance.actionsConfig);
		    	var actions = actionConfig.actions;
		    	if (actions) {
		        	for (var k = 0; k < actions.length; k ++) {
		        		if (actions[k].pageVars) {
		        			upgradePageVarMappings(actions[k]);
		        		}
		        		var conditions = actions[k].conditions;
		        		if (conditions) {
		        			updateExpressionJSON(conditions);
		        		}
		        	}
		        	visInstance.actionsConfig = JSON.stringify(actionConfig);
		    	}
		    }
    	}
    }
    upgradeUtil.writeFile(path, JSON.stringify(obj));
}

function updateExpressionJSON(expressionTokenDO) {
	if (expressionTokenDO.doClass == "ExpressionDO") {
		if (expressionTokenDO.tokens != null) {
			for (var t = 0; t < expressionTokenDO.tokens.length; t++) {
				var token = expressionTokenDO.tokens[t];
				token = updateExpressionJSON(token);
			}
		}
	} else if (expressionTokenDO.doClass == "ExpressionRuleDO") {
		if (logger.isTraceEnabled() ) {
	        logger.trace("converting DataAttributeTypeDO value: {} => {}", expressionTokenDO.type, DataAttributeTypeDO.byTypeName(expressionTokenDO.type).getOrdinal());
		}
        expressionTokenDO.type = DataAttributeTypeDO.byTypeName(expressionTokenDO.type).getOrdinal();
	}
	
	return expressionTokenDO;
	
};

function upgradePageVarMappings(action) {
	var pageVarMappings = {};
	for (var pageVarName in action.pageVars) {
	    if (action.pageVars.hasOwnProperty(pageVarName)) {
	        var mapping = {className:"edge.core.widget.actions.switchpage.ActionPageVarMapping"};
	        switch(action.pageVars[pageVarName].mapperType) {
		        case "attribute":
		        	mapping.type = 0;
		        	break;
		        case "pageVar":
		        	mapping.type = 1;
		        	break;
	        }
	        mapping.value = action.pageVars[pageVarName].value;
	        pageVarMappings[pageVarName] = mapping;
	    }
	}
	delete action.pageVars;
	action.pageVarMappings = pageVarMappings;
};