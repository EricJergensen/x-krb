logger.info("***********************************************");
logger.info("*       updating ColorPalette                 *");
logger.info("***********************************************");

var path = "VisualizationService/ColorPaletteDO.json";
if (upgradeUtil.fileExists(path)) {

	upgradeUtil.updateAllObjectsInFile(path, "ColorPaletteDO", function(propertyValue) {
            
       if (propertyValue.name === 'Default') 
           propertyValue.name = 'Chart'; 

       return propertyValue; 
    }, true);    
}




