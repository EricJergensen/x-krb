logger.info("***************************************************");
logger.info("* converting XmlAttributes to SelectedAttributes *");
logger.info("***************************************************");

function fillMissingAttributes(cachedAttrs, selectedAttrsList, hiddenList) {
	var lookup = {};
	for ( var i=0; i<selectedAttrsList.length; i++) {
		lookup[selectedAttrsList[i].attributeName] = selectedAttrsList[i];
	}
	for ( var k=0; k<cachedAttrs.length; k++ ) {
		var dataAttr = cachedAttrs[k];
		var sourceName = dataAttr.sourceName;
		if ( !sourceName ) {
			sourceName = dataAttr.name;
		}
		if ( !lookup[sourceName] && !hiddenList[sourceName]) {
			logger.info("* Generating SelectedAttribute: ");
			var selectedAttr = {
					"doClass":"SelectedAttributeDO",
					"attributeName":sourceName,
					"newAttributeName":dataAttr.name,
					"attributeType":0,
					"primaryKey":dataAttr.isId,
					"indexingOn":false,
					"elucidators":[],
					"optionalModifier":null
			};
			if ( selectedAttr.attributeName == selectedAttr.newAttributeName ) {
				selectedAttr.newAttributeName = undefined;
			}
			if ( dataAttr.type == "STRING" ) {
				selectedAttr.attributeType = 0;
			} else if ( dataAttr.type == "INT" ) {
				selectedAttr.attributeType = 1;
			} else if ( dataAttr.type == "LONG" ) {
				selectedAttr.attributeType = 2;
			} else if ( dataAttr.type == "NUMBER" ) {
				selectedAttr.attributeType = 3;
			} else if ( dataAttr.type == "BOOLEAN" ) {
				selectedAttr.attributeType = 4;
			} else if ( dataAttr.type == "DATE" ) {
				selectedAttr.attributeType = 5;
			} 

			logger.info("* Pushing SelectedAttribute: " + JSON.stringify(selectedAttr));
			selectedAttrsList.push( selectedAttr );
		}
	}
	
}

upgradeUtil.updateAllObjects("DataFeedDO", function (obj) {
    if (obj.typeName.search(/XML/) > -1) {
        var propertyValues = obj.properties.propertyValues;
        var hiddenList = {};
        for (var i=0; i < propertyValues.length; i++) {
            if (propertyValues[i].propertyTypeName === "XmlAttributes") {
                propertyValues[i].propertyTypeName = "SelectedAttributes";
                var xmlAttributes = JSON.parse(propertyValues[i].value);
                xmlAttributes.doClass = "SelectedAttributesDO";
                var shownList = [];
                var allList = xmlAttributes.xmlAttributeList;
                for (var j=0; j < allList.length; j++) {
                    if (! allList[j].hidden) {
                        delete allList[j].hidden;
                        delete allList[j].preview;
                        allList[j].doClass = "SelectedAttributeDO";
                        if (allList[j].attributeName === allList[j].newAttributeName) {
                            allList[j].newAttributeName = undefined;
                        }
                        shownList.push(allList[j]);
                    } else {
                			hiddenList[allList[j].attributeName] = allList[j];
                    }
                }

                fillMissingAttributes(obj.cachedAttributeDefs, shownList, hiddenList);
                
                xmlAttributes.selectedAttributeList = shownList;
                delete xmlAttributes.xmlAttributeList;
                propertyValues[i].value = JSON.stringify(xmlAttributes);
                break;
            }
        }
    }

    return obj;
}, false);

