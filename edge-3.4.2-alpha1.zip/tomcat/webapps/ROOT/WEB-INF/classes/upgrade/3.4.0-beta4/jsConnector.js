logger.info("***********************************************");
logger.info("* Removing JS Connector module reference      *");
logger.info("***********************************************");

/*************************************************************/
/*				Remove module reference						*/
/*************************************************************/
var moduleDefFile = [
    "entities/ModuleService-ModuleDefDO.json"
];

var moduleDefBundle = upgradeUtil.findUpgradeBundleInFiles(
		function (backupClass) { return backupClass.endsWith(".ModuleDefDO") }, moduleDefFile
	);

if (moduleDefBundle) {

    var obj = JSON.parse(moduleDefBundle.json);

    obj.objects = obj.objects.filter(function (def) {
    		return def.name !== "javascriptConnector" && def.fileName.indexOf("edge.javascriptConnector") == -1;
    });    

    upgradeUtil.writeFile(moduleDefBundle.path, JSON.stringify(obj));

} else {
    logger.info("Cannot find restore bundle for module defs");
}


/*************************************************************/
/*				Update Connection Type						*/
/*************************************************************/
var connFile = [
	"entities/ConnectionService-ConnectionDO.json"
];

var connBundle = upgradeUtil.findUpgradeBundleInFiles(
		function (backupClass) { return backupClass.endsWith(".ConnectionDO") }, connFile
);

if (connBundle) {

    var obj = JSON.parse(connBundle.json);

    obj.objects = obj.objects.map(function (item) {
    		if (item.doClass === "ConnectionDO" && item.typeName === "Javascript") {
    			item.typeName = "Javascript Connection";
    			item.nodeType = "CONNECTION";
    		}
    		return item;
    });

    upgradeUtil.writeFile(connBundle.path, JSON.stringify(obj));

} else {
    logger.info("Cannot find restore bundle for connections");
}