logger.info("***********************************************");
logger.info("*       updating Parameter Constraints        *");
logger.info("***********************************************");


var strId = null;
var numId = null;
var realtimeId = null;

var constraintsPath = "ParameterService/ParameterConstraintDO.json";
if (upgradeUtil.fileExists(constraintsPath)) {
    var json = upgradeUtil.readFileByPath(constraintsPath);
    var constraints = JSON.parse(json);

    for (i = 0; i < constraints.objects.length; i++) {
        var constraint = constraints.objects[i];
	if( constraint.name == "Unbounded String" ) {

	    strId = constraint.id;
	    constraint.id = "DEFAULT_STRING_CONSTRAINT";
	} else if( constraint.name == "Unbounded Number" ) {

	    numId = constraint.id;
	    constraint.id = "DEFAULT_NUMBER_CONSTRAINT";
	} else if( constraint.name == "Realtime" ) {

	    realtimeId = constraint.id;
	    constraint.id = "DEFAULT_REALTIME_CONSTRAINT";
	}
    }

    upgradeUtil.writeFile(constraintsPath, JSON.stringify(constraints));
}

replaceIds( "ConnectionService/ConnectionDO.json", strId, numId, realtimeId);
replaceIds( "DataProducerService/AbstractRelationalProducerDO.json", strId, numId, realtimeId);
replaceIds( "DataProducerService/AbstractTabularProducerDO.json", strId, numId, realtimeId);
replaceIds( "DataVisualizationService/DataVisualizationDO.json", strId, numId, realtimeId);
replaceIds( "ProxyFeedService/ProxyFeedDO.json", strId, numId, realtimeId);
replaceIds( "ProxyVisualizationService/ProxyVisualizationDO.json", strId, numId, realtimeId);
replaceIds( "VisualizationService/ProducerInstanceDO.json", strId, numId, realtimeId);
replaceIds( "MenuContentManager/AContentNodeDO.json", strId, numId, realtimeId);


function replaceIds( path, strId, numId, realtimeId ) {

    if (upgradeUtil.fileExists(path)) {
	    var json = upgradeUtil.readFileByPath(path);

	    if ( strId ) {
	        json = json.replace(new RegExp(strId, 'g'), "DEFAULT_STRING_CONSTRAINT");
	    } 

        if ( numId ) {
    	    json = json.replace(new RegExp(numId, 'g'), "DEFAULT_NUMBER_CONSTRAINT");
	    } 

        if ( realtimeId ) {
	        json = json.replace(new RegExp(realtimeId, 'g'), "DEFAULT_REALTIME_CONSTRAINT");
	    }

	    upgradeUtil.writeFile(path, json);
    }
}

function logObject(object) {
	logger.info(JSON.stringify(object, true));
}

function logObjectWithLabel(label, object) {
	logger.info(label + ":" + JSON.stringify(object, true));
}
