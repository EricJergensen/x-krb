logger.info("***********************************************");
logger.info("* Updating Actions                            *");
logger.info("***********************************************");

upgradeUtil.loadUpgradeScript('2.0.0/lib/MegaFormatterUtil.js');

function logObject(object) {
	logger.info(JSON.stringify(object, true));
}

var path = "VisualizationService/ProducerInstanceDO.json";
if (upgradeUtil.fileExists(path)) {
    var json = upgradeUtil.readFileByPath(path);
    var obj = JSON.parse(json);
    for (var i = 0; i < obj.objects.length; i++) {
        var currentConfig = obj.objects[i];
    	for (var j = 0; j < currentConfig.visualizationInstances.length; j++) {
    		var visInstance = currentConfig.visualizationInstances[j];
		    if (visInstance.actionsConfig) {
		    	var actionConfig = JSON.parse(visInstance.actionsConfig);
		    	var actions = actionConfig.actions;
		    	if (actions) {
		        	for (var k = 0; k < actions.length; k ++) {
		        		if (actions[k].className = "edge.core.widget.actions.tooltip.ActionTooltipConfig") {
		        			upgradeTooltipAction(actions[k]);
		        		}
		        	}
		        	visInstance.actionsConfig = JSON.stringify(actionConfig);
		    	}
		    }
    	}
    }
    upgradeUtil.writeFile(path, JSON.stringify(obj));
}

function upgradeTooltipAction(tooltipAction) {
	var attributeRendererDefs10 = tooltipAction.attributeRendererDefs;
	if (attributeRendererDefs10 != undefined) {

		var attributeRendererDefs20 = getAttributeRenderDefs20From10(attributeRendererDefs10);
	    
	    tooltipAction.attributeRendererDefs = attributeRendererDefs20;
	
	
		// Handle Label format from 1.0 version to 2.0
		var label10 = null;
		attributeRendererDefs10.forEach(function(entry){
			if (entry.labelOn) {
				if (label10 == null) {
					label10 = getNewFormatterFromOldMegaFormatter(entry.label); 
				}
			}
		});
		var labelPropertyValue = new edge.ui.complex.megaformatters.types.Text();
		if (label10 != null) {
			labelPropertyValue.color = label10.color
			labelPropertyValue.style = label10.style
			labelPropertyValue.size = label10.size
		}
	
		tooltipAction["labelFormatter"]=labelPropertyValue;
	}
};
