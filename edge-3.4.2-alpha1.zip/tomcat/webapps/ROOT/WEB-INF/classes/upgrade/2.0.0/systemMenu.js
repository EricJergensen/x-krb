logger.info("***********************************************");
logger.info("* Updating System Menu                        *");
logger.info("***********************************************");
//**********************************************************************************************************************
//* Load New System Menu Data
//**********************************************************************************************************************
upgradeUtil.loadUpgradeScript('2.0.0/lib/NewSystemMenuData.js');
//**********************************************************************************************************************
//* Upgrade the Menu Content
//**********************************************************************************************************************
var menuContentFile = "MenuContentManager/AContentNodeDO.json"
//wrap in TRY/CATCH just in case it's a partial backup without Menu Content
try {
	var json = upgradeUtil.readFileByPath(menuContentFile);
	var obj  = JSON.parse(json);
	if (upgradeUtil.fileExists("lib/devOverlay.jar")) {
	    //the backup had devOverlay
	
	    //while technically you aren't supposed to manage modules in product upgrade it's quicker and easier to make a
	    //special exception for the devOverlay here.  Otherwise we would force all developers to upgrade their module to
	    //get the menu fixed.
	    newMenu.children[2].children.push(adminTools);  //add the Admin Tools menu back into the menu
	}
	//find and replace the System menu in the archive with the new one
	//this does mean if the archive modified the System Menu it would be lost, but we didn't officially support that in
	//version 1.0
	obj.objects = obj.objects.map(function (item) {
	    return item.name === "System Menu" ? newMenu : item;
	});
	upgradeUtil.writeFile(menuContentFile, JSON.stringify(obj));
} catch (e) {
	logger.info("Content Menu data was not found in this archive, nothing to upgrade.");
	logger.info(e);
}
//**********************************************************************************************************************
//* Upgrade the Provisioning
//*
//* It's possible that someone provisioned a System Menu item to a specific user or role.   So we're going to have
//* to check each and every one looking for any that need to be updated to the new structure.
//**********************************************************************************************************************

// Lookup table for all path changes that need to be fixed.  The key is the old path, the value is the new path.
var pathChanges = {
    '/System Menu/Logout'                  : '/System Menu/User/Logout',
    '/System Menu/Preferences'             : '/System Menu/User/Preferences',
    '/System Menu/Change Password'         : '/System Menu/User/Change Password',
    '/System Menu/Toggle Navigation Filter': '/System Menu/User/Toggle Navigation Filter',
    '/System Menu/Backup & Restore'        : '/System Menu/System/Backup & Restore',
    '/System Menu/System Info'             : '/System Menu/System/System Info',
    '/System Menu/About'                   : '/System Menu/System/About'
};
//wrap in TRY/CATCH just in case it's a partial backup without provisioning data
try {
	json = upgradeUtil.readFileByPath("AccountProvisioningService/AccountProvisionDO.json");
	obj = JSON.parse(json);
	//remove all the dividers and Messages that are provisioned
	obj.objects = obj.objects.filter(
	    function (item) {
	        return (item.contentPath.indexOf(' Divider') === -1 && item.contentPath.indexOf('/System Menu/Messages') === -1);
	    });
	obj.objects = obj.objects.map(
	    function (item) {
	        if (pathChanges[item.contentPath] != undefined) {
	            logger.info('Found an AccountProvisionDO that needs to be changed: ' + item.contentPath + ' --> ' + pathChanges[item.contentPath]);
	            item.contentPath = pathChanges[item.contentPath];
	        }
	        return item;
	    });
	upgradeUtil.writeFile("AccountProvisioningService/AccountProvisionDO.json", JSON.stringify(obj));
} catch (e) {
	logger.info("Account Provisioning details not found in this archive, nothing to upgrade.");
}
