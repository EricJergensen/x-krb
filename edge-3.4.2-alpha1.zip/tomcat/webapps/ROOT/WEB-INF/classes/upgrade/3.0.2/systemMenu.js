logger.info("***********************************************");
logger.info("* Updating System Menu                        *");
logger.info("***********************************************");
//**********************************************************************************************************************
//* Load New System Menu Data
//**********************************************************************************************************************
upgradeUtil.loadUpgradeScript('3.0.0/lib/NewSystemMenuData.js');
//**********************************************************************************************************************
//* Upgrade the Menu Content - more of fix of 3.0.1 where message center is changed from route to dialog
//**********************************************************************************************************************
upgradeUtil.updateAllObjects("ContentFolderDO", function(folderItem) {
    if (folderItem.name === "System Menu") {

        if (upgradeUtil.fileExists("lib/devOverlay.jar")) {
            //the backup had devOverlay
        
            //while technically you aren't supposed to manage modules in product upgrade it's quicker and easier to make a
            //special exception for the devOverlay here.  Otherwise we would force all developers to upgrade their module to
            //get the menu fixed.
            newMenu.children[2].children.push(adminTools);  //add the Admin Tools menu back into the menu
        }
        //find and replace the System menu in the archive with the new one
        //this does mean if the archive modified the System Menu it would be lost, but we didn't officially support that in
        //version 1.0
        folderItem = newMenu;
    }

    return folderItem;
}, true);
