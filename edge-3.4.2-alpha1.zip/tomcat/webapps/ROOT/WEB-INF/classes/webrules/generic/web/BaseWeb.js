/*
 * Copyright 2015 Edge Technologies
 */

/**
 * The base proxy rule.  This includes operations that should apply to most proxied applications.
 *
 * Created by erik on 26/08/15.
 */

// for response processing
var HttpServletResponse = Java.type("javax.servlet.http.HttpServletResponse");

// for content or header transformation
var ProxyEvalEnvironment = Java.type("edge.server.proxy.eval.ProxyEvalEnvironment");
var LocationHeaderTransform = Java.type("edge.server.proxy.content.transform.LocationHeaderTransform");
var PlainTextRange = Java.type("edge.server.proxy.content.transform.PlainTextRange");
var BasicRegexTransform = Java.type("edge.server.proxy.content.transform.BasicRegexTransform");
var HtmlRegexPatterns = Java.type("edge.server.proxy.content.util.HtmlRegexPatterns");

loadSystemScript("UrlReplacement");
loadSystemScript("HeaderHandlers");
loadSystemScript("ContentReplacementUtils");

var BaseWeb = function(appContext) {

    this.appContext = appContext;
    this.headerHandlers = new HeaderHandlers(appContext);
    this.urlReplacement = new UrlReplacement(appContext);
    var htmlRegexPatterns = appContext.getBean("htmlRegexPatterns");
    this.locationHeaderReplacement = new LocationHeaderTransform(htmlRegexPatterns);

    this.onRequest = function (ctx) {

        this.headerHandlers.onRequest(ctx);

        //var cookies = clientRequest.getCookies();
        //for each (var cookie in cookies) {
        //    print('cookie: ' + cookie.getName() + ' = ' + cookie.getValue());
        //}
    };

    this.onResponse = function(ctx) {

        this.handleResponseHeaders(ctx);

        // if (appRequestContext.getResponsePipelineType() === AppRequestContext.ResponsePipelineType.TEXT) {
        this.urlReplacement.onResponse(ctx);
        // }
    };

    this.handleResponseHeaders = function(ctx) {

        var statusCode = ctx.appResponse.getStatusCode();
        // var statusCode = ctx.requestContext.getAppRequestContext().getResponse().getStatusCode();
        ctx.clientResponse.setStatusCode(statusCode);

        switch (statusCode) {
            case HttpServletResponse.SC_OK:
                ctx.event.setResult(true, "statusCode == 200");
                break;

            case HttpServletResponse.SC_CREATED:
            case HttpServletResponse.SC_MOVED_PERMANENTLY:
            case HttpServletResponse.SC_MOVED_TEMPORARILY:
            case HttpServletResponse.SC_SEE_OTHER:
            case HttpServletResponse.SC_TEMPORARY_REDIRECT:

                var location = ctx.appResponse.getHeader("Location");

                if (location) {

                    var outLocation;

                    if (EdgeWebUrl.isMappedUrl(location)) {
                        // for whatever reason, location is already via proxy
                        // the case we know about is when URLs in POST forms have not been unmapped
                        // the replace() call is to remove any host name from the front which may be incorrect
                        outLocation = EdgeWebUrl.makeMappedUrlRelative(location);
                    } else {
                        // rewrite the URL so that it is via the proxy
                        outLocation = transformString(this.locationHeaderReplacement, ctx, location);

                        // resolve any variables referenced by the transformed string
                        outLocation = ctx.evalEnvironment.evaluate(ctx.requestContext, outLocation);
                    }
                    ctx.clientResponse.setHeader("Location", outLocation);
                    ctx.event.setResult(true, "statusCode == " + statusCode);
                }
                else {
                    // NB setting even result to false doesn't cause rule to fail - response will still
                    // be forwarded to client, without a Location header
                    ctx.event.setResult(false, "statusCode == " + statusCode + ", but no Location header");
                }
                break;

            default:
                // no specific handling for other status code values for now.
                ctx.event.setResult(true, "statusCode == " + statusCode);
                break;
        }

        this.headerHandlers.onResponse(ctx);
    };
};
