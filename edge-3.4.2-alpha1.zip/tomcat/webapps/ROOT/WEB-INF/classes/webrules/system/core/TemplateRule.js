/*
 * Copyright 2015 Edge Technologies
 */

/**
 * A template ProxyRule implementation for YS.
 *
 * Created by erik on 25/09/15.
 */

var TemplateRule = function(appContext) {

    this.baseRule = new BaseWeb(appContext);

    this.onRequest = function(ctx) {

        this.baseRule.onRequest(ctx);

        // TODO implement application-specific request handling
    };

    this.onResponse = function(ctx) {

        this.baseRule.onResponse(ctx);

        // TODO implement application-specific response handling

        // TODO add application-specific transforms
        addTransformsToPipeline(ctx, [
            {
                name: "a useful name for this transform",
                find: "findtext",
                replace: "replacetext"
            }
        ]);

    };

};
