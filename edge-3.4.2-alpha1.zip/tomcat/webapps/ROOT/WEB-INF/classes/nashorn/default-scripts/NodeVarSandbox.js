//
// additional sandboxing for nodeVar js evaluation
//

function blockedFunction(functionName) {
    throw new Error("Not allowed to call " + functionName);
}

load = function() { blockedFunction("load"); };
loadWithNewGlobal = function() { blockedFunction("loadWithNewGlobal"); };
readLine = function() { blockedFunction("readLine"); };
readFully = function() { blockedFunction("readFully"); };
print = function() { blockedFunction("print"); };
echo = function() { blockedFunction("echo"); };

