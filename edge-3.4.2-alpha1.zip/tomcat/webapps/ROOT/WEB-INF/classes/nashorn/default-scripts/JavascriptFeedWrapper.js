function feedGetAttributesWrapper(feed, nodeVars, secVars) {
	// getAttributes should return either jsAttributesSuccess() or jsAttributesFailure()
	// getAttributes(nodeVars, secVars) => { return { success : true|false, attributes : [{}], message : string }; }
	var result = getAttributes(convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars));
	if (result.success) {
		return JavascriptAttributeResponseDO.makeSuccessResult(
				createAttributeList(result.attributes, feed),
				result.message);
	} else {
		return JavascriptAttributeResponseDO.makeErrorResult(result.message);
	}
}

function feedGetRecordsWrapper(feed, attributes, nodeVars, secVars) {
	// getRecords should return either jsRecordsSuccess() or jsRecordsFailure()
	// getRecords(nodeVars, secVars) => { return { success : true|false, records : [{}], message : string }; }
	var result = getRecords(convertNodeVarsForJs(nodeVars), convertSecVarsForJs(secVars));
	if (result.success) {
		return JavascriptRecordsResponseDO.makeSuccessResult(
				createResultBundle(feed, result.records, attributes),
				result.message);
	} else {
		return JavascriptRecordsResponseDO.makeErrorResult(result.message);
	}
}