# Custom overrides for edgeSuite
#
# * refer to the Runtime Options documentation for detailed information 
# * commented values are system DEFAULTS


# -- listening address and ports
#HTTP_ADDRESS=0.0.0.0
#HTTP_PORT=8080
#SHUTDOWN_PORT=8005


# -- HTTPS options
#HTTP_SSL=false
#KEYSTORE_FILE=../conf/ssl/tomcat.crt
#KEYSTORE_PASS=edgeti
#KEYSTORE_TYPE=JKS
#CLIENTAUTH=false
#TRUSTSTORE_FILE=
#TRUSTSTORE_PASS=
#TRUSTSTORE_TYPE=$KEYSTORE_TYPE

#CIPHERS="TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_DSS_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_128_SHA256,TLS_ECDHE_ECDSA_WITH_AES_128_SHA256,TLS_ECDHE_RSA_WITH_AES_128_SHA,TLS_ECDHE_ECDSA_WITH_AES_128_SHA,TLS_ECDHE_RSA_WITH_AES_256_SHA384,TLS_ECDHE_ECDSA_WITH_AES_256_SHA384,TLS_ECDHE_RSA_WITH_AES_256_SHA,TLS_ECDHE_ECDSA_WITH_AES_256_SHA,TLS_DHE_RSA_WITH_AES_128_SHA256,TLS_DHE_RSA_WITH_AES_128_SHA,TLS_DHE_DSS_WITH_AES_128_SHA256,TLS_DHE_RSA_WITH_AES_256_SHA256,TLS_DHE_DSS_WITH_AES_256_SHA,TLS_DHE_RSA_WITH_AES_256_SHA"
#HONOR_CIPHER_ORDER=false


# -- Other Tomcat options
#JAVA_MEMORY_MAX=2662
#JAVA_MEMORY_INIT=2662
#JAVA_GC_LOGGING=false

# Following if uncommented will apply default Tomcat v8.5.0
# file permissions on Unix (default umask of 0027), for files
# created while Tomcat is running (e.g. log files, expanded WARs, etc.).
# UMASK=027 -> rw-r-----
# UMASK=022 -> rw-r--r--
#UMASK=027

# -- Other runtime preferences
#TOMCAT_SERVICE=edge
#TOMCAT_USER=edge
#TOMCAT_GROUP=edge
#USE_JSVC=false
#CUSTOM_JAVA_OPTS=
#MAC_JAVA_OPTS="-Xdock:icon=\"$CATALINA_HOME/bin/EdgeTrayIcon_250x.png\" -Xdock:name=\"edge\""
#PIDFILE=/var/run/<service>/<service>.pid

# -- Default Cookie Processor: "org.apache.tomcat.util.http.Rfc6265CookieProcessor"; excludes the "; Created: Date.now().toString().
#COOKIE_PROCESSOR="org.apache.tomcat.util.http.Rfc6265CookieProcessor"

# -- Extended Cookie Processor adding the 'Created: Date.toString()' with the date formatted ( Similar to Expires Netscape format )
# -- Created=Mon, 31-Jul-2017 19:28:37 GMT2017-07-31T19:28:37.010Z
#COOKIE_PROCESSOR="edge.server.util.http.EdgeRfc6265CookieProcessor"

# -- Extended Cookie Processor adding the 'Created: Date.toString()' with the date formatted as
# -- Created=2017-07-31T19:26:48.325Z
#COOKIE_PROCESSOR="edge.server.util.http.EdgeIsoInstantRfc6265CookieProcessor"
